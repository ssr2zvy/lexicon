use std::fmt;

use lexicon_core::session::{
    RuntimeContextError, SessionFailureCode, SessionIdentity, SessionLeaseError, SessionState,
    SessionStoreError,
};

#[derive(Debug)]
pub enum PreparedLaunchConstructionError {
    SessionRecord(SessionStoreError),
    SessionPaths(RuntimeContextError),
    RuntimeContext(RuntimeContextError),
    OwnedPublication(SessionStoreError),
}

impl fmt::Display for PreparedLaunchConstructionError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::SessionRecord(error) => write!(f, "failed to load the claimed session record: {error}"),
            Self::SessionPaths(error) => write!(f, "failed to build session paths: {error}"),
            Self::RuntimeContext(error) => write!(f, "failed to encode runtime context: {error}"),
            Self::OwnedPublication(error) => write!(f, "failed to publish complete operator ownership: {error}"),
        }
    }
}

impl std::error::Error for PreparedLaunchConstructionError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::SessionRecord(error) => Some(error),
            Self::SessionPaths(error) | Self::RuntimeContext(error) => Some(error),
            Self::OwnedPublication(error) => Some(error),
        }
    }
}

#[derive(Debug)]
pub struct PreparedLaunchReconciliationError {
    pub transition: Box<SessionStoreError>,
    pub summary_rebuild: Option<Box<SessionStoreError>>,
}

impl fmt::Display for PreparedLaunchReconciliationError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "terminal transition failed: {}", self.transition)?;
        if let Some(error) = &self.summary_rebuild {
            write!(f, "; root-summary recovery also failed: {error}")?;
        }
        Ok(())
    }
}

impl std::error::Error for PreparedLaunchReconciliationError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        Some(self.transition.as_ref())
    }
}

/// Errors arising from session coordination operations.
#[derive(Debug)]
pub enum SessionCoordinationError {
    /// A coordination failure tied to an already validated durable session.
    /// `failure_code` is present only when that exact terminal failure was
    /// committed to the detailed record.
    SessionBound {
        session: SessionIdentity,
        failure_code: Option<SessionFailureCode>,
        source: Box<SessionCoordinationError>,
    },
    /// Session store operation failed.
    Store(SessionStoreError),
    /// Session lease operation failed.
    Lease(SessionLeaseError),
    /// A live session is already in progress; cannot start a new one.
    LiveSessionAlreadyActive,
    /// The current session is in a failed state that has not been abandoned.
    UnresolvedFailure,
    /// Resume is not available because there is no prior resumable session.
    ResumeUnavailable,
    /// Resume is not available for this operation type.
    ResumeNotSupportedForOperation,
    /// The session targeted for abandonment is in a state that cannot be abandoned.
    AbandonmentUnavailable { reason: &'static str },
    /// Failed to encode the runtime context document.
    ContextEncoding(RuntimeContextError),
    /// Session operation root could not be derived from the given paths.
    InvalidOperationRoot(RuntimeContextError),
    /// A durable Prepared session (and, for handoff claims, successor authority)
    /// was acquired, but constructing the in-memory launch owner failed. The
    /// session was reconciled while the exact lease remained live.
    PreparedLaunchConstruction {
        construction: PreparedLaunchConstructionError,
        session_reconciliation: Option<Box<PreparedLaunchReconciliationError>>,
        authority_reconciliation: Option<Box<SessionStoreError>>,
    },
    /// Background-execution handoff: the referenced session is no longer
    /// `Prepared` (some other process already advanced or terminated it), so
    /// `resume_prepared_launch` refuses to take ownership of it.
    HandoffSessionNotPrepared { actual_state: SessionState },
    /// The durable reservation does not belong to the project/runtime/operation
    /// re-admitted by this operator host.
    HandoffSessionIdentityMismatch,
    Handoff(lexicon_core::session::HandoffProtocolError),
}

impl SessionCoordinationError {
    pub(crate) fn bind_session(self, session: SessionIdentity) -> Self {
        match self {
            already @ Self::SessionBound { .. } => already,
            source => Self::SessionBound {
                session,
                failure_code: None,
                source: Box::new(source),
            },
        }
    }

    pub(crate) fn bind_terminal_failure(
        self,
        session: SessionIdentity,
        failure_code: SessionFailureCode,
    ) -> Self {
        match self {
            Self::SessionBound { source, .. } => Self::SessionBound {
                session,
                failure_code: Some(failure_code),
                source,
            },
            source => Self::SessionBound {
                session,
                failure_code: Some(failure_code),
                source: Box::new(source),
            },
        }
    }

    pub(crate) fn validated_session(&self) -> Option<&SessionIdentity> {
        match self {
            Self::SessionBound { session, .. } => Some(session),
            _ => None,
        }
    }

    pub(crate) fn authoritative_failure_code(&self) -> Option<SessionFailureCode> {
        match self {
            Self::SessionBound { failure_code, .. } => *failure_code,
            _ => None,
        }
    }

    pub(crate) fn into_unbound(self) -> Self {
        match self {
            Self::SessionBound { source, .. } => (*source).into_unbound(),
            source => source,
        }
    }
}

pub(crate) fn detailed_session_store_transition_committed(
    error: &SessionStoreError,
) -> bool {
    error.committed_session_failure().is_some()
        || match error {
            SessionStoreError::PartialCommit {
                record_error: None,
                ..
            } => true,
            SessionStoreError::StaleOwnershipReconciliationFailed(source) => {
                detailed_session_store_transition_committed(source)
            }
            _ => false,
        }
}

pub(crate) fn detailed_session_transition_committed(
    error: &SessionCoordinationError,
) -> bool {
    error.authoritative_failure_code().is_some()
        || match error {
            SessionCoordinationError::Store(source) => {
                detailed_session_store_transition_committed(source)
            }
            SessionCoordinationError::SessionBound { source, .. } => {
                detailed_session_transition_committed(source)
            }
            _ => false,
        }
}

impl fmt::Display for SessionCoordinationError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::SessionBound { source, .. } => write!(f, "{source}"),
            Self::Store(err) => write!(f, "session store error: {err}"),
            Self::Lease(err) => write!(f, "session lease error: {err}"),
            Self::LiveSessionAlreadyActive => {
                f.write_str("a live session is already active; cannot start a new session")
            }
            Self::UnresolvedFailure => {
                f.write_str("current session is in a failed state; use --abandon-past-fail to abandon it before retrying")
            }
            Self::ResumeUnavailable => {
                f.write_str("no prior resumable session is available")
            }
            Self::ResumeNotSupportedForOperation => {
                f.write_str("resume is only supported for acquisition sessions")
            }
            Self::AbandonmentUnavailable { reason } => {
                write!(f, "session abandonment unavailable: {reason}")
            }
            Self::ContextEncoding(err) => {
                write!(f, "runtime context encoding error: {err}")
            }
            Self::InvalidOperationRoot(err) => {
                write!(f, "invalid session operation root: {err}")
            }
            Self::PreparedLaunchConstruction {
                construction,
                session_reconciliation,
                authority_reconciliation,
            } => {
                write!(f, "prepared launch construction failed: {construction}")?;
                if let Some(error) = session_reconciliation {
                    write!(f, "; terminal session reconciliation failed: {error}")?;
                }
                if let Some(error) = authority_reconciliation {
                    write!(f, "; handoff-authority reconciliation failed: {error}")?;
                }
                Ok(())
            }
            Self::HandoffSessionNotPrepared { actual_state } => write!(
                f,
                "background handoff session is no longer Prepared (found {actual_state:?}); it may have already been claimed or terminated"
            ),
            Self::HandoffSessionIdentityMismatch => f.write_str(
                "background handoff session identity does not match the admitted operator host",
            ),
            Self::Handoff(err) => write!(f, "background handoff coordination failed: {err}"),
        }
    }
}

impl std::error::Error for SessionCoordinationError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::SessionBound { source, .. } => Some(source.as_ref()),
            Self::Store(err) => Some(err),
            Self::Handoff(err) => Some(err),
            Self::Lease(err) => Some(err),
            Self::LiveSessionAlreadyActive
            | Self::UnresolvedFailure
            | Self::ResumeUnavailable
            | Self::ResumeNotSupportedForOperation
            | Self::AbandonmentUnavailable { .. }
            | Self::HandoffSessionNotPrepared { .. }
            | Self::HandoffSessionIdentityMismatch => None,
            Self::ContextEncoding(err) => Some(err),
            Self::InvalidOperationRoot(err) => Some(err),
            Self::PreparedLaunchConstruction { construction, .. } => Some(construction),
        }
    }
}
