use std::path::PathBuf;

use lexicon_core::session::{
    HandoffAuthorityRecordV1, HandoffClaimProof, HandoffTokenDigest, OperatorIdentityV1,
    NewSessionRecord, ProjectIdentity, RuntimeContextPaths, SafeSessionFailure, SessionIdentity,
    SessionLease, SessionOperation, SessionOperationRoot, SessionRecordV1, SessionState,
    SessionStore, SessionTransition, encode_runtime_context_with_lease,
};
use lexicon_core::runtime::{OwnedRuntimeIdentity, RuntimeExecutionMode, RuntimeSupervisionMode};

use super::error::{
    PreparedLaunchConstructionError, PreparedLaunchReconciliationError, SessionCoordinationError,
    detailed_session_store_transition_committed,
};
use super::selection::{
    CurrentSessionStatus, assess_current_session, validate_resume_selection,
    validate_run_selection,
};

// ---------------------------------------------------------------------------
// PreparedSessionLaunch
// ---------------------------------------------------------------------------

/// The result of a successful session preparation by the coordinator.
///
/// Retains:
/// - The `PreparedSession` record.
/// - The exclusive parent-side lease on the session.
/// - The runtime context environment document (JSON string for the child process).
/// - The operation root needed for post-launch session reconciliation.
///
/// The parent lease must be held through child startup, child execution,
/// and terminal reconciliation.
///
/// Do not drop this value before the child has started unless the preparation
/// should be marked as failed.
pub struct PreparedSessionLaunch {
    record: SessionRecordV1,
    lease: SessionLease,
    context_document: String,
    operation_root: PathBuf,
}

impl PreparedSessionLaunch {
    pub fn record(&self) -> &SessionRecordV1 {
        &self.record
    }

    /// The generated session identity for this launch.
    pub fn session(&self) -> &SessionIdentity {
        self.record.session()
    }

    /// The JSON string to set as `LEXICON_RUNTIME_CONTEXT_V1` in the child environment.
    pub fn context_document(&self) -> &str {
        &self.context_document
    }

    /// The operation root directory, needed to reload the session record after child termination.
    pub fn operation_root(&self) -> &std::path::Path {
        &self.operation_root
    }

    pub(crate) fn lease(&self) -> &SessionLease { &self.lease }

    /// Mark the prepared session as failed, releasing the lease.
    ///
    /// Use this if the child process launch fails before the session is handed off.
    pub fn fail_launch(
        self,
        store: &SessionStore,
        failure: SafeSessionFailure,
    ) -> Result<SessionRecordV1, SessionCoordinationError> {
        let session_id = self.record.session().clone();
        let revision = self.record.revision();
        let transition_result = store
            .transition_as_lease_owner(&session_id, &self.lease, revision, SessionTransition::ToFailed { failure })
            .map_err(SessionCoordinationError::Store);
        drop(self);
        transition_result
    }

    pub fn reserve_handoff(
        &self,
        store: &SessionStore,
        token_digest: HandoffTokenDigest,
        expected_operator: OperatorIdentityV1,
        expires_at_unix_nanos: u64,
    ) -> Result<HandoffAuthorityRecordV1, SessionCoordinationError> {
        store.reserve_handoff(self.session(), &self.lease, token_digest, expected_operator, expires_at_unix_nanos)
            .map_err(SessionCoordinationError::Handoff)
    }

    pub(crate) fn revoke_handoff(
        &self,
        store: &SessionStore,
        epoch: u64,
        reason: lexicon_core::session::HandoffRevocationReasonV1,
    ) -> Result<HandoffAuthorityRecordV1, SessionCoordinationError> {
        store.revoke_handoff(self.session(), &self.lease, epoch, reason)
            .map_err(SessionCoordinationError::Handoff)
    }

    /// Validate that the authenticated successor is ready while the initiating
    /// lease is still held. Only the following reserved release may drop it.
    pub fn validate_reserved_handoff_for_release(
        &self,
        store: &SessionStore,
        epoch: u64,
        token: &HandoffToken,
        expected_operator: &OperatorIdentityV1,
    ) -> Result<(), SessionCoordinationError> {
        store.validate_ready_handoff_for_release(
            self.session(),
            &self.lease,
            epoch,
            token,
            expected_operator,
        )
            .map_err(SessionCoordinationError::Handoff)
    }

    pub fn release_reserved_handoff(self) -> SessionRecordV1 {
        let PreparedSessionLaunch { record, lease, .. } = self;
        drop(lease);
        record
    }
}

impl std::fmt::Debug for PreparedSessionLaunch {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("PreparedSessionLaunch")
            .field("session", self.record.session())
            .field("operation", &self.record.operation())
            .finish_non_exhaustive()
    }
}

// ---------------------------------------------------------------------------
// SessionCoordinator
// ---------------------------------------------------------------------------

/// Framework-owned coordinator for session preparation and reconciliation.
///
/// Operates on already validated project, source, protocol, operation, runtime,
/// and filesystem identities.
///
/// Does not launch processes.
pub struct SessionCoordinator {
    project: ProjectIdentity,
    runtime: OwnedRuntimeIdentity,
    operation: SessionOperation,
    store: SessionStore,
    /// Absolute project root directory, used when building per-session context paths.
    project_root: PathBuf,
    /// Absolute configured source root admitted by project discovery.
    sources_root: PathBuf,
    /// Absolute protocol root directory (e.g. `<sources_root>/<source>/http`), used when
    /// building per-session context paths.
    protocol_root: PathBuf,
}

impl SessionCoordinator {
    /// Construct a coordinator from validated identities and paths.
    ///
    /// `operation_root` is the session store root (e.g. `protocol_root/get-raw-data` or
    /// `protocol_root/process-data`). The validated project, configured-source, and
    /// protocol roots are retained to derive per-session `RuntimeContextPaths`.
    pub fn new(
        project: ProjectIdentity,
        runtime: OwnedRuntimeIdentity,
        operation: SessionOperation,
        operation_root: SessionOperationRoot,
        project_root: PathBuf,
        sources_root: PathBuf,
        protocol_root: PathBuf,
    ) -> Result<Self, SessionCoordinationError> {
        let store = SessionStore::open(operation_root).map_err(SessionCoordinationError::Store)?;
        Ok(Self {
            project,
            runtime,
            operation,
            store,
            project_root,
            sources_root,
            protocol_root,
        })
    }

    /// Prepare a new run session.
    ///
    /// - Rejects an actively owned Prepared or Running current session.
    /// - Rejects an unresolved Failed current session unless abandonment was applied.
    /// - Generates a new session identity.
    /// - Creates session.json in Prepared state.
    /// - Updates session_status.json.
    /// - Acquires and retains the lease in the returned launch value.
    pub fn prepare_run(
        &self,
        supervision: RuntimeSupervisionMode,
    ) -> Result<PreparedSessionLaunch, SessionCoordinationError> {
        let selection = self.store.acquire_selection_lease().map_err(SessionCoordinationError::Store)?;
        let current = self.current_session_status()?;
        validate_run_selection(&current)?;

        self.create_prepared_launch(RuntimeExecutionMode::Run, supervision, &selection)
    }

    /// Prepare a resume session.
    ///
    /// - Requires acquisition operation.
    /// - Requires a prior resumable (failed or stale-reconciled) session.
    /// - Rejects a currently live owned session.
    /// - Creates a new Prepared record with execution mode Resume.
    pub fn prepare_resume(
        &self,
        supervision: RuntimeSupervisionMode,
    ) -> Result<PreparedSessionLaunch, SessionCoordinationError> {
        let selection = self.store.acquire_selection_lease().map_err(SessionCoordinationError::Store)?;
        let current = self.current_session_status()?;
        validate_resume_selection(self.operation, &current)?;

        self.create_prepared_launch(RuntimeExecutionMode::Resume, supervision, &selection)
    }

    /// Abandon the current failed session.
    ///
    /// This implements the `--abandon-past-fail` CLI flag policy.
    ///
    /// Only abandons failed sessions. Stale Prepared or Running sessions are
    /// reconciled to Failed before this policy is evaluated.
    ///
    /// Will not abandon:
    /// - A live leased session.
    /// - A succeeded session.
    /// - An already abandoned session.
    /// - A session belonging to another project, source, protocol, or operation.
    pub fn abandon_current_failure(
        &self,
    ) -> Result<SessionRecordV1, SessionCoordinationError> {
        let _selection = self.store.acquire_selection_lease().map_err(SessionCoordinationError::Store)?;
        let current = self.current_session_status()?;

        match current {
            CurrentSessionStatus::Failed(record) => {
                let session_id = record.session().clone();
                let revision = record.revision();
                let lease = self.store.acquire_lease(&session_id).map_err(SessionCoordinationError::Lease)?;
                self.store
                    .transition_as_lease_owner(&session_id, &lease, revision, SessionTransition::ToAbandoned)
                    .map_err(|error| {
                        SessionCoordinationError::Store(error).bind_session(session_id)
                    })
            }
            CurrentSessionStatus::Live(_) => {
                Err(SessionCoordinationError::AbandonmentUnavailable {
                    reason: "session is currently live and cannot be abandoned",
                })
            }
            CurrentSessionStatus::Succeeded => {
                Err(SessionCoordinationError::AbandonmentUnavailable {
                    reason: "succeeded sessions cannot be abandoned",
                })
            }
            CurrentSessionStatus::Abandoned => {
                Err(SessionCoordinationError::AbandonmentUnavailable {
                    reason: "session is already abandoned",
                })
            }
            CurrentSessionStatus::None => {
                Err(SessionCoordinationError::AbandonmentUnavailable {
                    reason: "no current session to abandon",
                })
            }
        }
    }

    /// Reconcile a potentially stale current session.
    ///
    /// If the current session owner is no longer alive, transitions the durable
    /// record to Failed with StaleOwnership and updates the root summary.
    ///
    /// Returns `Ok(Some(record))` if reconciliation occurred, `Ok(None)` if no
    /// reconciliation was needed.
    pub fn reconcile_stale_current_session(
        &self,
    ) -> Result<Option<SessionRecordV1>, SessionCoordinationError> {
        let history = self
            .store
            .load_session_history()
            .map_err(SessionCoordinationError::Store)?;
        let mut latest_reconciled = None;
        for record in history {
            if !matches!(record.state(), SessionState::Prepared | SessionState::Running) {
                continue;
            }
            let session = record.session().clone();
            if let Some(reconciled) = self
                .store
                .reconcile_stale_current_session(record.session())
                .map_err(|error| {
                    let terminal_persisted =
                        detailed_session_store_transition_committed(&error);
                    let error = SessionCoordinationError::Store(error);
                    if terminal_persisted {
                        error.bind_terminal_failure(
                            session.clone(),
                            lexicon_core::session::SessionFailureCode::StaleOwnership,
                        )
                    } else {
                        error.bind_session(session.clone())
                    }
                })?
            {
                latest_reconciled = Some(reconciled);
            }
        }
        Ok(latest_reconciled)
    }

    pub(crate) fn current_session_status(
        &self,
    ) -> Result<CurrentSessionStatus, SessionCoordinationError> {
        assess_current_session(
            &self.store,
            &self.project,
            &self.runtime,
            self.operation,
        )
    }

    /// Expose the underlying store for post-launch session reconciliation.
    pub fn store(&self) -> &SessionStore {
        &self.store
    }

    pub fn mark_handoff_ready(
        &self,
        proof: &HandoffClaimProof,
    ) -> Result<HandoffAuthorityRecordV1, SessionCoordinationError> {
        self.store.mark_handoff_ready(proof).map_err(SessionCoordinationError::Handoff)
    }

    /// Bind a background reservation to the exact identity re-admitted by the
    /// operator host before it acknowledges readiness.
    pub fn validate_reserved_session_identity(
        &self,
        session: &SessionIdentity,
    ) -> Result<SessionRecordV1, SessionCoordinationError> {
        let record = self.store.load(session).map_err(SessionCoordinationError::Store)?;
        self.validate_handoff_record_identity(&record)?;
        Ok(record)
    }

    fn validate_handoff_record_identity(
        &self,
        record: &SessionRecordV1,
    ) -> Result<(), SessionCoordinationError> {
        if record.state() != SessionState::Prepared {
            return Err(SessionCoordinationError::HandoffSessionNotPrepared {
                actual_state: record.state(),
            });
        }
        if record.project() != &self.project
            || record.runtime() != &self.runtime
            || record.operation() != self.operation
            || record.supervision_mode() != RuntimeSupervisionMode::Background
        {
            return Err(SessionCoordinationError::HandoffSessionIdentityMismatch);
        }
        Ok(())
    }

    pub fn claim_reserved_handoff(
        &self,
        proof: &HandoffClaimProof,
    ) -> Result<PreparedSessionLaunch, SessionCoordinationError> {
        let session_id = SessionIdentity::new(proof.session_id.clone())
            .map_err(|_| SessionCoordinationError::Handoff(lexicon_core::session::HandoffProtocolError::SessionMismatch))?;
        let pre_claim_record = self.validate_reserved_session_identity(&session_id)?;
        let lease = self.store.acquire_reserved_handoff(proof).map_err(SessionCoordinationError::Store)?;
        let record = match self.store.load(&session_id) {
            Ok(record) => record,
            Err(error) => {
                return Err(self.fail_prepared_launch_construction(
                    pre_claim_record,
                    lease,
                    Some(proof),
                    PreparedLaunchConstructionError::SessionRecord(error),
                ));
            }
        };
        if let Err(identity_error) = self.validate_handoff_record_identity(&record) {
            let cleanup = self.store.revoke_claimed_handoff_as_lease_owner(
                &session_id,
                &lease,
                proof,
                lexicon_core::session::HandoffRevocationReasonV1::OperatorExited,
            );
            drop(lease);
            cleanup.map_err(SessionCoordinationError::Store)?;
            return Err(identity_error);
        }
        let launch = self.finish_prepared_launch(record, lease, Some(proof))?;
        if let Err(error) = self.store.publish_owned_handoff(&launch.lease, proof) {
            let PreparedSessionLaunch { record, lease, .. } = launch;
            return Err(self.fail_prepared_launch_construction(
                record,
                lease,
                Some(proof),
                PreparedLaunchConstructionError::OwnedPublication(error),
            ));
        }
        Ok(launch)
    }

    pub fn revoke_and_recover_handoff(
        &self,
        session_id: &SessionIdentity,
        epoch: u64,
        reason: lexicon_core::session::HandoffRevocationReasonV1,
    ) -> Result<PreparedSessionLaunch, SessionCoordinationError> {
        let pre_recovery_record = self.store.load(session_id).map_err(SessionCoordinationError::Store)?;
        if pre_recovery_record.state() != SessionState::Prepared {
            return Err(SessionCoordinationError::HandoffSessionNotPrepared {
                actual_state: pre_recovery_record.state(),
            });
        }
        let (lease, _) = self.store.revoke_handoff_after_release(session_id, epoch, reason)
            .map_err(SessionCoordinationError::Store)?;
        let record = match self.store.load(session_id) {
            Ok(record) => record,
            Err(error) => {
                return Err(self.fail_prepared_launch_construction(
                    pre_recovery_record,
                    lease,
                    None,
                    PreparedLaunchConstructionError::SessionRecord(error),
                ));
            }
        };
        if record.state() != SessionState::Prepared {
            return Err(SessionCoordinationError::HandoffSessionNotPrepared { actual_state: record.state() });
        }
        self.finish_prepared_launch(record, lease, None)
    }

    pub fn fence_ready_handoff(
        &self,
        session_id: &SessionIdentity,
        epoch: u64,
        token: &lexicon_core::session::HandoffToken,
        expected_operator: &OperatorIdentityV1,
        reason: lexicon_core::session::HandoffRevocationReasonV1,
    ) -> Result<lexicon_core::session::HandoffFenceOutcome, SessionCoordinationError> {
        self.store.fence_ready_handoff(session_id, epoch, token, expected_operator, reason)
            .map_err(SessionCoordinationError::Handoff)
    }

    pub fn recover_handoff_after_operator_death(
        &self,
        session_id: &SessionIdentity,
        epoch: u64,
        expected_operator: &OperatorIdentityV1,
    ) -> Result<PreparedSessionLaunch, SessionCoordinationError> {
        let pre_recovery_record = self.store.load(session_id).map_err(SessionCoordinationError::Store)?;
        if pre_recovery_record.state() != SessionState::Prepared {
            return Err(SessionCoordinationError::HandoffSessionNotPrepared {
                actual_state: pre_recovery_record.state(),
            });
        }
        let (lease, _) = self.store.recover_handoff_after_operator_death(
            session_id, epoch, expected_operator, lexicon_core::session::HandoffRevocationReasonV1::OperatorExited,
        ).map_err(SessionCoordinationError::Store)?;
        let record = match self.store.load(session_id) {
            Ok(record) => record,
            Err(error) => {
                return Err(self.fail_prepared_launch_construction(
                    pre_recovery_record,
                    lease,
                    None,
                    PreparedLaunchConstructionError::SessionRecord(error),
                ));
            }
        };
        if record.state() != SessionState::Prepared {
            return Err(SessionCoordinationError::HandoffSessionNotPrepared { actual_state: record.state() });
        }
        self.finish_prepared_launch(record, lease, None)
    }

    pub fn verify_live_owned_handoff(
        &self,
        session_id: &SessionIdentity,
        epoch: u64,
        token: &lexicon_core::session::HandoffToken,
        expected_operator: &OperatorIdentityV1,
    ) -> Result<bool, SessionCoordinationError> {
        self.store
            .verify_live_owned_handoff(session_id, epoch, token, expected_operator)
            .map_err(SessionCoordinationError::Store)
    }

    // ------------------------------------------------------------------
    // Internal helpers
    // ------------------------------------------------------------------

    fn create_prepared_launch(
        &self,
        execution_mode: RuntimeExecutionMode,
        supervision: RuntimeSupervisionMode,
        selection: &lexicon_core::session::OperationSelectionLease,
    ) -> Result<PreparedSessionLaunch, SessionCoordinationError> {
        let input = NewSessionRecord {
            project: self.project.clone(),
            runtime: self.runtime.clone(),
            operation: self.operation,
            execution_mode,
            supervision_mode: supervision,
        };

        let prepared = self
            .store
            .create_prepared_while_selected(input, selection)
            .map_err(project_session_store_error)?;

        let (record, lease) = prepared.into_owned_parts();
        self.finish_prepared_launch(record, lease, None)
    }

    fn finish_prepared_launch(
        &self,
        record: SessionRecordV1,
        lease: SessionLease,
        claimed_handoff: Option<&HandoffClaimProof>,
    ) -> Result<PreparedSessionLaunch, SessionCoordinationError> {
        let session_id = record.session().clone();
        let construction = build_session_paths(
            &self.project_root,
            &self.sources_root,
            &self.protocol_root,
            self.runtime.source_name(),
            self.operation,
            &session_id,
        )
        .map_err(PreparedLaunchConstructionError::SessionPaths)
        .and_then(|session_paths| {
            encode_runtime_context_with_lease(
                &self.project,
                &self.runtime,
                &session_id,
                &session_paths,
                lease.identity(),
            )
            .map_err(PreparedLaunchConstructionError::RuntimeContext)
        });

        match construction {
            Ok(context_document) => Ok(PreparedSessionLaunch {
                record,
                lease,
                context_document,
                operation_root: self.store.operation_root().path().to_path_buf(),
            }),
            Err(construction) => Err(self.fail_prepared_launch_construction(
                record,
                lease,
                claimed_handoff,
                construction,
            )),
        }
    }

    fn fail_prepared_launch_construction(
        &self,
        record: SessionRecordV1,
        lease: SessionLease,
        claimed_handoff: Option<&HandoffClaimProof>,
        construction: PreparedLaunchConstructionError,
    ) -> SessionCoordinationError {
        let session_id = record.session().clone();
        // The session is already durably discoverable. Retain the exact
        // physical authority through both cleanup operations so no stale
        // observer can race this failure reconciliation.
        let transition_result = self.store.transition_as_lease_owner(
            &session_id,
            &lease,
            record.revision(),
            SessionTransition::ToFailed {
                failure: SafeSessionFailure::runtime_failure(
                    lexicon_core::session::SessionFailureCode::RuntimeInitializationFailed,
                    Some("framework failed to construct a complete supervised session owner".into()),
                ),
            },
        );
        let terminal_persisted = transition_result.as_ref().map_or_else(
            |error| detailed_session_store_transition_committed(error),
            |_| true,
        );
        let session_reconciliation = transition_result.err().map(|transition| {
            let summary_rebuild = self.store
                .rebuild_status_from_record(&session_id, &lease)
                .err()
                .map(Box::new);
            Box::new(PreparedLaunchReconciliationError {
                transition: Box::new(transition),
                summary_rebuild,
            })
        });
        let authority_reconciliation = claimed_handoff.and_then(|proof| {
            let result = self.store.revoke_claimed_handoff_as_lease_owner(
                &session_id,
                &lease,
                proof,
                lexicon_core::session::HandoffRevocationReasonV1::OperatorExited,
            );
            result.err().map(Box::new)
        });
        drop(lease);
        let error = SessionCoordinationError::PreparedLaunchConstruction {
            construction,
            session_reconciliation,
            authority_reconciliation,
        };
        if terminal_persisted {
            error.bind_terminal_failure(
                session_id,
                lexicon_core::session::SessionFailureCode::RuntimeInitializationFailed,
            )
        } else {
            error.bind_session(session_id)
        }
    }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fn project_session_store_error(
    error: lexicon_core::session::SessionStoreError,
) -> SessionCoordinationError {
    let committed = error
        .committed_session_failure()
        .map(|(session, code)| (session.clone(), code));
    let error = SessionCoordinationError::Store(error);
    match committed {
        Some((session, code)) => error.bind_terminal_failure(session, code),
        None => error,
    }
}

/// Build `RuntimeContextPaths` scoped to a specific session.
fn build_session_paths(
    project_root: &std::path::Path,
    sources_root: &std::path::Path,
    protocol_root: &std::path::Path,
    source_name: &str,
    operation: SessionOperation,
    session: &SessionIdentity,
) -> Result<RuntimeContextPaths, lexicon_core::session::RuntimeContextError> {
    let op = operation.to_runtime_operation();

    let op_name = match op {
        lexicon_core::runtime::RuntimeOperation::Acquisition => "get-raw-data",
        lexicon_core::runtime::RuntimeOperation::Processing => "process-data",
        _ => unreachable!("unknown RuntimeOperation variant"),
    };
    let operation_root = protocol_root.join(op_name);
    let session_directory = operation_root.join("sessions").join(session.id());
    let raw_data_directory = protocol_root.join("data/raw");
    let processed_data_directory = protocol_root.join("data/processed");
    let source_state_directory = match op {
        lexicon_core::runtime::RuntimeOperation::Acquisition => {
            Some(operation_root.join("state"))
        }
        lexicon_core::runtime::RuntimeOperation::Processing => None,
        _ => unreachable!("unknown RuntimeOperation variant"),
    };

    RuntimeContextPaths::new(
        project_root.to_path_buf(),
        sources_root.to_path_buf(),
        protocol_root.to_path_buf(),
        source_name,
        operation_root,
        session_directory,
        raw_data_directory,
        processed_data_directory,
        source_state_directory,
        op,
        session,
    )
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use std::path::PathBuf;

    use lexicon_core::runtime::{OwnedRuntimeIdentity, RuntimeSupervisionMode};
    use lexicon_core::session::{
        HandoffClaimProof, HandoffToken, OperatorIdentityV1, SessionFailureCode, SessionState,
        SessionTransition,
    };

    use super::SessionCoordinationError;
    use crate::data::request::DataOperation;
    use crate::data::test_support::{build_fake_coordinator, build_fake_project, open_store};

    #[test]
    fn launch_construction_failure_is_terminal_before_lease_release() {
        let project = build_fake_project("construction-failure-source");
        let mut coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
        coordinator.project_root = PathBuf::from("relative-project-root");
        let store = open_store(&project, DataOperation::Acquisition);

        let error = coordinator
            .prepare_run(RuntimeSupervisionMode::Foreground)
            .unwrap_err();
        let SessionCoordinationError::SessionBound {
            failure_code,
            source,
            ..
        } = error else {
            panic!("construction failure lost its durable session identity");
        };
        assert_eq!(failure_code, Some(SessionFailureCode::RuntimeInitializationFailed));
        assert!(matches!(
            *source,
            SessionCoordinationError::PreparedLaunchConstruction {
                session_reconciliation: None,
                authority_reconciliation: None,
                ..
            }
        ));

        let summary = store.load_status().unwrap().unwrap();
        let session = summary.current_session().unwrap();
        let record = store.load(session).unwrap();
        assert_eq!(record.state(), SessionState::Failed);
        assert_eq!(summary.current_state(), Some(SessionState::Failed));
        assert_eq!(summary.revision(), record.revision());
    }

    #[test]
    fn concurrent_prepare_is_fenced_while_successor_reservation_is_active() {
        let project = build_fake_project("example-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
        let store = open_store(&project, DataOperation::Acquisition);

        let prepared = coordinator
            .prepare_run(RuntimeSupervisionMode::Background)
            .unwrap();
        let handed_off_session = prepared.session().clone();
        let token = HandoffToken::generate().unwrap();
        let reserved_operator = OperatorIdentityV1 {
            instance_nonce: "expected-instance".into(),
            process_id: 0,
        };
        let reservation = store.reserve_handoff(
            &handed_off_session,
            &prepared.lease,
            token.digest(),
            reserved_operator.clone(),
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos() as u64 + 30_000_000_000,
        ).unwrap();
        let proof = HandoffClaimProof {
            session_id: handed_off_session.id().to_owned(),
            epoch: reservation.epoch,
            token,
            operator: OperatorIdentityV1 {
                instance_nonce: reserved_operator.instance_nonce,
                process_id: 42,
            },
        };
        store.mark_handoff_ready(&proof).unwrap();
        prepared
            .validate_reserved_handoff_for_release(
                &store,
                reservation.epoch,
                &proof.token,
                &proof.operator,
            )
            .unwrap();
        prepared.release_reserved_handoff();

        // Simulates an unrelated concurrent `lexicon data` invocation racing the handoff.
        let racing = coordinator.prepare_run(RuntimeSupervisionMode::Foreground);

        assert!(matches!(
            racing,
            Err(SessionCoordinationError::SessionBound { source, .. })
                if matches!(*source, SessionCoordinationError::LiveSessionAlreadyActive)
        ));
        assert_eq!(
            store.load(&handed_off_session).unwrap().state(),
            SessionState::Prepared
        );
    }

    #[test]
    fn terminal_record_remains_live_until_supervisor_releases_lease() {
        let project = build_fake_project("terminal-lease-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
        let store = open_store(&project, DataOperation::Acquisition);
        let prepared = coordinator
            .prepare_run(RuntimeSupervisionMode::Foreground)
            .unwrap();
        let running = store
            .transition_as_lease_owner(
                prepared.session(),
                &prepared.lease,
                prepared.record().revision(),
                SessionTransition::ToRunning,
            )
            .unwrap();
        store
            .transition_as_lease_owner(
                prepared.session(),
                &prepared.lease,
                running.revision(),
                SessionTransition::ToSucceeded,
            )
            .unwrap();

        assert!(matches!(
            coordinator.prepare_run(RuntimeSupervisionMode::Foreground),
            Err(SessionCoordinationError::SessionBound { source, .. })
                if matches!(*source, SessionCoordinationError::LiveSessionAlreadyActive)
        ));

        drop(prepared);
        let successor = coordinator
            .prepare_run(RuntimeSupervisionMode::Foreground)
            .expect("terminal session is available after supervisor lease release");
        drop(successor);
    }

    #[test]
    fn operator_host_rejects_prepared_session_from_different_runtime_identity() {
        let project = build_fake_project("handoff-identity-source");
        let mut coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
        let prepared = coordinator
            .prepare_run(RuntimeSupervisionMode::Background)
            .unwrap();
        coordinator.runtime = OwnedRuntimeIdentity::http_acquisition(
            "replacement-source",
            lexicon_core::http::HTTP_SOURCE_CONTRACT_VERSION,
        );

        assert!(matches!(
            coordinator.validate_reserved_session_identity(prepared.session()),
            Err(SessionCoordinationError::HandoffSessionIdentityMismatch)
        ));
    }

    #[test]
    fn expired_ready_handoff_cannot_authorize_initiating_lease_release() {
        let project = build_fake_project("expired-ready-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
        let store = open_store(&project, DataOperation::Acquisition);
        let prepared = coordinator
            .prepare_run(RuntimeSupervisionMode::Background)
            .unwrap();
        let token = HandoffToken::generate().unwrap();
        let reserved_operator = OperatorIdentityV1 {
            instance_nonce: "expiring-operator".into(),
            process_id: 0,
        };
        let expires_at = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos() as u64
            + 50_000_000;
        let reservation = prepared
            .reserve_handoff(
                &store,
                token.digest(),
                reserved_operator.clone(),
                expires_at,
            )
            .unwrap();
        let proof = HandoffClaimProof {
            session_id: prepared.session().id().to_owned(),
            epoch: reservation.epoch,
            token,
            operator: OperatorIdentityV1 {
                instance_nonce: reserved_operator.instance_nonce,
                process_id: 42,
            },
        };
        store.mark_handoff_ready(&proof).unwrap();
        std::thread::sleep(std::time::Duration::from_millis(75));

        assert!(matches!(
            prepared.validate_reserved_handoff_for_release(
                &store,
                reservation.epoch,
                &proof.token,
                &proof.operator,
            ),
            Err(SessionCoordinationError::Handoff(
                lexicon_core::session::HandoffProtocolError::Expired
            ))
        ));
    }

    #[test]
    fn missing_root_summary_uses_detailed_history_and_reconciles_stale_session() {
        let project = build_fake_project("missing-summary-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
        let store = open_store(&project, DataOperation::Acquisition);
        let prepared = coordinator
            .prepare_run(RuntimeSupervisionMode::Foreground)
            .unwrap();
        let session = prepared.session().clone();
        drop(prepared);
        std::fs::remove_file(store.operation_root().status_path()).unwrap();

        assert!(matches!(
            coordinator.prepare_run(RuntimeSupervisionMode::Foreground),
            Err(SessionCoordinationError::SessionBound { source, .. })
                if matches!(*source, SessionCoordinationError::UnresolvedFailure)
        ));
        assert_eq!(store.load(&session).unwrap().state(), SessionState::Failed);
    }

    #[test]
    fn missing_detailed_record_fails_closed_even_if_summary_references_it() {
        let project = build_fake_project("missing-record-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
        let store = open_store(&project, DataOperation::Acquisition);
        let prepared = coordinator
            .prepare_run(RuntimeSupervisionMode::Foreground)
            .unwrap();
        let session = prepared.session().clone();
        drop(prepared);
        std::fs::remove_file(store.operation_root().session_record_path(&session)).unwrap();

        assert!(matches!(
            coordinator.prepare_run(RuntimeSupervisionMode::Foreground),
            Err(SessionCoordinationError::Store(
                lexicon_core::session::SessionStoreError::CorruptSession(_)
            ))
        ));
    }
}
