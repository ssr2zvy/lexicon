use lexicon_core::session::{
    ProjectIdentity, SessionLeaseState, SessionOperation, SessionRecordV1, SessionState,
    SessionStore,
};
use lexicon_core::runtime::OwnedRuntimeIdentity;

use super::error::{
    SessionCoordinationError, detailed_session_store_transition_committed,
};

/// Result of checking a current session's liveness status.
pub(crate) enum CurrentSessionStatus {
    /// No current session exists.
    None,
    /// The current session completed successfully.
    Succeeded,
    /// The current session was abandoned.
    Abandoned,
    /// A live lease is held by another process; the session is active.
    Live(SessionRecordV1),
    /// The current session failed and has not been abandoned.
    Failed(SessionRecordV1),
}

/// Check the current session's status, reconciling stale ownership as needed.
pub(super) fn assess_current_session(
    store: &SessionStore,
    expected_project: &ProjectIdentity,
    expected_runtime: &OwnedRuntimeIdentity,
    expected_operation: SessionOperation,
) -> Result<CurrentSessionStatus, SessionCoordinationError> {
    let mut history = store
        .load_session_history()
        .map_err(SessionCoordinationError::Store)?;

    // Physical ownership is a global operation-level contention barrier. Check
    // every durable record before compatibility filtering so a newer runtime or
    // otherwise incompatible live supervisor cannot be ignored.
    for record in &history {
        if matches!(
            store
                .inspect_lease_state(record.session())
                .map_err(|error| {
                    SessionCoordinationError::Lease(error)
                        .bind_session(record.session().clone())
                })?,
            SessionLeaseState::Owned
        ) {
            return Ok(CurrentSessionStatus::Live(record.clone()));
        }
    }

    // Reconcile every unowned nonterminal record before choosing policy. A
    // reserved handoff can still prevent acquisition; in that case the record
    // remains nonterminal and is conservatively treated as live below.
    for record in &mut history {
        if matches!(record.state(), SessionState::Prepared | SessionState::Running) {
            let session = record.session().clone();
            if let Some(reconciled) = store
                .reconcile_stale_current_session(&session)
                .map_err(|error| {
                    let terminal_persisted =
                        detailed_session_store_transition_committed(&error);
                    let error = SessionCoordinationError::Store(error);
                    if terminal_persisted {
                        error.bind_terminal_failure(
                            session.clone(),
                            lexicon_core::session::SessionFailureCode::StaleOwnership,
                        )
                    } else {
                        error.bind_session(session.clone())
                    }
                })?
            {
                *record = reconciled;
            } else {
                *record = store
                    .load(&session)
                    .map_err(|error| {
                        SessionCoordinationError::Store(error)
                            .bind_session(session.clone())
                    })?;
                if matches!(record.state(), SessionState::Prepared | SessionState::Running) {
                    return Ok(CurrentSessionStatus::Live(record.clone()));
                }
            }
        }
    }

    let Some(record) = history
        .into_iter()
        .rev()
        .find(|record| {
            record.project() == expected_project
                && record.runtime() == expected_runtime
                && record.operation() == expected_operation
        })
    else {
        return Ok(CurrentSessionStatus::None);
    };

    match record.state() {
        SessionState::Succeeded => Ok(CurrentSessionStatus::Succeeded),
        SessionState::Abandoned => Ok(CurrentSessionStatus::Abandoned),
        SessionState::Failed => Ok(CurrentSessionStatus::Failed(record)),
        SessionState::Prepared | SessionState::Running => {
            Ok(CurrentSessionStatus::Live(record))
        }
    }
}

/// Determine whether a new run session can be started given the current status.
///
/// - Rejects an actively owned `Prepared` or `Running` current session.
/// - Rejects an unresolved `Failed` current session unless abandonment was applied.
/// - Allows a new run after `Succeeded`, `Abandoned`, `None`, or a stale reconciled session.
pub(super) fn validate_run_selection(
    current: &CurrentSessionStatus,
) -> Result<(), SessionCoordinationError> {
    match current {
        CurrentSessionStatus::None
        | CurrentSessionStatus::Succeeded
        | CurrentSessionStatus::Abandoned => Ok(()),
        CurrentSessionStatus::Live(record) => Err(
            SessionCoordinationError::LiveSessionAlreadyActive
                .bind_session(record.session().clone()),
        ),
        CurrentSessionStatus::Failed(record) => Err(
            SessionCoordinationError::UnresolvedFailure
                .bind_session(record.session().clone()),
        ),
    }
}

/// Determine whether a resume session can be started given the current status.
///
/// Requires acquisition operation. Processing resume is not supported.
/// Requires a prior resumable (reconciled or failed) session.
pub(super) fn validate_resume_selection(
    operation: SessionOperation,
    current: &CurrentSessionStatus,
) -> Result<(), SessionCoordinationError> {
    if operation != SessionOperation::Acquisition {
        return Err(SessionCoordinationError::ResumeNotSupportedForOperation);
    }

    match current {
        CurrentSessionStatus::Failed(_) => Ok(()),
        CurrentSessionStatus::Live(record) => Err(
            SessionCoordinationError::LiveSessionAlreadyActive
                .bind_session(record.session().clone()),
        ),
        CurrentSessionStatus::None
        | CurrentSessionStatus::Succeeded
        | CurrentSessionStatus::Abandoned => Err(SessionCoordinationError::ResumeUnavailable),
    }
}
