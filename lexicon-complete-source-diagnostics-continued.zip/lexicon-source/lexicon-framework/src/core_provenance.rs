use sha2::{Digest, Sha256};
use std::collections::BTreeSet;
use std::ffi::OsStr;
use std::fs;
use std::io::{self, Write};
use std::path::{Component, Path, PathBuf};
use thiserror::Error;

const SNAPSHOT_MAGIC: &[u8] = b"LEXICON_CORE_SNAPSHOT_V1\0";
const MAX_SNAPSHOT_BYTES: usize = 64 * 1024 * 1024;
const MAX_SNAPSHOT_FILES: usize = 16_384;
const MAX_PATH_BYTES: usize = 4_096;
const IMPLEMENTATION_PLACEHOLDER: &str = "lexicon-lock-template-implementation";
const RUNNER_PLACEHOLDER: &str = "lexicon-lock-template-runner";

static EMBEDDED_CORE_SNAPSHOT: &[u8] =
    include_bytes!(concat!(env!("OUT_DIR"), "/lexicon_core_snapshot_v1.bin"));
static EMBEDDED_LOCK_TEMPLATE: &str =
    include_str!(concat!(env!("OUT_DIR"), "/lexicon_source_workspace_Cargo.lock"));

pub const EMBEDDED_CORE_PACKAGE: &str = env!("LEXICON_EMBEDDED_CORE_PACKAGE");
pub const EMBEDDED_CORE_VERSION: &str = env!("LEXICON_EMBEDDED_CORE_VERSION");
pub const EMBEDDED_CORE_SHA256: &str = env!("LEXICON_EMBEDDED_CORE_SHA256");
pub const EMBEDDED_CORE_LOCK_SHA256: &str = env!("LEXICON_EMBEDDED_CORE_LOCK_SHA256");
pub const LEXICON_BUILD_REVISION: &str = env!("LEXICON_BUILD_REVISION");
pub const MANAGED_CORE_RELATIVE_PATH: &str = "../vendor/lexicon-core";
pub const CORE_PROVENANCE_FILE: &str = "lexicon-core.provenance.toml";

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct EmbeddedCoreIdentity {
    pub package: &'static str,
    pub version: &'static str,
    pub sha256: &'static str,
    pub lock_sha256: &'static str,
    pub informational_build_revision: Option<&'static str>,
}

pub const EMBEDDED_CORE_IDENTITY: EmbeddedCoreIdentity = EmbeddedCoreIdentity {
    package: EMBEDDED_CORE_PACKAGE,
    version: EMBEDDED_CORE_VERSION,
    sha256: EMBEDDED_CORE_SHA256,
    lock_sha256: EMBEDDED_CORE_LOCK_SHA256,
    informational_build_revision: if LEXICON_BUILD_REVISION.is_empty() {
        None
    } else {
        Some(LEXICON_BUILD_REVISION)
    },
};

#[derive(Debug, Error)]
pub enum CoreProvenanceError {
    #[error("embedded Core snapshot identity is invalid: {0}")]
    InvalidEmbeddedIdentity(&'static str),
    #[error("embedded Core snapshot is malformed: {0}")]
    MalformedSnapshot(String),
    #[error("managed Core source path is unsafe: {0}")]
    UnsafePath(PathBuf),
    #[error("managed Core source contains a symlink or non-regular entry: {0}")]
    UnsupportedEntry(PathBuf),
    #[error("managed Core source I/O failed at {path}: {source}")]
    Io {
        path: PathBuf,
        #[source]
        source: io::Error,
    },
    #[error("managed Core source digest mismatch: expected {expected}, found {actual}")]
    DigestMismatch { expected: String, actual: String },
    #[error("managed Core package identity mismatch: {0}")]
    PackageMismatch(String),
    #[error("managed Core provenance document is invalid: {0}")]
    InvalidProvenance(String),
}

pub fn materialize_embedded_core(vendor_directory: &Path) -> Result<PathBuf, CoreProvenanceError> {
    validate_embedded_identity()?;
    if vendor_directory.exists() {
        return Err(CoreProvenanceError::Io {
            path: vendor_directory.to_path_buf(),
            source: io::Error::new(io::ErrorKind::AlreadyExists, "vendor directory already exists"),
        });
    }
    fs::create_dir_all(vendor_directory).map_err(|source| io_error(vendor_directory, source))?;
    let core_root = vendor_directory.join("lexicon-core");
    fs::create_dir(&core_root).map_err(|source| io_error(&core_root, source))?;

    let result = (|| {
        for (path, contents) in decode_snapshot(EMBEDDED_CORE_SNAPSHOT)? {
            let target = core_root.join(&path);
            if let Some(parent) = target.parent() {
                fs::create_dir_all(parent).map_err(|source| io_error(parent, source))?;
            }
            write_new_file(&target, &contents)?;
        }
        validate_managed_core(&core_root)?;
        let provenance_path = vendor_directory.join(CORE_PROVENANCE_FILE);
        write_new_file(&provenance_path, provenance_document().as_bytes())?;
        validate_provenance_document(&provenance_path)?;
        Ok(core_root.clone())
    })();
    if result.is_err() {
        let _ = fs::remove_dir_all(vendor_directory);
    }
    result
}

pub fn validate_managed_core(core_root: &Path) -> Result<(), CoreProvenanceError> {
    validate_embedded_identity()?;
    let archive = encode_snapshot_directory(core_root)?;
    let actual = hex_sha256(&archive);
    if actual != EMBEDDED_CORE_SHA256 {
        return Err(CoreProvenanceError::DigestMismatch {
            expected: EMBEDDED_CORE_SHA256.to_owned(),
            actual,
        });
    }
    let manifest_path = core_root.join("Cargo.toml");
    let manifest = fs::read_to_string(&manifest_path).map_err(|source| io_error(&manifest_path, source))?;
    let document: toml::Value = toml::from_str(&manifest)
        .map_err(|error| CoreProvenanceError::PackageMismatch(error.to_string()))?;
    let package = document.get("package").ok_or_else(|| CoreProvenanceError::PackageMismatch("missing [package]".to_owned()))?;
    if package.get("name").and_then(toml::Value::as_str) != Some(EMBEDDED_CORE_PACKAGE) {
        return Err(CoreProvenanceError::PackageMismatch("package.name disagrees with embedded identity".to_owned()));
    }
    if package.get("version").and_then(toml::Value::as_str) != Some(EMBEDDED_CORE_VERSION) {
        return Err(CoreProvenanceError::PackageMismatch("package.version disagrees with embedded identity".to_owned()));
    }
    Ok(())
}

pub fn validate_provenance_document(path: &Path) -> Result<(), CoreProvenanceError> {
    let text = fs::read_to_string(path).map_err(|source| io_error(path, source))?;
    let document: toml::Value = toml::from_str(&text)
        .map_err(|error| CoreProvenanceError::InvalidProvenance(error.to_string()))?;
    let exact = |key: &str, expected: &str| {
        document.get(key).and_then(toml::Value::as_str) == Some(expected)
    };
    let table = document.as_table().ok_or_else(|| CoreProvenanceError::InvalidProvenance("document root is not a table".to_owned()))?;
    let mut actual_keys = table.keys().map(String::as_str).collect::<Vec<_>>();
    actual_keys.sort();
    let mut expected_keys = vec![
        "lock_sha256",
        "package",
        "schema_version",
        "sha256",
        "version",
    ];
    if !LEXICON_BUILD_REVISION.is_empty() { expected_keys.push("build_revision"); }
    expected_keys.sort();
    if actual_keys != expected_keys {
        return Err(CoreProvenanceError::InvalidProvenance(format!("unexpected key set: {actual_keys:?}")));
    }
    if document.get("schema_version").and_then(toml::Value::as_integer) != Some(1)
        || !exact("package", EMBEDDED_CORE_PACKAGE)
        || !exact("version", EMBEDDED_CORE_VERSION)
        || !exact("sha256", EMBEDDED_CORE_SHA256)
        || !exact("lock_sha256", EMBEDDED_CORE_LOCK_SHA256)
    {
        return Err(CoreProvenanceError::InvalidProvenance(
            "schema, package, version, or digest disagrees with the installed executable".to_owned(),
        ));
    }
    let recorded_revision = document.get("build_revision").and_then(toml::Value::as_str);
    if recorded_revision != (!LEXICON_BUILD_REVISION.is_empty()).then_some(LEXICON_BUILD_REVISION) {
        return Err(CoreProvenanceError::InvalidProvenance("build revision disagrees with installed executable".to_owned()));
    }
    Ok(())
}

pub fn managed_workspace_lockfile(implementation_package: &str, runner_package: &str) -> Result<String, CoreProvenanceError> {
    validate_embedded_identity()?;
    if implementation_package.is_empty() || runner_package.is_empty() {
        return Err(CoreProvenanceError::MalformedSnapshot("managed package name is empty".to_owned()));
    }
    let implementation_count = EMBEDDED_LOCK_TEMPLATE.matches(IMPLEMENTATION_PLACEHOLDER).count();
    let runner_count = EMBEDDED_LOCK_TEMPLATE.matches(RUNNER_PLACEHOLDER).count();
    if implementation_count != 2 || runner_count != 1 {
        return Err(CoreProvenanceError::MalformedSnapshot(
            "embedded lockfile placeholder shape is invalid".to_owned(),
        ));
    }

    // Replace against the immutable template in one pass. Sequential
    // replacements would inspect text inserted by the first operation, so a
    // valid package name containing the other placeholder could be rewritten
    // a second time and corrupt the generated lockfile.
    let mut remaining = EMBEDDED_LOCK_TEMPLATE;
    let mut output = String::with_capacity(
        EMBEDDED_LOCK_TEMPLATE.len() + implementation_package.len() * 2 + runner_package.len(),
    );
    loop {
        let implementation = remaining.find(IMPLEMENTATION_PLACEHOLDER);
        let runner = remaining.find(RUNNER_PLACEHOLDER);
        let (offset, placeholder, replacement) = match (implementation, runner) {
            (None, None) => break,
            (Some(offset), None) => (offset, IMPLEMENTATION_PLACEHOLDER, implementation_package),
            (None, Some(offset)) => (offset, RUNNER_PLACEHOLDER, runner_package),
            (Some(implementation), Some(runner)) if implementation <= runner => {
                (implementation, IMPLEMENTATION_PLACEHOLDER, implementation_package)
            }
            (Some(_), Some(runner)) => (runner, RUNNER_PLACEHOLDER, runner_package),
        };
        output.push_str(&remaining[..offset]);
        output.push_str(replacement);
        remaining = &remaining[offset + placeholder.len()..];
    }
    output.push_str(remaining);
    Ok(output)
}

fn provenance_document() -> String {
    let mut document = format!(
        "schema_version = 1\npackage = {:?}\nversion = {:?}\nsha256 = {:?}\nlock_sha256 = {:?}\n",
        EMBEDDED_CORE_PACKAGE,
        EMBEDDED_CORE_VERSION,
        EMBEDDED_CORE_SHA256,
        EMBEDDED_CORE_LOCK_SHA256,
    );
    if !LEXICON_BUILD_REVISION.is_empty() {
        document.push_str(&format!("build_revision = {:?}\n", LEXICON_BUILD_REVISION));
    }
    document
}

fn validate_embedded_identity() -> Result<(), CoreProvenanceError> {
    if EMBEDDED_CORE_PACKAGE != "lexicon-core" {
        return Err(CoreProvenanceError::InvalidEmbeddedIdentity("package must equal lexicon-core"));
    }
    if EMBEDDED_CORE_VERSION.is_empty() || EMBEDDED_CORE_VERSION.contains(['\n', '\r', '\0']) {
        return Err(CoreProvenanceError::InvalidEmbeddedIdentity("version is empty or unsafe"));
    }
    if EMBEDDED_CORE_SHA256.len() != 64 || !EMBEDDED_CORE_SHA256.bytes().all(|byte| byte.is_ascii_hexdigit()) {
        return Err(CoreProvenanceError::InvalidEmbeddedIdentity("digest must be 64 hexadecimal characters"));
    }
    if EMBEDDED_CORE_LOCK_SHA256.len() != 64
        || !EMBEDDED_CORE_LOCK_SHA256
            .bytes()
            .all(|byte| byte.is_ascii_hexdigit())
        || hex_sha256(EMBEDDED_LOCK_TEMPLATE.as_bytes()) != EMBEDDED_CORE_LOCK_SHA256
    {
        return Err(CoreProvenanceError::InvalidEmbeddedIdentity(
            "embedded lock template disagrees with its digest",
        ));
    }
    if !LEXICON_BUILD_REVISION.is_empty()
        && (LEXICON_BUILD_REVISION.len() != 40
            || !LEXICON_BUILD_REVISION.bytes().all(|byte| byte.is_ascii_hexdigit())
            || LEXICON_BUILD_REVISION.bytes().all(|byte| byte == b'0'))
    {
        return Err(CoreProvenanceError::InvalidEmbeddedIdentity("optional build revision is malformed"));
    }
    if hex_sha256(EMBEDDED_CORE_SNAPSHOT) != EMBEDDED_CORE_SHA256 {
        return Err(CoreProvenanceError::InvalidEmbeddedIdentity("embedded bytes disagree with embedded digest"));
    }
    Ok(())
}

fn decode_snapshot(bytes: &[u8]) -> Result<Vec<(PathBuf, Vec<u8>)>, CoreProvenanceError> {
    if bytes.len() > MAX_SNAPSHOT_BYTES || !bytes.starts_with(SNAPSHOT_MAGIC) {
        return Err(CoreProvenanceError::MalformedSnapshot("bad magic or excessive archive size".to_owned()));
    }
    let mut cursor = SNAPSHOT_MAGIC.len();
    let file_count = read_u32(bytes, &mut cursor)? as usize;
    if file_count == 0 || file_count > MAX_SNAPSHOT_FILES {
        return Err(CoreProvenanceError::MalformedSnapshot("invalid file count".to_owned()));
    }
    let mut seen = BTreeSet::new();
    let mut files = Vec::with_capacity(file_count);
    for _ in 0..file_count {
        let path_length = read_u32(bytes, &mut cursor)? as usize;
        let content_length = usize::try_from(read_u64(bytes, &mut cursor)?)
            .map_err(|_| CoreProvenanceError::MalformedSnapshot("file is too large".to_owned()))?;
        if path_length == 0 || path_length > MAX_PATH_BYTES {
            return Err(CoreProvenanceError::MalformedSnapshot("invalid path length".to_owned()));
        }
        let path_bytes = take(bytes, &mut cursor, path_length)?;
        let path_text = std::str::from_utf8(path_bytes)
            .map_err(|_| CoreProvenanceError::MalformedSnapshot("path is not UTF-8".to_owned()))?;
        if path_text.contains('\\') {
            return Err(CoreProvenanceError::MalformedSnapshot("archive path is not slash-normalized".to_owned()));
        }
        let path = PathBuf::from(path_text);
        validate_relative_path(&path)?;
        if !seen.insert(path.clone()) {
            return Err(CoreProvenanceError::MalformedSnapshot(format!("duplicate path: {path_text}")));
        }
        let contents = take(bytes, &mut cursor, content_length)?.to_vec();
        files.push((path, contents));
    }
    if cursor != bytes.len() {
        return Err(CoreProvenanceError::MalformedSnapshot("trailing bytes".to_owned()));
    }
    Ok(files)
}

fn encode_snapshot_directory(root: &Path) -> Result<Vec<u8>, CoreProvenanceError> {
    let mut files = Vec::new();
    collect_files(root, root, &mut files)?;
    files.sort();
    if files.is_empty() || files.len() > MAX_SNAPSHOT_FILES {
        return Err(CoreProvenanceError::MalformedSnapshot(
            "invalid file count".to_owned(),
        ));
    }
    let mut output = Vec::new();
    output.extend_from_slice(SNAPSHOT_MAGIC);
    output.extend_from_slice(&(files.len() as u32).to_be_bytes());
    for relative in files {
        let path_text = relative.to_str().ok_or_else(|| CoreProvenanceError::UnsafePath(relative.clone()))?.replace('\\', "/");
        if path_text.is_empty() || path_text.len() > MAX_PATH_BYTES {
            return Err(CoreProvenanceError::MalformedSnapshot(
                "invalid path length".to_owned(),
            ));
        }
        let metadata = fs::metadata(root.join(&relative))
            .map_err(|source| io_error(&root.join(&relative), source))?;
        let content_length = usize::try_from(metadata.len()).map_err(|_| {
            CoreProvenanceError::MalformedSnapshot("file is too large".to_owned())
        })?;
        let encoded_length = 12usize
            .checked_add(path_text.len())
            .and_then(|length| length.checked_add(content_length))
            .ok_or_else(|| {
                CoreProvenanceError::MalformedSnapshot("archive size overflow".to_owned())
            })?;
        if output
            .len()
            .checked_add(encoded_length)
            .is_none_or(|length| length > MAX_SNAPSHOT_BYTES)
        {
            return Err(CoreProvenanceError::MalformedSnapshot(
                "excessive archive size".to_owned(),
            ));
        }
        let contents = fs::read(root.join(&relative)).map_err(|source| io_error(&root.join(&relative), source))?;
        if contents.len() != content_length {
            return Err(CoreProvenanceError::MalformedSnapshot(
                "file changed while snapshotting".to_owned(),
            ));
        }
        output.extend_from_slice(&(path_text.len() as u32).to_be_bytes());
        output.extend_from_slice(&(contents.len() as u64).to_be_bytes());
        output.extend_from_slice(path_text.as_bytes());
        output.extend_from_slice(&contents);
    }
    Ok(output)
}

fn collect_files(root: &Path, directory: &Path, files: &mut Vec<PathBuf>) -> Result<(), CoreProvenanceError> {
    let mut entries = fs::read_dir(directory).map_err(|source| io_error(directory, source))?
        .collect::<Result<Vec<_>, _>>().map_err(|source| io_error(directory, source))?;
    entries.sort_by_key(|entry| entry.file_name());
    for entry in entries {
        let path = entry.path();
        let file_type = entry.file_type().map_err(|source| io_error(&path, source))?;
        let relative = path.strip_prefix(root).map_err(|_| CoreProvenanceError::UnsafePath(path.clone()))?;
        validate_relative_path(relative)?;
        if file_type.is_symlink() || (!file_type.is_file() && !file_type.is_dir()) {
            return Err(CoreProvenanceError::UnsupportedEntry(path));
        }
        if file_type.is_dir() {
            collect_files(root, &path, files)?;
        } else {
            files.push(relative.to_path_buf());
        }
    }
    Ok(())
}

fn validate_relative_path(path: &Path) -> Result<(), CoreProvenanceError> {
    let text = path.to_string_lossy();
    if path.as_os_str().is_empty() || path.is_absolute()
        || (text.contains('/') && text.split('/').any(|segment| segment.is_empty() || segment == "." || segment == ".."))
    {
        return Err(CoreProvenanceError::UnsafePath(path.to_path_buf()));
    }
    for component in path.components() {
        match component {
            Component::Normal(value)
                if value != OsStr::new("")
                    && value != OsStr::new(".")
                    && value != OsStr::new("..")
                    && !value.to_string_lossy().contains([':', '\\']) => {}
            _ => return Err(CoreProvenanceError::UnsafePath(path.to_path_buf())),
        }
    }
    Ok(())
}

fn write_new_file(path: &Path, bytes: &[u8]) -> Result<(), CoreProvenanceError> {
    let mut file = fs::OpenOptions::new().write(true).create_new(true).open(path)
        .map_err(|source| io_error(path, source))?;
    file.write_all(bytes).map_err(|source| io_error(path, source))?;
    file.sync_all().map_err(|source| io_error(path, source))
}

fn read_u32(bytes: &[u8], cursor: &mut usize) -> Result<u32, CoreProvenanceError> {
    let value: [u8; 4] = take(bytes, cursor, 4)?.try_into().expect("fixed length");
    Ok(u32::from_be_bytes(value))
}

fn read_u64(bytes: &[u8], cursor: &mut usize) -> Result<u64, CoreProvenanceError> {
    let value: [u8; 8] = take(bytes, cursor, 8)?.try_into().expect("fixed length");
    Ok(u64::from_be_bytes(value))
}

fn take<'a>(bytes: &'a [u8], cursor: &mut usize, length: usize) -> Result<&'a [u8], CoreProvenanceError> {
    let end = cursor.checked_add(length).ok_or_else(|| CoreProvenanceError::MalformedSnapshot("length overflow".to_owned()))?;
    let value = bytes.get(*cursor..end).ok_or_else(|| CoreProvenanceError::MalformedSnapshot("truncated archive".to_owned()))?;
    *cursor = end;
    Ok(value)
}

fn io_error(path: &Path, source: io::Error) -> CoreProvenanceError {
    CoreProvenanceError::Io { path: path.to_path_buf(), source }
}

fn hex_sha256(bytes: &[u8]) -> String {
    let digest = Sha256::digest(bytes);
    let mut output = String::with_capacity(64);
    for byte in digest {
        use std::fmt::Write as _;
        write!(&mut output, "{byte:02x}").expect("writing to String cannot fail");
    }
    output
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn embedded_snapshot_round_trips_to_its_declared_digest() {
        let directory = tempfile::tempdir().unwrap();
        let vendor = directory.path().join("vendor");
        let core = materialize_embedded_core(&vendor).unwrap();
        validate_managed_core(&core).unwrap();
        validate_provenance_document(&vendor.join(CORE_PROVENANCE_FILE)).unwrap();
    }

    #[test]
    fn mutation_is_rejected_by_content_identity() {
        let directory = tempfile::tempdir().unwrap();
        let vendor = directory.path().join("vendor");
        let core = materialize_embedded_core(&vendor).unwrap();
        fs::write(core.join("src/lib.rs"), b"pub fn replaced() {}\n").unwrap();
        assert!(matches!(validate_managed_core(&core), Err(CoreProvenanceError::DigestMismatch { .. })));
    }

    #[test]
    fn lockfile_substitution_does_not_rewrite_inserted_placeholder_text() {
        let implementation = "lexicon-lock-template-runner-get-raw-data";
        let runner = "lexicon-lock-template-runner-get-raw-data-runner";
        let lockfile = managed_workspace_lockfile(implementation, runner).unwrap();

        assert!(lockfile.contains(&format!("name = \"{implementation}\"")));
        assert!(lockfile.contains(&format!("name = \"{runner}\"")));
        assert!(lockfile.contains(&format!(" \"{implementation}\",")));
        assert!(!lockfile.contains(
            "lexicon-lock-template-runner-get-raw-data-runner-get-raw-data"
        ));
    }
}
