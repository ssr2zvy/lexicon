use lexicon_core::runtime::{OwnedRuntimeIdentity, RuntimeSupervisionMode};
use lexicon_core::session::{
    ProjectIdentity, SafeSessionFailure, SessionFailureCode, SessionFailureKind,
    SessionIdentity, SessionOperation, SessionOperationRoot, SessionRecordV1,
    SessionState, SessionStore, SessionStoreError, SessionTransition,
};

use crate::data::error::{
    ForegroundDataExecutionError, RootSummaryReconciliationError, RootSummaryValidationError,
    TerminalSessionIdentityMismatch,
};
use crate::data::project::RuntimeProjectLayout;
use crate::data::request::DataOperation;
use crate::data::runtime::AdmittedBundle;
use crate::session::{
    CurrentSessionStatus, PreparedSessionLaunch, SessionCoordinator, SessionCoordinationError,
};

// ---------------------------------------------------------------------------
// Session operations
// ---------------------------------------------------------------------------

/// Build a `SessionOperation` from a `DataOperation`.
pub fn data_operation_to_session_operation(op: DataOperation) -> SessionOperation {
    match op {
        DataOperation::Acquisition => SessionOperation::Acquisition,
        DataOperation::Processing => SessionOperation::Processing,
    }
}

/// Build the `SessionOperationRoot` for the given operation layout.
pub fn build_operation_root(
    layout: &RuntimeProjectLayout,
    operation: DataOperation,
) -> Result<SessionOperationRoot, ForegroundDataExecutionError> {
    let op_root_path = layout.operation_root(operation);
    SessionOperationRoot::new(op_root_path).map_err(ForegroundDataExecutionError::StaleSessionReconciliation)
}

/// Construct a `ProjectIdentity` from the project name.
pub fn build_project_identity(
    project_name: &str,
) -> Result<ProjectIdentity, ForegroundDataExecutionError> {
    ProjectIdentity::new(project_name).map_err(|e| {
        ForegroundDataExecutionError::ProjectConfiguration(
            crate::data::error::ProjectConfigurationError::Identity(format!(
                "invalid project identity '{}': {e}",
                project_name
            ))
        )
    })
}

// ---------------------------------------------------------------------------
// SessionCoordinator construction
// ---------------------------------------------------------------------------

/// Build a `SessionCoordinator` from validated layout, project, and runtime identity.
pub fn build_coordinator(
    layout: &RuntimeProjectLayout,
    project_identity: ProjectIdentity,
    runtime_identity: OwnedRuntimeIdentity,
    operation: DataOperation,
) -> Result<SessionCoordinator, ForegroundDataExecutionError> {
    let session_operation = data_operation_to_session_operation(operation);
    let op_root = build_operation_root(layout, operation)?;

    SessionCoordinator::new(
        project_identity,
        runtime_identity,
        session_operation,
        op_root,
        layout.project_root().to_path_buf(),
        layout.sources_root().to_path_buf(),
        layout.protocol_root().to_path_buf(),
    )
    .map_err(ForegroundDataExecutionError::SessionPreparation)
}

// ---------------------------------------------------------------------------
// Session selection policy
// ---------------------------------------------------------------------------

/// Apply the session selection policy and return a `PreparedSessionLaunch`.
///
/// For acquisition: supports run, resume (if available), and abandon-then-run.
/// For processing: supports run and abandon-then-run; resume is not supported.
///
/// `supervision` controls whether the freshly `Prepared` session records
/// `Foreground` (used by `execute_foreground_data`) or `Background` (used by
/// the initiating process of `execute_background_data`, which then hands the
/// prepared session off to the operator host).
pub fn select_and_prepare_session(
    coordinator: &SessionCoordinator,
    operation: DataOperation,
    abandon_past_failure: bool,
    admitted_bundle: &AdmittedBundle,
    supervision: RuntimeSupervisionMode,
) -> Result<PreparedSessionLaunch, ForegroundDataExecutionError> {
    // Reconcile stale ownership first.
    coordinator
        .reconcile_stale_current_session()
        .map_err(project_stale_session_reconciliation_error)?;

    match operation {
        DataOperation::Acquisition => {
            select_and_prepare_acquisition(coordinator, abandon_past_failure, admitted_bundle, supervision)
        }
        DataOperation::Processing => {
            select_and_prepare_processing(coordinator, abandon_past_failure, supervision)
        }
    }
}

fn select_and_prepare_acquisition(
    coordinator: &SessionCoordinator,
    abandon_past_failure: bool,
    admitted_bundle: &AdmittedBundle,
    supervision: RuntimeSupervisionMode,
) -> Result<PreparedSessionLaunch, ForegroundDataExecutionError> {
    // Load current status after stale reconciliation.
    let current_status = coordinator
        .current_session_status()
        .map_err(project_session_selection_error)?;

    match current_status {
        CurrentSessionStatus::None
        | CurrentSessionStatus::Succeeded
        | CurrentSessionStatus::Abandoned => {
            coordinator
                .prepare_run(supervision)
                .map_err(project_session_preparation_error)
        }
        CurrentSessionStatus::Live(record) => {
            Err(
                ForegroundDataExecutionError::SessionSelection(
                    SessionCoordinationError::LiveSessionAlreadyActive,
                )
                .bind_session(record.session().clone()),
            )
        }
        CurrentSessionStatus::Failed(record) => {
            if abandon_past_failure {
                // Abandon the failed session, then prepare a new run.
                coordinator
                    .abandon_current_failure()
                    .map_err(project_abandonment_error)?;

                coordinator
                    .prepare_run(supervision)
                    .map_err(project_session_preparation_error)
            } else {
                // No abandon flag: try to resume if the handler is registered.
                let has_resume = match admitted_bundle {
                    AdmittedBundle::Acquisition(b) => {
                        crate::data::runtime::acquisition_bundle_has_resume(b)
                    }
                    AdmittedBundle::Processing(_) => false,
                };

                if has_resume {
                    coordinator
                        .prepare_resume(supervision)
                        .map_err(project_session_preparation_error)
                } else {
                    Err(
                        ForegroundDataExecutionError::ResumeHandlerUnavailable
                            .bind_session(record.session().clone()),
                    )
                }
            }
        }
    }
}

fn select_and_prepare_processing(
    coordinator: &SessionCoordinator,
    abandon_past_failure: bool,
    supervision: RuntimeSupervisionMode,
) -> Result<PreparedSessionLaunch, ForegroundDataExecutionError> {
    let current_status = coordinator
        .current_session_status()
        .map_err(project_session_selection_error)?;

    match current_status {
        CurrentSessionStatus::None
        | CurrentSessionStatus::Succeeded
        | CurrentSessionStatus::Abandoned => {
            coordinator
                .prepare_run(supervision)
                .map_err(project_session_preparation_error)
        }
        CurrentSessionStatus::Live(record) => {
            Err(
                ForegroundDataExecutionError::SessionSelection(
                    SessionCoordinationError::LiveSessionAlreadyActive,
                )
                .bind_session(record.session().clone()),
            )
        }
        CurrentSessionStatus::Failed(record) => {
            if abandon_past_failure {
                coordinator
                    .abandon_current_failure()
                    .map_err(project_abandonment_error)?;
                coordinator
                    .prepare_run(supervision)
                    .map_err(project_session_preparation_error)
            } else {
                Err(
                    ForegroundDataExecutionError::SessionSelection(
                        SessionCoordinationError::UnresolvedFailure,
                    )
                    .bind_session(record.session().clone()),
                )
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Post-launch session reconciliation
// ---------------------------------------------------------------------------

/// Load a session record from the operation root after the child has terminated.
pub fn load_terminal_session(
    operation_root_path: &std::path::Path,
    session_id: &SessionIdentity,
) -> Result<SessionRecordV1, ForegroundDataExecutionError> {
    let op_root = SessionOperationRoot::new(operation_root_path.to_path_buf())
        .map_err(ForegroundDataExecutionError::StaleSessionReconciliation)?;
    let store = SessionStore::open(op_root)
        .map_err(ForegroundDataExecutionError::MissingTerminalSession)?;
    store
        .load(session_id)
        .map_err(|e| match e {
            SessionStoreError::MissingSession => {
                ForegroundDataExecutionError::MissingTerminalSession(e)
            }
            _ => ForegroundDataExecutionError::CorruptTerminalSession(e),
        })
}

/// Transition a session to Failed after abnormal termination.
///
/// Returns the transition error if persistence fails, so the caller can
/// produce a combined error.
pub fn persist_abnormal_termination(
    operation_root_path: &std::path::Path,
    session_id: &SessionIdentity,
    lease: &lexicon_core::session::SessionLease,
    revision: u64,
    failure_code: SessionFailureCode,
    diagnostic: Option<String>,
) -> Result<SessionRecordV1, SessionCoordinationError> {
    let op_root = SessionOperationRoot::new(operation_root_path.to_path_buf())
        .map_err(SessionCoordinationError::Store)?;
    let store = SessionStore::open(op_root).map_err(SessionCoordinationError::Store)?;
    let failure = SafeSessionFailure::new(
        SessionFailureKind::AbnormalTermination,
        failure_code,
        diagnostic,
    );
    store
        .transition_as_lease_owner(
            session_id,
            lease,
            revision,
            SessionTransition::ToFailed { failure },
        )
        .map_err(SessionCoordinationError::Store)
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

fn session_coordination_error_to_store_error(
    err: SessionCoordinationError,
) -> SessionStoreError {
    match err {
        SessionCoordinationError::Store(e) => e,
        SessionCoordinationError::SessionBound { source, .. } => {
            session_coordination_error_to_store_error((*source).into_unbound())
        }
        _ => SessionStoreError::Io(std::io::Error::new(
            std::io::ErrorKind::Other,
            err.to_string(),
        )),
    }
}

fn project_session_coordination_error(
    error: SessionCoordinationError,
    wrap: fn(SessionCoordinationError) -> ForegroundDataExecutionError,
) -> ForegroundDataExecutionError {
    let session = error.validated_session().cloned();
    let failure_code = error.authoritative_failure_code();
    let error = wrap(error);
    match (session, failure_code) {
        (Some(session), Some(code)) => error.bind_terminal_failure(session, code),
        (Some(session), None) => error.bind_session(session),
        (None, _) => error,
    }
}

pub(crate) fn project_session_preparation_error(
    error: SessionCoordinationError,
) -> ForegroundDataExecutionError {
    project_session_coordination_error(
        error,
        ForegroundDataExecutionError::SessionPreparation,
    )
}

fn project_session_selection_error(
    error: SessionCoordinationError,
) -> ForegroundDataExecutionError {
    project_session_coordination_error(
        error,
        ForegroundDataExecutionError::SessionSelection,
    )
}

fn project_abandonment_error(
    error: SessionCoordinationError,
) -> ForegroundDataExecutionError {
    project_session_coordination_error(error, ForegroundDataExecutionError::Abandonment)
}

fn project_stale_session_reconciliation_error(
    error: SessionCoordinationError,
) -> ForegroundDataExecutionError {
    let session = error.validated_session().cloned();
    let failure_code = error.authoritative_failure_code();
    let store_error = session_coordination_error_to_store_error(error);
    let error = ForegroundDataExecutionError::StaleSessionReconciliation(store_error);
    match (session, failure_code) {
        (Some(session), Some(code)) => error.bind_terminal_failure(session, code),
        (Some(session), None) => error.bind_session(session),
        (None, _) => error,
    }
}

// ---------------------------------------------------------------------------
// Terminal session validation helpers
// ---------------------------------------------------------------------------

pub struct ReconciledTerminalSession {
    record: SessionRecordV1,
}

impl ReconciledTerminalSession {
    pub fn record(&self) -> &SessionRecordV1 {
        &self.record
    }
}

/// Load the session record after child termination and verify that its identity
/// fields match the prepared launch.
pub fn load_and_validate_terminal_session(
    operation_root_path: &std::path::Path,
    prepared_record: &SessionRecordV1,
) -> Result<SessionRecordV1, ForegroundDataExecutionError> {
    let session_id = prepared_record.session();
    let record = load_terminal_session(operation_root_path, session_id)?;
    validate_terminal_session_identity(prepared_record, &record)?;
    Ok(record)
}

pub fn validate_terminal_session_identity(
    prepared_record: &SessionRecordV1,
    record: &SessionRecordV1,
) -> Result<(), ForegroundDataExecutionError> {
    if record.project() != prepared_record.project() {
        return Err(ForegroundDataExecutionError::SessionIdentityDisagreement(
            TerminalSessionIdentityMismatch::Project {
                expected: prepared_record.project().clone(),
                actual: record.project().clone(),
            },
        ));
    }
    if record.runtime() != prepared_record.runtime() {
        return Err(ForegroundDataExecutionError::SessionIdentityDisagreement(
            TerminalSessionIdentityMismatch::Runtime {
                expected: prepared_record.runtime().clone(),
                actual: record.runtime().clone(),
            },
        ));
    }
    if record.session() != prepared_record.session() {
        return Err(ForegroundDataExecutionError::SessionIdentityDisagreement(
            TerminalSessionIdentityMismatch::Session {
                expected: prepared_record.session().clone(),
                actual: record.session().clone(),
            },
        ));
    }
    if record.operation() != prepared_record.operation() {
        return Err(ForegroundDataExecutionError::SessionIdentityDisagreement(
            TerminalSessionIdentityMismatch::Operation {
                expected: prepared_record.operation(),
                actual: record.operation(),
            },
        ));
    }
    if record.execution_mode() != prepared_record.execution_mode() {
        return Err(ForegroundDataExecutionError::SessionIdentityDisagreement(
            TerminalSessionIdentityMismatch::ExecutionMode {
                expected: prepared_record.execution_mode(),
                actual: record.execution_mode(),
            },
        ));
    }
    if record.supervision_mode() != prepared_record.supervision_mode() {
        return Err(ForegroundDataExecutionError::SessionIdentityDisagreement(
            TerminalSessionIdentityMismatch::SupervisionMode {
                expected: prepared_record.supervision_mode(),
                actual: record.supervision_mode(),
            },
        ));
    }

    Ok(())
}

pub fn validate_root_summary_against_record(
    store: &SessionStore,
    record: &SessionRecordV1,
) -> Result<(), RootSummaryValidationError> {
    let status = match store.load_status() {
        Ok(Some(s)) => s,
        Ok(None) => return Err(RootSummaryValidationError::Missing),
        Err(e) => return Err(RootSummaryValidationError::Load(e)),
    };

    if status.schema_version() != lexicon_core::session::SESSION_SCHEMA_VERSION {
        return Err(RootSummaryValidationError::SchemaVersionMismatch {
            expected: lexicon_core::session::SESSION_SCHEMA_VERSION,
            actual: status.schema_version(),
        });
    }
    if status.project() != record.project() {
        return Err(RootSummaryValidationError::ProjectMismatch);
    }
    if status.runtime() != record.runtime() {
        return Err(RootSummaryValidationError::RuntimeMismatch);
    }
    if status.operation() != record.operation() {
        return Err(RootSummaryValidationError::OperationMismatch);
    }
    match status.current_session() {
        None => return Err(RootSummaryValidationError::MissingCurrentSession),
        Some(id) if id != record.session() => {
            return Err(RootSummaryValidationError::SessionMismatch);
        }
        Some(_) => {}
    }
    match status.current_state() {
        None => return Err(RootSummaryValidationError::MissingCurrentState),
        Some(s) if s != record.state() => {
            return Err(RootSummaryValidationError::StateMismatch {
                expected: record.state(),
                actual: s,
            });
        }
        Some(_) => {}
    }
    if status.revision() != record.revision() {
        return Err(RootSummaryValidationError::RevisionMismatch {
            expected: record.revision(),
            actual: status.revision(),
        });
    }

    Ok(())
}

pub fn validate_or_rebuild_root_summary(
    store: &SessionStore,
    record: &SessionRecordV1,
    lease: &lexicon_core::session::SessionLease,
) -> Result<(), RootSummaryReconciliationError> {
    match validate_root_summary_against_record(store, record) {
        Ok(()) => Ok(()),
        Err(_) => {
            store
                .rebuild_status_from_record(record.session(), lease)
                .map_err(RootSummaryReconciliationError::Rebuild)?;
            validate_root_summary_against_record(store, record)
                .map_err(RootSummaryReconciliationError::ValidationAfterRebuild)
        }
    }
}

pub fn reconcile_terminal_session(
    prepared_record: &SessionRecordV1,
    record: SessionRecordV1,
    store: &SessionStore,
    expected_state: SessionState,
    lease: &lexicon_core::session::SessionLease,
) -> Result<ReconciledTerminalSession, ForegroundDataExecutionError> {
    validate_terminal_session_identity(prepared_record, &record)?;
    if record.state() != expected_state {
        return Err(ForegroundDataExecutionError::ExitSessionDisagreement {
            termination: crate::data::outcome::ObservedChildTermination::UnknownAbnormalTermination,
            durable_state: record.state(),
        });
    }
    validate_or_rebuild_root_summary(store, &record, lease)
        .map_err(ForegroundDataExecutionError::RootSummaryReconciliationFailed)?;
    Ok(ReconciledTerminalSession { record })
}

#[cfg(test)]
mod tests {
    use super::select_and_prepare_session;
    use crate::data::test_support::{
        admit_fake_bundle, build_fake_coordinator, build_fake_project,
        enable_fake_acquisition_resume,
    };
    use crate::session::SessionCoordinationError;
    use lexicon_core::session::{SafeSessionFailure, SessionState};

    use super::{DataOperation, ForegroundDataExecutionError, RuntimeSupervisionMode};
    use lexicon_core::runtime::RuntimeExecutionMode;

    /// `select_and_prepare_session` records the requested supervision mode
    /// (`Background`) on the resulting `PreparedSessionLaunch`.
    #[test]
    fn records_background_supervision_mode_when_requested() {
        let project = build_fake_project("example-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
        let admitted = admit_fake_bundle(&project);

        let prepared = select_and_prepare_session(
            &coordinator,
            DataOperation::Acquisition,
            false,
            &admitted,
            RuntimeSupervisionMode::Background,
        )
        .unwrap();

        assert_eq!(prepared.record().supervision_mode(), RuntimeSupervisionMode::Background);
    }

    /// `select_and_prepare_session` records `Foreground` when requested,
    /// exercising the same call path `execute_foreground_data` uses.
    #[test]
    fn records_foreground_supervision_mode_when_requested() {
        let project = build_fake_project("example-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
        let admitted = admit_fake_bundle(&project);

        let prepared = select_and_prepare_session(
            &coordinator,
            DataOperation::Acquisition,
            false,
            &admitted,
            RuntimeSupervisionMode::Foreground,
        )
        .unwrap();

        assert_eq!(prepared.record().supervision_mode(), RuntimeSupervisionMode::Foreground);
    }

    /// The processing selection path also threads the supervision mode
    /// through, even though it never inspects the admitted bundle.
    #[test]
    fn processing_operation_records_requested_supervision_mode() {
        let project = build_fake_project("example-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Processing);
        let admitted = admit_fake_bundle(&project);

        let prepared = select_and_prepare_session(
            &coordinator,
            DataOperation::Processing,
            false,
            &admitted,
            RuntimeSupervisionMode::Background,
        )
        .unwrap();

        assert_eq!(prepared.record().supervision_mode(), RuntimeSupervisionMode::Background);
    }

    /// A second selection attempt against an already-live (Prepared, still
    /// leased) session is rejected, regardless of supervision mode. This
    /// preserves the pre-existing live-session-rejection scenario now that
    /// `select_and_prepare_session` takes an extra parameter.
    #[test]
    fn rejects_selection_when_a_live_session_is_already_active() {
        let project = build_fake_project("example-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
        let admitted = admit_fake_bundle(&project);

        let first = select_and_prepare_session(
            &coordinator,
            DataOperation::Acquisition,
            false,
            &admitted,
            RuntimeSupervisionMode::Background,
        )
        .unwrap();
        let active_session = first.session().clone();

        let second = select_and_prepare_session(
            &coordinator,
            DataOperation::Acquisition,
            false,
            &admitted,
            RuntimeSupervisionMode::Foreground,
        );

        let error = second.unwrap_err();
        assert_eq!(error.validated_session(), Some(&active_session));
        assert!(matches!(
            error,
            ForegroundDataExecutionError::SessionBound { source, .. }
                if matches!(
                    *source,
                    ForegroundDataExecutionError::SessionSelection(
                        SessionCoordinationError::LiveSessionAlreadyActive
                    )
                )
        ));
    }

    #[test]
    fn acquisition_abandon_flag_abandons_failed_session_before_new_run() {
        let project = build_fake_project("example-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
        let admitted = admit_fake_bundle(&project);

        let prepared = select_and_prepare_session(
            &coordinator,
            DataOperation::Acquisition,
            false,
            &admitted,
            RuntimeSupervisionMode::Foreground,
        )
        .unwrap();
        let failed_session = prepared.session().clone();
        prepared
            .fail_launch(coordinator.store(), SafeSessionFailure::source_failure())
            .unwrap();

        let replacement = select_and_prepare_session(
            &coordinator,
            DataOperation::Acquisition,
            true,
            &admitted,
            RuntimeSupervisionMode::Foreground,
        )
        .unwrap();

        let abandoned = coordinator.store().load(&failed_session).unwrap();
        assert_eq!(abandoned.state(), SessionState::Abandoned);
        assert_eq!(replacement.record().state(), SessionState::Prepared);
        assert_ne!(replacement.session(), &failed_session);
    }

    #[test]
    fn processing_abandon_flag_abandons_failed_session_before_new_run() {
        let project = build_fake_project("example-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Processing);
        let admitted = admit_fake_bundle(&project);

        let prepared = select_and_prepare_session(
            &coordinator,
            DataOperation::Processing,
            false,
            &admitted,
            RuntimeSupervisionMode::Foreground,
        )
        .unwrap();
        let failed_session = prepared.session().clone();
        prepared
            .fail_launch(coordinator.store(), SafeSessionFailure::source_failure())
            .unwrap();

        let replacement = select_and_prepare_session(
            &coordinator,
            DataOperation::Processing,
            true,
            &admitted,
            RuntimeSupervisionMode::Background,
        )
        .unwrap();

        let abandoned = coordinator.store().load(&failed_session).unwrap();
        assert_eq!(abandoned.state(), SessionState::Abandoned);
        assert_eq!(replacement.record().state(), SessionState::Prepared);
        assert_eq!(
            replacement.record().supervision_mode(),
            RuntimeSupervisionMode::Background
        );
        assert_ne!(replacement.session(), &failed_session);
    }

    #[test]
    fn acquisition_failure_without_resume_or_abandon_remains_failed() {
        let project = build_fake_project("example-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
        let admitted = admit_fake_bundle(&project);

        let prepared = select_and_prepare_session(
            &coordinator,
            DataOperation::Acquisition,
            false,
            &admitted,
            RuntimeSupervisionMode::Foreground,
        )
        .unwrap();
        let failed_session = prepared.session().clone();
        prepared
            .fail_launch(coordinator.store(), SafeSessionFailure::source_failure())
            .unwrap();

        let result = select_and_prepare_session(
            &coordinator,
            DataOperation::Acquisition,
            false,
            &admitted,
            RuntimeSupervisionMode::Foreground,
        );

        let error = result.unwrap_err();
        assert_eq!(error.validated_session(), Some(&failed_session));
        assert!(matches!(
            error,
            ForegroundDataExecutionError::SessionBound { source, .. }
                if matches!(*source, ForegroundDataExecutionError::ResumeHandlerUnavailable)
        ));
        assert_eq!(
            coordinator.store().load(&failed_session).unwrap().state(),
            SessionState::Failed
        );
    }

    #[test]
    fn acquisition_failure_with_resume_handler_prepares_resume_without_abandoning() {
        let project = build_fake_project("example-source");
        enable_fake_acquisition_resume(&project);
        let coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
        let admitted = admit_fake_bundle(&project);

        let prepared = select_and_prepare_session(
            &coordinator,
            DataOperation::Acquisition,
            false,
            &admitted,
            RuntimeSupervisionMode::Foreground,
        )
        .unwrap();
        let failed_session = prepared.session().clone();
        prepared
            .fail_launch(coordinator.store(), SafeSessionFailure::source_failure())
            .unwrap();

        let resumed = select_and_prepare_session(
            &coordinator,
            DataOperation::Acquisition,
            false,
            &admitted,
            RuntimeSupervisionMode::Foreground,
        )
        .unwrap();

        assert_eq!(resumed.record().execution_mode(), RuntimeExecutionMode::Resume);
        assert_ne!(resumed.session(), &failed_session);
        assert_eq!(
            coordinator.store().load(&failed_session).unwrap().state(),
            SessionState::Failed
        );
    }

    #[test]
    fn processing_failure_without_abandon_remains_failed() {
        let project = build_fake_project("example-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Processing);
        let admitted = admit_fake_bundle(&project);

        let prepared = select_and_prepare_session(
            &coordinator,
            DataOperation::Processing,
            false,
            &admitted,
            RuntimeSupervisionMode::Foreground,
        )
        .unwrap();
        let failed_session = prepared.session().clone();
        prepared
            .fail_launch(coordinator.store(), SafeSessionFailure::source_failure())
            .unwrap();

        let result = select_and_prepare_session(
            &coordinator,
            DataOperation::Processing,
            false,
            &admitted,
            RuntimeSupervisionMode::Foreground,
        );

        let error = result.unwrap_err();
        assert_eq!(error.validated_session(), Some(&failed_session));
        assert!(matches!(
            error,
            ForegroundDataExecutionError::SessionBound { source, .. }
                if matches!(
                    *source,
                    ForegroundDataExecutionError::SessionSelection(
                        SessionCoordinationError::UnresolvedFailure
                    )
                )
        ));
        assert_eq!(
            coordinator.store().load(&failed_session).unwrap().state(),
            SessionState::Failed
        );
    }
}
