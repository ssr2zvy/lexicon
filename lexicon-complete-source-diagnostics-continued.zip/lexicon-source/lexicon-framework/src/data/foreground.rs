use std::ffi::{OsStr, OsString};
use std::path::Path;
use std::sync::OnceLock;

use lexicon_core::runtime::{
    RuntimeExecutionMode, RuntimeInvocationEnvelopeV1, RuntimeSupervisionMode,
    encode_runtime_invocation,
    invocation::{ProjectInvocationIdentity, SessionInvocationIdentity},
};
use lexicon_core::session::{
    RUNTIME_CONTEXT_ENVIRONMENT_VARIABLE, SafeSessionFailure, SessionFailureCode, SessionFailureKind,
    SessionIdentity, SessionRecordV1, SessionState,
};

use crate::data::error::{
    CancellationControlFailureError, ChildOwnershipUncertainError,
    ForegroundDataExecutionError, ForegroundInvocationConstructionError,
    ForegroundPreparationError, WaitRecoveryFailure,
};
use crate::data::outcome::{ForegroundDataOutcome, ObservedChildTermination};
use crate::data::project::{RuntimeProjectLayout, resolve_project_layout};
use crate::data::request::{DataExecutionRequest, DataOperation};
use crate::data::runtime::{
    AdmittedBundle, ProductionRuntimeBundleAdmitter, RuntimeBundleAdmitter,
    recheck_executable_integrity,
};
use crate::data::session::{
    build_coordinator, build_project_identity, load_and_validate_terminal_session,
    persist_abnormal_termination, select_and_prepare_session, validate_or_rebuild_root_summary,
    validate_terminal_session_identity,
};
use crate::session::{
    PreparedSessionLaunch, SessionCoordinator, detailed_session_transition_committed,
};
use crate::process::{
    CancellationKind, CancellationPolicy, CancellationSource, CancellationState,
    ProcessTreeLauncher, ProductionLauncher, SupervisedChild, SupervisionOutcome,
    install_cancellation_handlers, wait_with_cancellation,
};

// ---------------------------------------------------------------------------
// Launcher seam
// ---------------------------------------------------------------------------

/// Narrow ownership-oriented launcher for the foreground runtime process.
///
/// The seam separates preparation from spawning and child ownership.
/// It must not expose shell commands, arbitrary environment maps, or PATH lookup.
pub(crate) trait ForegroundRuntimeLauncher {
    fn spawn(
        &self,
        executable: &Path,
        arguments: &[OsString],
        context_environment: &OsStr,
        working_directory: &Path,
    ) -> Result<Box<dyn SupervisedChild>, std::io::Error>;
}

/// Production launcher using `std::process::Command`.
pub(crate) struct ProcessCommandLauncher;

impl ForegroundRuntimeLauncher for ProcessCommandLauncher {
    fn spawn(
        &self,
        executable: &Path,
        arguments: &[OsString],
        context_environment: &OsStr,
        working_directory: &Path,
    ) -> Result<Box<dyn SupervisedChild>, std::io::Error> {
        ProcessTreeLauncher::spawn(
            &ProductionLauncher,
            executable,
            arguments,
            context_environment,
            working_directory,
        )
    }
}

// ---------------------------------------------------------------------------
// Ownership types
// ---------------------------------------------------------------------------

/// Owns the prepared session lease plus the information needed to spawn the runtime.
///
/// # Ownership invariant
/// Neither `PreparedForegroundExecution` nor `RunningForegroundExecution` is `Clone`.
/// The prepared owner retains the session lease. The lease must not be released
/// before terminal reconciliation completes.
pub(crate) struct PreparedForegroundExecution {
    prepared: PreparedSessionLaunch,
    operation: DataOperation,
    project_name: String,
    source_name: String,
}

impl PreparedForegroundExecution {
    /// `pub(crate)` because `background.rs`'s operator-host entrypoint
    /// constructs this owner from a resumed (rather than freshly created)
    /// `PreparedSessionLaunch` before calling the shared `spawn_and_supervise`.
    pub(crate) fn new(
        prepared: PreparedSessionLaunch,
        operation: DataOperation,
        project_name: String,
        source_name: String,
    ) -> Self {
        Self { prepared, operation, project_name, source_name }
    }

    fn record(&self) -> &SessionRecordV1 {
        self.prepared.record()
    }

    fn session(&self) -> &SessionIdentity {
        self.prepared.session()
    }

    fn context_document(&self) -> &str {
        self.prepared.context_document()
    }

    fn operation_root(&self) -> &std::path::Path {
        self.prepared.operation_root()
    }
}

/// Owns both the live child handle and the session lease.
///
/// # Ownership invariant
/// While `RunningForegroundExecution` exists, the child may be alive and the supervisor
/// lease remains held. The lease is released only when terminal reconciliation
/// completes or produces its final structured error.
pub(crate) struct RunningForegroundExecution {
    child: Box<dyn SupervisedChild>,
    prepared: PreparedSessionLaunch,
    operation: DataOperation,
    project_name: String,
    source_name: String,
}

enum WaitRecoveryState {
    WaitFailed,
    ChildAlreadyExited,
    TerminationRequested,
    TerminationObserved,
    Reaped,
    OwnershipUncertain,
}

impl RunningForegroundExecution {
    /// Wait for the child to exit and reconcile the session.
    ///
    /// The supervisor lease is held throughout. It is released only at the end
    /// of this method, after reconciliation is complete.
    pub(crate) fn wait_and_reconcile(
        self,
    ) -> Result<ForegroundDataOutcome, ForegroundDataExecutionError> {
        let cancellation = process_cancellation_state();
        self.wait_and_reconcile_with(cancellation, CancellationPolicy::default_cli_policy())
    }

    fn wait_and_reconcile_with(
        mut self,
        cancellation: &dyn CancellationSource,
        policy: CancellationPolicy,
    ) -> Result<ForegroundDataOutcome, ForegroundDataExecutionError> {
        match wait_with_cancellation(
            self.child.as_mut(),
            cancellation,
            policy,
        ) {
            Ok(SupervisionOutcome::Completed { status }) => {
                reconcile_terminal_execution(self, observe_termination(status))
            }
            Ok(SupervisionOutcome::CancelledGracefully { kind, status }) => {
                reconcile_cancelled_execution(self, kind, false, status)
            }
            Ok(SupervisionOutcome::CancelledForcefully { kind, status }) => {
                reconcile_cancelled_execution(self, kind, true, status)
            }
            Ok(SupervisionOutcome::CancellationControlFailedButTerminated {
                kind,
                graceful_error,
                force_error,
                status,
            }) => {
                let observed_termination = observe_termination(status);
                let reconciliation_error =
                    reconcile_terminal_execution(self, observed_termination.clone()).err();
                Err(ForegroundDataExecutionError::CancellationControlFailure(
                    Box::new(CancellationControlFailureError {
                        kind,
                        graceful_error,
                        force_error,
                        observed_termination,
                        reconciliation_error: reconciliation_error.map(Box::new),
                    }),
                ))
            }
            Err(wait_err) => self.handle_wait_error(wait_err),
        }
    }

    /// Recovery path when `child.wait()` fails with a non-Interrupted error.
    ///
    /// Attempts to determine child state, kill if running, reap, reconcile session.
    fn handle_wait_error(
        mut self,
        wait_err: std::io::Error,
    ) -> Result<ForegroundDataOutcome, ForegroundDataExecutionError> {
        let mut _state = WaitRecoveryState::WaitFailed;
        let mut try_wait_error: Option<std::io::Error> = None;
        let mut kill_error: Option<std::io::Error> = None;
        let mut reap_error: Option<std::io::Error> = None;

        let termination = match self.child.try_wait() {
            Ok(Some(status)) => {
                _state = WaitRecoveryState::ChildAlreadyExited;
                Some(observe_termination(status))
            }
            Ok(None) => {
                let mut observed_after_kill_failure: Option<ObservedChildTermination> = None;
                match self.child.force_terminate_tree() {
                    Ok(()) => {
                        _state = WaitRecoveryState::TerminationRequested;
                    }
                    Err(err) => {
                        kill_error = Some(err);
                        match self.child.try_wait() {
                            Ok(Some(status)) => {
                                _state = WaitRecoveryState::TerminationObserved;
                                observed_after_kill_failure = Some(observe_termination(status));
                            }
                            Ok(None) => {
                                _state = WaitRecoveryState::OwnershipUncertain;
                                return Err(self.ownership_uncertain(wait_err, try_wait_error, kill_error, reap_error));
                            }
                            Err(err) => {
                                try_wait_error = Some(err);
                                _state = WaitRecoveryState::OwnershipUncertain;
                                return Err(self.ownership_uncertain(wait_err, try_wait_error, kill_error, reap_error));
                            }
                        }
                    }
                }

                if let Some(termination) = observed_after_kill_failure {
                    _state = WaitRecoveryState::Reaped;
                    Some(termination)
                } else {
                    loop {
                        match self.child.wait_reaped() {
                            Ok(status) => {
                                _state = WaitRecoveryState::Reaped;
                                break Some(observe_termination(status));
                            }
                            Err(err) if err.kind() == std::io::ErrorKind::Interrupted => continue,
                            Err(err) => {
                                reap_error = Some(err);
                                match self.child.try_wait() {
                                    Ok(Some(status)) => {
                                        _state = WaitRecoveryState::Reaped;
                                        break Some(observe_termination(status));
                                    }
                                    Ok(None) => {
                                        _state = WaitRecoveryState::OwnershipUncertain;
                                        return Err(self.ownership_uncertain(wait_err, try_wait_error, kill_error, reap_error));
                                    }
                                    Err(err) => {
                                        try_wait_error = Some(err);
                                        _state = WaitRecoveryState::OwnershipUncertain;
                                        return Err(self.ownership_uncertain(wait_err, try_wait_error, kill_error, reap_error));
                                    }
                                }
                            }
                        }
                    }
                }
            }
            Err(err) => {
                try_wait_error = Some(err);
                _state = WaitRecoveryState::OwnershipUncertain;
                return Err(self.ownership_uncertain(wait_err, try_wait_error, kill_error, reap_error));
            }
        };

        let Some(termination) = termination else {
            _state = WaitRecoveryState::OwnershipUncertain;
            return Err(self.ownership_uncertain(wait_err, try_wait_error, kill_error, reap_error));
        };

        let (final_state, final_failure_code) = match
            reconcile_wait_recovery_session_state(&mut self, &termination)
        {
            Ok(record) => (
                Some(record.state()),
                record.failure().map(|failure| failure.code()),
            ),
            Err(session_error) => {
                let (session_load_error, session_reconciliation_error) = match session_error {
                    ForegroundDataExecutionError::MissingTerminalSession(_)
                    | ForegroundDataExecutionError::CorruptTerminalSession(_)
                    | ForegroundDataExecutionError::SessionIdentityDisagreement(_) => {
                        (Some(Box::new(session_error)), None)
                    }
                    _ => (None, Some(Box::new(session_error))),
                };
                return Err(ForegroundDataExecutionError::ProcessWaitRecovery(Box::new(
                    WaitRecoveryFailure {
                        wait_error: wait_err,
                        kill_error,
                        try_wait_error,
                        reap_error,
                        session_load_error,
                        session_reconciliation_error,
                        final_state: None,
                        final_failure_code: None,
                    },
                )));
            }
        };

        Err(ForegroundDataExecutionError::ProcessWaitRecovery(Box::new(
            WaitRecoveryFailure {
                wait_error: wait_err,
                kill_error,
                try_wait_error,
                reap_error,
                session_load_error: None,
                session_reconciliation_error: None,
                final_state,
                final_failure_code,
            },
        )))
    }

    fn ownership_uncertain(
        mut self,
        wait_error: std::io::Error,
        mut try_wait_error: Option<std::io::Error>,
        mut kill_error: Option<std::io::Error>,
        mut reap_error: Option<std::io::Error>,
    ) -> ForegroundDataExecutionError {
        // Losing confidence in an individual control operation does not release
        // supervision. Keep the child handle and exact session lease attached,
        // repeatedly request whole-tree termination, and do not return until an
        // actual exit status proves death and reaping.
        let observed_termination = loop {
            if let Err(error) = self.child.force_terminate_tree() {
                if kill_error.is_none() {
                    kill_error = Some(error);
                }
            }

            match self.child.wait_reaped() {
                Ok(status) => break observe_termination(status),
                Err(error) if error.kind() == std::io::ErrorKind::Interrupted => continue,
                Err(error) => {
                    if reap_error.is_none() {
                        reap_error = Some(error);
                    }
                }
            }

            match self.child.try_wait() {
                Ok(Some(status)) => break observe_termination(status),
                Ok(None) => {}
                Err(error) => {
                    if try_wait_error.is_none() {
                        try_wait_error = Some(error);
                    }
                }
            }
            std::thread::sleep(std::time::Duration::from_millis(50));
        };

        let (
            session_load_error,
            session_reconciliation_error,
            final_state,
            final_failure_code,
        ) =
            match reconcile_wait_recovery_session_state(&mut self, &observed_termination) {
                Ok(record) => (
                    None,
                    None,
                    Some(record.state()),
                    record.failure().map(|failure| failure.code()),
                ),
                Err(error @ (ForegroundDataExecutionError::MissingTerminalSession(_)
                    | ForegroundDataExecutionError::CorruptTerminalSession(_)
                    | ForegroundDataExecutionError::SessionIdentityDisagreement(_))) => {
                    (Some(Box::new(error)), None, None, None)
                }
                Err(error) => (None, Some(Box::new(error)), None, None),
            };

        ForegroundDataExecutionError::ChildOwnershipUncertain(Box::new(
            ChildOwnershipUncertainError {
                wait_error,
                try_wait_error,
                kill_error,
                reap_error,
                observed_termination,
                session_load_error,
                session_reconciliation_error,
                final_state,
                final_failure_code,
            },
        ))
    }
}

// ---------------------------------------------------------------------------
// Public entry point
// ---------------------------------------------------------------------------

/// Execute a foreground data acquisition or processing run.
///
/// This is the single public entrypoint for the data command.
pub fn execute_foreground_data(
    request: DataExecutionRequest,
) -> Result<ForegroundDataOutcome, ForegroundDataExecutionError> {
    execute_foreground_data_with_launcher(request, &ProcessCommandLauncher)
}

pub(crate) fn execute_foreground_data_with_launcher(
    request: DataExecutionRequest,
    launcher: &dyn ForegroundRuntimeLauncher,
) -> Result<ForegroundDataOutcome, ForegroundDataExecutionError> {
    execute_foreground_data_with_dependencies(
        request,
        launcher,
        &ProductionRuntimeBundleAdmitter,
    )
}

pub(crate) fn execute_foreground_data_with_dependencies(
    request: DataExecutionRequest,
    launcher: &dyn ForegroundRuntimeLauncher,
    admitter: &dyn RuntimeBundleAdmitter,
) -> Result<ForegroundDataOutcome, ForegroundDataExecutionError> {
    if request.background {
        return Err(ForegroundDataExecutionError::BackgroundModeUnsupported);
    }

    // 1. Project discovery and layout validation.
    let (layout, project_name) = resolve_project_layout(&request.source_name, &request.protocol, request.operation)?;

    // 2. Bundle admission.
    // Complete bundle admission and a fresh bounded information probe before
    // session history is inspected or a Prepared session can be persisted.
    let admitted = admitter.admit(&layout, request.operation)?;

    // 3. Build project identity.
    let project_identity = build_project_identity(&project_name)?;

    // 4. Build session coordinator.
    let runtime_identity = admitted.identity().clone();
    let coordinator = build_coordinator(
        &layout,
        project_identity.clone(),
        runtime_identity.clone(),
        request.operation,
    )?;

    // 5. Session selection policy (reconcile stale → select → prepare).
    let prepared = select_and_prepare_session(
        &coordinator,
        request.operation,
        request.abandon_past_failure,
        &admitted,
        RuntimeSupervisionMode::Foreground,
    )?;

    // From here onward, every error must transition the session to Failed before returning.
    let owner = PreparedForegroundExecution::new(
        prepared,
        request.operation,
        project_name,
        request.source_name.clone(),
    );
    let session = owner.session().clone();

    // 6-11. Build the invocation envelope, spawn the runtime, and supervise it to
    // completion. Shared with the operator-host caller (see `execute_operator_host_with_launcher`
    // in `background.rs`), parametrized only by the supervision mode.
    spawn_and_supervise(
        owner,
        &layout,
        &admitted,
        &coordinator,
        &request.source_arguments,
        RuntimeSupervisionMode::Foreground,
        launcher,
    )
    .map_err(|error| error.bind_session(session))
}

// ---------------------------------------------------------------------------
// Shared spawn-and-supervise pipeline
// ---------------------------------------------------------------------------

/// Build the invocation envelope, spawn the admitted runtime, and supervise it
/// through to terminal reconciliation.
///
/// This is the shared core of both foreground execution and operator-host
/// execution. The only difference between the two callers is the supervision
/// mode recorded in the invocation envelope; the spawn, integrity-recheck, and
/// termination-reconciliation logic is identical and must not be duplicated.
pub(crate) fn spawn_and_supervise(
    owner: PreparedForegroundExecution,
    layout: &RuntimeProjectLayout,
    admitted: &AdmittedBundle,
    coordinator: &SessionCoordinator,
    source_arguments: &[OsString],
    supervision: RuntimeSupervisionMode,
    launcher: &dyn ForegroundRuntimeLauncher,
) -> Result<ForegroundDataOutcome, ForegroundDataExecutionError> {
    // 6. Build invocation envelope.
    let session_id = owner.session().clone();
    let execution_mode = owner.record().execution_mode();
    let envelope = match build_invocation_envelope(
        &owner.project_name,
        admitted,
        &session_id,
        execution_mode,
        supervision,
    ) {
        Ok(e) => e,
        Err(cause) => {
            return Err(fail_prepared_execution(
                owner.prepared,
                coordinator.store(),
                SessionFailureCode::InvocationConstructionFailed,
                ForegroundPreparationError::InvocationConstruction(cause),
            ));
        }
    };

    // 7. Encode argv.
    let encoded = match encode_runtime_invocation(&envelope, source_arguments) {
        Ok(e) => e,
        Err(cause) => {
            return Err(fail_prepared_execution(
                owner.prepared,
                coordinator.store(),
                SessionFailureCode::InvocationEncodingFailed,
                ForegroundPreparationError::InvocationEncoding(cause),
            ));
        }
    };

    // 8. Pre-launch executable integrity recheck.
    if let Err(prep_err) = recheck_executable_integrity_typed(admitted) {
        return Err(fail_prepared_execution(
            owner.prepared,
            coordinator.store(),
            SessionFailureCode::ExecutableIntegrityFailed,
            prep_err,
        ));
    }

    // 9. Build argv.
    let executable = admitted.executable_path().to_path_buf();
    let mut argv: Vec<OsString> = Vec::new();
    argv.extend(encoded.arguments().iter().cloned());

    let context_document = owner.context_document().to_owned();
    let working_directory = layout.protocol_root().to_path_buf();

    // 10. Install the process-lifetime operator-cancellation binding before
    // spawning. A live child must never exist if Lexicon cannot receive the
    // operator's cancellation request.
    // Drain a request belonging to an earlier completed run before ensuring
    // the process-lifetime handlers. Once this boundary has been established,
    // every newly delivered request belongs to this run and must not be
    // discarded in the install-to-spawn interval.
    process_cancellation_state().begin_supervision_run();
    if let Err(install_err) = ensure_cancellation_handlers() {
        return Err(fail_prepared_execution(
            owner.prepared,
            coordinator.store(),
            SessionFailureCode::LaunchFailed,
            ForegroundPreparationError::ProcessSpawn(install_err),
        ));
    }
    // 11. Spawn.
    let child = match launcher.spawn(
        &executable,
        &argv,
        OsStr::new(&context_document),
        &working_directory,
    ) {
        Ok(c) => c,
        Err(spawn_err) => {
            return Err(fail_prepared_execution(
                owner.prepared,
                coordinator.store(),
                SessionFailureCode::LaunchFailed,
                ForegroundPreparationError::ProcessSpawn(spawn_err),
            ));
        }
    };

    // Transfer ownership from PreparedForegroundExecution to RunningForegroundExecution.
    // Do not alter the child's session record from the parent merely because spawn succeeded.
    let running = RunningForegroundExecution {
        child,
        prepared: owner.prepared,
        operation: owner.operation,
        project_name: owner.project_name,
        source_name: owner.source_name,
    };

    // 12. Wait and reconcile; lease is held throughout and released inside.
    running.wait_and_reconcile()
}

static PROCESS_CANCELLATION_STATE: CancellationState = CancellationState::new();
static CANCELLATION_HANDLER_INSTALLATION: OnceLock<Result<(), HandlerInstallationFailure>> =
    OnceLock::new();

#[derive(Clone, Debug)]
struct HandlerInstallationFailure {
    kind: std::io::ErrorKind,
    raw_os_error: Option<i32>,
    message: String,
}

fn process_cancellation_state() -> &'static CancellationState {
    &PROCESS_CANCELLATION_STATE
}

fn ensure_cancellation_handlers() -> Result<(), std::io::Error> {
    match CANCELLATION_HANDLER_INSTALLATION.get_or_init(|| {
        install_cancellation_handlers(process_cancellation_state()).map_err(|error| {
            HandlerInstallationFailure {
                kind: error.kind(),
                raw_os_error: error.raw_os_error(),
                message: error.to_string(),
            }
        })
    }) {
        Ok(()) => Ok(()),
        Err(failure) => Err(match failure.raw_os_error {
            Some(code) => std::io::Error::from_raw_os_error(code),
            None => std::io::Error::new(failure.kind, failure.message.clone()),
        }),
    }
}

// ---------------------------------------------------------------------------
// Centralized pre-spawn failure handler
// ---------------------------------------------------------------------------

/// Transition the prepared session to Failed and return a typed execution error.
///
/// Required order:
/// 1. Retain lease (held in `prepared`).
/// 2. Transition Prepared to Failed.
/// 3. Update root summary (inside `fail_launch`).
/// 4. Release lease (drop of `prepared`).
/// 5. Return typed error.
fn fail_prepared_execution(
    prepared: PreparedSessionLaunch,
    store: &lexicon_core::session::SessionStore,
    failure_code: SessionFailureCode,
    cause: ForegroundPreparationError,
) -> ForegroundDataExecutionError {
    let session = prepared.session().clone();
    let failure = SafeSessionFailure::new(
        SessionFailureKind::Runtime,
        failure_code,
        None,
    );
    match prepared.fail_launch(store, failure) {
        Ok(_) => {
            // Lease released; convert cause to the appropriate top-level error.
            preparation_error_to_execution_error(cause)
                .bind_terminal_failure(session, failure_code)
        }
        Err(persistence_err) => {
            let terminal_persisted = detailed_session_transition_committed(&persistence_err);
            let error = ForegroundDataExecutionError::PreparationFailureAndPersistenceFailure {
                preparation: cause,
                persistence: persistence_err,
            };
            if terminal_persisted {
                error.bind_terminal_failure(session, failure_code)
            } else {
                error
            }
        }
    }
}

fn preparation_error_to_execution_error(cause: ForegroundPreparationError) -> ForegroundDataExecutionError {
    match cause {
        ForegroundPreparationError::InvocationConstruction(e) => {
            ForegroundDataExecutionError::InvocationConstruction(e)
        }
        ForegroundPreparationError::InvocationEncoding(e) => {
            ForegroundDataExecutionError::InvocationEncoding(e)
        }
        ForegroundPreparationError::ExecutableIntegrity(e) => {
            ForegroundDataExecutionError::ExecutableIntegrity(e)
        }
        ForegroundPreparationError::ProcessSpawn(e) => {
            ForegroundDataExecutionError::ProcessSpawn { source: e, persistence_failure: None }
        }
    }
}

// ---------------------------------------------------------------------------
// Invocation envelope construction
// ---------------------------------------------------------------------------

fn build_invocation_envelope(
    project_name: &str,
    admitted: &AdmittedBundle,
    session_id: &SessionIdentity,
    execution_mode: RuntimeExecutionMode,
    supervision: RuntimeSupervisionMode,
) -> Result<RuntimeInvocationEnvelopeV1, ForegroundInvocationConstructionError> {
    let project_invocation = ProjectInvocationIdentity::new(project_name)
        .map_err(ForegroundInvocationConstructionError::InvalidProjectIdentity)?;

    let session_invocation = SessionInvocationIdentity::new(session_id.id())
        .map_err(ForegroundInvocationConstructionError::InvalidSessionIdentity)?;

    let runtime_identity = admitted.information_identity();

    RuntimeInvocationEnvelopeV1::new_owned(
        project_invocation,
        runtime_identity.clone(),
        session_invocation,
        execution_mode,
        supervision,
    )
    .map_err(ForegroundInvocationConstructionError::EnvelopeConstruction)
}

// ---------------------------------------------------------------------------
// Integrity check (returns ForegroundPreparationError)
// ---------------------------------------------------------------------------

fn recheck_executable_integrity_typed(
    admitted: &AdmittedBundle,
) -> Result<(), ForegroundPreparationError> {
    recheck_executable_integrity(admitted).map_err(ForegroundPreparationError::ExecutableIntegrity)
}

// ---------------------------------------------------------------------------
// Termination observation
// ---------------------------------------------------------------------------

fn observe_termination(status: std::process::ExitStatus) -> ObservedChildTermination {
    if let Some(code) = status.code() {
        return ObservedChildTermination::ExitCode(code);
    }

    #[cfg(unix)]
    {
        use std::os::unix::process::ExitStatusExt;
        return ObservedChildTermination::Signaled {
            signal: status.signal(),
        };
    }

    #[cfg(not(unix))]
    ObservedChildTermination::UnknownAbnormalTermination
}

fn reconcile_cancelled_execution(
    running: RunningForegroundExecution,
    kind: CancellationKind,
    forced: bool,
    status: std::process::ExitStatus,
) -> Result<ForegroundDataOutcome, ForegroundDataExecutionError> {
    let observed_termination = observe_termination(status);
    let reconciliation_error =
        reconcile_terminal_execution(running, observed_termination.clone()).err();
    Err(ForegroundDataExecutionError::OperatorCancelled {
        kind,
        forced,
        observed_termination,
        reconciliation_error: reconciliation_error.map(Box::new),
    })
}

// ---------------------------------------------------------------------------
// Termination reconciliation (lease still held via `running`)
// ---------------------------------------------------------------------------

pub fn reconcile_terminal_execution(
    running: RunningForegroundExecution,
    termination: ObservedChildTermination,
) -> Result<ForegroundDataOutcome, ForegroundDataExecutionError> {
    let prepared_record = running.prepared.record().clone();
    let operation_root = running.prepared.operation_root().to_path_buf();
    let operation = running.operation;
    let source_name = running.source_name.clone();
    let project_name = running.project_name.clone();
    let execution_mode = prepared_record.execution_mode();

    let op_root = lexicon_core::session::SessionOperationRoot::new(operation_root.clone())
        .map_err(ForegroundDataExecutionError::StaleSessionReconciliation)?;
    let store = lexicon_core::session::SessionStore::open(op_root)
        .map_err(ForegroundDataExecutionError::MissingTerminalSession)?;

    let record = load_and_validate_terminal_session(&operation_root, &prepared_record)?;
    if record.state().is_terminal() {
        validate_or_rebuild_root_summary(&store, &record, running.prepared.lease())
            .map_err(|error| {
                bind_session_record_error(
                    ForegroundDataExecutionError::RootSummaryReconciliationFailed(error),
                    &record,
                )
            })?;
    }
    match termination {
        ObservedChildTermination::ExitCode(0) => reconcile_zero_exit(
            record,
            &prepared_record,
            running.prepared.lease(),
            &store,
            &operation_root,
            operation,
            &source_name,
            &project_name,
            execution_mode,
        ),
        ObservedChildTermination::ExitCode(exit_code) => reconcile_nonzero_exit(
            record,
            &prepared_record,
            running.prepared.lease(),
            &store,
            &operation_root,
            operation,
            &source_name,
            exit_code,
        ),
        ObservedChildTermination::Signaled { signal } => reconcile_abnormal_termination(
            record,
            &prepared_record,
            running.prepared.lease(),
            &store,
            &operation_root,
            operation,
            &source_name,
            ObservedChildTermination::Signaled { signal },
        ),
        ObservedChildTermination::UnknownAbnormalTermination => reconcile_abnormal_termination(
            record,
            &prepared_record,
            running.prepared.lease(),
            &store,
            &operation_root,
            operation,
            &source_name,
            ObservedChildTermination::UnknownAbnormalTermination,
        ),
    }
}

fn reconcile_zero_exit(
    record: SessionRecordV1,
    prepared_record: &SessionRecordV1,
    lease: &lexicon_core::session::SessionLease,
    store: &lexicon_core::session::SessionStore,
    operation_root: &std::path::Path,
    operation: DataOperation,
    source_name: &str,
    project_name: &str,
    execution_mode: RuntimeExecutionMode,
) -> Result<ForegroundDataOutcome, ForegroundDataExecutionError> {
    let session_id = prepared_record.session().clone();
    match record.state() {
        SessionState::Succeeded => {
            Ok(ForegroundDataOutcome {
                project: project_name.to_owned(),
                source: source_name.to_owned(),
                operation,
                session: session_id,
                execution_mode,
            })
        }
        SessionState::Failed => {
            let failure = record.failure().cloned();
            Err(ForegroundDataExecutionError::ChildFailed {
                operation,
                source: source_name.to_owned(),
                session: session_id,
                failure_kind: failure
                    .as_ref()
                    .map(|f| f.kind())
                    .unwrap_or(SessionFailureKind::AbnormalTermination),
                failure_code: failure
                    .as_ref()
                    .map(|f| f.code())
                    .unwrap_or(SessionFailureCode::AbnormalTermination),
                exit_code: Some(0),
            })
        }
        SessionState::Prepared | SessionState::Running => {
            let transitioned = persist_abnormal_termination(
                operation_root,
                &session_id,
                lease,
                record.revision(),
                SessionFailureCode::ZeroExitWithoutCompletion,
                Some("child exited zero without completing the session".to_owned()),
            )
            .map_err(|persistence_failure| {
                let terminal_persisted =
                    detailed_session_transition_committed(&persistence_failure);
                let error = ForegroundDataExecutionError::AbnormalTerminationPersistence {
                    termination: ObservedChildTermination::ExitCode(0),
                    persistence_failure,
                };
                if terminal_persisted {
                    error.bind_terminal_failure(
                        session_id.clone(),
                        SessionFailureCode::ZeroExitWithoutCompletion,
                    )
                } else {
                    error
                }
            })?;
            validate_terminal_session_identity(prepared_record, &transitioned).map_err(|error| {
                error.bind_terminal_failure(
                    session_id.clone(),
                    SessionFailureCode::ZeroExitWithoutCompletion,
                )
            })?;
            validate_or_rebuild_root_summary(store, &transitioned, lease)
                .map_err(|error| {
                    ForegroundDataExecutionError::RootSummaryReconciliationFailed(error)
                        .bind_terminal_failure(
                            session_id.clone(),
                            SessionFailureCode::ZeroExitWithoutCompletion,
                        )
                })?;
            Err(ForegroundDataExecutionError::ZeroExitSessionIncomplete {
                session: session_id,
                operation,
            })
        }
        SessionState::Abandoned => Err(ForegroundDataExecutionError::ExitSessionDisagreement {
            termination: ObservedChildTermination::ExitCode(0),
            durable_state: SessionState::Abandoned,
        }),
    }
}

fn reconcile_nonzero_exit(
    record: SessionRecordV1,
    prepared_record: &SessionRecordV1,
    lease: &lexicon_core::session::SessionLease,
    store: &lexicon_core::session::SessionStore,
    operation_root: &std::path::Path,
    operation: DataOperation,
    source_name: &str,
    exit_code: i32,
) -> Result<ForegroundDataOutcome, ForegroundDataExecutionError> {
    let session_id = prepared_record.session().clone();
    match record.state() {
        SessionState::Failed => {
            let failure = record.failure().cloned();
            Err(ForegroundDataExecutionError::ChildFailed {
                operation,
                source: source_name.to_owned(),
                session: session_id,
                failure_kind: failure
                    .as_ref()
                    .map(|f| f.kind())
                    .unwrap_or(SessionFailureKind::AbnormalTermination),
                failure_code: failure
                    .as_ref()
                    .map(|f| f.code())
                    .unwrap_or(SessionFailureCode::NonzeroExitWithoutFailureRecord),
                exit_code: Some(exit_code),
            })
        }
        SessionState::Prepared | SessionState::Running => {
            let transitioned = persist_abnormal_termination(
                operation_root,
                &session_id,
                lease,
                record.revision(),
                SessionFailureCode::NonzeroExitWithoutFailureRecord,
                None,
            )
            .map_err(|persistence_failure| {
                let terminal_persisted =
                    detailed_session_transition_committed(&persistence_failure);
                let error = ForegroundDataExecutionError::AbnormalExitPersistence {
                    exit_code,
                    persistence_failure,
                };
                if terminal_persisted {
                    error.bind_terminal_failure(
                        session_id.clone(),
                        SessionFailureCode::NonzeroExitWithoutFailureRecord,
                    )
                } else {
                    error
                }
            })?;
            validate_terminal_session_identity(prepared_record, &transitioned).map_err(|error| {
                error.bind_terminal_failure(
                    session_id.clone(),
                    SessionFailureCode::NonzeroExitWithoutFailureRecord,
                )
            })?;
            validate_or_rebuild_root_summary(store, &transitioned, lease)
                .map_err(|error| {
                    ForegroundDataExecutionError::RootSummaryReconciliationFailed(error)
                        .bind_terminal_failure(
                            session_id.clone(),
                            SessionFailureCode::NonzeroExitWithoutFailureRecord,
                        )
                })?;
            Err(ForegroundDataExecutionError::ChildFailed {
                operation,
                source: source_name.to_owned(),
                session: session_id,
                failure_kind: SessionFailureKind::AbnormalTermination,
                failure_code: SessionFailureCode::NonzeroExitWithoutFailureRecord,
                exit_code: Some(exit_code),
            })
        }
        SessionState::Succeeded => Err(ForegroundDataExecutionError::ExitSessionDisagreement {
            termination: ObservedChildTermination::ExitCode(exit_code),
            durable_state: SessionState::Succeeded,
        }),
        SessionState::Abandoned => Err(ForegroundDataExecutionError::ExitSessionDisagreement {
            termination: ObservedChildTermination::ExitCode(exit_code),
            durable_state: SessionState::Abandoned,
        }),
    }
}

fn reconcile_abnormal_termination(
    record: SessionRecordV1,
    prepared_record: &SessionRecordV1,
    lease: &lexicon_core::session::SessionLease,
    store: &lexicon_core::session::SessionStore,
    operation_root: &std::path::Path,
    operation: DataOperation,
    source_name: &str,
    termination: ObservedChildTermination,
) -> Result<ForegroundDataOutcome, ForegroundDataExecutionError> {
    let session_id = prepared_record.session().clone();
    let signal = match termination {
        ObservedChildTermination::Signaled { signal } => signal,
        _ => None,
    };

    match record.state() {
        SessionState::Prepared | SessionState::Running => {
            let transitioned = persist_abnormal_termination(
                operation_root,
                &session_id,
                lease,
                record.revision(),
                SessionFailureCode::AbnormalTermination,
                signal.map(|s| format!("terminated by signal {s}")),
            )
            .map_err(|persistence_failure| {
                let terminal_persisted =
                    detailed_session_transition_committed(&persistence_failure);
                let error = ForegroundDataExecutionError::AbnormalTerminationPersistence {
                    termination: termination.clone(),
                    persistence_failure,
                };
                if terminal_persisted {
                    error.bind_terminal_failure(
                        session_id.clone(),
                        SessionFailureCode::AbnormalTermination,
                    )
                } else {
                    error
                }
            })?;
            validate_terminal_session_identity(prepared_record, &transitioned).map_err(|error| {
                error.bind_terminal_failure(
                    session_id.clone(),
                    SessionFailureCode::AbnormalTermination,
                )
            })?;
            validate_or_rebuild_root_summary(store, &transitioned, lease)
                .map_err(|error| {
                    ForegroundDataExecutionError::RootSummaryReconciliationFailed(error)
                        .bind_terminal_failure(
                            session_id.clone(),
                            SessionFailureCode::AbnormalTermination,
                        )
                })?;
            Err(ForegroundDataExecutionError::AbnormalTermination {
                operation,
                source: source_name.to_owned(),
                session: session_id,
                signal,
            })
        }
        SessionState::Failed => {
            let failure = record.failure().cloned();
            Err(ForegroundDataExecutionError::ChildFailed {
                operation,
                source: source_name.to_owned(),
                session: session_id,
                failure_kind: failure
                    .as_ref()
                    .map(|f| f.kind())
                    .unwrap_or(SessionFailureKind::AbnormalTermination),
                failure_code: failure
                    .as_ref()
                    .map(|f| f.code())
                    .unwrap_or(SessionFailureCode::AbnormalTermination),
                exit_code: None,
            })
        }
        SessionState::Succeeded => {
            Err(ForegroundDataExecutionError::ExitSessionDisagreement {
                termination,
                durable_state: SessionState::Succeeded,
            })
        }
        SessionState::Abandoned => Err(ForegroundDataExecutionError::ExitSessionDisagreement {
            termination,
            durable_state: SessionState::Abandoned,
        }),
    }
}

fn reconcile_wait_recovery_session_state(
    running: &mut RunningForegroundExecution,
    termination: &ObservedChildTermination,
) -> Result<SessionRecordV1, ForegroundDataExecutionError> {
    let prepared_record = running.prepared.record().clone();
    let operation_root = running.prepared.operation_root().to_path_buf();
    let op_root = lexicon_core::session::SessionOperationRoot::new(operation_root.clone())
        .map_err(ForegroundDataExecutionError::StaleSessionReconciliation)?;
    let store = lexicon_core::session::SessionStore::open(op_root)
        .map_err(ForegroundDataExecutionError::MissingTerminalSession)?;
    let record = load_and_validate_terminal_session(&operation_root, &prepared_record)?;

    let final_record = match record.state() {
        SessionState::Prepared | SessionState::Running => persist_abnormal_termination(
            &operation_root,
            prepared_record.session(),
            running.prepared.lease(),
            record.revision(),
            SessionFailureCode::AbnormalTermination,
            Some("wait recovery terminated the runtime process".to_owned()),
        )
        .map_err(|persistence_failure| {
            let terminal_persisted =
                detailed_session_transition_committed(&persistence_failure);
            let error = ForegroundDataExecutionError::AbnormalTerminationPersistence {
                termination: termination.clone(),
                persistence_failure,
            };
            if terminal_persisted {
                error.bind_terminal_failure(
                    prepared_record.session().clone(),
                    SessionFailureCode::AbnormalTermination,
                )
            } else {
                error
            }
        })?,
        _ => record,
    };
    validate_terminal_session_identity(&prepared_record, &final_record)
        .map_err(|error| bind_session_record_error(error, &final_record))?;
    validate_or_rebuild_root_summary(&store, &final_record, running.prepared.lease())
        .map_err(|error| {
            bind_session_record_error(
                ForegroundDataExecutionError::RootSummaryReconciliationFailed(error),
                &final_record,
            )
        })?;
    Ok(final_record)
}

fn bind_session_record_error(
    error: ForegroundDataExecutionError,
    record: &SessionRecordV1,
) -> ForegroundDataExecutionError {
    match record.failure() {
        Some(failure) => error.bind_terminal_failure(record.session().clone(), failure.code()),
        None => error.bind_session(record.session().clone()),
    }
}

#[cfg(test)]
mod cancellation_reconciliation_tests {
    use super::*;
    use crate::data::test_support::{build_fake_coordinator, build_fake_project, open_store};

    const ABNORMAL_EXIT_HELPER_CONTEXT: &str = "lexicon-test-abnormal-exit-helper-v1";

    struct ControlFailureThenExitChild {
        force_attempted: bool,
    }

    impl SupervisedChild for ControlFailureThenExitChild {
        fn id(&self) -> u32 { 1 }
        fn try_wait(&mut self) -> std::io::Result<Option<std::process::ExitStatus>> {
            Ok(self.force_attempted.then(cancelled_status))
        }
        fn request_graceful_shutdown(&mut self, _: CancellationKind) -> std::io::Result<()> { Ok(()) }
        fn force_terminate_tree(&mut self) -> std::io::Result<()> {
            self.force_attempted = true;
            Err(std::io::Error::other("simulated process-tree control failure"))
        }
        fn wait_reaped(&mut self) -> std::io::Result<std::process::ExitStatus> { unreachable!() }
    }

    struct ImmediateCancellation;
    impl CancellationSource for ImmediateCancellation {
        fn requested(&self) -> Option<CancellationKind> {
            Some(CancellationKind::Terminate)
        }
    }

    struct NeverCancellation;
    impl CancellationSource for NeverCancellation {
        fn requested(&self) -> Option<CancellationKind> {
            None
        }
    }

    struct ImmediateExitChild {
        status: Option<std::process::ExitStatus>,
    }

    impl SupervisedChild for ImmediateExitChild {
        fn id(&self) -> u32 { 3 }
        fn try_wait(&mut self) -> std::io::Result<Option<std::process::ExitStatus>> {
            Ok(self.status.take())
        }
        fn request_graceful_shutdown(&mut self, _: CancellationKind) -> std::io::Result<()> {
            unreachable!("completed child must not receive cancellation")
        }
        fn force_terminate_tree(&mut self) -> std::io::Result<()> {
            unreachable!("completed child must not be force-terminated")
        }
        fn wait_reaped(&mut self) -> std::io::Result<std::process::ExitStatus> {
            unreachable!("try_wait already returned the reaped status")
        }
    }

    #[cfg(unix)]
    fn exit_status(code: i32) -> std::process::ExitStatus {
        use std::os::unix::process::ExitStatusExt;
        std::process::ExitStatus::from_raw(code << 8)
    }

    #[cfg(windows)]
    fn exit_status(code: i32) -> std::process::ExitStatus {
        use std::os::windows::process::ExitStatusExt;
        std::process::ExitStatus::from_raw(code as u32)
    }

    struct ControlErrorsThenReapedChild {
        termination_requests: usize,
    }

    impl SupervisedChild for ControlErrorsThenReapedChild {
        fn id(&self) -> u32 { 2 }
        fn try_wait(&mut self) -> std::io::Result<Option<std::process::ExitStatus>> {
            Err(std::io::Error::other("simulated status query failure"))
        }
        fn request_graceful_shutdown(&mut self, _: CancellationKind) -> std::io::Result<()> {
            Err(std::io::Error::other("simulated graceful-control failure"))
        }
        fn force_terminate_tree(&mut self) -> std::io::Result<()> {
            self.termination_requests += 1;
            Err(std::io::Error::other("simulated force-control uncertainty"))
        }
        fn wait_reaped(&mut self) -> std::io::Result<std::process::ExitStatus> {
            assert!(self.termination_requests > 0);
            Ok(cancelled_status())
        }
    }

    #[cfg(unix)]
    fn cancelled_status() -> std::process::ExitStatus {
        use std::os::unix::process::ExitStatusExt;
        std::process::ExitStatus::from_raw(libc::SIGTERM)
    }

    #[cfg(windows)]
    fn cancelled_status() -> std::process::ExitStatus {
        use std::os::windows::process::ExitStatusExt;
        std::process::ExitStatus::from_raw(1)
    }

    fn cancellation_reconciles_operation(operation: DataOperation) {
        let project = build_fake_project("cancel-source");
        let coordinator = build_fake_coordinator(&project, operation);
        let prepared = coordinator.prepare_run(RuntimeSupervisionMode::Foreground).unwrap();
        let session = prepared.session().clone();
        let running = RunningForegroundExecution {
            child: Box::new(ControlFailureThenExitChild { force_attempted: false }),
            prepared,
            operation,
            project_name: "test-project".to_owned(),
            source_name: project.source_name.clone(),
        };

        let result = running.wait_and_reconcile_with(
            &ImmediateCancellation,
            CancellationPolicy {
                graceful_timeout: std::time::Duration::ZERO,
                poll_interval: std::time::Duration::ZERO,
            },
        );
        assert!(matches!(
            result,
            Err(ForegroundDataExecutionError::CancellationControlFailure(_))
        ));

        let store = open_store(&project, operation);
        let record = store.load(&session).unwrap();
        assert_eq!(record.state(), SessionState::Failed);
        let summary = store.load_status().unwrap().unwrap();
        assert_eq!(summary.current_session(), Some(&session));
        assert_eq!(summary.current_state(), Some(SessionState::Failed));
        assert_eq!(summary.revision(), record.revision());
    }

    #[test]
    fn acquisition_cancellation_persists_failure_and_root_summary() {
        cancellation_reconciles_operation(DataOperation::Acquisition);
    }

    #[test]
    fn processing_cancellation_persists_failure_and_root_summary() {
        cancellation_reconciles_operation(DataOperation::Processing);
    }

    #[test]
    fn nonzero_child_without_terminal_record_is_reconciled_to_failed() {
        let project = build_fake_project("nonzero-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
        let prepared = coordinator.prepare_run(RuntimeSupervisionMode::Foreground).unwrap();
        let session = prepared.session().clone();
        let running = RunningForegroundExecution {
            child: Box::new(ImmediateExitChild { status: Some(exit_status(23)) }),
            prepared,
            operation: DataOperation::Acquisition,
            project_name: "test-project".to_owned(),
            source_name: project.source_name.clone(),
        };

        let result = running.wait_and_reconcile_with(
            &NeverCancellation,
            CancellationPolicy {
                graceful_timeout: std::time::Duration::ZERO,
                poll_interval: std::time::Duration::ZERO,
            },
        );
        let error = match result {
            Err(error) => error,
            Ok(_) => panic!("nonzero child without a terminal record must fail"),
        };
        assert!(matches!(
            &error,
            ForegroundDataExecutionError::ChildFailed {
                failure_kind: SessionFailureKind::AbnormalTermination,
                failure_code: SessionFailureCode::NonzeroExitWithoutFailureRecord,
                exit_code: Some(23),
                ..
            }
        ));

        let store = open_store(&project, DataOperation::Acquisition);
        let record = store.load(&session).unwrap();
        let summary = store.load_status().unwrap().unwrap();
        assert_eq!(record.state(), SessionState::Failed);
        assert_eq!(
            record.failure().map(|failure| failure.code()),
            Some(SessionFailureCode::NonzeroExitWithoutFailureRecord)
        );
        assert_eq!(summary.current_session(), Some(&session));
        assert_eq!(summary.current_state(), Some(SessionState::Failed));
        assert_eq!(summary.revision(), record.revision());
        let diagnostic = lexicon_core::diagnostic::ReportableDiagnostic::diagnostic(&error);
        assert_eq!(diagnostic.code().namespace(), "session");
        assert_eq!(
            Some(diagnostic.code().name()),
            record.failure().map(|failure| failure.code().identifier())
        );
    }

    #[test]
    fn zero_child_without_terminal_record_is_never_reported_as_success() {
        let project = build_fake_project("zero-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Processing);
        let prepared = coordinator.prepare_run(RuntimeSupervisionMode::Foreground).unwrap();
        let session = prepared.session().clone();
        let running = RunningForegroundExecution {
            child: Box::new(ImmediateExitChild { status: Some(exit_status(0)) }),
            prepared,
            operation: DataOperation::Processing,
            project_name: "test-project".to_owned(),
            source_name: project.source_name.clone(),
        };

        let result = running.wait_and_reconcile_with(
            &NeverCancellation,
            CancellationPolicy {
                graceful_timeout: std::time::Duration::ZERO,
                poll_interval: std::time::Duration::ZERO,
            },
        );
        assert!(matches!(
            result,
            Err(ForegroundDataExecutionError::ZeroExitSessionIncomplete { .. })
        ));

        let store = open_store(&project, DataOperation::Processing);
        let record = store.load(&session).unwrap();
        assert_eq!(record.state(), SessionState::Failed);
        assert_eq!(
            record.failure().map(|failure| failure.code()),
            Some(SessionFailureCode::ZeroExitWithoutCompletion)
        );
        let summary = store.load_status().unwrap().unwrap();
        assert_eq!(summary.current_state(), Some(SessionState::Failed));
        assert_eq!(summary.revision(), record.revision());
    }

    #[test]
    fn real_nonzero_child_exit_is_reaped_and_reconciled_to_failed() {
        if std::env::var_os(RUNTIME_CONTEXT_ENVIRONMENT_VARIABLE).as_deref()
            != Some(std::ffi::OsStr::new(ABNORMAL_EXIT_HELPER_CONTEXT))
        {
            let project = build_fake_project("real-nonzero-source");
            let coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
            let prepared = coordinator.prepare_run(RuntimeSupervisionMode::Foreground).unwrap();
            let session = prepared.session().clone();
            let executable = std::env::current_exe().unwrap();
            let arguments = [
                OsString::from("real_nonzero_child_exit_is_reaped_and_reconciled_to_failed"),
                OsString::from("--nocapture"),
            ];
            let child = ProcessTreeLauncher::spawn(
                &ProductionLauncher,
                &executable,
                &arguments,
                std::ffi::OsStr::new(ABNORMAL_EXIT_HELPER_CONTEXT),
                &project.project_root,
            )
            .unwrap();
            let running = RunningForegroundExecution {
                child,
                prepared,
                operation: DataOperation::Acquisition,
                project_name: "test-project".to_owned(),
                source_name: project.source_name.clone(),
            };

            let result = running.wait_and_reconcile_with(
                &NeverCancellation,
                CancellationPolicy {
                    graceful_timeout: std::time::Duration::from_secs(1),
                    poll_interval: std::time::Duration::from_millis(1),
                },
            );
            let error = match result {
                Err(error) => error,
                Ok(_) => panic!("nonzero child without a terminal record must fail"),
            };
            assert!(matches!(
                &error,
                ForegroundDataExecutionError::ChildFailed {
                    failure_kind: SessionFailureKind::AbnormalTermination,
                    failure_code: SessionFailureCode::NonzeroExitWithoutFailureRecord,
                    exit_code: Some(23),
                    ..
                }
            ));

            let store = open_store(&project, DataOperation::Acquisition);
            let record = store.load(&session).unwrap();
            let summary = store.load_status().unwrap().unwrap();
            assert_eq!(record.state(), SessionState::Failed);
            assert_eq!(
                record.failure().map(|failure| failure.code()),
                Some(SessionFailureCode::NonzeroExitWithoutFailureRecord)
            );
            assert_eq!(summary.current_session(), Some(&session));
            assert_eq!(summary.current_state(), Some(SessionState::Failed));
            assert_eq!(summary.revision(), record.revision());
            let diagnostic =
                lexicon_core::diagnostic::ReportableDiagnostic::diagnostic(&error);
            assert_eq!(diagnostic.code().namespace(), "session");
            assert_eq!(
                Some(diagnostic.code().name()),
                record.failure().map(|failure| failure.code().identifier())
            );
            return;
        }
        std::process::exit(23);
    }

    #[test]
    fn uncertain_control_retains_supervision_until_reaped_then_reconciles() {
        let project = build_fake_project("uncertain-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
        let prepared = coordinator.prepare_run(RuntimeSupervisionMode::Foreground).unwrap();
        let session = prepared.session().clone();
        let running = RunningForegroundExecution {
            child: Box::new(ControlErrorsThenReapedChild { termination_requests: 0 }),
            prepared,
            operation: DataOperation::Acquisition,
            project_name: "test-project".to_owned(),
            source_name: project.source_name.clone(),
        };

        let error = running.ownership_uncertain(
            std::io::Error::other("simulated initial wait failure"),
            Some(std::io::Error::other("simulated initial status failure")),
            Some(std::io::Error::other("simulated initial kill failure")),
            None,
        );
        let ForegroundDataExecutionError::ChildOwnershipUncertain(details) = error else {
            panic!("expected typed ownership-uncertain recovery error");
        };
        assert!(matches!(
            &details.observed_termination,
            ObservedChildTermination::Signaled { .. }
                | ObservedChildTermination::ExitCode(_)
                | ObservedChildTermination::UnknownAbnormalTermination
        ));
        assert_eq!(details.final_state, Some(SessionState::Failed));
        assert!(details.session_load_error.is_none());
        assert!(details.session_reconciliation_error.is_none());

        let store = open_store(&project, DataOperation::Acquisition);
        let record = store.load(&session).unwrap();
        let summary = store.load_status().unwrap().unwrap();
        assert_eq!(record.state(), SessionState::Failed);
        assert_eq!(summary.current_session(), Some(&session));
        assert_eq!(summary.current_state(), Some(SessionState::Failed));
        assert_eq!(summary.revision(), record.revision());
    }
}

#[cfg(test)]
mod admission_ordering_tests {
    use super::*;
    use crate::data::test_support::{
        RejectingRuntimeBundleAdmitter, assert_no_session_mutation,
        build_fake_project, with_test_cwd,
    };

    struct PanicLauncher;

    impl ForegroundRuntimeLauncher for PanicLauncher {
        fn spawn(
            &self,
            _executable: &Path,
            _arguments: &[OsString],
            _context_environment: &OsStr,
            _working_directory: &Path,
        ) -> Result<Box<dyn SupervisedChild>, std::io::Error> {
            panic!("runtime launch must not be reached after admission failure")
        }
    }

    fn admission_failure_precedes_session_mutation(operation: DataOperation) {
        let project = build_fake_project("admission-source");
        let admitter = RejectingRuntimeBundleAdmitter::new();
        let request = DataExecutionRequest {
            operation,
            source_name: project.source_name.clone(),
            protocol: "http".to_owned(),
            abandon_past_failure: false,
            background: false,
            source_arguments: Vec::new(),
        };

        let result = with_test_cwd(&project.project_root, || {
            execute_foreground_data_with_dependencies(
                request,
                &PanicLauncher,
                &admitter,
            )
        });

        match operation {
            DataOperation::Acquisition => assert!(matches!(
                result,
                Err(ForegroundDataExecutionError::HttpLaunchRuntimeProbe(_))
            )),
            DataOperation::Processing => assert!(matches!(
                result,
                Err(ForegroundDataExecutionError::ProcessingLaunchRuntimeProbe(_))
            )),
        }
        assert_eq!(admitter.calls(), 1);
        assert_no_session_mutation(&project, operation);
    }

    #[test]
    fn acquisition_probe_failure_precedes_foreground_session_creation() {
        admission_failure_precedes_session_mutation(DataOperation::Acquisition);
    }

    #[test]
    fn processing_probe_failure_precedes_foreground_session_creation() {
        admission_failure_precedes_session_mutation(DataOperation::Processing);
    }
}
