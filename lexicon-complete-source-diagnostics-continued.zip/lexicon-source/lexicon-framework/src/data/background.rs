use std::ffi::OsString;
use std::path::Path;
use std::process::Stdio;
use std::time::{Duration, Instant};

use lexicon_core::runtime::RuntimeSupervisionMode;
use lexicon_core::session::{
    generate_instance_nonce, HandoffAuthorityStateV1, HandoffClaimProof,
    HandoffRevocationReasonV1, HandoffToken, OperatorIdentityV1, SafeSessionFailure,
    SessionLeaseError, SessionStoreError,
};

use crate::data::error::{
    ForegroundDataExecutionError, OperatorHostHandoffCleanupFailure, OperatorHostHandoffError,
};
use crate::data::foreground::{
    spawn_and_supervise, PreparedForegroundExecution,
    ProcessCommandLauncher,
};
use crate::data::outcome::{BackgroundHandoffOutcome, ForegroundDataOutcome};
use crate::data::project::resolve_project_layout;
use crate::data::request::DataExecutionRequest;
use crate::data::runtime::{
    ProductionRuntimeBundleAdmitter, RuntimeBundleAdmitter,
};
use crate::data::session::{
    build_coordinator, build_project_identity, project_session_preparation_error,
    select_and_prepare_session,
};
use crate::session::{SessionCoordinationError, detailed_session_transition_committed};
use crate::supervision::{
    OperatorHostInvocationV1, OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE,
};

const HANDOFF_TIMEOUT: Duration = Duration::from_secs(10);
const POLL_INTERVAL: Duration = Duration::from_millis(20);

pub(crate) trait OperatorHostReExecutor {
    fn spawn_operator_host(
        &self,
        arguments: &[OsString],
        working_directory: &Path,
        private_handoff_token: &str,
    )
        -> Result<std::process::Child, std::io::Error>;
}

pub(crate) struct ProcessOperatorHostReExecutor;
impl OperatorHostReExecutor for ProcessOperatorHostReExecutor {
    fn spawn_operator_host(
        &self,
        arguments: &[OsString],
        working_directory: &Path,
        private_handoff_token: &str,
    )
        -> Result<std::process::Child, std::io::Error>
    {
        let mut command = std::process::Command::new(std::env::current_exe()?);
        command
            .args(arguments)
            .env(
                OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE,
                private_handoff_token,
            )
            .current_dir(working_directory)
            .stdin(Stdio::null())
            .stdout(Stdio::null())
            .stderr(Stdio::null());
        configure_detached_operator_host(&mut command);
        command.spawn()
    }
}

#[cfg(unix)]
fn configure_detached_operator_host(command: &mut std::process::Command) {
    use std::os::unix::process::CommandExt;

    // A background operator host must not remain in the invoking terminal's
    // session. `setsid` gives it a new session and process group before exec.
    unsafe {
        command.pre_exec(|| {
            if libc::setsid() == -1 {
                Err(std::io::Error::last_os_error())
            } else {
                Ok(())
            }
        });
    }
}

#[cfg(windows)]
fn configure_detached_operator_host(command: &mut std::process::Command) {
    use std::os::windows::process::CommandExt;

    const DETACHED_PROCESS: u32 = 0x0000_0008;
    const CREATE_NEW_PROCESS_GROUP: u32 = 0x0000_0200;
    command.creation_flags(DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP);
}

#[cfg(not(any(unix, windows)))]
fn configure_detached_operator_host(_command: &mut std::process::Command) {}

pub fn execute_background_data(request: DataExecutionRequest)
    -> Result<BackgroundHandoffOutcome, ForegroundDataExecutionError>
{
    execute_background_data_with_re_executor_and_timing(
        request, &ProcessOperatorHostReExecutor, HANDOFF_TIMEOUT, POLL_INTERVAL,
    )
}

pub(crate) fn execute_background_data_with_re_executor_and_timing(
    request: DataExecutionRequest,
    re_executor: &dyn OperatorHostReExecutor,
    timeout: Duration,
    poll_interval: Duration,
) -> Result<BackgroundHandoffOutcome, ForegroundDataExecutionError> {
    execute_background_data_with_dependencies(
        request,
        re_executor,
        timeout,
        poll_interval,
        &ProductionRuntimeBundleAdmitter,
    )
}

pub(crate) fn execute_background_data_with_dependencies(
    request: DataExecutionRequest,
    re_executor: &dyn OperatorHostReExecutor,
    timeout: Duration,
    poll_interval: Duration,
    admitter: &dyn RuntimeBundleAdmitter,
) -> Result<BackgroundHandoffOutcome, ForegroundDataExecutionError> {
    let (layout, project_name) = resolve_project_layout(
        &request.source_name, &request.protocol, request.operation,
    )?;
    // A background request must fail before creating a Prepared session when
    // the published runtime is absent, changed, incompatible, noisy, or
    // unresponsive.
    let admitted = admitter.admit(&layout, request.operation)?;
    let project_identity = build_project_identity(&project_name)?;
    let coordinator = build_coordinator(
        &layout, project_identity, admitted.identity().clone(), request.operation,
    )?;
    let token = HandoffToken::generate().map_err(|error|
        ForegroundDataExecutionError::OperatorHostHandoff(OperatorHostHandoffError::TokenGeneration(error)))?;
    let nonce = generate_instance_nonce().map_err(|error|
        ForegroundDataExecutionError::OperatorHostHandoff(OperatorHostHandoffError::NonceGeneration(error)))?;
    let expected_operator_nonce = nonce.clone();
    let timeout_nanos = u64::try_from(timeout.as_nanos()).map_err(|_| {
        ForegroundDataExecutionError::OperatorHostHandoff(
            OperatorHostHandoffError::TimeoutOutOfRange { timeout },
        )
    })?;
    let current_nanos = now_nanos()?;
    let expires_at = current_nanos.checked_add(timeout_nanos).ok_or_else(|| {
        ForegroundDataExecutionError::OperatorHostHandoff(
            OperatorHostHandoffError::DeadlineOverflow { now_unix_nanos: current_nanos, timeout_nanos },
        )
    })?;
    let prepared = select_and_prepare_session(
        &coordinator, request.operation, request.abandon_past_failure, &admitted,
        RuntimeSupervisionMode::Background,
    )?;
    let session = prepared.session().clone();
    let token_digest = token.digest();
    let reservation = match prepared.reserve_handoff(
        coordinator.store(), token_digest,
        OperatorIdentityV1 { instance_nonce: nonce.clone(), process_id: 0 }, expires_at,
    ) {
        Ok(reservation) => reservation,
        Err(error) => {
            let mut last_inspection = None;
            // A durable reservation may have been published before the
            // reserve call reported an I/O error. Keep the initiating lease
            // and retry inspection for a bounded interval so a transient read
            // failure cannot strand an authenticated authority record.
            let inspection_deadline = Instant::now() + timeout;
            let matching_epoch = loop {
                match coordinator.store().load_handoff_authority(&session) {
                    Ok(Some(authority))
                        if authority.token_digest == token_digest
                            && authority.expected_operator.instance_nonce
                                == expected_operator_nonce =>
                    {
                        break Some(authority.epoch);
                    }
                    Ok(_) => break None,
                    Err(inspection) if Instant::now() < inspection_deadline => {
                        last_inspection = Some(inspection);
                        std::thread::sleep(poll_interval.max(Duration::from_millis(1)));
                    }
                    Err(inspection) => {
                        last_inspection = Some(inspection);
                        break None;
                    }
                }
            };
            let primary = ForegroundDataExecutionError::OperatorHostHandoff(
                OperatorHostHandoffError::ReservationPublication { source: error, last_inspection },
            );
            return Err(match matching_epoch {
                Some(epoch) => fail_before_handoff_release(
                    None,
                    prepared,
                    coordinator.store(),
                    &session,
                    epoch,
                    HandoffRevocationReasonV1::InitiatorFailure,
                    primary,
                ),
                None => fail_unreserved_preparation(prepared, coordinator.store(), primary),
            });
        }
    };

    let reference = match OperatorHostInvocationV1::new_reserved(
        request.source_name.clone(), request.protocol.clone(), request.operation, session.clone(),
        reservation.epoch, nonce,
    ) {
        Ok(reference) => reference,
        Err(error) => return Err(fail_before_handoff_release(
            None,
            prepared,
            coordinator.store(),
            &session,
            reservation.epoch,
            HandoffRevocationReasonV1::InitiatorFailure,
            ForegroundDataExecutionError::OperatorHostDecoding(error),
        )),
    };
    let encoded = match reference.to_json() {
        Ok(encoded) => encoded,
        Err(error) => return Err(fail_before_handoff_release(
            None,
            prepared,
            coordinator.store(),
            &session,
            reservation.epoch,
            HandoffRevocationReasonV1::InitiatorFailure,
            ForegroundDataExecutionError::OperatorHostEncoding(error),
        )),
    };
    let mut arguments = vec![OsString::from("__operator-host"), OsString::from(encoded), OsString::from("--")];
    arguments.extend(request.source_arguments.iter().cloned());
    let mut private_token = token.expose_hex_for_private_transport();
    let spawn_result = re_executor.spawn_operator_host(
        &arguments,
        layout.project_root(),
        &private_token,
    );
    // SAFETY: NUL is valid UTF-8 and the encoded capability is no longer used
    // after the child environment has been copied by spawn.
    unsafe {
        private_token.as_bytes_mut().fill(0);
    }
    let mut child = match spawn_result {
        Ok(child) => child,
        Err(error) => {
            return Err(fail_before_handoff_release(
                None,
                prepared,
                coordinator.store(),
                &session,
                reservation.epoch,
                HandoffRevocationReasonV1::InitiatorFailure,
                ForegroundDataExecutionError::OperatorHostReExec(error),
            ));
        }
    };
    let expected_operator = OperatorIdentityV1 {
        instance_nonce: expected_operator_nonce.clone(),
        process_id: child.id(),
    };
    let deadline = Instant::now() + timeout;
    loop {
        let observed = match child.try_wait() {
            Ok(value) => value,
            Err(error) => {
                return Err(fail_before_handoff_release(
                    Some(&mut child), prepared, coordinator.store(), &session,
                    reservation.epoch, HandoffRevocationReasonV1::InitiatorFailure,
                    ForegroundDataExecutionError::OperatorHostReExec(error),
                ));
            }
        };
        if let Some(status) = observed {
            return Err(fail_before_handoff_release(
                Some(&mut child), prepared, coordinator.store(), &session,
                reservation.epoch, HandoffRevocationReasonV1::OperatorExited,
                ForegroundDataExecutionError::OperatorHostExitedBeforeOwnership {
                    exit_code: status.code(),
                },
            ));
        }
        let authority = match coordinator.store().load_handoff_authority(&session) {
            Ok(Some(authority)) => authority,
            Ok(None) => {
                return Err(fail_before_handoff_release(
                    Some(&mut child), prepared, coordinator.store(), &session,
                    reservation.epoch, HandoffRevocationReasonV1::InitiatorFailure,
                    ForegroundDataExecutionError::OperatorHostHandoff(OperatorHostHandoffError::ReservationMissing),
                ));
            }
            Err(error) => {
                return Err(fail_before_handoff_release(
                    Some(&mut child), prepared, coordinator.store(), &session,
                    reservation.epoch, HandoffRevocationReasonV1::InitiatorFailure,
                    ForegroundDataExecutionError::OperatorHostHandoff(OperatorHostHandoffError::AuthorityLoad(error)),
                ));
            }
        };
        let operator_host_pid = child.id();
        if authority.epoch != reservation.epoch || authority.expected_operator.process_id != operator_host_pid {
            return Err(fail_before_handoff_release(
                Some(&mut child), prepared, coordinator.store(), &session,
                reservation.epoch, HandoffRevocationReasonV1::InitiatorFailure,
                ForegroundDataExecutionError::OperatorHostHandoff(
                    OperatorHostHandoffError::AcknowledgementMismatch {
                        expected_epoch: reservation.epoch,
                        actual_epoch: authority.epoch,
                        expected_process_id: operator_host_pid,
                        actual_process_id: authority.expected_operator.process_id,
                    },
                ),
            ));
        }
        if matches!(authority.state, HandoffAuthorityStateV1::Ready { .. }) { break; }
        if Instant::now() >= deadline {
            return Err(fail_before_handoff_release(
                Some(&mut child), prepared, coordinator.store(), &session,
                reservation.epoch, HandoffRevocationReasonV1::Timeout,
                ForegroundDataExecutionError::OperatorHostOwnershipTimeout,
            ));
        }
        std::thread::sleep(poll_interval);
    }

    if let Err(error) = prepared.validate_reserved_handoff_for_release(
        coordinator.store(),
        reservation.epoch,
        &token,
        &expected_operator,
    ) {
        return Err(fail_before_handoff_release(
            Some(&mut child), prepared, coordinator.store(), &session, reservation.epoch,
            HandoffRevocationReasonV1::InitiatorFailure,
            project_session_preparation_error(error),
        ));
    }
    prepared.release_reserved_handoff();
    let mut observation_failure: Option<OperatorHostHandoffError> = None;
    loop {
        match handoff_is_owned_by(
            &mut child,
            &coordinator,
            &session,
            reservation.epoch,
            &token,
            &expected_operator,
        ) {
        Ok(true) => {
                return Ok(BackgroundHandoffOutcome { project: project_name, source: request.source_name,
                    operation: request.operation, session });
        }
        Ok(false) => {}
        Err(ForegroundDataExecutionError::OperatorHostHandoff(error)) => observation_failure = Some(error),
        Err(error) => return Err(error.bind_session(session.clone())),
        }
        let child_status = match child.try_wait() {
            Ok(status) => status,
            Err(source) => { observation_failure = Some(OperatorHostHandoffError::ChildStatus { stage: "ownership observation", source }); None }
        };
        if let Some(status) = child_status {
            let resolution = match resolve_failed_handoff(
                &mut child, &coordinator, &session, reservation.epoch, &token, &expected_operator,
                HandoffRevocationReasonV1::OperatorExited,
            ) {
                Ok(resolution) => resolution,
                Err(primary) => {
                    match fail_after_handoff_release(
                        &mut child, &coordinator, &session, reservation.epoch,
                        &token, &expected_operator, HandoffRevocationReasonV1::OperatorExited,
                        primary,
                    ) {
                        PostReleaseFailureResolution::Owned => return Ok(BackgroundHandoffOutcome {
                            project: project_name,
                            source: request.source_name,
                            operation: request.operation,
                            session,
                        }),
                        PostReleaseFailureResolution::Failed(error) => return Err(error),
                    }
                }
            };
            match resolution {
                TransferResolution::Owned => {
                    let primary = ForegroundDataExecutionError::OperatorHostExitedBeforeOwnership {
                        exit_code: status.code(),
                    };
                    match coordinator.recover_handoff_after_operator_death(
                        &session, reservation.epoch, &expected_operator,
                    ) {
                        Ok(prepared) => {
                            return Err(finish_recovered_handoff_failure(
                                &mut child, prepared, coordinator.store(), primary,
                            ));
                        }
                        Err(error) => {
                            return Err(
                                aggregate_handoff_failure(
                                    primary,
                                    terminate_and_reap(&mut child),
                                    None,
                                    vec![error],
                                )
                                .bind_session(session.clone()),
                            );
                        }
                    }
                }
                TransferResolution::Recovered(prepared) => {
                    let primary = match observation_failure {
                        Some(error) => ForegroundDataExecutionError::OperatorHostHandoff(error),
                        None => ForegroundDataExecutionError::OperatorHostExitedBeforeOwnership { exit_code: status.code() },
                    };
                    return Err(finish_recovered_handoff_failure(
                        &mut child, prepared, coordinator.store(), primary,
                    ));
                }
                TransferResolution::Pending => {}
            }
        }
        if Instant::now() >= deadline {
            let resolution = match resolve_failed_handoff(
                &mut child, &coordinator, &session, reservation.epoch, &token, &expected_operator,
                HandoffRevocationReasonV1::Timeout,
            ) {
                Ok(resolution) => resolution,
                Err(primary) => {
                    match fail_after_handoff_release(
                        &mut child, &coordinator, &session, reservation.epoch,
                        &token, &expected_operator, HandoffRevocationReasonV1::Timeout,
                        primary,
                    ) {
                        PostReleaseFailureResolution::Owned => return Ok(BackgroundHandoffOutcome {
                            project: project_name,
                            source: request.source_name,
                            operation: request.operation,
                            session,
                        }),
                        PostReleaseFailureResolution::Failed(error) => return Err(error),
                    }
                }
            };
            match resolution {
                TransferResolution::Recovered(prepared) => {
                    let primary = observation_failure.take().map_or(
                        ForegroundDataExecutionError::OperatorHostOwnershipTimeout,
                        |error| ForegroundDataExecutionError::OperatorHostHandoff(error),
                    );
                    return Err(finish_recovered_handoff_failure(
                        &mut child, prepared, coordinator.store(), primary,
                    ));
                }
                TransferResolution::Owned => {
                    return Ok(BackgroundHandoffOutcome {
                        project: project_name,
                        source: request.source_name,
                        operation: request.operation,
                        session,
                    });
                }
                TransferResolution::Pending => {
                    match coordinator.fence_ready_handoff(
                        &session, reservation.epoch, &token, &expected_operator,
                        HandoffRevocationReasonV1::Timeout,
                    ) {
                        Ok(lexicon_core::session::HandoffFenceOutcome::AlreadyOwned) => {
                            if handoff_is_owned_by(
                                &mut child,
                                &coordinator,
                                &session,
                                reservation.epoch,
                                &token,
                                &expected_operator,
                            )
                            .map_err(|error| error.bind_session(session.clone()))?
                            {
                                return Ok(BackgroundHandoffOutcome {
                                    project: project_name,
                                    source: request.source_name,
                                    operation: request.operation,
                                    session,
                                });
                            }
                            let recovered = coordinator.recover_handoff_after_operator_death(
                                &session,
                                reservation.epoch,
                                &expected_operator,
                            )
                            .map_err(|error| {
                                project_session_preparation_error(error)
                                    .bind_session(session.clone())
                            })?;
                            let exit_code = child.try_wait().ok().flatten()
                                .and_then(|status| status.code());
                            return Err(finish_recovered_handoff_failure(
                                &mut child,
                                recovered,
                                coordinator.store(),
                                ForegroundDataExecutionError::OperatorHostExitedBeforeOwnership {
                                    exit_code,
                                },
                            ));
                        }
                        Ok(lexicon_core::session::HandoffFenceOutcome::Revoked) => {
                            let cleanup = terminate_and_reap(&mut child);
                            let recovered = coordinator.revoke_and_recover_handoff(
                                &session, reservation.epoch, HandoffRevocationReasonV1::Timeout,
                            )
                            .map_err(|error| {
                                project_session_preparation_error(error)
                                    .bind_session(session.clone())
                            })?;
                            let primary = observation_failure.take().map_or(
                                ForegroundDataExecutionError::OperatorHostOwnershipTimeout,
                                |error| ForegroundDataExecutionError::OperatorHostHandoff(error),
                            );
                            return Err(finish_recovered_handoff_failure_with_cleanup(
                                recovered, coordinator.store(), primary, cleanup,
                            ));
                        }
                        Err(error) => {
                            let primary = ForegroundDataExecutionError::OperatorHostHandoff(
                                OperatorHostHandoffError::TimeoutFencing(error),
                            );
                            match fail_after_handoff_release(
                                &mut child,
                                &coordinator,
                                &session,
                                reservation.epoch,
                                &token,
                                &expected_operator,
                                HandoffRevocationReasonV1::Timeout,
                                primary,
                            ) {
                                PostReleaseFailureResolution::Owned => {
                                    return Ok(BackgroundHandoffOutcome {
                                        project: project_name,
                                        source: request.source_name,
                                        operation: request.operation,
                                        session,
                                    });
                                }
                                PostReleaseFailureResolution::Failed(error) => return Err(error),
                            }
                        }
                    }
                }
            }
        }
        std::thread::sleep(poll_interval);
    }
}

pub fn execute_operator_host(
    reference: OperatorHostInvocationV1,
    token: HandoffToken,
    source_arguments: Vec<OsString>,
) -> Result<ForegroundDataOutcome, ForegroundDataExecutionError> {
    execute_operator_host_with_admitter(
        reference,
        token,
        source_arguments,
        &ProductionRuntimeBundleAdmitter,
    )
}

pub(crate) fn execute_operator_host_with_admitter(
    reference: OperatorHostInvocationV1,
    token: HandoffToken,
    source_arguments: Vec<OsString>,
    admitter: &dyn RuntimeBundleAdmitter,
) -> Result<ForegroundDataOutcome, ForegroundDataExecutionError> {
    if reference.handoff_epoch() == 0 || reference.operator_instance_nonce().is_empty() {
        return Err(ForegroundDataExecutionError::OperatorHostHandoff(OperatorHostHandoffError::MissingReferenceFields));
    }
    let request = DataExecutionRequest {
        operation: reference.operation(), source_name: reference.source_name().to_owned(),
        protocol: reference.protocol().to_owned(), abandon_past_failure: false,
        background: true, source_arguments,
    };
    let (layout, project_name) = resolve_project_layout(&request.source_name, &request.protocol, request.operation)?;
    // The operator host repeats the complete admission immediately before it
    // claims durable authority.  This closes replacement between the original
    // CLI's probe and the eventual source-runtime launch.
    let admitted = admitter.admit(&layout, request.operation)?;
    let project_identity = build_project_identity(&project_name)?;
    let coordinator = build_coordinator(&layout, project_identity.clone(), admitted.identity().clone(), request.operation)?;
    let proof = HandoffClaimProof {
        session_id: reference.session().id().to_string(), epoch: reference.handoff_epoch(), token,
        operator: OperatorIdentityV1 { instance_nonce: reference.operator_instance_nonce().to_string(), process_id: std::process::id() },
    };
    coordinator
        .validate_reserved_session_identity(reference.session())
        .map_err(ForegroundDataExecutionError::SessionPreparation)?;
    let validated_session = reference.session().clone();
    coordinator.mark_handoff_ready(&proof).map_err(|error| {
        project_session_preparation_error(error)
            .bind_session(validated_session.clone())
    })?;
    let prepared = loop {
        let authority = coordinator.store().load_handoff_authority(reference.session())
            .map_err(|error| {
                ForegroundDataExecutionError::OperatorHostHandoff(
                    OperatorHostHandoffError::AuthorityLoad(error),
                )
                .bind_session(validated_session.clone())
            })?
            .ok_or_else(|| {
                ForegroundDataExecutionError::OperatorHostHandoff(
                    OperatorHostHandoffError::ReservationMissing,
                )
                .bind_session(validated_session.clone())
            })?;
        if now_nanos()
            .map_err(|error| error.bind_session(validated_session.clone()))?
            > authority.expires_at_unix_nanos
        {
            return Err(
                ForegroundDataExecutionError::OperatorHostOwnershipTimeout
                    .bind_session(validated_session.clone()),
            );
        }
        match coordinator.claim_reserved_handoff(&proof) {
            Ok(prepared) => break prepared,
            Err(SessionCoordinationError::Store(SessionStoreError::LeaseRequired(SessionLeaseError::AlreadyOwned))) => std::thread::sleep(POLL_INTERVAL),
            Err(error) => {
                return Err(
                    project_session_preparation_error(error)
                        .bind_session(validated_session.clone()),
                );
            }
        }
    };
    let execution = PreparedForegroundExecution::new(prepared, request.operation, project_name, request.source_name);
    spawn_and_supervise(
        execution, &layout, &admitted, &coordinator, &request.source_arguments,
        RuntimeSupervisionMode::Background, &ProcessCommandLauncher,
    )
    .map_err(|error| error.bind_session(validated_session))
}

enum TransferResolution { Owned, Recovered(crate::session::PreparedSessionLaunch), Pending }

fn resolve_failed_handoff(
    child: &mut std::process::Child,
    coordinator: &crate::session::SessionCoordinator,
    session: &lexicon_core::session::SessionIdentity,
    epoch: u64,
    token: &HandoffToken,
    expected_operator: &OperatorIdentityV1,
    reason: HandoffRevocationReasonV1,
) -> Result<TransferResolution, ForegroundDataExecutionError> {
    if handoff_is_owned_by(child, coordinator, session, epoch, token, expected_operator)? {
        return Ok(TransferResolution::Owned);
    }
    match coordinator.revoke_and_recover_handoff(session, epoch, reason) {
        Ok(prepared) => Ok(TransferResolution::Recovered(prepared)),
        Err(error) => {
            if handoff_is_owned_by(child, coordinator, session, epoch, token, expected_operator)? {
                Ok(TransferResolution::Owned)
            } else if matches!(error, SessionCoordinationError::Store(SessionStoreError::LeaseRequired(SessionLeaseError::AlreadyOwned))) {
                Ok(TransferResolution::Pending)
            } else {
                Err(project_session_preparation_error(error))
            }
        }
    }
}

fn handoff_is_owned_by(
    child: &mut std::process::Child,
    coordinator: &crate::session::SessionCoordinator,
    session: &lexicon_core::session::SessionIdentity,
    epoch: u64,
    token: &HandoffToken,
    expected_operator: &OperatorIdentityV1,
) -> Result<bool, ForegroundDataExecutionError> {
    if child.try_wait().map_err(|source| {
        ForegroundDataExecutionError::OperatorHostHandoff(
            OperatorHostHandoffError::ChildStatus { stage: "liveness probe", source },
        )
    })?.is_some() {
        return Ok(false);
    }
    if !coordinator
        .verify_live_owned_handoff(session, epoch, token, expected_operator)
        .map_err(|error| ForegroundDataExecutionError::OperatorHostHandoff(OperatorHostHandoffError::OwnershipVerification(error)))?
    {
        return Ok(false);
    }
    Ok(child.try_wait().map_err(|source| {
        ForegroundDataExecutionError::OperatorHostHandoff(
            OperatorHostHandoffError::ChildStatus { stage: "liveness confirmation", source },
        )
    })?.is_none())
}

#[derive(Default)]
struct ChildCleanupFailures {
    status_probe: Option<std::io::Error>,
    termination: Option<std::io::Error>,
    reap: Option<std::io::Error>,
}

fn fail_before_handoff_release(
    child: Option<&mut std::process::Child>,
    prepared: crate::session::PreparedSessionLaunch,
    store: &lexicon_core::session::SessionStore,
    session: &lexicon_core::session::SessionIdentity,
    epoch: u64,
    reason: HandoffRevocationReasonV1,
    primary: ForegroundDataExecutionError,
) -> ForegroundDataExecutionError {
    let cleanup = child.map_or_else(ChildCleanupFailures::default, terminate_and_reap);
    let handoff_revocation = prepared.revoke_handoff(store, epoch, reason).err();
    let session_reconciliation = prepared
        .fail_launch(store, handoff_runtime_failure())
        .err();
    let terminal_persisted = session_reconciliation
        .as_ref()
        .map_or(true, detailed_session_transition_committed);
    let error = aggregate_handoff_failure(
        primary,
        cleanup,
        handoff_revocation,
        session_reconciliation.into_iter().collect(),
    );
    bind_handoff_failure(error, session.clone(), terminal_persisted)
}

fn fail_unreserved_preparation(
    prepared: crate::session::PreparedSessionLaunch,
    store: &lexicon_core::session::SessionStore,
    primary: ForegroundDataExecutionError,
) -> ForegroundDataExecutionError {
    let session = prepared.session().clone();
    let session_reconciliation = prepared
        .fail_launch(store, handoff_runtime_failure())
        .err();
    let terminal_persisted = session_reconciliation
        .as_ref()
        .map_or(true, detailed_session_transition_committed);
    let error = aggregate_handoff_failure(
        primary,
        ChildCleanupFailures::default(),
        None,
        session_reconciliation.into_iter().collect(),
    );
    bind_handoff_failure(error, session, terminal_persisted)
}

fn finish_recovered_handoff_failure(
    child: &mut std::process::Child,
    prepared: crate::session::PreparedSessionLaunch,
    store: &lexicon_core::session::SessionStore,
    primary: ForegroundDataExecutionError,
) -> ForegroundDataExecutionError {
    let cleanup = terminate_and_reap(child);
    finish_recovered_handoff_failure_with_cleanup(prepared, store, primary, cleanup)
}

enum PostReleaseFailureResolution {
    Owned,
    Failed(ForegroundDataExecutionError),
}

fn fail_after_handoff_release(
    child: &mut std::process::Child,
    coordinator: &crate::session::SessionCoordinator,
    session: &lexicon_core::session::SessionIdentity,
    epoch: u64,
    token: &HandoffToken,
    expected_operator: &OperatorIdentityV1,
    reason: HandoffRevocationReasonV1,
    primary: ForegroundDataExecutionError,
) -> PostReleaseFailureResolution {
    let mut reconciliation_errors = Vec::new();
    loop {
        if matches!(
            handoff_is_owned_by(child, coordinator, session, epoch, token, expected_operator),
            Ok(true)
        ) {
            return PostReleaseFailureResolution::Owned;
        }

        match coordinator.fence_ready_handoff(
            session,
            epoch,
            token,
            expected_operator,
            reason,
        ) {
            Ok(lexicon_core::session::HandoffFenceOutcome::AlreadyOwned) => {
                // The durable record said Owned, but success still requires
                // the exact physical lease identity and a live child. If the
                // child is dead, recover under the physical lease below.
            }
            Ok(lexicon_core::session::HandoffFenceOutcome::Revoked) => {
                let cleanup = terminate_and_reap(child);
                match coordinator.revoke_and_recover_handoff(session, epoch, reason) {
                    Ok(prepared) => {
                        let session_reconciliation = prepared.fail_launch(
                            coordinator.store(),
                            handoff_runtime_failure(),
                        ).err();
                        let terminal_persisted = session_reconciliation
                            .as_ref()
                            .map_or(true, detailed_session_transition_committed);
                        reconciliation_errors.extend(session_reconciliation);
                        let error = aggregate_handoff_failure(
                            primary,
                            cleanup,
                            None,
                            reconciliation_errors,
                        );
                        return PostReleaseFailureResolution::Failed(bind_handoff_failure(
                            error,
                            session.clone(),
                            terminal_persisted,
                        ));
                    }
                    Err(error) => reconciliation_errors.push(error),
                }
            }
            Err(error) => reconciliation_errors.push(error),
        }

        let child_dead = match child.try_wait() {
            Ok(Some(_)) => true,
            Ok(None) => false,
            Err(_) => false,
        };
        if child_dead {
            match coordinator.recover_handoff_after_operator_death(session, epoch, expected_operator) {
                Ok(prepared) => {
                    let session_reconciliation = prepared.fail_launch(
                        coordinator.store(),
                        handoff_runtime_failure(),
                    ).err();
                    let terminal_persisted = session_reconciliation
                        .as_ref()
                        .map_or(true, detailed_session_transition_committed);
                    reconciliation_errors.extend(session_reconciliation);
                    let error = aggregate_handoff_failure(
                        primary,
                        ChildCleanupFailures::default(),
                        None,
                        reconciliation_errors,
                    );
                    return PostReleaseFailureResolution::Failed(bind_handoff_failure(
                        error,
                        session.clone(),
                        terminal_persisted,
                    ));
                }
                Err(error) => reconciliation_errors.push(error),
            }
        }

        // Preserve a bounded diagnostic history while supervision remains
        // attached. Persistent ambiguity intentionally does not return or kill
        // across a transfer which may already have completed.
        if reconciliation_errors.len() > 8 {
            reconciliation_errors.remove(0);
        }
        std::thread::sleep(POLL_INTERVAL);
    }
}

fn finish_recovered_handoff_failure_with_cleanup(
    prepared: crate::session::PreparedSessionLaunch,
    store: &lexicon_core::session::SessionStore,
    primary: ForegroundDataExecutionError,
    cleanup: ChildCleanupFailures,
) -> ForegroundDataExecutionError {
    let session = prepared.session().clone();
    let session_reconciliation = prepared
        .fail_launch(store, handoff_runtime_failure())
        .err();
    let terminal_persisted = session_reconciliation
        .as_ref()
        .map_or(true, detailed_session_transition_committed);
    let error = aggregate_handoff_failure(
        primary,
        cleanup,
        None,
        session_reconciliation.into_iter().collect(),
    );
    bind_handoff_failure(error, session, terminal_persisted)
}

fn bind_handoff_failure(
    error: ForegroundDataExecutionError,
    session: lexicon_core::session::SessionIdentity,
    terminal_persisted: bool,
) -> ForegroundDataExecutionError {
    if terminal_persisted {
        error.bind_terminal_failure(
            session,
            lexicon_core::session::SessionFailureCode::RuntimeInitializationFailed,
        )
    } else {
        error.bind_session(session)
    }
}

fn aggregate_handoff_failure(
    primary: ForegroundDataExecutionError,
    cleanup: ChildCleanupFailures,
    handoff_revocation: Option<SessionCoordinationError>,
    session_reconciliation: Vec<SessionCoordinationError>,
) -> ForegroundDataExecutionError {
    let failure = OperatorHostHandoffCleanupFailure {
        primary: Box::new(primary),
        child_status_probe: cleanup.status_probe,
        child_termination: cleanup.termination,
        child_reap: cleanup.reap,
        handoff_revocation,
        session_reconciliation,
    };
    if failure.has_cleanup_failure() {
        ForegroundDataExecutionError::OperatorHostHandoffCleanup(Box::new(failure))
    } else {
        *failure.primary
    }
}

fn terminate_and_reap(child: &mut std::process::Child) -> ChildCleanupFailures {
    let mut failures = ChildCleanupFailures::default();
    match child.try_wait() {
        Ok(Some(_)) => return failures,
        Ok(None) => {}
        Err(error) => failures.status_probe = Some(error),
    }

    if let Err(error) = child.kill() {
        failures.termination = Some(error);
    }

    loop {
        match child.wait() {
            Ok(_) => break,
            Err(error) if error.kind() == std::io::ErrorKind::Interrupted => continue,
            Err(error) => {
                if failures.reap.is_none() {
                    failures.reap = Some(error);
                }
                match child.try_wait() {
                    Ok(Some(_)) => break,
                    Ok(None) | Err(_) => std::thread::sleep(POLL_INTERVAL),
                }
            }
        }
    }
    failures
}

fn now_nanos() -> Result<u64, ForegroundDataExecutionError> {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH)
        .map(|duration| duration.as_nanos().min(u64::MAX as u128) as u64)
        .map_err(|error| ForegroundDataExecutionError::OperatorHostHandoff(
            OperatorHostHandoffError::SystemClock(error),
        ))
}

fn handoff_runtime_failure() -> SafeSessionFailure {
    SafeSessionFailure::runtime_failure(
        lexicon_core::session::SessionFailureCode::RuntimeInitializationFailed,
        Some("background operator-host supervision transfer failed".into()),
    )
}

#[cfg(test)]
mod admission_ordering_tests {
    use super::*;
    use crate::data::test_support::{
        RejectingRuntimeBundleAdmitter, assert_no_session_mutation,
        build_fake_coordinator, build_fake_project, with_test_cwd,
    };
    use crate::data::request::DataOperation;
    use lexicon_core::session::HandoffAuthorityStateV1;

    struct PanicReExecutor;

    impl OperatorHostReExecutor for PanicReExecutor {
        fn spawn_operator_host(
            &self,
            _arguments: &[OsString],
            _working_directory: &Path,
            _private_handoff_token: &str,
        ) -> Result<std::process::Child, std::io::Error> {
            panic!("operator-host spawn must not be reached after admission failure")
        }
    }

    fn initiator_admission_failure_precedes_session_mutation(operation: DataOperation) {
        let project = build_fake_project("background-admission-source");
        let admitter = RejectingRuntimeBundleAdmitter::new();
        let request = DataExecutionRequest {
            operation,
            source_name: project.source_name.clone(),
            protocol: "http".to_owned(),
            abandon_past_failure: false,
            background: true,
            source_arguments: Vec::new(),
        };

        let result = with_test_cwd(&project.project_root, || {
            execute_background_data_with_dependencies(
                request,
                &PanicReExecutor,
                Duration::from_millis(10),
                Duration::from_millis(1),
                &admitter,
            )
        });

        match operation {
            DataOperation::Acquisition => assert!(matches!(
                result,
                Err(ForegroundDataExecutionError::HttpLaunchRuntimeProbe(_))
            )),
            DataOperation::Processing => assert!(matches!(
                result,
                Err(ForegroundDataExecutionError::ProcessingLaunchRuntimeProbe(_))
            )),
        }
        assert_eq!(admitter.calls(), 1);
        assert_no_session_mutation(&project, operation);
    }

    #[test]
    fn acquisition_probe_failure_precedes_background_session_creation() {
        initiator_admission_failure_precedes_session_mutation(DataOperation::Acquisition);
    }

    #[test]
    fn processing_probe_failure_precedes_background_session_creation() {
        initiator_admission_failure_precedes_session_mutation(DataOperation::Processing);
    }

    #[test]
    fn operator_host_probe_failure_does_not_claim_reserved_authority() {
        let project = build_fake_project("operator-admission-source");
        let coordinator = build_fake_coordinator(&project, DataOperation::Acquisition);
        let prepared = coordinator
            .prepare_run(RuntimeSupervisionMode::Background)
            .expect("prepare reserved session");
        let session = prepared.session().clone();
        let token = HandoffToken::generate().expect("handoff token");
        let nonce = generate_instance_nonce().expect("operator nonce");
        let reservation = prepared
            .reserve_handoff(
                coordinator.store(),
                token.digest(),
                OperatorIdentityV1 {
                    instance_nonce: nonce.clone(),
                    process_id: 0,
                },
                u64::MAX,
            )
            .expect("reserve handoff");
        let reference = OperatorHostInvocationV1::new_reserved(
            project.source_name.clone(),
            "http",
            DataOperation::Acquisition,
            session.clone(),
            reservation.epoch,
            nonce,
        )
        .expect("operator-host reference");
        let admitter = RejectingRuntimeBundleAdmitter::new();

        let result = with_test_cwd(&project.project_root, || {
            execute_operator_host_with_admitter(
                reference,
                token,
                Vec::new(),
                &admitter,
            )
        });

        assert!(matches!(
            result,
            Err(ForegroundDataExecutionError::HttpLaunchRuntimeProbe(_))
        ));
        assert_eq!(admitter.calls(), 1);
        let authority = coordinator
            .store()
            .load_handoff_authority(&session)
            .expect("load reservation")
            .expect("reservation remains present");
        assert_eq!(authority.state, HandoffAuthorityStateV1::Reserved);
        assert_eq!(authority.epoch, reservation.epoch);
    }
}
