use std::env;
use std::path::{Path, PathBuf};

use crate::data::error::{
    ForegroundDataExecutionError, PathKind, ProjectConfigurationError, ProjectDiscoveryError,
    RuntimeProjectLayoutError,
};
use crate::data::request::DataOperation;
use crate::identity::{ManagedName, ManagedProtocol};
use crate::project::{Project, ProjectError};

// ---------------------------------------------------------------------------
// RuntimeProjectLayout
// ---------------------------------------------------------------------------

/// Session-independent validated project/source/protocol layout.
///
/// All fields are absolute paths. Structural containment is verified at
/// construction time:
/// The admitted relationships are `sources_root = project_root / configured
/// sources directory` and `protocol_root = sources_root / source / protocol`.
#[derive(Debug)]
pub struct RuntimeProjectLayout {
    location: crate::project::SourceLocation,
}

impl RuntimeProjectLayout {
    /// Absolute project root directory.
    pub fn project_root(&self) -> &Path {
        self.location.project().root()
    }

    /// Absolute sources root directory (`project_root/<configured-sources-directory>`).
    pub fn sources_root(&self) -> &Path {
        self.location.project().sources_root()
    }

    /// Validated source name.
    pub fn source_name(&self) -> &str {
        self.location.source().as_str()
    }

    /// Validated protocol name.
    pub fn protocol(&self) -> &str {
        self.location.protocol().as_str()
    }

    /// Absolute protocol root: `sources_root/<source_name>/<protocol>`.
    pub fn protocol_root(&self) -> &Path {
        self.location.protocol_root()
    }

    // -----------------------------------------------------------------------
    // Derived paths
    // -----------------------------------------------------------------------

    /// `protocol_root/data/raw`
    pub fn raw_data_directory(&self) -> PathBuf {
        self.protocol_root().join("data/raw")
    }

    /// `protocol_root/data/processed`
    pub fn processed_data_directory(&self) -> PathBuf {
        self.protocol_root().join("data/processed")
    }

    /// `protocol_root/get-raw-data`
    pub fn acquisition_operation_root(&self) -> PathBuf {
        self.protocol_root().join("get-raw-data")
    }

    /// `protocol_root/process-data`
    pub fn processing_operation_root(&self) -> PathBuf {
        self.protocol_root().join("process-data")
    }

    /// Operation root for the given operation.
    pub fn operation_root(&self, operation: DataOperation) -> PathBuf {
        match operation {
            DataOperation::Acquisition => self.acquisition_operation_root(),
            DataOperation::Processing => self.processing_operation_root(),
        }
    }

    /// `protocol_root/get-raw-data/runtime`
    pub fn acquisition_bundle_directory(&self) -> PathBuf {
        self.protocol_root().join("get-raw-data/runtime")
    }

    /// `protocol_root/process-data/runtime`
    pub fn processing_bundle_directory(&self) -> PathBuf {
        self.protocol_root().join("process-data/runtime")
    }

    /// Runtime bundle directory for the given operation.
    pub fn bundle_directory(&self, operation: DataOperation) -> PathBuf {
        match operation {
            DataOperation::Acquisition => self.acquisition_bundle_directory(),
            DataOperation::Processing => self.processing_bundle_directory(),
        }
    }

    /// Session directory: `operation_root/sessions/<session_id>`.
    pub fn session_directory(&self, operation: DataOperation, session_id: &str) -> PathBuf {
        self.operation_root(operation)
            .join("sessions")
            .join(session_id)
    }
}

// ---------------------------------------------------------------------------
// Discovery and construction
// ---------------------------------------------------------------------------

/// Discover the project, load configuration, validate the source layout, and
/// construct a `RuntimeProjectLayout` for the given source, protocol, and operation.
pub fn resolve_project_layout(
    source_name: &str,
    protocol: &str,
    operation: DataOperation,
) -> Result<(RuntimeProjectLayout, String), ForegroundDataExecutionError> {
    let cwd = env::current_dir().map_err(|e| {
        ForegroundDataExecutionError::ProjectDiscovery(
            ProjectDiscoveryError::CurrentDirectory(e),
        )
    })?;

    let project = Project::discover_from(&cwd).map_err(|error| {
        ForegroundDataExecutionError::ProjectDiscovery(ProjectDiscoveryError::FindRoot(
            crate::ProjectRootDiscoveryError::InvalidProject(error),
        ))
    })?;
    let source = ManagedName::parse(source_name)
        .map_err(|error| ForegroundDataExecutionError::ProjectLayout(
            RuntimeProjectLayoutError::SourceIdentity(
                lexicon_core::runtime::invocation::RuntimeInvocationValueError::invalid(
                    "source_name",
                    error.to_string(),
                ),
            ),
        ))?;
    let protocol = ManagedProtocol::parse(protocol)
        .map_err(|error| ForegroundDataExecutionError::UnsupportedProtocol(error.to_string()))?;
    let location = project.source(source.clone(), protocol).map_err(|error| match error {
        ProjectError::SourceNotFound(path) => ForegroundDataExecutionError::MissingSource {
            source_name: source.as_str().to_owned(),
            path,
        },
        ProjectError::ProtocolNotFound(path) => {
            ForegroundDataExecutionError::MissingProtocolLayout {
                source_name: source.as_str().to_owned(),
                path,
            }
        }
        other => ForegroundDataExecutionError::ProjectConfiguration(
            ProjectConfigurationError::Load(crate::ProjectConfigLoadError::InvalidProject(other)),
        ),
    })?;
    let manifest_path = location
        .require_regular_file(Path::new("source.toml"))
        .map_err(|error| match error {
            ProjectError::ManagedPathMetadata { path, source }
                if source.kind() == std::io::ErrorKind::NotFound =>
            {
                ForegroundDataExecutionError::MissingSourceManifest {
                    source_name: source_name.to_owned(),
                    path,
                }
            }
            ProjectError::SymlinkNotPermitted(path) => {
                ForegroundDataExecutionError::ProjectLayout(
                    RuntimeProjectLayoutError::SymlinkNotPermitted { path },
                )
            }
            other => ForegroundDataExecutionError::ProjectConfiguration(
                ProjectConfigurationError::Load(crate::ProjectConfigLoadError::InvalidProject(
                    other,
                )),
            ),
        })?;

    let manifest_contents = std::fs::read_to_string(&manifest_path).map_err(|e| {
        ForegroundDataExecutionError::ProjectDiscovery(
            ProjectDiscoveryError::CurrentDirectory(e),
        )
    })?;

    crate::validate_source_toml_text(&manifest_contents, source_name, protocol.as_str()).map_err(
        |error| ForegroundDataExecutionError::InvalidSourceManifest {
            source_name: source_name.to_owned(),
            path: manifest_path,
            error,
        },
    )?;

    let layout = RuntimeProjectLayout { location };

    let op_relative = Path::new(match operation {
        DataOperation::Acquisition => "get-raw-data",
        DataOperation::Processing => "process-data",
    });
    let op_root = layout.operation_root(operation);
    require_location_directory(&layout.location, op_relative, PathKind::OperationRoot).map_err(|e| {
        match &e {
            RuntimeProjectLayoutError::MissingPath { .. } => {
                ForegroundDataExecutionError::MissingOperationLayout {
                    operation: operation.display_name().to_owned(),
                    path: op_root.clone(),
                }
            }
            _ => ForegroundDataExecutionError::ProjectLayout(e),
        }
    })?;

    let raw_dir = layout.raw_data_directory();
    require_location_directory(&layout.location, Path::new("data/raw"), PathKind::RawDataDirectory).map_err(|e| {
        match &e {
            RuntimeProjectLayoutError::MissingPath { .. } => {
                ForegroundDataExecutionError::MissingOperationLayout {
                    operation: "data/raw".to_owned(),
                    path: raw_dir.clone(),
                }
            }
            _ => ForegroundDataExecutionError::ProjectLayout(e),
        }
    })?;

    let processed_dir = layout.processed_data_directory();
    require_location_directory(&layout.location, Path::new("data/processed"), PathKind::ProcessedDataDirectory).map_err(|e| {
        match &e {
            RuntimeProjectLayoutError::MissingPath { .. } => {
                ForegroundDataExecutionError::MissingOperationLayout {
                    operation: "data/processed".to_owned(),
                    path: processed_dir.clone(),
                }
            }
            _ => ForegroundDataExecutionError::ProjectLayout(e),
        }
    })?;

    let bundle_dir = layout.bundle_directory(operation);
    let bundle_relative = op_relative.join("runtime");
    require_location_directory(&layout.location, &bundle_relative, PathKind::RuntimeBundleDirectory).map_err(|e| {
        match &e {
            RuntimeProjectLayoutError::MissingPath { .. } => {
                ForegroundDataExecutionError::MissingRuntimeBundle {
                    operation: operation.display_name().to_owned(),
                    path: bundle_dir.clone(),
                }
            }
            _ => ForegroundDataExecutionError::ProjectLayout(e),
        }
    })?;

    let project_name = project.name().as_str().to_owned();
    Ok((layout, project_name))
}

/// Require that `path` is a real directory (not a symlink, not a file, not missing).
///
/// Uses `symlink_metadata` so symlinks are rejected even if they point to directories.
fn require_location_directory(
    location: &crate::project::SourceLocation,
    relative: &Path,
    kind: PathKind,
) -> Result<(), RuntimeProjectLayoutError> {
    match location.require_directory(relative) {
        Ok(_) => Ok(()),
        Err(ProjectError::SymlinkNotPermitted(path)) => {
            Err(RuntimeProjectLayoutError::SymlinkNotPermitted { path })
        }
        Err(ProjectError::ManagedPathNotDirectory(path)) => {
            Err(RuntimeProjectLayoutError::NotADirectory { path, kind })
        }
        Err(ProjectError::ManagedPathMetadata { path, source })
            if source.kind() == std::io::ErrorKind::NotFound =>
        {
            Err(RuntimeProjectLayoutError::MissingPath { path, kind })
        }
        Err(ProjectError::ManagedPathMetadata { path, source }) => {
            Err(RuntimeProjectLayoutError::MetadataIo { path, source })
        }
        Err(error) => Err(RuntimeProjectLayoutError::MetadataIo {
            path: location.protocol_root().join(relative),
            source: std::io::Error::other(error.to_string()),
        }),
    }
}

#[cfg(test)]
mod tests {
    use std::fs;
    use std::path::PathBuf;

    use super::*;
    use crate::data::error::ForegroundDataExecutionError;
    use crate::data::request::DataOperation;
    use crate::data::test_support::with_test_cwd;
    use crate::SourceManifestError;

    fn make_valid_project_structure(root: &Path, source_name: &str) {
        fs::write(
            root.join("lexicon.toml"),
            "schema_version = 1\n[project]\nname = \"test-project\"\n[paths]\nsources_directory = \"sources\"\n",
        )
        .unwrap();

        let protocol_root = root.join("sources").join(source_name).join("http");
        fs::create_dir_all(&protocol_root).unwrap();
        fs::create_dir_all(protocol_root.join("data/raw")).unwrap();
        fs::create_dir_all(protocol_root.join("data/processed")).unwrap();
        fs::create_dir_all(protocol_root.join("get-raw-data")).unwrap();
        fs::create_dir_all(protocol_root.join("process-data")).unwrap();
        fs::create_dir_all(protocol_root.join("get-raw-data/runtime")).unwrap();
        fs::create_dir_all(protocol_root.join("process-data/runtime")).unwrap();
    }

    #[test]
    fn resolve_project_layout_rejects_missing_source_manifest() {
        let temp = tempfile::tempdir().unwrap();
        let project_root = temp.path();
        make_valid_project_structure(project_root, "my-source");

        let result = with_test_cwd(project_root, || {
            resolve_project_layout("my-source", "http", DataOperation::Acquisition)
        });

        assert!(matches!(
            result,
            Err(ForegroundDataExecutionError::MissingSourceManifest { source_name, .. })
                if source_name == "my-source"
        ));
    }

    #[test]
    fn resolve_project_layout_rejects_schema_1_source_manifest() {
        let temp = tempfile::tempdir().unwrap();
        let project_root = temp.path();
        make_valid_project_structure(project_root, "my-source");

        let protocol_root = project_root.join("sources/my-source/http");
        fs::write(
            protocol_root.join("source.toml"),
            "schema_version = 1\n[source]\nname = \"my-source\"\nprotocol = \"http\"\n",
        )
        .unwrap();

        let result = with_test_cwd(project_root, || {
            resolve_project_layout("my-source", "http", DataOperation::Acquisition)
        });

        assert!(matches!(
            result,
            Err(ForegroundDataExecutionError::InvalidSourceManifest {
                error: SourceManifestError::UnsupportedSchemaVersion { actual: 1 },
                ..
            })
        ));
    }

    #[test]
    fn resolve_project_layout_rejects_mismatched_source_manifest_identity() {
        let temp = tempfile::tempdir().unwrap();
        let project_root = temp.path();
        make_valid_project_structure(project_root, "my-source");

        let protocol_root = project_root.join("sources/my-source/http");
        let manifest = crate::format_source_toml("different-source", "http");
        fs::write(protocol_root.join("source.toml"), manifest).unwrap();

        let result = with_test_cwd(project_root, || {
            resolve_project_layout("my-source", "http", DataOperation::Acquisition)
        });

        assert!(matches!(
            result,
            Err(ForegroundDataExecutionError::InvalidSourceManifest {
                error: SourceManifestError::UnexpectedContractIdentifier { operation: "source", .. },
                ..
            })
        ));
    }

    #[test]
    fn resolve_project_layout_succeeds_with_valid_schema_2_source_manifest() {
        let temp = tempfile::tempdir().unwrap();
        let project_root = temp.path();
        make_valid_project_structure(project_root, "my-source");

        let protocol_root = project_root.join("sources/my-source/http");
        let manifest = crate::format_source_toml("my-source", "http");
        fs::write(protocol_root.join("source.toml"), manifest).unwrap();

        let result = with_test_cwd(project_root, || {
            resolve_project_layout("my-source", "http", DataOperation::Acquisition)
        });

        assert!(result.is_ok(), "expected layout to resolve: {result:?}");
        let (layout, project_name) = result.unwrap();
        assert_eq!(project_name, "test-project");
        assert_eq!(layout.source_name(), "my-source");
        assert_eq!(layout.protocol(), "http");
    }
}
