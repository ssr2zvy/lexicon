use std::path::Path;

use lexicon_core::protocols::http::HttpSourceContractV1;
use lexicon_core::processing::ProcessingSourceContractV1;
use lexicon_core::runtime::OwnedRuntimeIdentity;

use crate::build::{
    AdmittedHttpRuntimeBundle, AdmittedProcessingRuntimeBundle, HashedRuntimeArtifact,
    admit_http_runtime_bundle_owned, admit_processing_runtime_bundle_owned,
    hash_runtime_executable, probe_http_runtime_information_owned,
    probe_processing_runtime_information_owned,
};
use crate::data::error::{ExecutableIntegrityError, ForegroundDataExecutionError};
use crate::data::project::RuntimeProjectLayout;
use crate::data::request::DataOperation;
use crate::publication::runtime_pair_transaction::{
    RuntimePairAdmissionGuard, acquire_runtime_pair_admission_guard,
};

// ---------------------------------------------------------------------------
// Bundle admission result
// ---------------------------------------------------------------------------

/// Admitted runtime bundle for the acquisition (HTTP) operation.
pub struct AdmittedAcquisitionBundle {
    pub bundle: AdmittedHttpRuntimeBundle,
    pub identity: OwnedRuntimeIdentity,
    pub(crate) publication_guard: Option<RuntimePairAdmissionGuard>,
}

/// Admitted runtime bundle for the processing operation.
pub struct AdmittedProcessingBundle {
    pub bundle: AdmittedProcessingRuntimeBundle,
    pub identity: OwnedRuntimeIdentity,
    pub(crate) publication_guard: Option<RuntimePairAdmissionGuard>,
}

/// Either acquisition or processing admitted bundle, with resolved executable path and identity.
pub enum AdmittedBundle {
    Acquisition(AdmittedAcquisitionBundle),
    Processing(AdmittedProcessingBundle),
}

pub(crate) trait RuntimeBundleAdmitter: Send + Sync {
    fn admit(
        &self,
        layout: &RuntimeProjectLayout,
        operation: DataOperation,
    ) -> Result<AdmittedBundle, ForegroundDataExecutionError>;
}

pub(crate) struct ProductionRuntimeBundleAdmitter;

impl RuntimeBundleAdmitter for ProductionRuntimeBundleAdmitter {
    fn admit(
        &self,
        layout: &RuntimeProjectLayout,
        operation: DataOperation,
    ) -> Result<AdmittedBundle, ForegroundDataExecutionError> {
        admit_and_probe_bundle(layout, operation)
    }
}

impl AdmittedBundle {
    pub fn identity(&self) -> &OwnedRuntimeIdentity {
        match self {
            Self::Acquisition(b) => &b.identity,
            Self::Processing(b) => &b.identity,
        }
    }

    pub fn executable_path(&self) -> &Path {
        match self {
            Self::Acquisition(b) => b.bundle.executable_path(),
            Self::Processing(b) => b.bundle.executable_path(),
        }
    }

    pub fn admitted_artifact(&self) -> &HashedRuntimeArtifact {
        match self {
            Self::Acquisition(b) => b.bundle.artifact(),
            Self::Processing(b) => b.bundle.artifact(),
        }
    }

    /// Returns the owned identity proven by the admitted manifest and probe.
    pub fn information_identity(&self) -> &OwnedRuntimeIdentity {
        self.identity()
    }
}

// ---------------------------------------------------------------------------
// Admission
// ---------------------------------------------------------------------------

/// Admit the runtime bundle appropriate for the given operation and verify that
/// the admitted bundle identity matches the expected owned identity.
pub fn admit_bundle(
    layout: &RuntimeProjectLayout,
    operation: DataOperation,
) -> Result<AdmittedBundle, ForegroundDataExecutionError> {
    let publication_guard = acquire_runtime_pair_admission_guard(
        layout.protocol_root(),
        &layout.acquisition_bundle_directory(),
        &layout.processing_bundle_directory(),
    )
    .map_err(ForegroundDataExecutionError::RuntimePairAdmission)?;
    match operation {
        DataOperation::Acquisition => {
            admit_acquisition_bundle(layout, publication_guard)
        }
        DataOperation::Processing => {
            admit_processing_bundle(layout, publication_guard)
        }
    }
}

/// Perform complete parent-side runtime admission before any session is
/// selected or created.  The information probe is deliberately part of this
/// operation: callers must not retain a structurally admitted bundle without
/// also proving that the executable currently at the admitted path describes
/// exactly the runtime recorded in `runtime.json`.
pub fn admit_and_probe_bundle(
    layout: &RuntimeProjectLayout,
    operation: DataOperation,
) -> Result<AdmittedBundle, ForegroundDataExecutionError> {
    let admitted = admit_bundle(layout, operation)?;
    probe_admitted_runtime(&admitted)?;
    recheck_executable_integrity(&admitted)
        .map_err(ForegroundDataExecutionError::ExecutableIntegrity)?;
    Ok(admitted)
}

fn probe_admitted_runtime(
    admitted: &AdmittedBundle,
) -> Result<(), ForegroundDataExecutionError> {
    match admitted {
        AdmittedBundle::Acquisition(bundle) => {
            let fresh = probe_http_runtime_information_owned(
                bundle.bundle.executable_path(),
                &bundle.identity,
            )
            .map_err(ForegroundDataExecutionError::HttpLaunchRuntimeProbe)?;
            if fresh.information() != bundle.bundle.runtime_information() {
                return Err(ForegroundDataExecutionError::HttpLaunchRuntimeInformationMismatch {
                    manifest: bundle.bundle.runtime_information().clone(),
                    probe: fresh.information().clone(),
                });
            }
        }
        AdmittedBundle::Processing(bundle) => {
            let fresh = probe_processing_runtime_information_owned(
                bundle.bundle.executable_path(),
                &bundle.identity,
            )
            .map_err(ForegroundDataExecutionError::ProcessingLaunchRuntimeProbe)?;
            if fresh.information() != bundle.bundle.runtime_information() {
                return Err(ForegroundDataExecutionError::ProcessingLaunchRuntimeInformationMismatch {
                    manifest: bundle.bundle.runtime_information().clone(),
                    probe: fresh.information().clone(),
                });
            }
        }
    }
    Ok(())
}

fn admit_acquisition_bundle(
    layout: &RuntimeProjectLayout,
    publication_guard: RuntimePairAdmissionGuard,
) -> Result<AdmittedBundle, ForegroundDataExecutionError> {
    let bundle_dir = layout.acquisition_bundle_directory();

    let expected_identity = OwnedRuntimeIdentity::http_acquisition(
        layout.source_name(),
        HttpSourceContractV1::CONTRACT_VERSION,
    );

    let bundle = admit_http_runtime_bundle_owned(&bundle_dir, &expected_identity)
        .map_err(ForegroundDataExecutionError::HttpBundleAdmission)?;

    let actual_identity = bundle
        .runtime_information()
        .identity()
        .clone();

    Ok(AdmittedBundle::Acquisition(AdmittedAcquisitionBundle {
        bundle,
        identity: actual_identity,
        publication_guard: Some(publication_guard),
    }))
}

fn admit_processing_bundle(
    layout: &RuntimeProjectLayout,
    publication_guard: RuntimePairAdmissionGuard,
) -> Result<AdmittedBundle, ForegroundDataExecutionError> {
    let bundle_dir = layout.processing_bundle_directory();

    let expected_identity = OwnedRuntimeIdentity::http_processing(
        layout.source_name(),
        ProcessingSourceContractV1::CONTRACT_VERSION,
    );

    let bundle = admit_processing_runtime_bundle_owned(&bundle_dir, &expected_identity)
        .map_err(ForegroundDataExecutionError::ProcessingBundleAdmission)?;

    let actual_identity = bundle
        .runtime_information()
        .identity()
        .clone();

    Ok(AdmittedBundle::Processing(AdmittedProcessingBundle {
        bundle,
        identity: actual_identity,
        publication_guard: Some(publication_guard),
    }))
}

// ---------------------------------------------------------------------------
// Pre-launch integrity recheck
// ---------------------------------------------------------------------------

/// Immediately before spawning: verify the admitted executable still matches
/// the admitted artifact (size + SHA-256). Reject symlinks.
pub fn recheck_executable_integrity(
    admitted: &AdmittedBundle,
) -> Result<(), ExecutableIntegrityError> {
    let executable = admitted.executable_path();
    let original = admitted.admitted_artifact();

    // The shared hasher opens the final component without following a link,
    // verifies the opened object is a regular file, and hashes that handle.
    // Do not manufacture an "actual" digest from the admitted digest when a
    // symlink or other non-file is encountered.
    let current = hash_runtime_executable(executable)
        .map_err(ExecutableIntegrityError::Inspection)?;

    if current.size() != original.size() {
        return Err(ExecutableIntegrityError::Changed {
            path: executable.to_path_buf(),
            expected: original.clone(),
            actual: current.clone(),
        });
    }
    if current.sha256() != original.sha256() {
        return Err(ExecutableIntegrityError::Changed {
            path: executable.to_path_buf(),
            expected: original.clone(),
            actual: current,
        });
    }

    Ok(())
}

/// Returns true if the admitted HTTP bundle registers a resume handler.
pub fn acquisition_bundle_has_resume(bundle: &AdmittedAcquisitionBundle) -> bool {
    bundle.bundle.runtime_information().resume_handler_registered()
}

#[cfg(test)]
mod tests {
    use std::ffi::OsString;

    use lexicon_core::protocols::http::{
        AcquisitionResult, HttpCapabilitySet, HttpSourceContractV1,
    };
    use lexicon_core::runtime::{RuntimeIdentity, RuntimeInformationV1};
    use lexicon_core::HttpAcquisitionContext;

    use super::{
        AdmittedAcquisitionBundle, AdmittedBundle, probe_admitted_runtime,
        recheck_executable_integrity,
    };
    use crate::build::runtime_probe::test_fixture::{
        ProbeFixtureBehavior, write_probe_executable,
    };
    use crate::build::{
        admit_http_runtime_bundle_owned, stage_verified_http_runtime_bundle,
        verify_http_runtime_candidate,
    };
    use crate::data::error::{ExecutableIntegrityError, ForegroundDataExecutionError};
    use crate::data::project::resolve_project_layout;
    use crate::data::request::DataOperation;
    use crate::data::test_support::{build_fake_project, with_test_cwd};
    use crate::publication::runtime_pair_transaction::{
        RuntimePairTransaction, RuntimePairTransactionError,
    };

    fn acquire(
        _context: &mut HttpAcquisitionContext,
        _args: &[OsString],
    ) -> AcquisitionResult<()> {
        Ok(())
    }

    fn resume(
        _context: &mut HttpAcquisitionContext,
        _args: &[OsString],
    ) -> AcquisitionResult<()> {
        Ok(())
    }

    fn information_output(with_resume: bool) -> Vec<u8> {
        let identity = RuntimeIdentity::http_acquisition("example-source", 1);
        let source = if with_resume {
            HttpSourceContractV1::new(acquire).with_resume(resume)
        } else {
            HttpSourceContractV1::new(acquire)
        };
        let information = RuntimeInformationV1::from_http_source(
            identity,
            &source,
            HttpCapabilitySet::empty(),
        );
        let mut output = information.to_json().unwrap().into_bytes();
        output.push(b'\n');
        output
    }

    fn admitted_fixture() -> (tempfile::TempDir, crate::build::StagedHttpRuntimeBundle, AdmittedBundle) {
        let temp = tempfile::tempdir().unwrap();
        let candidate = temp.path().join(if cfg!(windows) {
            "candidate.exe"
        } else {
            "candidate"
        });
        write_probe_executable(
            &candidate,
            &information_output(false),
            ProbeFixtureBehavior::Valid,
        );
        let identity = RuntimeIdentity::http_acquisition("example-source", 1);
        let verified = verify_http_runtime_candidate(&candidate, identity).unwrap();
        let executable_name = format!(
            "example-source-get-raw-data{}",
            std::env::consts::EXE_SUFFIX,
        );
        let staged =
            stage_verified_http_runtime_bundle(temp.path(), &executable_name, &verified).unwrap();
        let expected = identity.into_owned_identity();
        let bundle = admit_http_runtime_bundle_owned(staged.directory(), &expected).unwrap();
        let actual = bundle.runtime_information().identity().clone();
        let admitted = AdmittedBundle::Acquisition(AdmittedAcquisitionBundle {
            bundle,
            identity: actual,
            publication_guard: None,
        });
        (temp, staged, admitted)
    }

    #[test]
    fn fresh_probe_information_must_equal_the_admitted_manifest() {
        let (_temp, _staged, admitted) = admitted_fixture();
        write_probe_executable(
            admitted.executable_path(),
            &information_output(true),
            ProbeFixtureBehavior::Valid,
        );

        let error = probe_admitted_runtime(&admitted).unwrap_err();
        assert!(matches!(
            error,
            ForegroundDataExecutionError::HttpLaunchRuntimeInformationMismatch { .. }
        ));
    }

    #[test]
    fn executable_change_after_probe_is_rejected_by_the_final_hash() {
        let (_temp, _staged, admitted) = admitted_fixture();
        probe_admitted_runtime(&admitted).unwrap();
        write_probe_executable(
            admitted.executable_path(),
            &information_output(true),
            ProbeFixtureBehavior::Valid,
        );

        let error = recheck_executable_integrity(&admitted).unwrap_err();
        assert!(matches!(error, ExecutableIntegrityError::Changed { .. }));
    }

    #[test]
    fn production_admit_bundle_holds_publication_guard_until_bundle_drop() {
        let project = build_fake_project("publication-guard-source");
        with_test_cwd(&project.project_root, || {
            let (layout, _) = resolve_project_layout(
                &project.source_name,
                "http",
                DataOperation::Acquisition,
            )
            .unwrap();
            let admitted = super::admit_bundle(&layout, DataOperation::Acquisition).unwrap();
            assert!(matches!(
                &admitted,
                AdmittedBundle::Acquisition(bundle)
                    if bundle.publication_guard.is_some()
            ));

            let error = RuntimePairTransaction::begin(
                layout.protocol_root(),
                &layout.acquisition_bundle_directory(),
                &layout.processing_bundle_directory(),
            )
            .unwrap_err();
            assert!(matches!(
                error,
                RuntimePairTransactionError::PublicationInProgress { .. }
            ));

            drop(admitted);
            let mut transaction = RuntimePairTransaction::begin(
                layout.protocol_root(),
                &layout.acquisition_bundle_directory(),
                &layout.processing_bundle_directory(),
            )
            .unwrap();
            transaction.recover_after_failure().unwrap();
        });
    }
}
