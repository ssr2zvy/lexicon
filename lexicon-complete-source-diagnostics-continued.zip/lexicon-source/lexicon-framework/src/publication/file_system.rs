//! Typed filesystem transaction seam for runtime publication.
//!
//! `runtime_bundle_replacement` performs every publication mutation through
//! this interface. Production delegates to the host filesystem; tests inject
//! deterministic failures without duplicating the transaction state machine.

use std::fs;
use std::io::{self, ErrorKind, Write};
use std::path::{Path, PathBuf};
use std::sync::Mutex;
use std::time::Duration;

use crate::fs::DirectorySyncOutcome;

/// Abstraction over filesystem effects used by runtime publication.
pub trait PublicationFileSystem: Send + Sync {
    fn metadata(&self, path: &Path) -> io::Result<fs::Metadata>;
    fn symlink_metadata(&self, path: &Path) -> io::Result<fs::Metadata>;
    fn try_exists(&self, path: &Path) -> io::Result<bool>;
    fn rename(&self, from: &Path, to: &Path) -> io::Result<()>;
    fn remove_file(&self, path: &Path) -> io::Result<()>;
    fn remove_dir_all(&self, path: &Path) -> io::Result<()>;
    fn write_new_file_and_sync(&self, path: &Path, contents: &[u8]) -> io::Result<()>;
    fn replace_file(&self, from: &Path, to: &Path) -> io::Result<()>;
    fn sync_file(&self, path: &Path) -> io::Result<()>;
    fn sync_directory(&self, path: &Path) -> io::Result<DirectorySyncOutcome>;
    /// Sleep before retrying a transient failure (Windows ETXTBSY-style
    /// races). Production pauses; the fake can advance its clock.
    fn sleep_before_retry(&self, delay: Duration);
}

/// Production implementation that invokes real OS calls.
pub struct ProductionPublicationFileSystem;

impl PublicationFileSystem for ProductionPublicationFileSystem {
    fn metadata(&self, path: &Path) -> io::Result<fs::Metadata> {
        path.metadata()
    }

    fn symlink_metadata(&self, path: &Path) -> io::Result<fs::Metadata> {
        path.symlink_metadata()
    }

    fn try_exists(&self, path: &Path) -> io::Result<bool> {
        path.try_exists()
    }

    fn rename(&self, from: &Path, to: &Path) -> io::Result<()> {
        fs::rename(from, to)
    }

    fn remove_file(&self, path: &Path) -> io::Result<()> {
        fs::remove_file(path)
    }

    fn remove_dir_all(&self, path: &Path) -> io::Result<()> {
        fs::remove_dir_all(path)
    }

    fn write_new_file_and_sync(&self, path: &Path, contents: &[u8]) -> io::Result<()> {
        let mut file = fs::OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(path)?;
        file.write_all(contents)?;
        file.sync_all()
    }

    fn replace_file(&self, from: &Path, to: &Path) -> io::Result<()> {
        atomic_replace_file(from, to)
    }

    fn sync_file(&self, path: &Path) -> io::Result<()> {
        crate::fs::sync_file(path)
    }

    fn sync_directory(&self, path: &Path) -> io::Result<DirectorySyncOutcome> {
        crate::fs::sync_directory(path)
    }

    fn sleep_before_retry(&self, delay: Duration) {
        std::thread::sleep(delay);
    }
}

/// Scripted test implementation. The audit's PROCESS-01 / PUBLISH-01 lists
/// specific Nth-operation failure modes. Calls are dispatched in FIFO
/// order, and each script entry's first matching call consumes the entry.
pub struct ScriptedPublicationFileSystem {
    inner: Mutex<ScriptedInner>,
}

struct ScriptedInner {
    history: Vec<CallRecord>,
    script: Vec<ScriptEntry>,
    forced_directory_sync_outcomes: Vec<(usize, DirectorySyncOutcome)>,
}

#[derive(Clone, Debug)]
pub struct CallRecord {
    pub method: &'static str,
    pub from: Option<PathBuf>,
    pub to: Option<PathBuf>,
    pub outcome: Result<(), String>,
}

#[derive(Clone, Debug)]
pub struct ScriptEntry {
    pub matches: ScriptMatcher,
    pub response: Result<(), String>,
}

/// Filter that decides which calls a script entry applies to.
#[derive(Clone, Debug)]
pub enum ScriptMatcher {
    /// Always match the next call regardless of method or path. The
    /// catch-all entry used to script "no further calls".
    Any,
    /// Match the first rename whose `from` path equals the supplied string.
    FirstRenameFrom { from_match: String },
    /// Match the first call whose method name equals this string. Used
    /// for "the Nth sync fails" scripting.
    FirstMethod(&'static str),
}

impl ScriptedPublicationFileSystem {
    pub fn new(script: Vec<ScriptEntry>) -> Self {
        Self {
            inner: Mutex::new(ScriptedInner {
                history: Vec::new(),
                script,
                forced_directory_sync_outcomes: Vec::new(),
            }),
        }
    }

    /// Quick-start: a script that fails only when called once, then
    /// succeeds thereafter. This is the minimum lethal injection.
    pub fn fail_once(method: &'static str, message: &str) -> Self {
        Self::new(vec![ScriptEntry {
            matches: ScriptMatcher::FirstMethod(method),
            response: Err(message.to_owned()),
        }])
    }

    /// Execute one operation, consuming the first matching scripted entry
    /// and recording the operation's actual final outcome. A scripted error
    /// prevents the underlying operation; a scripted success permits it.
    fn perform<T>(
        &self,
        method: &'static str,
        from: Option<&Path>,
        to: Option<&Path>,
        operation: impl FnOnce() -> io::Result<T>,
    ) -> io::Result<T> {
        let scripted = {
            let mut guard = self.inner.lock().expect("poisoning");
            let matching = guard.script.iter().position(|entry| match &entry.matches {
                ScriptMatcher::Any => true,
                ScriptMatcher::FirstMethod(expected) => *expected == method,
                ScriptMatcher::FirstRenameFrom { from_match } => {
                    method == "rename"
                        && from.is_some_and(|path| path.to_string_lossy() == from_match.as_str())
                }
            });
            matching.map(|index| guard.script.remove(index).response)
        };

        let result = match scripted {
            Some(Err(message)) => Err(io_error(message)),
            Some(Ok(())) | None => operation(),
        };
        let recorded_outcome = result
            .as_ref()
            .map(|_| ())
            .map_err(std::string::ToString::to_string);
        self.inner
            .lock()
            .expect("poisoning")
            .history
            .push(CallRecord {
                method,
                from: from.map(Path::to_path_buf),
                to: to.map(Path::to_path_buf),
                outcome: recorded_outcome,
            });
        result
    }

    /// Snapshot of recorded calls, oldest first.
    pub fn history(&self) -> Vec<CallRecord> {
        self.inner.lock().expect("poisoning").history.clone()
    }

    /// Remaining unconsumed scripted entries.
    pub fn remaining(&self) -> usize {
        self.inner.lock().expect("poisoning").script.len()
    }

    /// Force one numbered `sync_directory` call to return a platform outcome
    /// without touching the host directory. Occurrences are one-based and the
    /// override is consumed exactly once.
    pub fn force_directory_sync_outcome_at(
        &self,
        occurrence: usize,
        outcome: DirectorySyncOutcome,
    ) {
        assert!(occurrence > 0, "directory-sync occurrence is one-based");
        self.inner
            .lock()
            .expect("poisoning")
            .forced_directory_sync_outcomes
            .push((occurrence, outcome));
    }
}

impl PublicationFileSystem for ScriptedPublicationFileSystem {
    fn metadata(&self, path: &Path) -> io::Result<fs::Metadata> {
        self.perform("metadata", Some(path), None, || path.metadata())
    }

    fn symlink_metadata(&self, path: &Path) -> io::Result<fs::Metadata> {
        self.perform("symlink_metadata", Some(path), None, || {
            path.symlink_metadata()
        })
    }

    fn try_exists(&self, path: &Path) -> io::Result<bool> {
        self.perform("try_exists", Some(path), None, || path.try_exists())
    }

    fn rename(&self, from: &Path, to: &Path) -> io::Result<()> {
        self.perform("rename", Some(from), Some(to), || fs::rename(from, to))
    }

    fn remove_file(&self, path: &Path) -> io::Result<()> {
        self.perform("remove_file", Some(path), None, || fs::remove_file(path))
    }

    fn remove_dir_all(&self, path: &Path) -> io::Result<()> {
        self.perform("remove_dir_all", Some(path), None, || fs::remove_dir_all(path))
    }

    fn write_new_file_and_sync(&self, path: &Path, contents: &[u8]) -> io::Result<()> {
        self.perform("write_new_file_and_sync", Some(path), None, || {
            let mut file = fs::OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(path)?;
            file.write_all(contents)?;
            file.sync_all()
        })
    }

    fn replace_file(&self, from: &Path, to: &Path) -> io::Result<()> {
        self.perform("replace_file", Some(from), Some(to), || {
            atomic_replace_file(from, to)
        })
    }

    fn sync_file(&self, path: &Path) -> io::Result<()> {
        self.perform("sync_file", Some(path), None, || {
            let file = fs::OpenOptions::new().read(true).open(path)?;
            file.sync_all()
        })
    }

    fn sync_directory(&self, path: &Path) -> io::Result<DirectorySyncOutcome> {
        let forced = {
            let mut guard = self.inner.lock().expect("poisoning");
            let occurrence = guard
                .history
                .iter()
                .filter(|record| record.method == "sync_directory")
                .count()
                + 1;
            guard
                .forced_directory_sync_outcomes
                .iter()
                .position(|(expected, _)| *expected == occurrence)
                .map(|index| guard.forced_directory_sync_outcomes.remove(index).1)
        };
        self.perform("sync_directory", Some(path), None, || {
            match forced {
                Some(outcome) => Ok(outcome),
                None => crate::fs::sync_directory(path),
            }
        })
    }

    fn sleep_before_retry(&self, delay: Duration) {
        let _ = delay;
        self.perform("sleep_before_retry", None, None, || Ok(()))
            .expect("scripted retry sleep failure");
    }
}

fn io_error(message: String) -> io::Error {
    io::Error::new(ErrorKind::Other, message)
}

#[cfg(not(windows))]
fn atomic_replace_file(from: &Path, to: &Path) -> io::Result<()> {
    fs::rename(from, to)
}

#[cfg(windows)]
fn atomic_replace_file(from: &Path, to: &Path) -> io::Result<()> {
    use std::os::windows::ffi::OsStrExt;
    use windows_sys::Win32::Storage::FileSystem::{
        MOVEFILE_REPLACE_EXISTING, MOVEFILE_WRITE_THROUGH, MoveFileExW,
    };

    let from: Vec<u16> = from.as_os_str().encode_wide().chain(Some(0)).collect();
    let to: Vec<u16> = to.as_os_str().encode_wide().chain(Some(0)).collect();
    let result = unsafe {
        MoveFileExW(
            from.as_ptr(),
            to.as_ptr(),
            MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH,
        )
    };
    if result == 0 {
        Err(io::Error::last_os_error())
    } else {
        Ok(())
    }
}

/// Convenience helper for tests: build a canonical file-system snapshot
/// at `root` containing `relative` paths, all empty. Used to seed staged
/// factories before exercising publication paths.
pub fn seed_empty_staging(root: &Path, relative: &[&str]) -> io::Result<()> {
    fs::create_dir_all(root)?;
    for entry in relative {
        let target = root.join(entry);
        if let Some(parent) = target.parent() {
            fs::create_dir_all(parent)?;
        }
        if !target.exists() {
            std::fs::OpenOptions::new()
                .create(true)
                .write(true)
                .open(&target)?;
        }
    }
    Ok(())
}

/// Helper used by tests: ensure a script's history matches an expected
/// list of (method, outcome_ok). The audit's PROCESS-01 / PUBLISH-01
/// tests exercise failure modes whose scripts we ship below.
pub fn assert_history_methods(history: &[CallRecord], expected: &[&'static str]) {
    assert_eq!(
        history.len(),
        expected.len(),
        "expected {} calls got {} history {:?}",
        expected.len(),
        history.len(),
        history.iter().map(|r| r.method).collect::<Vec<_>>()
    );
    for (i, (record, method)) in history.iter().zip(expected.iter()).enumerate() {
        assert_eq!(
            record.method, *method,
            "history[{i}] expected {method} got {}",
            record.method
        );
        assert!(
            record.outcome.is_ok(),
            "history[{i}] method {method} should succeed; got {:?}",
            record.outcome
        );
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use tempfile::tempdir;

    #[test]
    fn production_helper_succeeds_against_real_filesystem() {
        let dir = tempdir().expect("tempdir");
        let src = dir.path().join("src.txt");
        let dst = dir.path().join("dst.txt");
        std::fs::write(&src, b"data").expect("write");
        let fs = ProductionPublicationFileSystem;
        fs.rename(&src, &dst).expect("rename");
        assert!(!src.exists());
        assert_eq!(std::fs::read(&dst).expect("read"), b"data");
    }

    #[test]
    fn scripted_fs_returns_first_script_outcome_and_then_succeeds() {
        let dir = tempdir().expect("tempdir");
        let src = dir.path().join("a.txt");
        let dst = dir.path().join("b.txt");
        std::fs::write(&src, b"x").expect("write");

        // First call (metadata) fails with our scripted message.
        let script = ScriptedPublicationFileSystem::new(vec![ScriptEntry {
            matches: ScriptMatcher::FirstMethod("metadata"),
            response: Err("simulated_os_failure".to_owned()),
        }]);
        let outcome = script.metadata(&src);
        assert!(outcome.is_err());

        // Subsequent calls succeed; we reach a regular rename next.
        script.rename(&src, &dst).expect("rename on second try");
        assert!(!src.exists());
        assert!(dst.exists());
        assert!(script.history().len() == 2);
    }

    #[test]
    fn scripted_fs_records_history_in_call_order() {
        let dir = tempdir().expect("tempdir");
        let fs = ScriptedPublicationFileSystem::fail_once("sync_file", "won't sync");
        let _ = fs.metadata(&dir.path().join("missing"));
        let history = fs.history();
        assert_eq!(
            history.first().map(|r| r.method),
            Some("metadata")
        );
    }

    #[test]
    fn empty_staging_helper_seeds_files() {
        let dir = tempdir().expect("tempdir");
        seed_empty_staging(dir.path(), &["a.txt", "nested/b.txt"]).expect("seed");
        assert!(dir.path().join("a.txt").is_file());
        assert!(dir.path().join("nested").is_dir());
        assert!(dir.path().join("nested/b.txt").is_file());
    }

    #[test]
    fn fail_once_helper_surfaces_failure_on_every_path() {
        let dir = tempdir().expect("tempdir");
        let fs = ScriptedPublicationFileSystem::fail_once("sync_file", "fsync refused");
        let err = fs.sync_file(&dir.path().join("ghost.txt")).unwrap_err();
        assert!(err.to_string().contains("fsync refused"));
        assert_eq!(fs.remaining(), 0);
    }
}
