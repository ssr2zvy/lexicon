//! Durable authority and crash recovery for paired runtime publication.
//!
//! A pair publication owns one cross-process exclusive lock rooted at the
//! source/protocol directory (or the common destination parent used by unit
//! fixtures). Before either runtime directory is renamed, it publishes a
//! bounded recovery record. Runtime admission holds a shared lock and rejects
//! every non-committed recovery record, so a process death can never make a
//! mixed pair admissible.

use std::fs::{self, File, OpenOptions};
use std::path::{Component, Path, PathBuf};
use std::sync::Arc;

use serde::{Deserialize, Serialize};

use crate::fs::DirectorySyncOutcome;
use crate::publication::file_system::{
    ProductionPublicationFileSystem, PublicationFileSystem,
};
use crate::publication::runtime_bundle_replacement::rename_for_publication;

const STATE_SCHEMA_VERSION: u32 = 1;
const STATE_LIMIT: u64 = 16 * 1024;
const LOCK_FILE_NAME: &str = ".lexicon-runtime-pair.lock";
const STATE_FILE_NAME: &str = ".lexicon-runtime-pair-state.json";
const STATE_TEMPORARY_PREFIX: &str = ".lexicon-runtime-pair-state.tmp-";

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub(crate) enum RuntimePairPublicationPhase {
    Prepared,
    AcquisitionInstalled,
    PairInstalled,
    Committed,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct RuntimePairPublicationStateV1 {
    schema_version: u32,
    transaction_id: String,
    acquisition_destination: Vec<String>,
    processing_destination: Vec<String>,
    acquisition_baseline_present: bool,
    processing_baseline_present: bool,
    phase: RuntimePairPublicationPhase,
}

#[derive(Debug, thiserror::Error)]
pub enum RuntimePairTransactionError {
    #[error("runtime-pair transaction root is invalid: {path}", path = path.display())]
    InvalidRoot { path: PathBuf },
    #[error("runtime-pair destination is outside its transaction root: {path}", path = path.display())]
    InvalidDestination { path: PathBuf },
    #[error("runtime-pair managed path is malformed: {path}", path = path.display())]
    MalformedManagedPath { path: PathBuf },
    #[error("failed to inspect runtime-pair path {path}: {source}", path = path.display())]
    Inspect {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },
    #[error("failed to open runtime-pair lock {path}: {source}", path = path.display())]
    LockOpen {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },
    #[error("another runtime publication owns {path}", path = path.display())]
    PublicationInProgress { path: PathBuf },
    #[error("failed to acquire runtime-pair lock {path}: {source}", path = path.display())]
    Lock {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },
    #[error("runtime admission found an interrupted runtime-pair publication at {path}", path = path.display())]
    RecoveryRequired { path: PathBuf },
    #[error("runtime-pair recovery record is malformed: {path}", path = path.display())]
    StateMalformed { path: PathBuf },
    #[error("failed to read runtime-pair recovery record {path}: {source}", path = path.display())]
    StateRead {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },
    #[error("failed to publish runtime-pair recovery record {path}: {source}", path = path.display())]
    StatePublish {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },
    #[error("runtime-pair recovery failed under {path}: {source}", path = path.display())]
    Recovery {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum RuntimePairDurability {
    Synced,
    DirectorySyncUnsupported,
}

impl RuntimePairDurability {
    fn observe(&mut self, outcome: DirectorySyncOutcome) {
        if outcome == DirectorySyncOutcome::UnsupportedByPlatform {
            *self = Self::DirectorySyncUnsupported;
        }
    }

    pub(crate) fn directory_sync_unsupported(self) -> bool {
        self == Self::DirectorySyncUnsupported
    }
}

pub(crate) struct RuntimePairTransaction {
    root: PathBuf,
    state_path: PathBuf,
    lock_file: File,
    state: RuntimePairPublicationStateV1,
    durability: RuntimePairDurability,
    file_system: Arc<dyn PublicationFileSystem>,
    finished: bool,
}

impl std::fmt::Debug for RuntimePairTransaction {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("RuntimePairTransaction")
            .field("root", &self.root)
            .field("state_path", &self.state_path)
            .field("phase", &self.state.phase)
            .field("durability", &self.durability)
            .field("finished", &self.finished)
            .finish_non_exhaustive()
    }
}

impl RuntimePairTransaction {
    pub(crate) fn begin(
        root: &Path,
        acquisition_destination: &Path,
        processing_destination: &Path,
    ) -> Result<Self, RuntimePairTransactionError> {
        Self::begin_with_file_system(
            root,
            acquisition_destination,
            processing_destination,
            Arc::new(ProductionPublicationFileSystem),
        )
    }

    pub(crate) fn begin_with_file_system(
        root: &Path,
        acquisition_destination: &Path,
        processing_destination: &Path,
        file_system: Arc<dyn PublicationFileSystem>,
    ) -> Result<Self, RuntimePairTransactionError> {
        require_managed_directory(root)?;
        let acquisition_relative = encode_relative_path(root, acquisition_destination)?;
        let processing_relative = encode_relative_path(root, processing_destination)?;
        if acquisition_relative == processing_relative {
            return Err(RuntimePairTransactionError::InvalidDestination {
                path: acquisition_destination.to_path_buf(),
            });
        }

        let lock_path = root.join(LOCK_FILE_NAME);
        let lock_file = open_lock_file(&lock_path)?;
        try_lock(&lock_file, LockMode::Exclusive).map_err(|error| match error {
            LockError::Contended => RuntimePairTransactionError::PublicationInProgress {
                path: lock_path.clone(),
            },
            LockError::Io(source) => RuntimePairTransactionError::Lock {
                path: lock_path.clone(),
                source,
            },
        })?;

        let state_path = root.join(STATE_FILE_NAME);
        let mut durability = RuntimePairDurability::Synced;
        durability.observe(cleanup_state_temporaries(file_system.as_ref(), root)?);
        if state_path_exists(&state_path)? {
            durability.observe(recover_interrupted_runtime_pair_locked(
                file_system.as_ref(),
                root,
                &state_path,
                &acquisition_relative,
                &processing_relative,
            )?);
        }

        let acquisition_baseline_present =
            managed_directory_exists(file_system.as_ref(), acquisition_destination)?;
        let processing_baseline_present =
            managed_directory_exists(file_system.as_ref(), processing_destination)?;
        let transaction_id = uuid::Uuid::new_v4().simple().to_string();
        let state = RuntimePairPublicationStateV1 {
            schema_version: STATE_SCHEMA_VERSION,
            transaction_id,
            acquisition_destination: acquisition_relative,
            processing_destination: processing_relative,
            acquisition_baseline_present,
            processing_baseline_present,
            phase: RuntimePairPublicationPhase::Prepared,
        };

        let outcome = publish_state(file_system.as_ref(), root, &state_path, &state)?;
        durability.observe(outcome);
        Ok(Self {
            root: root.to_path_buf(),
            state_path,
            lock_file,
            state,
            durability,
            file_system,
            finished: false,
        })
    }

    pub(crate) fn acquisition_backup_path(&self) -> Result<PathBuf, RuntimePairTransactionError> {
        let destination = decode_relative_path(&self.root, &self.state.acquisition_destination)?;
        backup_path(&destination, &self.state.transaction_id)
    }

    pub(crate) fn processing_backup_path(&self) -> Result<PathBuf, RuntimePairTransactionError> {
        let destination = decode_relative_path(&self.root, &self.state.processing_destination)?;
        backup_path(&destination, &self.state.transaction_id)
    }

    pub(crate) fn record_acquisition_installed(
        &mut self,
    ) -> Result<(), RuntimePairTransactionError> {
        self.record_phase(RuntimePairPublicationPhase::AcquisitionInstalled)
    }

    pub(crate) fn record_pair_installed(&mut self) -> Result<(), RuntimePairTransactionError> {
        self.record_phase(RuntimePairPublicationPhase::PairInstalled)
    }

    pub(crate) fn record_committed(&mut self) -> Result<(), RuntimePairTransactionError> {
        self.record_phase(RuntimePairPublicationPhase::Committed)
    }

    fn record_phase(
        &mut self,
        phase: RuntimePairPublicationPhase,
    ) -> Result<(), RuntimePairTransactionError> {
        let valid = matches!(
            (self.state.phase, phase),
            (
                RuntimePairPublicationPhase::Prepared,
                RuntimePairPublicationPhase::AcquisitionInstalled,
            ) | (
                RuntimePairPublicationPhase::AcquisitionInstalled,
                RuntimePairPublicationPhase::PairInstalled,
            ) | (
                RuntimePairPublicationPhase::PairInstalled,
                RuntimePairPublicationPhase::Committed,
            )
        );
        if !valid {
            return Err(RuntimePairTransactionError::StateMalformed {
                path: self.state_path.clone(),
            });
        }
        let mut next = self.state.clone();
        next.phase = phase;
        let outcome = publish_state(
            self.file_system.as_ref(),
            &self.root,
            &self.state_path,
            &next,
        )?;
        self.durability.observe(outcome);
        self.state = next;
        Ok(())
    }

    pub(crate) fn recover_after_failure(
        &mut self,
    ) -> Result<RuntimePairDurability, RuntimePairTransactionError> {
        if self.state.phase == RuntimePairPublicationPhase::Committed {
            return Err(RuntimePairTransactionError::StateMalformed {
                path: self.state_path.clone(),
            });
        }
        let persisted = read_state(&self.state_path)?;
        validate_state(
            &self.root,
            &self.state_path,
            &persisted,
            &self.state.acquisition_destination,
            &self.state.processing_destination,
        )?;
        if persisted.transaction_id != self.state.transaction_id {
            return Err(RuntimePairTransactionError::StateMalformed {
                path: self.state_path.clone(),
            });
        }
        if persisted.phase != self.state.phase {
            if !is_direct_phase_successor(self.state.phase, persisted.phase) {
                return Err(RuntimePairTransactionError::StateMalformed {
                    path: self.state_path.clone(),
                });
            }

            // The journal replacement advanced but its following parent sync
            // failed. Re-publish the last phase acknowledged in memory before
            // mutating either runtime again. A crash during rollback will then
            // resume rollback instead of treating the unacknowledged phase as
            // a committed success.
            let outcome = publish_state(
                self.file_system.as_ref(),
                &self.root,
                &self.state_path,
                &self.state,
            )?;
            self.durability.observe(outcome);
        }
        let outcome = recover_interrupted_runtime_pair_locked(
            self.file_system.as_ref(),
            &self.root,
            &self.state_path,
            &self.state.acquisition_destination,
            &self.state.processing_destination,
        )?;
        self.durability.observe(outcome);
        self.finished = true;
        Ok(self.durability)
    }

    pub(crate) fn finish_committed(
        &mut self,
    ) -> Result<RuntimePairDurability, RuntimePairTransactionError> {
        if self.state.phase != RuntimePairPublicationPhase::Committed {
            return Err(RuntimePairTransactionError::StateMalformed {
                path: self.state_path.clone(),
            });
        }
        remove_managed_file_if_present(self.file_system.as_ref(), &self.state_path).map_err(|source| {
            RuntimePairTransactionError::Recovery {
                path: self.root.clone(),
                source,
            }
        })?;
        let outcome = self.file_system.sync_directory(&self.root).map_err(|source| {
            RuntimePairTransactionError::Recovery {
                path: self.root.clone(),
                source,
            }
        })?;
        self.durability.observe(outcome);
        self.finished = true;
        Ok(self.durability)
    }

    pub(crate) fn durability(&self) -> RuntimePairDurability {
        self.durability
    }

    pub(crate) fn observe_directory_sync_outcome(&mut self, outcome: DirectorySyncOutcome) {
        self.durability.observe(outcome);
    }

    pub(crate) fn root(&self) -> &Path {
        self.root.as_path()
    }
}

impl Drop for RuntimePairTransaction {
    fn drop(&mut self) {
        let _ = self.finished;
        unlock(&self.lock_file);
    }
}

fn is_direct_phase_successor(
    current: RuntimePairPublicationPhase,
    persisted: RuntimePairPublicationPhase,
) -> bool {
    matches!(
        (current, persisted),
        (
            RuntimePairPublicationPhase::Prepared,
            RuntimePairPublicationPhase::AcquisitionInstalled,
        ) | (
            RuntimePairPublicationPhase::AcquisitionInstalled,
            RuntimePairPublicationPhase::PairInstalled,
        ) | (
            RuntimePairPublicationPhase::PairInstalled,
            RuntimePairPublicationPhase::Committed,
        )
    )
}

/// Shared publication authority retained by an admitted runtime until the
/// caller has completed its launch/supervision scope. An exclusive publisher
/// therefore cannot replace either bundle after admission but before spawn.
pub(crate) struct RuntimePairAdmissionGuard {
    lock_file: File,
}

impl std::fmt::Debug for RuntimePairAdmissionGuard {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter
            .debug_struct("RuntimePairAdmissionGuard")
            .finish_non_exhaustive()
    }
}

impl Drop for RuntimePairAdmissionGuard {
    fn drop(&mut self) {
        unlock(&self.lock_file);
    }
}

pub(crate) fn acquire_runtime_pair_admission_guard(
    root: &Path,
    acquisition_destination: &Path,
    processing_destination: &Path,
) -> Result<RuntimePairAdmissionGuard, RuntimePairTransactionError> {
    require_managed_directory(root)?;
    let acquisition_relative = encode_relative_path(root, acquisition_destination)?;
    let processing_relative = encode_relative_path(root, processing_destination)?;
    let lock_path = root.join(LOCK_FILE_NAME);
    let lock_file = open_lock_file(&lock_path)?;
    try_lock(&lock_file, LockMode::Shared).map_err(|error| match error {
        LockError::Contended => RuntimePairTransactionError::PublicationInProgress {
            path: lock_path.clone(),
        },
        LockError::Io(source) => RuntimePairTransactionError::Lock {
            path: lock_path.clone(),
            source,
        },
    })?;

    let state_path = root.join(STATE_FILE_NAME);
    if state_path_exists(&state_path)? {
        let state = read_state(&state_path)?;
        validate_state(
            root,
            &state_path,
            &state,
            &acquisition_relative,
            &processing_relative,
        )?;
        if state.phase != RuntimePairPublicationPhase::Committed {
            unlock(&lock_file);
            return Err(RuntimePairTransactionError::RecoveryRequired {
                path: state_path,
            });
        }
    }
    require_managed_directory(acquisition_destination)?;
    require_managed_directory(processing_destination)?;

    Ok(RuntimePairAdmissionGuard { lock_file })
}

fn recover_interrupted_runtime_pair_locked(
    file_system: &dyn PublicationFileSystem,
    root: &Path,
    state_path: &Path,
    expected_acquisition: &[String],
    expected_processing: &[String],
) -> Result<DirectorySyncOutcome, RuntimePairTransactionError> {
    let state = read_state(state_path)?;
    validate_state(
        root,
        state_path,
        &state,
        expected_acquisition,
        expected_processing,
    )?;
    let acquisition_destination = decode_relative_path(root, &state.acquisition_destination)?;
    let processing_destination = decode_relative_path(root, &state.processing_destination)?;
    let acquisition_backup = backup_path(&acquisition_destination, &state.transaction_id)?;
    let processing_backup = backup_path(&processing_destination, &state.transaction_id)?;

    if state.phase == RuntimePairPublicationPhase::Committed {
        require_managed_directory(&acquisition_destination)?;
        require_managed_directory(&processing_destination)?;
        remove_managed_directory_if_present(file_system, &acquisition_backup).map_err(|source| {
            RuntimePairTransactionError::Recovery {
                path: acquisition_backup.clone(),
                source,
            }
        })?;
        remove_managed_directory_if_present(file_system, &processing_backup).map_err(|source| {
            RuntimePairTransactionError::Recovery {
                path: processing_backup.clone(),
                source,
            }
        })?;
    } else {
        restore_baseline(
            file_system,
            &processing_destination,
            &processing_backup,
            state.processing_baseline_present,
        )?;
        restore_baseline(
            file_system,
            &acquisition_destination,
            &acquisition_backup,
            state.acquisition_baseline_present,
        )?;
    }

    let mut durability = RuntimePairDurability::Synced;
    for parent in distinct_destination_parents(&acquisition_destination, &processing_destination)? {
        let outcome = file_system.sync_directory(&parent).map_err(|source| {
            RuntimePairTransactionError::Recovery {
                path: parent.clone(),
                source,
            }
        })?;
        durability.observe(outcome);
    }
    remove_managed_file_if_present(file_system, state_path).map_err(|source| {
        RuntimePairTransactionError::Recovery {
            path: state_path.to_path_buf(),
            source,
        }
    })?;
    let root_outcome = file_system.sync_directory(root).map_err(|source| {
        RuntimePairTransactionError::Recovery {
            path: root.to_path_buf(),
            source,
        }
    })?;
    durability.observe(root_outcome);
    Ok(match durability {
        RuntimePairDurability::Synced => DirectorySyncOutcome::Synced,
        RuntimePairDurability::DirectorySyncUnsupported => {
            DirectorySyncOutcome::UnsupportedByPlatform
        }
    })
}

fn restore_baseline(
    file_system: &dyn PublicationFileSystem,
    destination: &Path,
    backup: &Path,
    baseline_present: bool,
) -> Result<(), RuntimePairTransactionError> {
    let destination_present = managed_directory_exists(file_system, destination)?;
    let backup_present = managed_directory_exists(file_system, backup)?;
    if baseline_present {
        if backup_present {
            if destination_present {
                remove_managed_directory_if_present(file_system, destination).map_err(|source| {
                    RuntimePairTransactionError::Recovery {
                        path: destination.to_path_buf(),
                        source,
                    }
                })?;
            }
            rename_for_publication(file_system, backup, destination).map_err(|source| {
                RuntimePairTransactionError::Recovery {
                    path: destination.to_path_buf(),
                    source,
                }
            })?;
        } else if !destination_present {
            return Err(RuntimePairTransactionError::StateMalformed {
                path: destination.to_path_buf(),
            });
        }
    } else {
        if backup_present {
            return Err(RuntimePairTransactionError::StateMalformed {
                path: backup.to_path_buf(),
            });
        }
        if destination_present {
            remove_managed_directory_if_present(file_system, destination).map_err(|source| {
                RuntimePairTransactionError::Recovery {
                    path: destination.to_path_buf(),
                    source,
                }
            })?;
        }
    }
    Ok(())
}

fn publish_state(
    file_system: &dyn PublicationFileSystem,
    root: &Path,
    state_path: &Path,
    state: &RuntimePairPublicationStateV1,
) -> Result<DirectorySyncOutcome, RuntimePairTransactionError> {
    let mut bytes = serde_json::to_vec(state).map_err(|_| {
        RuntimePairTransactionError::StateMalformed {
            path: state_path.to_path_buf(),
        }
    })?;
    bytes.push(b'\n');
    if bytes.len() as u64 > STATE_LIMIT {
        return Err(RuntimePairTransactionError::StateMalformed {
            path: state_path.to_path_buf(),
        });
    }
    let temporary = root.join(format!(
        "{STATE_TEMPORARY_PREFIX}{}",
        uuid::Uuid::new_v4().simple(),
    ));
    let result = (|| -> Result<DirectorySyncOutcome, std::io::Error> {
        file_system.write_new_file_and_sync(&temporary, &bytes)?;
        file_system.replace_file(&temporary, state_path)?;
        file_system.sync_directory(root)
    })();
    match result {
        Ok(outcome) => Ok(outcome),
        Err(source) => {
            let _ = remove_managed_file_if_present(file_system, &temporary);
            Err(RuntimePairTransactionError::StatePublish {
                path: state_path.to_path_buf(),
                source,
            })
        }
    }
}

fn read_state(
    state_path: &Path,
) -> Result<RuntimePairPublicationStateV1, RuntimePairTransactionError> {
    let metadata = fs::symlink_metadata(state_path).map_err(|source| {
        RuntimePairTransactionError::StateRead {
            path: state_path.to_path_buf(),
            source,
        }
    })?;
    if metadata_is_link_or_reparse(&metadata)
        || !metadata.is_file()
        || metadata.len() > STATE_LIMIT
    {
        return Err(RuntimePairTransactionError::StateMalformed {
            path: state_path.to_path_buf(),
        });
    }
    let bytes = fs::read(state_path).map_err(|source| RuntimePairTransactionError::StateRead {
        path: state_path.to_path_buf(),
        source,
    })?;
    serde_json::from_slice(&bytes).map_err(|_| RuntimePairTransactionError::StateMalformed {
        path: state_path.to_path_buf(),
    })
}

fn validate_state(
    root: &Path,
    state_path: &Path,
    state: &RuntimePairPublicationStateV1,
    expected_acquisition: &[String],
    expected_processing: &[String],
) -> Result<(), RuntimePairTransactionError> {
    if state.schema_version != STATE_SCHEMA_VERSION
        || uuid::Uuid::parse_str(&state.transaction_id).is_err()
        || state.acquisition_destination != expected_acquisition
        || state.processing_destination != expected_processing
        || state.acquisition_destination == state.processing_destination
    {
        return Err(RuntimePairTransactionError::StateMalformed {
            path: state_path.to_path_buf(),
        });
    }
    let _ = decode_relative_path(root, &state.acquisition_destination)?;
    let _ = decode_relative_path(root, &state.processing_destination)?;
    Ok(())
}

fn cleanup_state_temporaries(
    file_system: &dyn PublicationFileSystem,
    root: &Path,
) -> Result<DirectorySyncOutcome, RuntimePairTransactionError> {
    let mut removed = false;
    for entry in fs::read_dir(root).map_err(|source| RuntimePairTransactionError::Inspect {
        path: root.to_path_buf(),
        source,
    })? {
        let entry = entry.map_err(|source| RuntimePairTransactionError::Inspect {
            path: root.to_path_buf(),
            source,
        })?;
        let name = entry.file_name();
        let Some(name) = name.to_str() else {
            continue;
        };
        let Some(nonce) = name.strip_prefix(STATE_TEMPORARY_PREFIX) else {
            continue;
        };
        if uuid::Uuid::parse_str(nonce).is_err() {
            return Err(RuntimePairTransactionError::StateMalformed {
                path: entry.path(),
            });
        }
        remove_managed_file_if_present(file_system, &entry.path()).map_err(|source| {
            RuntimePairTransactionError::Recovery {
                path: entry.path(),
                source,
            }
        })?;
        removed = true;
    }
    if removed {
        file_system.sync_directory(root).map_err(|source| RuntimePairTransactionError::Recovery {
            path: root.to_path_buf(),
            source,
        })
    } else {
        Ok(DirectorySyncOutcome::Synced)
    }
}

fn state_path_exists(path: &Path) -> Result<bool, RuntimePairTransactionError> {
    match fs::symlink_metadata(path) {
        Ok(metadata) => {
            if metadata_is_link_or_reparse(&metadata) || !metadata.is_file() {
                return Err(RuntimePairTransactionError::StateMalformed {
                    path: path.to_path_buf(),
                });
            }
            Ok(true)
        }
        Err(source) if source.kind() == std::io::ErrorKind::NotFound => Ok(false),
        Err(source) => Err(RuntimePairTransactionError::Inspect {
            path: path.to_path_buf(),
            source,
        }),
    }
}

fn encode_relative_path(
    root: &Path,
    path: &Path,
) -> Result<Vec<String>, RuntimePairTransactionError> {
    let relative = path
        .strip_prefix(root)
        .map_err(|_| RuntimePairTransactionError::InvalidDestination {
            path: path.to_path_buf(),
        })?;
    let mut parts = Vec::new();
    for component in relative.components() {
        let Component::Normal(value) = component else {
            return Err(RuntimePairTransactionError::InvalidDestination {
                path: path.to_path_buf(),
            });
        };
        let value = value
            .to_str()
            .ok_or_else(|| RuntimePairTransactionError::InvalidDestination {
                path: path.to_path_buf(),
            })?;
        if value.is_empty() {
            return Err(RuntimePairTransactionError::InvalidDestination {
                path: path.to_path_buf(),
            });
        }
        parts.push(value.to_owned());
    }
    if parts.is_empty() {
        return Err(RuntimePairTransactionError::InvalidDestination {
            path: path.to_path_buf(),
        });
    }
    Ok(parts)
}

fn decode_relative_path(
    root: &Path,
    parts: &[String],
) -> Result<PathBuf, RuntimePairTransactionError> {
    if parts.is_empty() {
        return Err(RuntimePairTransactionError::MalformedManagedPath {
            path: root.to_path_buf(),
        });
    }
    let mut path = root.to_path_buf();
    for part in parts {
        let mut components = Path::new(part).components();
        if part.is_empty()
            || !matches!(components.next(), Some(Component::Normal(_)))
            || components.next().is_some()
        {
            return Err(RuntimePairTransactionError::MalformedManagedPath {
                path: root.join(part),
            });
        }
        path.push(part);
    }
    Ok(path)
}

fn backup_path(
    destination: &Path,
    transaction_id: &str,
) -> Result<PathBuf, RuntimePairTransactionError> {
    if uuid::Uuid::parse_str(transaction_id).is_err() {
        return Err(RuntimePairTransactionError::MalformedManagedPath {
            path: destination.to_path_buf(),
        });
    }
    let parent = destination.parent().ok_or_else(|| {
        RuntimePairTransactionError::InvalidDestination {
            path: destination.to_path_buf(),
        }
    })?;
    let name = destination
        .file_name()
        .and_then(|value| value.to_str())
        .ok_or_else(|| RuntimePairTransactionError::InvalidDestination {
            path: destination.to_path_buf(),
        })?;
    Ok(parent.join(format!(
        ".{name}.lexicon-backup-{transaction_id}"
    )))
}

fn distinct_destination_parents(
    acquisition: &Path,
    processing: &Path,
) -> Result<Vec<PathBuf>, RuntimePairTransactionError> {
    let acquisition_parent = acquisition.parent().ok_or_else(|| {
        RuntimePairTransactionError::InvalidDestination {
            path: acquisition.to_path_buf(),
        }
    })?;
    let processing_parent = processing.parent().ok_or_else(|| {
        RuntimePairTransactionError::InvalidDestination {
            path: processing.to_path_buf(),
        }
    })?;
    let mut parents = vec![acquisition_parent.to_path_buf()];
    if acquisition_parent != processing_parent {
        parents.push(processing_parent.to_path_buf());
    }
    Ok(parents)
}

fn require_managed_directory(path: &Path) -> Result<(), RuntimePairTransactionError> {
    let metadata = fs::symlink_metadata(path).map_err(|source| {
        RuntimePairTransactionError::Inspect {
            path: path.to_path_buf(),
            source,
        }
    })?;
    if metadata_is_link_or_reparse(&metadata) || !metadata.is_dir() {
        return Err(RuntimePairTransactionError::MalformedManagedPath {
            path: path.to_path_buf(),
        });
    }
    Ok(())
}

fn managed_directory_exists(
    file_system: &dyn PublicationFileSystem,
    path: &Path,
) -> Result<bool, RuntimePairTransactionError> {
    match file_system.symlink_metadata(path) {
        Ok(metadata) => {
            if metadata_is_link_or_reparse(&metadata) || !metadata.is_dir() {
                return Err(RuntimePairTransactionError::MalformedManagedPath {
                    path: path.to_path_buf(),
                });
            }
            Ok(true)
        }
        Err(source) if source.kind() == std::io::ErrorKind::NotFound => Ok(false),
        Err(source) => Err(RuntimePairTransactionError::Inspect {
            path: path.to_path_buf(),
            source,
        }),
    }
}

fn remove_managed_directory_if_present(
    file_system: &dyn PublicationFileSystem,
    path: &Path,
) -> std::io::Result<()> {
    match file_system.symlink_metadata(path) {
        Ok(metadata) if metadata.is_dir() && !metadata_is_link_or_reparse(&metadata) => {
            file_system.remove_dir_all(path)
        }
        Ok(_) => Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            "managed runtime-pair cleanup target is not a real directory",
        )),
        Err(source) if source.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(source) => Err(source),
    }
}

fn remove_managed_file_if_present(
    file_system: &dyn PublicationFileSystem,
    path: &Path,
) -> std::io::Result<()> {
    match file_system.symlink_metadata(path) {
        Ok(metadata) if metadata.is_file() && !metadata_is_link_or_reparse(&metadata) => {
            file_system.remove_file(path)
        }
        Ok(_) => Err(std::io::Error::new(
            std::io::ErrorKind::InvalidData,
            "managed runtime-pair cleanup target is not a regular file",
        )),
        Err(source) if source.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(source) => Err(source),
    }
}

fn open_lock_file(path: &Path) -> Result<File, RuntimePairTransactionError> {
    if let Ok(metadata) = fs::symlink_metadata(path)
        && (metadata_is_link_or_reparse(&metadata) || !metadata.is_file())
    {
        return Err(RuntimePairTransactionError::MalformedManagedPath {
            path: path.to_path_buf(),
        });
    }
    let file = OpenOptions::new()
        .read(true)
        .write(true)
        .create(true)
        .truncate(false)
        .open(path)
        .map_err(|source| RuntimePairTransactionError::LockOpen {
            path: path.to_path_buf(),
            source,
        })?;
    let metadata = file.metadata().map_err(|source| RuntimePairTransactionError::Inspect {
        path: path.to_path_buf(),
        source,
    })?;
    if !metadata.is_file() {
        return Err(RuntimePairTransactionError::MalformedManagedPath {
            path: path.to_path_buf(),
        });
    }
    let path_metadata = fs::symlink_metadata(path).map_err(|source| {
        RuntimePairTransactionError::Inspect {
            path: path.to_path_buf(),
            source,
        }
    })?;
    if metadata_is_link_or_reparse(&path_metadata) || !path_metadata.is_file() {
        return Err(RuntimePairTransactionError::MalformedManagedPath {
            path: path.to_path_buf(),
        });
    }
    Ok(file)
}

fn metadata_is_link_or_reparse(metadata: &fs::Metadata) -> bool {
    if metadata.file_type().is_symlink() {
        return true;
    }
    #[cfg(windows)]
    {
        use std::os::windows::fs::MetadataExt;
        const FILE_ATTRIBUTE_REPARSE_POINT: u32 = 0x0000_0400;
        return metadata.file_attributes() & FILE_ATTRIBUTE_REPARSE_POINT != 0;
    }
    #[cfg(not(windows))]
    false
}

#[derive(Clone, Copy)]
enum LockMode {
    Shared,
    Exclusive,
}

enum LockError {
    Contended,
    Io(std::io::Error),
}

#[cfg(unix)]
fn try_lock(file: &File, mode: LockMode) -> Result<(), LockError> {
    use std::os::fd::AsRawFd;
    let operation = match mode {
        LockMode::Shared => libc::LOCK_SH,
        LockMode::Exclusive => libc::LOCK_EX,
    } | libc::LOCK_NB;
    if unsafe { libc::flock(file.as_raw_fd(), operation) } == 0 {
        return Ok(());
    }
    let source = std::io::Error::last_os_error();
    if source.raw_os_error() == Some(libc::EWOULDBLOCK) {
        Err(LockError::Contended)
    } else {
        Err(LockError::Io(source))
    }
}

#[cfg(windows)]
fn try_lock(file: &File, mode: LockMode) -> Result<(), LockError> {
    use std::mem::zeroed;
    use std::os::windows::io::AsRawHandle;
    use windows_sys::Win32::Storage::FileSystem::{
        LOCKFILE_EXCLUSIVE_LOCK, LOCKFILE_FAIL_IMMEDIATELY, LockFileEx,
    };
    let mut flags = LOCKFILE_FAIL_IMMEDIATELY;
    if matches!(mode, LockMode::Exclusive) {
        flags |= LOCKFILE_EXCLUSIVE_LOCK;
    }
    let mut overlapped = unsafe { zeroed() };
    let result = unsafe {
        LockFileEx(
            file.as_raw_handle() as _,
            flags,
            0,
            u32::MAX,
            u32::MAX,
            &mut overlapped,
        )
    };
    if result != 0 {
        return Ok(());
    }
    let source = std::io::Error::last_os_error();
    if source.raw_os_error() == Some(33) {
        Err(LockError::Contended)
    } else {
        Err(LockError::Io(source))
    }
}

#[cfg(not(any(unix, windows)))]
fn try_lock(_file: &File, _mode: LockMode) -> Result<(), LockError> {
    Err(LockError::Io(std::io::Error::new(
        std::io::ErrorKind::Unsupported,
        "runtime-pair file locking is unsupported on this platform",
    )))
}

#[cfg(unix)]
fn unlock(file: &File) {
    use std::os::fd::AsRawFd;
    let _ = unsafe { libc::flock(file.as_raw_fd(), libc::LOCK_UN) };
}

#[cfg(windows)]
fn unlock(file: &File) {
    use std::mem::zeroed;
    use std::os::windows::io::AsRawHandle;
    use windows_sys::Win32::Storage::FileSystem::UnlockFileEx;
    let mut overlapped = unsafe { zeroed() };
    let _ = unsafe {
        UnlockFileEx(
            file.as_raw_handle() as _,
            0,
            u32::MAX,
            u32::MAX,
            &mut overlapped,
        )
    };
}

#[cfg(not(any(unix, windows)))]
fn unlock(_file: &File) {}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Arc;

    use crate::publication::{
        PublicationFileSystem, ScriptEntry, ScriptMatcher,
        ScriptedPublicationFileSystem,
    };

    fn pair(root: &Path) -> (PathBuf, PathBuf) {
        (
            root.join("get-raw-data/runtime"),
            root.join("process-data/runtime"),
        )
    }

    fn seed_old_pair(root: &Path) -> (PathBuf, PathBuf) {
        let (acquisition, processing) = pair(root);
        fs::create_dir_all(&acquisition).unwrap();
        fs::create_dir_all(&processing).unwrap();
        fs::write(acquisition.join("sentinel"), b"old acquisition").unwrap();
        fs::write(processing.join("sentinel"), b"old processing").unwrap();
        (acquisition, processing)
    }

    #[test]
    fn shared_admission_is_rejected_while_publication_is_owned() {
        let root = tempfile::tempdir().unwrap();
        let (acquisition, processing) = seed_old_pair(root.path());
        let transaction = RuntimePairTransaction::begin(
            root.path(),
            &acquisition,
            &processing,
        )
        .unwrap();
        let error = acquire_runtime_pair_admission_guard(
            root.path(),
            &acquisition,
            &processing,
        )
        .unwrap_err();
        assert!(matches!(
            error,
            RuntimePairTransactionError::PublicationInProgress { .. }
        ));
        drop(transaction);
    }

    #[test]
    fn publication_is_rejected_while_shared_admission_is_owned() {
        let root = tempfile::tempdir().unwrap();
        let (acquisition, processing) = seed_old_pair(root.path());
        let admission = acquire_runtime_pair_admission_guard(
            root.path(),
            &acquisition,
            &processing,
        )
        .unwrap();
        let error = RuntimePairTransaction::begin(
            root.path(),
            &acquisition,
            &processing,
        )
        .unwrap_err();
        assert!(matches!(
            error,
            RuntimePairTransactionError::PublicationInProgress { .. }
        ));
        drop(admission);
    }

    #[test]
    fn interrupted_recovery_state_is_rejected_by_runtime_admission() {
        let root = tempfile::tempdir().unwrap();
        let (acquisition, processing) = seed_old_pair(root.path());
        let transaction = RuntimePairTransaction::begin(
            root.path(),
            &acquisition,
            &processing,
        )
        .unwrap();
        drop(transaction);

        let error = acquire_runtime_pair_admission_guard(
            root.path(),
            &acquisition,
            &processing,
        )
        .unwrap_err();
        assert!(matches!(
            error,
            RuntimePairTransactionError::RecoveryRequired { .. }
        ));
    }

    #[test]
    fn recovery_rolls_back_a_crash_between_pair_replacements() {
        let root = tempfile::tempdir().unwrap();
        let (acquisition, processing) = seed_old_pair(root.path());
        let mut transaction = RuntimePairTransaction::begin(
            root.path(),
            &acquisition,
            &processing,
        )
        .unwrap();
        let acquisition_backup = transaction.acquisition_backup_path().unwrap();
        fs::rename(&acquisition, &acquisition_backup).unwrap();
        fs::create_dir(&acquisition).unwrap();
        fs::write(acquisition.join("sentinel"), b"new acquisition").unwrap();
        transaction.record_acquisition_installed().unwrap();
        drop(transaction);

        let transaction = RuntimePairTransaction::begin(
            root.path(),
            &acquisition,
            &processing,
        )
        .unwrap();
        assert_eq!(
            fs::read(acquisition.join("sentinel")).unwrap(),
            b"old acquisition",
        );
        assert_eq!(
            fs::read(processing.join("sentinel")).unwrap(),
            b"old processing",
        );
        drop(transaction);
    }

    #[test]
    fn committed_recovery_keeps_the_new_pair_and_removes_backups() {
        let root = tempfile::tempdir().unwrap();
        let (acquisition, processing) = seed_old_pair(root.path());
        let mut transaction = RuntimePairTransaction::begin(
            root.path(),
            &acquisition,
            &processing,
        )
        .unwrap();
        let acquisition_backup = transaction.acquisition_backup_path().unwrap();
        let processing_backup = transaction.processing_backup_path().unwrap();
        fs::rename(&acquisition, &acquisition_backup).unwrap();
        fs::create_dir(&acquisition).unwrap();
        fs::write(acquisition.join("sentinel"), b"new acquisition").unwrap();
        transaction.record_acquisition_installed().unwrap();
        fs::rename(&processing, &processing_backup).unwrap();
        fs::create_dir(&processing).unwrap();
        fs::write(processing.join("sentinel"), b"new processing").unwrap();
        transaction.record_pair_installed().unwrap();
        transaction.record_committed().unwrap();
        drop(transaction);

        let transaction = RuntimePairTransaction::begin(
            root.path(),
            &acquisition,
            &processing,
        )
        .unwrap();
        assert_eq!(
            fs::read(acquisition.join("sentinel")).unwrap(),
            b"new acquisition",
        );
        assert_eq!(
            fs::read(processing.join("sentinel")).unwrap(),
            b"new processing",
        );
        assert!(!acquisition_backup.exists());
        assert!(!processing_backup.exists());
        drop(transaction);
    }

    #[test]
    fn malformed_state_cannot_escape_the_transaction_root() {
        let root = tempfile::tempdir().unwrap();
        let (acquisition, processing) = seed_old_pair(root.path());
        let state = root.path().join(STATE_FILE_NAME);
        fs::write(
            &state,
            br#"{"schema_version":1,"transaction_id":"00000000000000000000000000000001","acquisition_destination":["..","keep"],"processing_destination":["process-data","runtime"],"acquisition_baseline_present":true,"processing_baseline_present":true,"phase":"prepared"}"#,
        )
        .unwrap();
        let error = RuntimePairTransaction::begin(
            root.path(),
            &acquisition,
            &processing,
        )
        .unwrap_err();
        assert!(matches!(
            error,
            RuntimePairTransactionError::StateMalformed { .. }
                | RuntimePairTransactionError::MalformedManagedPath { .. }
        ));
    }

    #[test]
    fn journal_phase_publication_uses_the_injected_file_system() {
        let root = tempfile::tempdir().unwrap();
        let (acquisition, processing) = seed_old_pair(root.path());
        let scripted = Arc::new(ScriptedPublicationFileSystem::new(Vec::new()));
        let file_system: Arc<dyn PublicationFileSystem> = scripted.clone();
        let mut transaction = RuntimePairTransaction::begin_with_file_system(
            root.path(),
            &acquisition,
            &processing,
            file_system,
        )
        .unwrap();

        transaction.record_acquisition_installed().unwrap();
        transaction.record_pair_installed().unwrap();
        transaction.record_committed().unwrap();

        let history = scripted.history();
        assert_eq!(
            history
                .iter()
                .filter(|call| call.method == "write_new_file_and_sync")
                .count(),
            4,
        );
        assert_eq!(
            history
                .iter()
                .filter(|call| call.method == "replace_file")
                .count(),
            4,
        );
        assert_eq!(
            history
                .iter()
                .filter(|call| call.method == "sync_directory")
                .count(),
            4,
        );
        transaction.finish_committed().unwrap();
    }

    #[test]
    fn committed_journal_parent_sync_failure_restores_the_previous_pair() {
        let root = tempfile::tempdir().unwrap();
        let (acquisition, processing) = seed_old_pair(root.path());
        let scripted = Arc::new(ScriptedPublicationFileSystem::new(vec![
            ScriptEntry {
                matches: ScriptMatcher::FirstMethod("sync_directory"),
                response: Ok(()),
            },
            ScriptEntry {
                matches: ScriptMatcher::FirstMethod("sync_directory"),
                response: Ok(()),
            },
            ScriptEntry {
                matches: ScriptMatcher::FirstMethod("sync_directory"),
                response: Ok(()),
            },
            ScriptEntry {
                matches: ScriptMatcher::FirstMethod("sync_directory"),
                response: Err("injected committed-journal parent sync failure".into()),
            },
        ]));
        let file_system: Arc<dyn PublicationFileSystem> = scripted.clone();
        let mut transaction = RuntimePairTransaction::begin_with_file_system(
            root.path(),
            &acquisition,
            &processing,
            file_system,
        )
        .unwrap();

        let acquisition_backup = transaction.acquisition_backup_path().unwrap();
        fs::rename(&acquisition, &acquisition_backup).unwrap();
        fs::create_dir(&acquisition).unwrap();
        fs::write(acquisition.join("sentinel"), b"new acquisition").unwrap();
        transaction.record_acquisition_installed().unwrap();

        let processing_backup = transaction.processing_backup_path().unwrap();
        fs::rename(&processing, &processing_backup).unwrap();
        fs::create_dir(&processing).unwrap();
        fs::write(processing.join("sentinel"), b"new processing").unwrap();
        transaction.record_pair_installed().unwrap();

        let error = transaction.record_committed().unwrap_err();
        assert!(matches!(error, RuntimePairTransactionError::StatePublish { .. }));
        transaction.recover_after_failure().unwrap();

        assert_eq!(
            fs::read(acquisition.join("sentinel")).unwrap(),
            b"old acquisition",
        );
        assert_eq!(
            fs::read(processing.join("sentinel")).unwrap(),
            b"old processing",
        );
        assert!(!root.path().join(STATE_FILE_NAME).exists());
        assert!(!acquisition_backup.exists());
        assert!(!processing_backup.exists());
        assert_eq!(scripted.remaining(), 0);
    }

    #[test]
    fn recovery_retains_unsupported_directory_sync_outcome() {
        let root = tempfile::tempdir().unwrap();
        let (acquisition, processing) = seed_old_pair(root.path());
        let scripted = Arc::new(ScriptedPublicationFileSystem::new(Vec::new()));
        let file_system: Arc<dyn PublicationFileSystem> = scripted.clone();
        let mut transaction = RuntimePairTransaction::begin_with_file_system(
            root.path(),
            &acquisition,
            &processing,
            file_system,
        )
        .unwrap();
        let acquisition_backup = transaction.acquisition_backup_path().unwrap();
        fs::rename(&acquisition, &acquisition_backup).unwrap();
        fs::create_dir(&acquisition).unwrap();
        transaction.record_acquisition_installed().unwrap();

        scripted.force_directory_sync_outcome_at(
            3,
            DirectorySyncOutcome::UnsupportedByPlatform,
        );
        assert_eq!(
            transaction.recover_after_failure().unwrap(),
            RuntimePairDurability::DirectorySyncUnsupported,
        );
    }

    #[cfg(windows)]
    #[test]
    fn interrupted_recovery_retries_a_temporarily_locked_backup() {
        use std::os::windows::fs::OpenOptionsExt;
        use std::thread;
        use std::time::{Duration, Instant};

        const FILE_SHARE_READ: u32 = 0x0000_0001;

        let root = tempfile::tempdir().unwrap();
        let (acquisition, processing) = seed_old_pair(root.path());
        let mut transaction = RuntimePairTransaction::begin(
            root.path(),
            &acquisition,
            &processing,
        )
        .unwrap();
        let acquisition_backup = transaction.acquisition_backup_path().unwrap();
        fs::rename(&acquisition, &acquisition_backup).unwrap();
        fs::create_dir(&acquisition).unwrap();
        fs::write(acquisition.join("sentinel"), b"new acquisition").unwrap();
        transaction.record_acquisition_installed().unwrap();
        drop(transaction);

        let lock = fs::OpenOptions::new()
            .read(true)
            .share_mode(FILE_SHARE_READ)
            .open(acquisition_backup.join("sentinel"))
            .unwrap();
        let release = thread::spawn(move || {
            thread::sleep(Duration::from_millis(40));
            drop(lock);
        });

        let started = Instant::now();
        let mut recovered = RuntimePairTransaction::begin(
            root.path(),
            &acquisition,
            &processing,
        )
        .unwrap();
        release.join().unwrap();

        assert!(started.elapsed() >= Duration::from_millis(25));
        assert_eq!(
            fs::read(acquisition.join("sentinel")).unwrap(),
            b"old acquisition",
        );
        recovered.recover_after_failure().unwrap();
    }
}
