use std::fmt;
use std::path::{Path, PathBuf};
use std::sync::Arc;

use lexicon_core::runtime::{OwnedRuntimeIdentity, RuntimeOperation};

use crate::build::{
    ProcessingRuntimeBundleAdmissionError, RuntimeBundleAdmissionError,
    RuntimeBundleStagingTransferError, StagedHttpRuntimeBundle, StagedProcessingRuntimeBundle,
    admit_http_runtime_bundle_owned,
    admit_processing_runtime_bundle_owned,
};
use crate::publication::runtime_bundle_replacement::{
    PreparedRuntimeBundleReplacement, RuntimeBundleReplacementError,
    prepare_runtime_bundle_replacement_for_staged_directory_with_backup_path_and_file_system,
};
use crate::publication::file_system::{
    ProductionPublicationFileSystem, PublicationFileSystem,
};
use crate::publication::runtime_pair_transaction::{
    RuntimePairDurability, RuntimePairTransaction, RuntimePairTransactionError,
};
use crate::fs::DirectorySyncOutcome;

#[derive(Debug)]
pub enum RuntimePairCleanupWarning {
    Acquisition { path: PathBuf, source: RuntimeBundleReplacementError },
    Processing { path: PathBuf, source: RuntimeBundleReplacementError },
    Transaction { path: PathBuf, source: RuntimePairTransactionError },
    DirectorySyncUnsupported { path: PathBuf },
}

impl fmt::Display for RuntimePairCleanupWarning {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Acquisition { path, source } => write!(
                formatter,
                "acquisition publication cleanup failed under '{}': {source}",
                path.display()
            ),
            Self::Processing { path, source } => write!(
                formatter,
                "processing publication cleanup failed under '{}': {source}",
                path.display()
            ),
            Self::Transaction { path, source } => write!(
                formatter,
                "runtime-pair transaction cleanup remains recoverable under '{}': {source}",
                path.display()
            ),
            Self::DirectorySyncUnsupported { path } => write!(
                formatter,
                "runtime-pair publication used the strongest available replacement but directory synchronization is unsupported under '{}'",
                path.display()
            ),
        }
    }
}

impl std::error::Error for RuntimePairCleanupWarning {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::Acquisition { source, .. } | Self::Processing { source, .. } => Some(source),
            Self::Transaction { source, .. } => Some(source),
            Self::DirectorySyncUnsupported { .. } => None,
        }
    }
}

fn format_destination_failure(
    formatter: &mut fmt::Formatter<'_>,
    operation: &str,
    source: &dyn fmt::Display,
    destination: &Path,
    expected_identity: &OwnedRuntimeIdentity,
    acquisition_rollback: Option<&RuntimeBundleReplacementError>,
    processing_rollback: Option<&RuntimeBundleReplacementError>,
) -> fmt::Result {
    write!(formatter, "failed to admit installed {operation} destination '{}' for identity {expected_identity:?}: {source}", destination.display())?;
    if let Some(rollback) = acquisition_rollback {
        write!(formatter, "; acquisition rollback also failed: {rollback}")?;
    }
    if let Some(rollback) = processing_rollback {
        write!(formatter, "; processing rollback also failed: {rollback}")?;
    }
    Ok(())
}

#[derive(Debug)]
pub enum RuntimePairPublicationError {
    InvalidDestinations,
    TransactionBegin {
        source: RuntimePairTransactionError,
    },
    TransactionState {
        source: RuntimePairTransactionError,
    },
    PublicationAndRecovery {
        primary: Box<RuntimePairPublicationError>,
        recovery: RuntimePairTransactionError,
    },
    PublicationRecoveredWithoutDirectorySync {
        primary: Box<RuntimePairPublicationError>,
        path: PathBuf,
    },
    InvalidAcquisitionIdentity,
    InvalidProcessingIdentity,
    RuntimePairIdentityMismatch {
        acquisition: OwnedRuntimeIdentity,
        processing: OwnedRuntimeIdentity,
    },
    AcquisitionStagedAdmission {
        source: RuntimeBundleAdmissionError,
        destination: PathBuf,
        expected_identity: OwnedRuntimeIdentity,
    },
    ProcessingStagedAdmission {
        source: ProcessingRuntimeBundleAdmissionError,
        destination: PathBuf,
        expected_identity: OwnedRuntimeIdentity,
    },
    AcquisitionStagingTransfer {
        source: RuntimeBundleStagingTransferError,
        destination: PathBuf,
    },
    ProcessingStagingTransfer {
        source: RuntimeBundleStagingTransferError,
        destination: PathBuf,
        acquisition_rollback: Option<RuntimeBundleReplacementError>,
    },
    PrepareAcquisition {
        source: RuntimeBundleReplacementError,
        destination: PathBuf,
    },
    PrepareProcessing {
        source: RuntimeBundleReplacementError,
        destination: PathBuf,
        acquisition_rollback: Option<RuntimeBundleReplacementError>,
    },
    AcquisitionDestinationAdmission {
        source: RuntimeBundleAdmissionError,
        destination: PathBuf,
        expected_identity: OwnedRuntimeIdentity,
        acquisition_rollback: Option<RuntimeBundleReplacementError>,
        processing_rollback: Option<RuntimeBundleReplacementError>,
    },
    ProcessingDestinationAdmission {
        source: ProcessingRuntimeBundleAdmissionError,
        destination: PathBuf,
        expected_identity: OwnedRuntimeIdentity,
        acquisition_rollback: Option<RuntimeBundleReplacementError>,
        processing_rollback: Option<RuntimeBundleReplacementError>,
    },
}

impl fmt::Display for RuntimePairPublicationError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidDestinations => formatter.write_str(
                "publication destinations are invalid: they must be distinct, non-overlapping, and backed by valid directories",
            ),
            Self::TransactionBegin { source } => write!(
                formatter,
                "failed to acquire or recover durable runtime-pair publication authority: {source}",
            ),
            Self::TransactionState { source } => write!(
                formatter,
                "failed to durably advance runtime-pair publication state: {source}",
            ),
            Self::PublicationAndRecovery { primary, recovery } => write!(
                formatter,
                "runtime-pair publication failed: {primary}; durable rollback also failed: {recovery}",
            ),
            Self::PublicationRecoveredWithoutDirectorySync { primary, path } => write!(
                formatter,
                "runtime-pair publication failed and the previous pair was restored, but directory synchronization is unsupported under '{}': {primary}",
                path.display(),
            ),
            Self::InvalidAcquisitionIdentity => formatter.write_str(
                "expected acquisition identity does not declare the acquisition operation",
            ),
            Self::InvalidProcessingIdentity => formatter.write_str(
                "expected processing identity does not declare the processing operation",
            ),
            Self::RuntimePairIdentityMismatch {
                acquisition,
                processing,
            } => write!(
                formatter,
                "runtime pair identities do not bind the same source/protocol: acquisition={acquisition:?}, processing={processing:?}",
            ),
            Self::AcquisitionStagedAdmission {
                source,
                destination,
                expected_identity,
            } => write!(
                formatter,
                "failed to admit staged acquisition bundle '{}' for identity {:?}: {source}",
                destination.display(),
                expected_identity
            ),
            Self::ProcessingStagedAdmission {
                source,
                destination,
                expected_identity,
            } => write!(
                formatter,
                "failed to admit staged processing bundle '{}' for identity {:?}: {source}",
                destination.display(),
                expected_identity
            ),
            Self::AcquisitionStagingTransfer { source, destination } => write!(
                formatter,
                "failed to transfer staged acquisition bundle for '{}': {source}",
                destination.display(),
            ),
            Self::ProcessingStagingTransfer { source, destination, acquisition_rollback } => {
                write!(formatter, "failed to transfer staged processing bundle for '{}': {source}", destination.display())?;
                if let Some(rollback) = acquisition_rollback { write!(formatter, "; acquisition rollback also failed: {rollback}")?; }
                Ok(())
            }
            Self::PrepareAcquisition { source, destination } => write!(
                formatter,
                "failed to prepare acquisition replacement at '{}': {source}",
                destination.display()
            ),
            Self::PrepareProcessing { source, destination, acquisition_rollback } => {
                write!(formatter, "failed to prepare processing replacement at '{}': {source}", destination.display())?;
                if let Some(rollback) = acquisition_rollback {
                    write!(formatter, "; acquisition rollback also failed: {rollback}")?;
                }
                Ok(())
            }
            Self::AcquisitionDestinationAdmission {
                source,
                destination,
                expected_identity,
                acquisition_rollback,
                processing_rollback,
            } => format_destination_failure(formatter, "acquisition", source, destination, expected_identity, acquisition_rollback.as_ref(), processing_rollback.as_ref()),
            Self::ProcessingDestinationAdmission {
                source,
                destination,
                expected_identity,
                acquisition_rollback,
                processing_rollback,
            } => format_destination_failure(formatter, "processing", source, destination, expected_identity, acquisition_rollback.as_ref(), processing_rollback.as_ref()),
        }
    }
}

impl std::error::Error for RuntimePairPublicationError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::TransactionBegin { source } | Self::TransactionState { source } => Some(source),
            Self::PublicationAndRecovery { primary, .. } => Some(primary.as_ref()),
            Self::PublicationRecoveredWithoutDirectorySync { primary, .. } => {
                Some(primary.as_ref())
            }
            Self::AcquisitionStagedAdmission { source, .. } => Some(source),
            Self::ProcessingStagedAdmission { source, .. } => Some(source),
            Self::AcquisitionStagingTransfer { source, .. }
            | Self::ProcessingStagingTransfer { source, .. } => Some(source),
            Self::AcquisitionDestinationAdmission { source, .. } => Some(source),
            Self::ProcessingDestinationAdmission { source, .. } => Some(source),
            Self::PrepareAcquisition { source, .. }
            | Self::PrepareProcessing { source, .. } => Some(source),
            Self::InvalidDestinations
            | Self::InvalidAcquisitionIdentity
            | Self::InvalidProcessingIdentity
            | Self::RuntimePairIdentityMismatch { .. } => None,
        }
    }
}

#[derive(Debug)]
pub struct PublishedRuntimePair {
    acquisition_directory: PathBuf,
    processing_directory: PathBuf,
    cleanup_warnings: Vec<RuntimePairCleanupWarning>,
}

impl PublishedRuntimePair {
    pub fn acquisition_directory(&self) -> &Path {
        self.acquisition_directory.as_path()
    }

    pub fn processing_directory(&self) -> &Path {
        self.processing_directory.as_path()
    }

    pub fn cleanup_warnings(&self) -> &[RuntimePairCleanupWarning] {
        self.cleanup_warnings.as_slice()
    }

    pub fn take_cleanup_warnings(&mut self) -> Vec<RuntimePairCleanupWarning> {
        std::mem::take(&mut self.cleanup_warnings)
    }
}

pub fn publish_runtime_pair<A, P>(
    acquisition: StagedHttpRuntimeBundle,
    processing: StagedProcessingRuntimeBundle,
    acquisition_destination: &Path,
    processing_destination: &Path,
    expected_acquisition_identity: A,
    expected_processing_identity: P,
) -> Result<PublishedRuntimePair, RuntimePairPublicationError>
where
    A: Into<OwnedRuntimeIdentity>,
    P: Into<OwnedRuntimeIdentity>,
{
    publish_runtime_pair_with_file_system(
        acquisition,
        processing,
        acquisition_destination,
        processing_destination,
        expected_acquisition_identity.into(),
        expected_processing_identity.into(),
        Arc::new(ProductionPublicationFileSystem),
    )
}

pub(crate) fn publish_runtime_pair_with_file_system(
    acquisition: StagedHttpRuntimeBundle,
    processing: StagedProcessingRuntimeBundle,
    acquisition_destination: &Path,
    processing_destination: &Path,
    expected_acquisition_identity: OwnedRuntimeIdentity,
    expected_processing_identity: OwnedRuntimeIdentity,
    file_system: Arc<dyn PublicationFileSystem>,
) -> Result<PublishedRuntimePair, RuntimePairPublicationError> {
    if validate_destination_pair(
        file_system.as_ref(),
        acquisition_destination,
        processing_destination,
    )
    .is_err()
    {
        return Err(RuntimePairPublicationError::InvalidDestinations);
    }
    if expected_acquisition_identity.operation() != RuntimeOperation::Acquisition {
        return Err(RuntimePairPublicationError::InvalidAcquisitionIdentity);
    }
    if expected_processing_identity.operation() != RuntimeOperation::Processing {
        return Err(RuntimePairPublicationError::InvalidProcessingIdentity);
    }
    if expected_acquisition_identity.source_name()
        != expected_processing_identity.source_name()
        || expected_acquisition_identity.protocol()
            != expected_processing_identity.protocol()
    {
        return Err(RuntimePairPublicationError::RuntimePairIdentityMismatch {
            acquisition: expected_acquisition_identity,
            processing: expected_processing_identity,
        });
    }

    let acquisition_staged = acquisition;
    let processing_staged = processing;

    admit_http_runtime_bundle_owned(
        acquisition_staged.directory(),
        &expected_acquisition_identity,
    )
    .map_err(
        |source| RuntimePairPublicationError::AcquisitionStagedAdmission {
            source,
            destination: acquisition_destination.to_path_buf(),
            expected_identity: expected_acquisition_identity.clone(),
        },
    )?;
    admit_processing_runtime_bundle_owned(processing_staged.directory(), &expected_processing_identity)
        .map_err(
            |source| RuntimePairPublicationError::ProcessingStagedAdmission {
                source,
                destination: processing_destination.to_path_buf(),
                expected_identity: expected_processing_identity.clone(),
            },
        )?;

    let transaction_root = transaction_root_for_destinations(
        acquisition_destination,
        processing_destination,
    )
    .ok_or(RuntimePairPublicationError::InvalidDestinations)?;
    let mut transaction = RuntimePairTransaction::begin_with_file_system(
        &transaction_root,
        acquisition_destination,
        processing_destination,
        Arc::clone(&file_system),
    )
    .map_err(|source| RuntimePairPublicationError::TransactionBegin { source })?;

    let publication_result = (|| {
        let acquisition_backup = transaction
            .acquisition_backup_path()
            .map_err(|source| RuntimePairPublicationError::TransactionState { source })?;
        let acquisition_owned = acquisition_staged
            .into_owned_staged_runtime_directory()
            .map_err(|source| RuntimePairPublicationError::AcquisitionStagingTransfer {
                source,
                destination: acquisition_destination.to_path_buf(),
            })?;
        let mut acquisition_prepared =
            prepare_runtime_bundle_replacement_for_staged_directory_with_backup_path_and_file_system(
                acquisition_owned,
                acquisition_destination,
                &acquisition_backup,
                Arc::clone(&file_system),
            )
            .map_err(|source| RuntimePairPublicationError::PrepareAcquisition {
                source,
                destination: acquisition_destination.to_path_buf(),
            })?;
        transaction
            .record_acquisition_installed()
            .map_err(|source| RuntimePairPublicationError::TransactionState { source })?;

        let processing_backup = transaction
            .processing_backup_path()
            .map_err(|source| RuntimePairPublicationError::TransactionState { source })?;
        let processing_owned = match processing_staged.into_owned_staged_runtime_directory() {
            Ok(owned) => owned,
            Err(source) => {
                let acquisition_rollback = rollback_prepared_replacement(
                    &mut transaction,
                    acquisition_prepared,
                );
                return Err(RuntimePairPublicationError::ProcessingStagingTransfer {
                    source,
                    destination: processing_destination.to_path_buf(),
                    acquisition_rollback,
                });
            }
        };
        let mut processing_prepared = match
            prepare_runtime_bundle_replacement_for_staged_directory_with_backup_path_and_file_system(
                processing_owned,
                processing_destination,
                &processing_backup,
                Arc::clone(&file_system),
            )
        {
            Ok(prepared) => prepared,
            Err(source) => {
                let acquisition_rollback = rollback_prepared_replacement(
                    &mut transaction,
                    acquisition_prepared,
                );
                return Err(RuntimePairPublicationError::PrepareProcessing {
                    source,
                    destination: processing_destination.to_path_buf(),
                    acquisition_rollback,
                });
            }
        };
        transaction
            .record_pair_installed()
            .map_err(|source| RuntimePairPublicationError::TransactionState { source })?;

        if let Err(source) =
            admit_http_runtime_bundle_owned(acquisition_destination, &expected_acquisition_identity)
        {
            let processing_rollback = rollback_prepared_replacement(
                &mut transaction,
                processing_prepared,
            );
            let acquisition_rollback = rollback_prepared_replacement(
                &mut transaction,
                acquisition_prepared,
            );
            return Err(RuntimePairPublicationError::AcquisitionDestinationAdmission {
                source,
                destination: acquisition_destination.to_path_buf(),
                expected_identity: expected_acquisition_identity.clone(),
                acquisition_rollback,
                processing_rollback,
            });
        }

        if let Err(source) = admit_processing_runtime_bundle_owned(
            processing_destination,
            &expected_processing_identity,
        ) {
            let processing_rollback = rollback_prepared_replacement(
                &mut transaction,
                processing_prepared,
            );
            let acquisition_rollback = rollback_prepared_replacement(
                &mut transaction,
                acquisition_prepared,
            );
            return Err(RuntimePairPublicationError::ProcessingDestinationAdmission {
                source,
                destination: processing_destination.to_path_buf(),
                expected_identity: expected_processing_identity.clone(),
                acquisition_rollback,
                processing_rollback,
            });
        }

        // From this point onward the durable pair journal is the sole recovery
        // authority. Disable the replacement objects' implicit per-bundle
        // rollback before publishing `Committed`: the state-file rename may
        // succeed even when its following parent sync reports an error.
        acquisition_prepared.mark_committed();
        processing_prepared.mark_committed();
        transaction
            .record_committed()
            .map_err(|source| RuntimePairPublicationError::TransactionState { source })?;

        let mut warnings = Vec::new();
        let mut cleanup_failed = false;
        let mut directory_sync_unsupported = transaction
            .durability()
            .directory_sync_unsupported()
            || acquisition_prepared.post_install_sync_outcome()
                == DirectorySyncOutcome::UnsupportedByPlatform
            || processing_prepared.post_install_sync_outcome()
                == DirectorySyncOutcome::UnsupportedByPlatform;

        let acquisition_cleanup_path = acquisition_prepared
            .backup_path()
            .unwrap_or_else(|| acquisition_prepared.parent_path())
            .to_path_buf();
        match acquisition_prepared.cleanup_backup() {
            Ok(outcome) => {
                directory_sync_unsupported |=
                    outcome == DirectorySyncOutcome::UnsupportedByPlatform;
            }
            Err(source) => {
                cleanup_failed = true;
                warnings.push(RuntimePairCleanupWarning::Acquisition {
                    path: acquisition_cleanup_path,
                    source,
                });
            }
        }
        let processing_cleanup_path = processing_prepared
            .backup_path()
            .unwrap_or_else(|| processing_prepared.parent_path())
            .to_path_buf();
        match processing_prepared.cleanup_backup() {
            Ok(outcome) => {
                directory_sync_unsupported |=
                    outcome == DirectorySyncOutcome::UnsupportedByPlatform;
            }
            Err(source) => {
                cleanup_failed = true;
                warnings.push(RuntimePairCleanupWarning::Processing {
                    path: processing_cleanup_path,
                    source,
                });
            }
        }

        if !cleanup_failed {
            match transaction.finish_committed() {
                Ok(RuntimePairDurability::DirectorySyncUnsupported) => {
                    directory_sync_unsupported = true;
                }
                Ok(RuntimePairDurability::Synced) => {}
                Err(source) => warnings.push(RuntimePairCleanupWarning::Transaction {
                    path: transaction.root().to_path_buf(),
                    source,
                }),
            }
        }
        if directory_sync_unsupported {
            warnings.push(RuntimePairCleanupWarning::DirectorySyncUnsupported {
                path: transaction_root.clone(),
            });
        }

        Ok(PublishedRuntimePair {
            acquisition_directory: acquisition_destination.to_path_buf(),
            processing_directory: processing_destination.to_path_buf(),
            cleanup_warnings: warnings,
        })
    })();

    match publication_result {
        Ok(published) => Ok(published),
        Err(primary) => match transaction.recover_after_failure() {
            Ok(RuntimePairDurability::Synced) => Err(primary),
            Ok(RuntimePairDurability::DirectorySyncUnsupported) => Err(
                RuntimePairPublicationError::PublicationRecoveredWithoutDirectorySync {
                    primary: Box::new(primary),
                    path: transaction_root,
                },
            ),
            Err(recovery) => Err(RuntimePairPublicationError::PublicationAndRecovery {
                primary: Box::new(primary),
                recovery,
            }),
        },
    }
}

fn rollback_prepared_replacement(
    transaction: &mut RuntimePairTransaction,
    replacement: PreparedRuntimeBundleReplacement,
) -> Option<RuntimeBundleReplacementError> {
    match replacement.rollback() {
        Ok(outcome) => {
            transaction.observe_directory_sync_outcome(outcome);
            None
        }
        Err(error) => Some(error),
    }
}

fn transaction_root_for_destinations(
    acquisition_destination: &Path,
    processing_destination: &Path,
) -> Option<PathBuf> {
    let acquisition_parent = acquisition_destination.parent()?;
    let processing_parent = processing_destination.parent()?;
    if acquisition_parent == processing_parent {
        return Some(acquisition_parent.to_path_buf());
    }
    let acquisition_root = acquisition_parent.parent()?;
    let processing_root = processing_parent.parent()?;
    (acquisition_root == processing_root).then(|| acquisition_root.to_path_buf())
}

fn validate_destination_pair(
    file_system: &dyn PublicationFileSystem,
    acquisition_destination: &Path,
    processing_destination: &Path,
) -> Result<(), ()> {
    if acquisition_destination == processing_destination
        || path_is_ancestor(acquisition_destination, processing_destination)
        || path_is_ancestor(processing_destination, acquisition_destination)
    {
        return Err(());
    }

    let acquisition_parent = acquisition_destination.parent().ok_or(())?;
    let processing_parent = processing_destination.parent().ok_or(())?;
    validate_parent_directory(file_system, acquisition_parent)?;
    validate_parent_directory(file_system, processing_parent)?;
    validate_existing_destination(file_system, acquisition_destination)?;
    validate_existing_destination(file_system, processing_destination)?;
    Ok(())
}

fn validate_parent_directory(
    file_system: &dyn PublicationFileSystem,
    parent: &Path,
) -> Result<(), ()> {
    let metadata = file_system.symlink_metadata(parent).map_err(|_| ())?;
    if metadata.file_type().is_symlink() || !metadata.is_dir() {
        return Err(());
    }
    Ok(())
}

fn validate_existing_destination(
    file_system: &dyn PublicationFileSystem,
    destination: &Path,
) -> Result<(), ()> {
    if !file_system.try_exists(destination).map_err(|_| ())? {
        return Ok(());
    }
    let metadata = file_system.symlink_metadata(destination).map_err(|_| ())?;
    if metadata.file_type().is_symlink() || !metadata.is_dir() {
        return Err(());
    }
    Ok(())
}

fn path_is_ancestor(ancestor: &Path, candidate: &Path) -> bool {
    if ancestor == candidate {
        return false;
    }
    candidate.starts_with(ancestor)
}

#[cfg(test)]
mod tests {
    use std::ffi::OsString;
    use std::fs;
    use std::path::Path;
    use std::sync::Arc;

    use lexicon_core::processing::{ProcessingContext, ProcessingRuntimeInformationV1, ProcessingSourceContractV1};
    use lexicon_core::protocols::http::{AcquisitionResult, HttpCapabilitySet, HttpSourceContractV1};
    use lexicon_core::runtime::{RuntimeIdentity, RuntimeInformationV1};
    use lexicon_core::HttpAcquisitionContext;

    use super::{
        RuntimePairPublicationError, publish_runtime_pair,
        publish_runtime_pair_with_file_system,
    };
    use crate::build::runtime_probe::test_fixture::{write_probe_executable, ProbeFixtureBehavior};
    use crate::build::{
        stage_verified_http_runtime_bundle, stage_verified_processing_runtime_bundle,
        verify_http_runtime_candidate, verify_processing_runtime_candidate,
    };
    use crate::fs::DirectorySyncOutcome;
    use crate::publication::{ScriptEntry, ScriptMatcher, ScriptedPublicationFileSystem};

    fn acquire(_: &mut HttpAcquisitionContext, _: &[OsString]) -> AcquisitionResult<()> { Ok(()) }
    fn process(_: &mut ProcessingContext, _: &[OsString]) -> lexicon_core::processing::ProcessingResult<()> { Ok(()) }

    fn staged_pair(root: &Path, source_name: &'static str) -> (crate::build::StagedHttpRuntimeBundle, crate::build::StagedProcessingRuntimeBundle) {
        staged_pair_generation(root, source_name, 0)
    }

    fn staged_pair_generation(
        root: &Path,
        source_name: &'static str,
        generation: u8,
    ) -> (crate::build::StagedHttpRuntimeBundle, crate::build::StagedProcessingRuntimeBundle) {
        let acquisition_identity = RuntimeIdentity::http_acquisition(source_name, 1);
        let acquisition_info = RuntimeInformationV1::from_http_source(
            acquisition_identity,
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );
        let mut acquisition_output = acquisition_info.to_json().unwrap().into_bytes();
        acquisition_output.push(b'\n');
        for _ in 0..generation {
            acquisition_output.push(b' ');
        }
        let acquisition_candidate = root.join(if cfg!(windows) { "acquisition.exe" } else { "acquisition" });
        write_probe_executable(&acquisition_candidate, &acquisition_output, ProbeFixtureBehavior::Valid);
        let acquisition_verified = verify_http_runtime_candidate(&acquisition_candidate, acquisition_identity).unwrap();
        let acquisition_name = format!(
            "{source_name}-get-raw-data{}",
            std::env::consts::EXE_SUFFIX,
        );
        let acquisition = stage_verified_http_runtime_bundle(
            root,
            &acquisition_name,
            &acquisition_verified,
        )
        .unwrap();

        let processing_identity = RuntimeIdentity::http_processing(source_name, 1);
        let processing_info = ProcessingRuntimeInformationV1::from_processing_source(
            processing_identity,
            &ProcessingSourceContractV1::new(process),
        ).unwrap();
        let mut processing_output = processing_info.to_json().unwrap().into_bytes();
        processing_output.push(b'\n');
        for _ in 0..generation {
            processing_output.push(b' ');
        }
        let processing_candidate = root.join(if cfg!(windows) { "processing.exe" } else { "processing" });
        write_probe_executable(&processing_candidate, &processing_output, ProbeFixtureBehavior::Valid);
        let processing_verified = verify_processing_runtime_candidate(&processing_candidate, processing_identity).unwrap();
        let processing_name = format!(
            "{source_name}-process-data{}",
            std::env::consts::EXE_SUFFIX,
        );
        let processing = stage_verified_processing_runtime_bundle(
            root,
            &processing_name,
            &processing_verified,
        )
        .unwrap();
        (acquisition, processing)
    }

    fn installed_executable_bytes(directory: &Path) -> Vec<u8> {
        let executables = fs::read_dir(directory)
            .unwrap()
            .map(Result::unwrap)
            .map(|entry| entry.path())
            .filter(|path| {
                path.file_name().and_then(|name| name.to_str()) != Some("runtime.json")
            })
            .collect::<Vec<_>>();
        assert_eq!(executables.len(), 1, "one installed runtime executable");
        fs::read(&executables[0]).unwrap()
    }

    fn assert_pair_recovery_artifacts_removed(root: &Path) {
        assert!(!root.join(".lexicon-runtime-pair-state.json").exists());
        assert!(!fs::read_dir(root).unwrap().map(Result::unwrap).any(|entry| {
            entry
                .file_name()
                .to_string_lossy()
                .contains(".lexicon-backup-")
        }));
    }

    #[test]
    fn publication_rejects_runtime_pair_with_different_source_identity() {
        let root = tempfile::tempdir().unwrap();
        let (acquisition, processing) = staged_pair(root.path(), "source-a");
        let error = publish_runtime_pair(
            acquisition,
            processing,
            &root.path().join("installed-acquisition"),
            &root.path().join("installed-processing"),
            RuntimeIdentity::http_acquisition("source-a", 1),
            RuntimeIdentity::http_processing("source-b", 1),
        ).unwrap_err();
        assert!(matches!(error, RuntimePairPublicationError::RuntimePairIdentityMismatch { .. }));
    }

    #[test]
    fn publication_fails_when_processing_staging_is_missing_and_cleans_up() {
        let root = tempfile::tempdir().unwrap();
        let (acquisition, processing) = staged_pair(root.path(), "source-a");
        let processing_stage = processing.directory().to_path_buf();
        fs::remove_dir_all(&processing_stage).unwrap();
        let acquisition_destination = root.path().join("installed-acquisition");
        fs::create_dir(&acquisition_destination).unwrap();
        fs::write(acquisition_destination.join("sentinel"), b"old").unwrap();
        let error = publish_runtime_pair(
            acquisition,
            processing,
            &acquisition_destination,
            &root.path().join("installed-processing"),
            RuntimeIdentity::http_acquisition("source-a", 1),
            RuntimeIdentity::http_processing("source-a", 1),
        ).unwrap_err();
        assert!(matches!(error, RuntimePairPublicationError::ProcessingStagedAdmission { .. }));
        assert_eq!(fs::read(acquisition_destination.join("sentinel")).unwrap(), b"old");
    }

    #[test]
    fn scripted_processing_replace_failure_restores_prior_acquisition_pair() {
        let root = tempfile::tempdir().unwrap();
        let acquisition_destination = root.path().join("installed-acquisition");
        let processing_destination = root.path().join("installed-processing");
        let (initial_acquisition, initial_processing) =
            staged_pair_generation(root.path(), "source-a", 1);
        publish_runtime_pair(
            initial_acquisition,
            initial_processing,
            &acquisition_destination,
            &processing_destination,
            RuntimeIdentity::http_acquisition("source-a", 1),
            RuntimeIdentity::http_processing("source-a", 1),
        )
        .unwrap();
        let original_acquisition_manifest =
            fs::read(acquisition_destination.join("runtime.json")).unwrap();
        let original_processing_manifest =
            fs::read(processing_destination.join("runtime.json")).unwrap();
        let original_acquisition_executable =
            installed_executable_bytes(&acquisition_destination);
        let original_processing_executable = installed_executable_bytes(&processing_destination);

        let scripted = Arc::new(ScriptedPublicationFileSystem::new(vec![ScriptEntry {
            matches: ScriptMatcher::FirstRenameFrom {
                from_match: processing_destination.to_string_lossy().into_owned(),
            },
            response: Err("injected processing replacement failure".to_owned()),
        }]));
        let file_system: Arc<dyn crate::publication::PublicationFileSystem> = scripted.clone();
        let (replacement_acquisition, replacement_processing) =
            staged_pair_generation(root.path(), "source-a", 2);
        let replacement_acquisition_manifest =
            fs::read(replacement_acquisition.manifest_path()).unwrap();
        let replacement_processing_manifest =
            fs::read(replacement_processing.manifest_path()).unwrap();
        let replacement_acquisition_executable =
            fs::read(replacement_acquisition.executable_path()).unwrap();
        let replacement_processing_executable =
            fs::read(replacement_processing.executable_path()).unwrap();
        assert_ne!(original_acquisition_manifest, replacement_acquisition_manifest);
        assert_ne!(original_processing_manifest, replacement_processing_manifest);
        assert_ne!(original_acquisition_executable, replacement_acquisition_executable);
        assert_ne!(original_processing_executable, replacement_processing_executable);
        let error = publish_runtime_pair_with_file_system(
            replacement_acquisition,
            replacement_processing,
            &acquisition_destination,
            &processing_destination,
            RuntimeIdentity::http_acquisition("source-a", 1).into(),
            RuntimeIdentity::http_processing("source-a", 1).into(),
            file_system,
        )
        .unwrap_err();

        assert!(matches!(error, RuntimePairPublicationError::PrepareProcessing { .. }));
        assert_eq!(
            fs::read(acquisition_destination.join("runtime.json")).unwrap(),
            original_acquisition_manifest,
        );
        assert_eq!(
            fs::read(processing_destination.join("runtime.json")).unwrap(),
            original_processing_manifest,
        );
        assert_eq!(
            installed_executable_bytes(&acquisition_destination),
            original_acquisition_executable,
        );
        assert_eq!(
            installed_executable_bytes(&processing_destination),
            original_processing_executable,
        );
        assert_pair_recovery_artifacts_removed(root.path());
        assert_eq!(scripted.remaining(), 0);
        assert!(scripted.history().iter().any(|call| {
            call.method == "rename"
                && call.from.as_deref() == Some(processing_destination.as_path())
                && call.outcome.is_err()
        }));
    }

    #[test]
    fn pair_installed_journal_failure_restores_the_complete_previous_pair() {
        let root = tempfile::tempdir().unwrap();
        let acquisition_destination = root.path().join("installed-acquisition");
        let processing_destination = root.path().join("installed-processing");
        let (initial_acquisition, initial_processing) =
            staged_pair_generation(root.path(), "source-a", 1);
        publish_runtime_pair(
            initial_acquisition,
            initial_processing,
            &acquisition_destination,
            &processing_destination,
            RuntimeIdentity::http_acquisition("source-a", 1),
            RuntimeIdentity::http_processing("source-a", 1),
        )
        .unwrap();
        let original_acquisition_manifest =
            fs::read(acquisition_destination.join("runtime.json")).unwrap();
        let original_processing_manifest =
            fs::read(processing_destination.join("runtime.json")).unwrap();
        let original_acquisition_executable =
            installed_executable_bytes(&acquisition_destination);
        let original_processing_executable =
            installed_executable_bytes(&processing_destination);

        let scripted = Arc::new(ScriptedPublicationFileSystem::new(vec![
            ScriptEntry {
                matches: ScriptMatcher::FirstMethod("replace_file"),
                response: Ok(()),
            },
            ScriptEntry {
                matches: ScriptMatcher::FirstMethod("replace_file"),
                response: Ok(()),
            },
            ScriptEntry {
                matches: ScriptMatcher::FirstMethod("replace_file"),
                response: Err("injected pair-installed journal failure".into()),
            },
        ]));
        let file_system: Arc<dyn crate::publication::PublicationFileSystem> =
            scripted.clone();
        let (replacement_acquisition, replacement_processing) =
            staged_pair_generation(root.path(), "source-a", 2);
        let error = publish_runtime_pair_with_file_system(
            replacement_acquisition,
            replacement_processing,
            &acquisition_destination,
            &processing_destination,
            RuntimeIdentity::http_acquisition("source-a", 1).into(),
            RuntimeIdentity::http_processing("source-a", 1).into(),
            file_system,
        )
        .unwrap_err();

        assert!(matches!(error, RuntimePairPublicationError::TransactionState { .. }));
        assert_eq!(
            fs::read(acquisition_destination.join("runtime.json")).unwrap(),
            original_acquisition_manifest,
        );
        assert_eq!(
            fs::read(processing_destination.join("runtime.json")).unwrap(),
            original_processing_manifest,
        );
        assert_eq!(
            installed_executable_bytes(&acquisition_destination),
            original_acquisition_executable,
        );
        assert_eq!(
            installed_executable_bytes(&processing_destination),
            original_processing_executable,
        );
        assert_pair_recovery_artifacts_removed(root.path());
        assert_eq!(scripted.remaining(), 0);
    }

    #[test]
    fn failed_publication_reports_unsupported_rollback_directory_sync() {
        let root = tempfile::tempdir().unwrap();
        let acquisition_destination = root.path().join("installed-acquisition");
        let processing_destination = root.path().join("installed-processing");
        let (initial_acquisition, initial_processing) =
            staged_pair_generation(root.path(), "source-a", 1);
        publish_runtime_pair(
            initial_acquisition,
            initial_processing,
            &acquisition_destination,
            &processing_destination,
            RuntimeIdentity::http_acquisition("source-a", 1),
            RuntimeIdentity::http_processing("source-a", 1),
        )
        .unwrap();
        let original_acquisition_manifest =
            fs::read(acquisition_destination.join("runtime.json")).unwrap();
        let original_processing_manifest =
            fs::read(processing_destination.join("runtime.json")).unwrap();

        let scripted = Arc::new(ScriptedPublicationFileSystem::new(vec![ScriptEntry {
            matches: ScriptMatcher::FirstRenameFrom {
                from_match: processing_destination.to_string_lossy().into_owned(),
            },
            response: Err("injected processing replacement failure".into()),
        }]));
        scripted.force_directory_sync_outcome_at(
            5,
            DirectorySyncOutcome::UnsupportedByPlatform,
        );
        let file_system: Arc<dyn crate::publication::PublicationFileSystem> =
            scripted.clone();
        let (replacement_acquisition, replacement_processing) =
            staged_pair_generation(root.path(), "source-a", 2);
        let error = publish_runtime_pair_with_file_system(
            replacement_acquisition,
            replacement_processing,
            &acquisition_destination,
            &processing_destination,
            RuntimeIdentity::http_acquisition("source-a", 1).into(),
            RuntimeIdentity::http_processing("source-a", 1).into(),
            file_system,
        )
        .unwrap_err();

        assert!(matches!(
            error,
            RuntimePairPublicationError::PublicationRecoveredWithoutDirectorySync {
                primary,
                ..
            } if matches!(*primary, RuntimePairPublicationError::PrepareProcessing { .. })
        ));
        assert_eq!(
            fs::read(acquisition_destination.join("runtime.json")).unwrap(),
            original_acquisition_manifest,
        );
        assert_eq!(
            fs::read(processing_destination.join("runtime.json")).unwrap(),
            original_processing_manifest,
        );
        assert_pair_recovery_artifacts_removed(root.path());
        assert_eq!(scripted.remaining(), 0);
    }

    #[test]
    fn committed_cleanup_failure_retains_recoverable_state_for_the_next_publication() {
        let root = tempfile::tempdir().unwrap();
        let acquisition_destination = root.path().join("installed-acquisition");
        let processing_destination = root.path().join("installed-processing");
        let (initial_acquisition, initial_processing) =
            staged_pair_generation(root.path(), "source-a", 1);
        publish_runtime_pair(
            initial_acquisition,
            initial_processing,
            &acquisition_destination,
            &processing_destination,
            RuntimeIdentity::http_acquisition("source-a", 1),
            RuntimeIdentity::http_processing("source-a", 1),
        )
        .unwrap();

        let scripted = Arc::new(ScriptedPublicationFileSystem::fail_once(
            "remove_dir_all",
            "injected committed-backup cleanup failure",
        ));
        let file_system: Arc<dyn crate::publication::PublicationFileSystem> = scripted;
        let (replacement_acquisition, replacement_processing) =
            staged_pair(root.path(), "source-a");
        let published = publish_runtime_pair_with_file_system(
            replacement_acquisition,
            replacement_processing,
            &acquisition_destination,
            &processing_destination,
            RuntimeIdentity::http_acquisition("source-a", 1).into(),
            RuntimeIdentity::http_processing("source-a", 1).into(),
            file_system,
        )
        .unwrap();
        assert!(published.cleanup_warnings().iter().any(|warning| matches!(
            warning,
            super::RuntimePairCleanupWarning::Acquisition { .. }
        )));
        let state = root.path().join(".lexicon-runtime-pair-state.json");
        assert!(state.is_file(), "committed state must remain until cleanup recovers");

        let (next_acquisition, next_processing) = staged_pair(root.path(), "source-a");
        publish_runtime_pair(
            next_acquisition,
            next_processing,
            &acquisition_destination,
            &processing_destination,
            RuntimeIdentity::http_acquisition("source-a", 1),
            RuntimeIdentity::http_processing("source-a", 1),
        )
        .unwrap();
        assert!(!state.exists(), "the next exclusive publisher must finish recovery");
    }

    #[test]
    fn successful_runtime_pair_publication_preserves_source_owned_state_database() {
        let root = tempfile::tempdir().unwrap();
        let (acquisition, processing) = staged_pair(root.path(), "source-a");
        let protocol_root = root.path().join("project/sources/source-a/http");
        let acquisition_operation = protocol_root.join("get-raw-data");
        let processing_operation = protocol_root.join("process-data");
        let state = acquisition_operation.join("state");
        fs::create_dir_all(&state).unwrap();
        fs::create_dir_all(&processing_operation).unwrap();
        let database = state.join("work.sqlite");
        {
            let connection = rusqlite::Connection::open(&database).unwrap();
            connection
                .execute_batch(
                    "PRAGMA journal_mode = WAL;
                     PRAGMA synchronous = FULL;
                     CREATE TABLE work_items(stable_key TEXT PRIMARY KEY, status TEXT NOT NULL);
                     INSERT INTO work_items VALUES ('item-001', 'active');",
                )
                .unwrap();
        }
        let before = fs::read(&database).unwrap();

        publish_runtime_pair(
            acquisition,
            processing,
            &acquisition_operation.join("runtime"),
            &processing_operation.join("runtime"),
            RuntimeIdentity::http_acquisition("source-a", 1),
            RuntimeIdentity::http_processing("source-a", 1),
        )
        .unwrap();

        assert_eq!(fs::read(&database).unwrap(), before);
        let connection = rusqlite::Connection::open(&database).unwrap();
        let row: (String, String) = connection
            .query_row(
                "SELECT stable_key, status FROM work_items",
                [],
                |row| Ok((row.get(0)?, row.get(1)?)),
            )
            .unwrap();
        assert_eq!(row, ("item-001".into(), "active".into()));
        assert!(state.is_dir());
    }

    #[cfg(windows)]
    #[test]
    fn windows_processing_executable_lock_release_allows_paired_publication() {
        use std::os::windows::fs::OpenOptionsExt;
        use std::thread;
        use std::time::{Duration, Instant};

        const FILE_SHARE_READ: u32 = 0x0000_0001;

        let root = tempfile::tempdir().unwrap();
        let acquisition_destination = root.path().join("installed-acquisition");
        let processing_destination = root.path().join("installed-processing");
        let (initial_acquisition, initial_processing) = staged_pair(root.path(), "source-a");
        publish_runtime_pair(
            initial_acquisition,
            initial_processing,
            &acquisition_destination,
            &processing_destination,
            RuntimeIdentity::http_acquisition("source-a", 1),
            RuntimeIdentity::http_processing("source-a", 1),
        )
        .unwrap();

        let locked_executable = fs::read_dir(&processing_destination)
            .unwrap()
            .map(Result::unwrap)
            .map(|entry| entry.path())
            .find(|path| path.extension().is_some_and(|extension| extension == "exe"))
            .expect("published processing executable");
        let lock = fs::OpenOptions::new()
            .read(true)
            .share_mode(FILE_SHARE_READ)
            .open(&locked_executable)
            .unwrap();
        let release = thread::spawn(move || {
            thread::sleep(Duration::from_millis(40));
            drop(lock);
        });

        let (replacement_acquisition, replacement_processing) =
            staged_pair(root.path(), "source-a");
        let started = Instant::now();
        publish_runtime_pair(
            replacement_acquisition,
            replacement_processing,
            &acquisition_destination,
            &processing_destination,
            RuntimeIdentity::http_acquisition("source-a", 1),
            RuntimeIdentity::http_processing("source-a", 1),
        )
        .unwrap();
        release.join().unwrap();

        assert!(started.elapsed() >= Duration::from_millis(25));
        assert!(acquisition_destination.join("runtime.json").is_file());
        assert!(processing_destination.join("runtime.json").is_file());
    }

    #[cfg(windows)]
    #[test]
    fn windows_processing_executable_lock_exhausts_retry_and_rolls_back_acquisition() {
        use std::os::windows::fs::OpenOptionsExt;
        use std::time::{Duration, Instant};

        const FILE_SHARE_READ: u32 = 0x0000_0001;

        let root = tempfile::tempdir().unwrap();
        let acquisition_destination = root.path().join("installed-acquisition");
        let processing_destination = root.path().join("installed-processing");

        let (initial_acquisition, initial_processing) = staged_pair(root.path(), "source-a");
        publish_runtime_pair(
            initial_acquisition,
            initial_processing,
            &acquisition_destination,
            &processing_destination,
            RuntimeIdentity::http_acquisition("source-a", 1),
            RuntimeIdentity::http_processing("source-a", 1),
        )
        .unwrap();

        let original_acquisition_manifest =
            fs::read(acquisition_destination.join("runtime.json")).unwrap();
        let original_processing_manifest =
            fs::read(processing_destination.join("runtime.json")).unwrap();
        let original_acquisition_executable =
            installed_executable_bytes(&acquisition_destination);
        let original_processing_executable = installed_executable_bytes(&processing_destination);
        let locked_executable = fs::read_dir(&processing_destination)
            .unwrap()
            .map(Result::unwrap)
            .map(|entry| entry.path())
            .find(|path| path.extension().is_some_and(|extension| extension == "exe"))
            .expect("published processing executable");
        let lock = fs::OpenOptions::new()
            .read(true)
            .share_mode(FILE_SHARE_READ)
            .open(&locked_executable)
            .unwrap();

        let (replacement_acquisition, replacement_processing) =
            staged_pair_generation(root.path(), "source-a", 2);
        let replacement_acquisition_manifest =
            fs::read(replacement_acquisition.manifest_path()).unwrap();
        let replacement_processing_manifest =
            fs::read(replacement_processing.manifest_path()).unwrap();
        let replacement_acquisition_executable =
            fs::read(replacement_acquisition.executable_path()).unwrap();
        let replacement_processing_executable =
            fs::read(replacement_processing.executable_path()).unwrap();
        assert_ne!(original_acquisition_manifest, replacement_acquisition_manifest);
        assert_ne!(original_processing_manifest, replacement_processing_manifest);
        assert_ne!(original_acquisition_executable, replacement_acquisition_executable);
        assert_ne!(original_processing_executable, replacement_processing_executable);
        let started = Instant::now();
        let error = publish_runtime_pair(
            replacement_acquisition,
            replacement_processing,
            &acquisition_destination,
            &processing_destination,
            RuntimeIdentity::http_acquisition("source-a", 1),
            RuntimeIdentity::http_processing("source-a", 1),
        )
        .unwrap_err();

        assert!(matches!(error, RuntimePairPublicationError::PrepareProcessing { .. }));
        assert!(started.elapsed() >= Duration::from_millis(75));
        assert_eq!(
            fs::read(acquisition_destination.join("runtime.json")).unwrap(),
            original_acquisition_manifest,
        );
        assert_eq!(
            fs::read(processing_destination.join("runtime.json")).unwrap(),
            original_processing_manifest,
        );
        assert_eq!(
            installed_executable_bytes(&acquisition_destination),
            original_acquisition_executable,
        );
        assert_eq!(
            installed_executable_bytes(&processing_destination),
            original_processing_executable,
        );
        assert_pair_recovery_artifacts_removed(root.path());
        assert!(locked_executable.is_file());
        drop(lock);
    }
}
