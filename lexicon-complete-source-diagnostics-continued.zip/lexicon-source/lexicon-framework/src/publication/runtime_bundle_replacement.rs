use std::fmt;
use std::io;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::Duration;

use lexicon_core::runtime::RuntimeIdentity;

use crate::build::runtime_staging::{
    OwnedStagedRuntimeDirectory, RuntimeBundleStagingTransferError,
};
use crate::build::{
    RuntimeBundleAdmissionError, StagedHttpRuntimeBundle, StagedProcessingRuntimeBundle,
};
use crate::fs::DirectorySyncOutcome;
use crate::publication::file_system::{
    ProductionPublicationFileSystem, PublicationFileSystem,
};

const RENAME_ATTEMPT_LIMIT: usize = 4;
const RENAME_RETRY_DELAY: Duration = Duration::from_millis(25);

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum ReplacementState {
    Prepared,
    Committed,
    RolledBack,
}

#[derive(Debug)]
pub enum RuntimeBundleReplacementError {
    DestinationParentMissing {
        path: PathBuf,
    },
    DestinationParentNotDirectory {
        path: PathBuf,
    },
    DestinationParentIsSymlink {
        path: PathBuf,
    },
    DestinationIsSymlink {
        path: PathBuf,
    },
    DestinationNotDirectory {
        path: PathBuf,
    },
    BackupPathExists {
        path: PathBuf,
    },
    InspectPath {
        path: PathBuf,
        source: io::Error,
    },
    StagingTransfer {
        source: RuntimeBundleStagingTransferError,
    },
    StagedBundleAdmission {
        source: RuntimeBundleAdmissionError,
    },
    CreateBackupPath {
        path: PathBuf,
        source: io::Error,
    },
    MoveDestinationToBackup {
        destination: PathBuf,
        backup: PathBuf,
        source: io::Error,
    },
    MoveStagedBundleToDestination {
        staged: PathBuf,
        destination: PathBuf,
        source: io::Error,
    },
    RestoreDestinationFromBackup {
        destination: PathBuf,
        backup: PathBuf,
        source: io::Error,
    },
    PrepareFailed {
        destination: PathBuf,
        backup: Option<PathBuf>,
        primary: io::Error,
        restore: Option<io::Error>,
    },
    DestinationParentSync {
        path: PathBuf,
        source: io::Error,
    },
    PostInstallSyncFailed {
        path: PathBuf,
        primary: io::Error,
        rollback: Option<Box<RuntimeBundleReplacementError>>,
    },
    RemoveBackup {
        path: PathBuf,
        source: io::Error,
    },
    RemoveDestination {
        path: PathBuf,
        source: io::Error,
    },
    RestoreBackup {
        destination: PathBuf,
        backup: PathBuf,
        source: io::Error,
    },
    InvalidTransition {
        expected: &'static str,
        actual: &'static str,
    },
}

impl fmt::Display for RuntimeBundleReplacementError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::DestinationParentMissing { path } => {
                write!(
                    formatter,
                    "destination parent '{}' does not exist",
                    path.display()
                )
            }
            Self::DestinationParentNotDirectory { path } => {
                write!(
                    formatter,
                    "destination parent '{}' is not a directory",
                    path.display()
                )
            }
            Self::DestinationParentIsSymlink { path } => {
                write!(
                    formatter,
                    "destination parent '{}' must not be a symlink",
                    path.display()
                )
            }
            Self::DestinationIsSymlink { path } => {
                write!(
                    formatter,
                    "destination bundle '{}' must not be a symlink",
                    path.display()
                )
            }
            Self::DestinationNotDirectory { path } => {
                write!(
                    formatter,
                    "destination bundle '{}' is not a directory",
                    path.display()
                )
            }
            Self::BackupPathExists { path } => {
                write!(formatter, "backup path '{}' already exists", path.display())
            }
            Self::InspectPath { path, source } => {
                write!(formatter, "failed to inspect '{}': {source}", path.display())
            }
            Self::StagingTransfer { source } => {
                write!(
                    formatter,
                    "failed to transfer staged bundle into publication ownership: {source}"
                )
            }
            Self::StagedBundleAdmission { source } => {
                write!(
                    formatter,
                    "staged bundle admission failed before publication: {source}"
                )
            }
            Self::CreateBackupPath { path, source } => {
                write!(
                    formatter,
                    "failed to construct a backup path under '{}': {source}",
                    path.display()
                )
            }
            Self::MoveDestinationToBackup {
                destination,
                backup,
                source,
            } => {
                write!(
                    formatter,
                    "failed to move existing destination '{}' to backup '{}': {source}",
                    destination.display(),
                    backup.display()
                )
            }
            Self::MoveStagedBundleToDestination {
                staged,
                destination,
                source,
            } => {
                write!(
                    formatter,
                    "failed to move staged bundle '{}' into destination '{}': {source}",
                    staged.display(),
                    destination.display()
                )
            }
            Self::RestoreDestinationFromBackup {
                destination,
                backup,
                source,
            } => {
                write!(
                    formatter,
                    "failed to restore backup '{}' back to destination '{}': {source}",
                    backup.display(),
                    destination.display()
                )
            }
            Self::PrepareFailed {
                destination,
                backup,
                primary,
                restore,
            } => {
                if let Some(backup_path) = backup {
                    write!(
                        formatter,
                        "prepare failed for destination '{}': {}. backup restoration {}.",
                        destination.display(),
                        primary,
                        match restore {
                            Some(_) => "failed",
                            None => "succeeded",
                        }
                    )?;
                    if let Some(restore_error) = restore {
                        write!(
                            formatter,
                            " Backup path: {}. Restore error: {restore_error}",
                            backup_path.display()
                        )?;
                    }
                    Ok(())
                } else {
                    write!(
                        formatter,
                        "prepare failed for destination '{}': {}",
                        destination.display(),
                        primary
                    )
                }
            }
            Self::DestinationParentSync { path, source } => {
                write!(
                    formatter,
                    "failed to synchronize destination parent '{}': {source}",
                    path.display()
                )
            }
            Self::PostInstallSyncFailed { path, primary, rollback } => {
                write!(formatter, "failed to synchronize destination parent '{}' after installing the staged bundle: {primary}", path.display())?;
                if let Some(rollback) = rollback { write!(formatter, "; rollback also failed: {rollback}")?; }
                Ok(())
            }
            Self::RemoveBackup { path, source } => {
                write!(
                    formatter,
                    "failed to remove backup '{}': {source}",
                    path.display()
                )
            }
            Self::RemoveDestination { path, source } => {
                write!(
                    formatter,
                    "failed to remove destination '{}': {source}",
                    path.display()
                )
            }
            Self::RestoreBackup {
                destination,
                backup,
                source,
            } => {
                write!(
                    formatter,
                    "failed to restore backup '{}' to destination '{}': {source}",
                    backup.display(),
                    destination.display()
                )
            }
            Self::InvalidTransition { expected, actual } => {
                write!(
                    formatter,
                    "invalid replacement transition: expected state {expected}, found {actual}"
                )
            }
        }
    }
}

impl std::error::Error for RuntimeBundleReplacementError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::StagingTransfer { source } => Some(source),
            Self::StagedBundleAdmission { source } => Some(source),
            Self::CreateBackupPath { source, .. }
            | Self::InspectPath { source, .. }
            | Self::MoveDestinationToBackup { source, .. }
            | Self::MoveStagedBundleToDestination { source, .. }
            | Self::RestoreDestinationFromBackup { source, .. }
            | Self::DestinationParentSync { source, .. }
            | Self::RemoveBackup { source, .. }
            | Self::RemoveDestination { source, .. }
            | Self::RestoreBackup { source, .. } => Some(source),
            Self::PostInstallSyncFailed { primary, .. } => Some(primary),
            Self::DestinationParentMissing { .. }
            | Self::DestinationParentNotDirectory { .. }
            | Self::DestinationParentIsSymlink { .. }
            | Self::DestinationIsSymlink { .. }
            | Self::DestinationNotDirectory { .. }
            | Self::BackupPathExists { .. }
            | Self::InvalidTransition { .. } => None,
            Self::PrepareFailed { primary, .. } => Some(primary),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub(crate) struct PublishedRuntimeBundle {
    path: PathBuf,
}

impl PublishedRuntimeBundle {
    pub(crate) fn path(&self) -> &Path {
        self.path.as_path()
    }
}

pub(crate) struct PreparedRuntimeBundleReplacement {
    destination: PathBuf,
    backup: Option<PathBuf>,
    parent: PathBuf,
    post_install_sync: DirectorySyncOutcome,
    state: ReplacementState,
    file_system: Arc<dyn PublicationFileSystem>,
}

impl fmt::Debug for PreparedRuntimeBundleReplacement {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter
            .debug_struct("PreparedRuntimeBundleReplacement")
            .field("destination", &self.destination)
            .field("backup", &self.backup)
            .field("parent", &self.parent)
            .field("post_install_sync", &self.post_install_sync)
            .field("state", &self.state)
            .finish_non_exhaustive()
    }
}

impl PreparedRuntimeBundleReplacement {
    pub(crate) fn backup_path(&self) -> Option<&Path> {
        self.backup.as_deref()
    }

    pub(crate) fn parent_path(&self) -> &Path {
        self.parent.as_path()
    }

    pub(crate) fn post_install_sync_outcome(&self) -> DirectorySyncOutcome {
        self.post_install_sync
    }

    pub(crate) fn mark_committed(&mut self) {
        self.state = ReplacementState::Committed;
    }

    pub(crate) fn cleanup_backup(
        &mut self,
    ) -> Result<DirectorySyncOutcome, RuntimeBundleReplacementError> {
        let backup = self.backup.clone();
        let parent = self.parent.clone();
        if !matches!(
            self.state,
            ReplacementState::Prepared | ReplacementState::Committed
        ) {
            let actual = match self.state {
                ReplacementState::Prepared => "Prepared",
                ReplacementState::Committed => "Committed",
                ReplacementState::RolledBack => "RolledBack",
            };
            return Err(RuntimeBundleReplacementError::InvalidTransition {
                expected: "Prepared or Committed",
                actual,
            });
        }

        if let Some(backup_path) = backup.as_ref() {
            if self.file_system.try_exists(backup_path).map_err(|source| {
                RuntimeBundleReplacementError::RemoveBackup {
                    path: backup_path.to_path_buf(),
                    source,
                }
            })? {
                self.file_system.remove_dir_all(backup_path).map_err(|source| {
                    RuntimeBundleReplacementError::RemoveBackup {
                        path: backup_path.to_path_buf(),
                        source,
                    }
                })?;
            }
        }

        let outcome = sync_parent_if_supported(self.file_system.as_ref(), &parent).map_err(|source| {
            RuntimeBundleReplacementError::DestinationParentSync {
                path: parent.clone(),
                source,
            }
        })?;

        self.state = ReplacementState::Committed;
        Ok(outcome)
    }

    pub(crate) fn commit(
        mut self,
    ) -> Result<PublishedRuntimeBundle, RuntimeBundleReplacementError> {
        self.mark_committed();
        Ok(PublishedRuntimeBundle {
            path: self.destination.clone(),
        })
    }

    pub(crate) fn rollback(
        mut self,
    ) -> Result<DirectorySyncOutcome, RuntimeBundleReplacementError> {
        let destination = self.destination.clone();
        let backup = self.backup.clone();
        let parent = self.parent.clone();
        let state = self.state;
        if !matches!(state, ReplacementState::Prepared) {
            let actual = match state {
                ReplacementState::Prepared => "Prepared",
                ReplacementState::Committed => "Committed",
                ReplacementState::RolledBack => "RolledBack",
            };
            return Err(RuntimeBundleReplacementError::InvalidTransition {
                expected: "Prepared",
                actual,
            });
        }

        let result = rollback_published_bundle(
            self.file_system.as_ref(),
            &destination,
            backup.as_deref(),
            &parent,
        );
        self.state = ReplacementState::RolledBack;
        result
    }
}

impl Drop for PreparedRuntimeBundleReplacement {
    fn drop(&mut self) {
        if !matches!(self.state, ReplacementState::Prepared) {
            return;
        }

        let destination = self.destination.clone();
        let backup = self.backup.clone();
        let parent = self.parent.clone();
        let _ = rollback_published_bundle(
            self.file_system.as_ref(),
            &destination,
            backup.as_deref(),
            &parent,
        );
        self.state = ReplacementState::RolledBack;
    }
}

pub(crate) fn prepare_runtime_bundle_replacement(
    staged: StagedHttpRuntimeBundle,
    published_bundle_path: &Path,
) -> Result<PreparedRuntimeBundleReplacement, RuntimeBundleReplacementError> {
    prepare_runtime_bundle_replacement_with_file_system(
        staged,
        published_bundle_path,
        Arc::new(ProductionPublicationFileSystem),
    )
}

pub(crate) fn prepare_runtime_bundle_replacement_with_file_system(
    staged: StagedHttpRuntimeBundle,
    published_bundle_path: &Path,
    file_system: Arc<dyn PublicationFileSystem>,
) -> Result<PreparedRuntimeBundleReplacement, RuntimeBundleReplacementError> {
    let _expected_identity = staged.manifest().runtime_information().identity();
    let staging_directory = staged
        .into_owned_staged_runtime_directory()
        .map_err(|source| RuntimeBundleReplacementError::StagingTransfer { source })?;
    prepare_runtime_bundle_replacement_for_staged_directory_with_file_system(
        staging_directory,
        published_bundle_path,
        file_system,
    )
}

pub(crate) fn prepare_processing_runtime_bundle_replacement(
    staged: StagedProcessingRuntimeBundle,
    published_bundle_path: &Path,
    expected_identity: RuntimeIdentity,
) -> Result<PreparedRuntimeBundleReplacement, RuntimeBundleReplacementError> {
    prepare_processing_runtime_bundle_replacement_with_file_system(
        staged,
        published_bundle_path,
        expected_identity,
        Arc::new(ProductionPublicationFileSystem),
    )
}

pub(crate) fn prepare_processing_runtime_bundle_replacement_with_file_system(
    staged: StagedProcessingRuntimeBundle,
    published_bundle_path: &Path,
    expected_identity: RuntimeIdentity,
    file_system: Arc<dyn PublicationFileSystem>,
) -> Result<PreparedRuntimeBundleReplacement, RuntimeBundleReplacementError> {
    let _ = expected_identity;
    let staging_directory = staged
        .into_owned_staged_runtime_directory()
        .map_err(|source| RuntimeBundleReplacementError::StagingTransfer { source })?;
    prepare_runtime_bundle_replacement_for_staged_directory_with_file_system(
        staging_directory,
        published_bundle_path,
        file_system,
    )
}

pub(crate) fn prepare_runtime_bundle_replacement_for_staged_directory(
    staged: OwnedStagedRuntimeDirectory,
    published_bundle_path: &Path,
) -> Result<PreparedRuntimeBundleReplacement, RuntimeBundleReplacementError> {
    prepare_runtime_bundle_replacement_for_staged_directory_with_file_system(
        staged,
        published_bundle_path,
        Arc::new(ProductionPublicationFileSystem),
    )
}

pub(crate) fn prepare_runtime_bundle_replacement_for_staged_directory_with_file_system(
    staged: OwnedStagedRuntimeDirectory,
    published_bundle_path: &Path,
    file_system: Arc<dyn PublicationFileSystem>,
) -> Result<PreparedRuntimeBundleReplacement, RuntimeBundleReplacementError> {
    prepare_runtime_bundle_replacement_for_staged_directory_with_optional_backup(
        staged,
        published_bundle_path,
        None,
        file_system,
    )
}

pub(crate) fn prepare_runtime_bundle_replacement_for_staged_directory_with_backup_path_and_file_system(
    staged: OwnedStagedRuntimeDirectory,
    published_bundle_path: &Path,
    backup_path: &Path,
    file_system: Arc<dyn PublicationFileSystem>,
) -> Result<PreparedRuntimeBundleReplacement, RuntimeBundleReplacementError> {
    prepare_runtime_bundle_replacement_for_staged_directory_with_optional_backup(
        staged,
        published_bundle_path,
        Some(backup_path),
        file_system,
    )
}

fn prepare_runtime_bundle_replacement_for_staged_directory_with_optional_backup(
    staged: OwnedStagedRuntimeDirectory,
    published_bundle_path: &Path,
    managed_backup_path: Option<&Path>,
    file_system: Arc<dyn PublicationFileSystem>,
) -> Result<PreparedRuntimeBundleReplacement, RuntimeBundleReplacementError> {
    let destination = published_bundle_path.to_path_buf();
    let destination_parent = published_bundle_path.parent().ok_or_else(|| {
        RuntimeBundleReplacementError::DestinationParentMissing {
            path: destination.clone(),
        }
    })?;

    let destination_parent_metadata = match file_system.symlink_metadata(destination_parent) {
        Ok(metadata) => metadata,
        Err(source) if source.kind() == io::ErrorKind::NotFound => {
            return Err(RuntimeBundleReplacementError::DestinationParentMissing {
                path: destination_parent.to_path_buf(),
            });
        }
        Err(source) => {
            return Err(RuntimeBundleReplacementError::InspectPath {
                path: destination_parent.to_path_buf(),
                source,
            });
        }
    };
    if destination_parent_metadata.file_type().is_symlink() {
        return Err(RuntimeBundleReplacementError::DestinationParentIsSymlink {
            path: destination_parent.to_path_buf(),
        });
    }
    if !destination_parent_metadata.is_dir() {
        return Err(
            RuntimeBundleReplacementError::DestinationParentNotDirectory {
                path: destination_parent.to_path_buf(),
            },
        );
    }

    let staging_directory = staged.path().to_path_buf();

    let mut backup = None;
    if file_system
        .try_exists(&destination)
        .map_err(|source| RuntimeBundleReplacementError::InspectPath {
            path: destination.clone(),
            source,
        })?
    {
        let backup_path = match managed_backup_path {
            Some(path) if path.parent() == Some(destination_parent) => path.to_path_buf(),
            Some(_) => {
                return Err(RuntimeBundleReplacementError::CreateBackupPath {
                    path: destination_parent.to_path_buf(),
                    source: io::Error::new(
                        io::ErrorKind::InvalidInput,
                        "managed backup path is outside the destination parent",
                    ),
                });
            }
            None => backup_path_for_destination(
                file_system.as_ref(),
                destination_parent,
                &destination,
            )
            .map_err(|source| RuntimeBundleReplacementError::CreateBackupPath {
                path: destination_parent.to_path_buf(),
                source,
            })?,
        };
        if file_system
            .try_exists(&backup_path)
            .map_err(|source| RuntimeBundleReplacementError::InspectPath {
                path: backup_path.clone(),
                source,
            })?
        {
            return Err(RuntimeBundleReplacementError::BackupPathExists {
                path: backup_path.clone(),
            });
        }

        let destination_metadata = file_system.symlink_metadata(&destination).map_err(|source| {
            RuntimeBundleReplacementError::MoveDestinationToBackup {
                destination: destination.clone(),
                backup: backup_path.clone(),
                source,
            }
        })?;
        if destination_metadata.file_type().is_symlink() {
            return Err(RuntimeBundleReplacementError::DestinationIsSymlink {
                path: destination.clone(),
            });
        }
        if !destination_metadata.is_dir() {
            return Err(RuntimeBundleReplacementError::DestinationNotDirectory {
                path: destination.clone(),
            });
        }

        rename_for_publication(file_system.as_ref(), &destination, &backup_path).map_err(|source| {
            RuntimeBundleReplacementError::MoveDestinationToBackup {
                destination: destination.clone(),
                backup: backup_path.clone(),
                source,
            }
        })?;
        backup = Some(backup_path);
    }

    if let Err(primary) = rename_for_publication(file_system.as_ref(), &staging_directory, &destination) {
        if let Some(backup_path) = backup.as_ref() {
            let restore = rename_for_publication(file_system.as_ref(), backup_path, &destination).err();
            let _ = file_system.remove_dir_all(&staging_directory);
            return Err(RuntimeBundleReplacementError::PrepareFailed {
                destination: destination.clone(),
                backup: Some(backup_path.clone()),
                primary,
                restore,
            });
        }

        let _ = file_system.remove_dir_all(&staging_directory);
        return Err(RuntimeBundleReplacementError::PrepareFailed {
            destination: destination.clone(),
            backup: backup.clone(),
            primary,
            restore: None,
        });
    }

    let post_install_sync = match sync_parent_if_supported(file_system.as_ref(), destination_parent) {
        Ok(outcome) => outcome,
        Err(primary) => {
            let rollback = rollback_published_bundle(
                file_system.as_ref(),
                &destination,
                backup.as_deref(),
                destination_parent,
            )
            .err()
            .map(Box::new);
            return Err(RuntimeBundleReplacementError::PostInstallSyncFailed {
                path: destination_parent.to_path_buf(),
                primary,
                rollback,
            });
        }
    };

    Ok(PreparedRuntimeBundleReplacement {
        destination,
        backup,
        parent: destination_parent.to_path_buf(),
        post_install_sync,
        state: ReplacementState::Prepared,
        file_system,
    })
}

fn backup_path_for_destination(
    file_system: &dyn PublicationFileSystem,
    parent: &Path,
    destination: &Path,
) -> Result<PathBuf, io::Error> {
    let destination_name = destination
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or("bundle");
    let now_nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_nanos();
    let mut candidate = parent.join(format!(
        ".{}.lexicon-backup-{}-{}",
        destination_name,
        std::process::id(),
        now_nanos,
    ));
    let mut index = 1;
    while file_system.try_exists(&candidate)? {
        let now_nanos = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos();
        candidate = parent.join(format!(
            ".{}.lexicon-backup-{}-{}-{}",
            destination_name,
            std::process::id(),
            now_nanos,
            index,
        ));
        index += 1;
    }
    Ok(candidate)
}

pub(crate) fn rename_for_publication(
    file_system: &dyn PublicationFileSystem,
    from: &Path,
    to: &Path,
) -> Result<(), io::Error> {
    let mut attempt = 1;
    loop {
        match file_system.rename(from, to) {
            Ok(()) => return Ok(()),
            Err(source)
                if attempt < RENAME_ATTEMPT_LIMIT
                    && is_retryable_replacement_error(&source) =>
            {
                file_system.sleep_before_retry(RENAME_RETRY_DELAY);
                attempt += 1;
            }
            Err(source) => return Err(source),
        }
    }
}

#[cfg(windows)]
fn is_retryable_replacement_error(error: &io::Error) -> bool {
    const ERROR_ACCESS_DENIED: i32 = 5;
    const ERROR_SHARING_VIOLATION: i32 = 32;
    const ERROR_LOCK_VIOLATION: i32 = 33;

    matches!(
        error.raw_os_error(),
        Some(ERROR_ACCESS_DENIED)
            | Some(ERROR_SHARING_VIOLATION)
            | Some(ERROR_LOCK_VIOLATION)
    )
}

#[cfg(not(windows))]
fn is_retryable_replacement_error(_error: &io::Error) -> bool {
    false
}

fn sync_parent_if_supported(
    file_system: &dyn PublicationFileSystem,
    path: &Path,
) -> Result<DirectorySyncOutcome, io::Error> {
    #[cfg(test)]
    if FAIL_NEXT_PARENT_SYNC.with(|flag| flag.replace(false)) {
        return Err(io::Error::new(io::ErrorKind::PermissionDenied, "injected parent sync failure"));
    }
    file_system.sync_directory(path)
}

#[cfg(test)]
std::thread_local! {
    static FAIL_NEXT_PARENT_SYNC: std::cell::Cell<bool> = const { std::cell::Cell::new(false) };
}

fn rollback_published_bundle(
    file_system: &dyn PublicationFileSystem,
    destination: &Path,
    backup: Option<&Path>,
    parent: &Path,
) -> Result<DirectorySyncOutcome, RuntimeBundleReplacementError> {
    if file_system.try_exists(destination).map_err(|source| {
        RuntimeBundleReplacementError::RemoveDestination {
            path: destination.to_path_buf(),
            source,
        }
    })? {
        file_system.remove_dir_all(destination).map_err(|source| {
            RuntimeBundleReplacementError::RemoveDestination {
                path: destination.to_path_buf(),
                source,
            }
        })?;
    }
    if let Some(backup_path) = backup {
        rename_for_publication(file_system, backup_path, destination).map_err(|source| {
            RuntimeBundleReplacementError::RestoreBackup {
                destination: destination.to_path_buf(),
                backup: backup_path.to_path_buf(),
                source,
            }
        })?;
    }
    sync_parent_if_supported(file_system, parent).map_err(|source| {
        RuntimeBundleReplacementError::DestinationParentSync {
            path: parent.to_path_buf(),
            source,
        }
    })
}

#[cfg(test)]
mod tests {
    use std::fs;

    use super::{
        prepare_runtime_bundle_replacement_for_staged_directory,
        RuntimeBundleReplacementError, FAIL_NEXT_PARENT_SYNC,
    };
    use crate::build::runtime_staging::OwnedStagedRuntimeDirectory;

    #[test]
    fn post_install_parent_sync_failure_restores_previous_destination() {
        let root = tempfile::tempdir().unwrap();
        let destination = root.path().join("runtime");
        fs::create_dir(&destination).unwrap();
        fs::write(destination.join("sentinel"), b"old").unwrap();
        let staged = root.path().join("staged");
        fs::create_dir(&staged).unwrap();
        fs::write(staged.join("sentinel"), b"new").unwrap();

        FAIL_NEXT_PARENT_SYNC.with(|flag| flag.set(true));
        let error = prepare_runtime_bundle_replacement_for_staged_directory(
            OwnedStagedRuntimeDirectory::from_test_path(staged),
            &destination,
        ).unwrap_err();

        assert!(matches!(error, RuntimeBundleReplacementError::PostInstallSyncFailed { rollback: None, .. }));
        assert_eq!(fs::read(destination.join("sentinel")).unwrap(), b"old");
    }
}
