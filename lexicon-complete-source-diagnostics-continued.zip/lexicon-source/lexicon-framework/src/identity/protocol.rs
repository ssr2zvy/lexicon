//! Canonical identity for protocols managed by Lexicon.
//!
//! The public command grammar currently admits exactly one protocol token:
//! `http`. Parsing is deliberately byte-exact. In particular, this module does
//! not trim whitespace or perform Unicode/ASCII case folding before deciding
//! whether a token is supported.

use std::error::Error;
use std::fmt;
use std::str::FromStr;

/// The one protocol identifier supported by the current contract.
pub const HTTP_PROTOCOL_IDENTIFIER: &str = "http";

/// A protocol admitted at a Lexicon command, configuration, or discovery
/// boundary.
///
/// Keeping this as a closed enum prevents downstream code from carrying an
/// unchecked `String` into source paths, manifests, build plans, or runtime
/// identities.
#[derive(Clone, Copy, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub enum ManagedProtocol {
    Http,
}

impl ManagedProtocol {
    /// All protocols supported by this contract version, in stable identifier
    /// order.
    pub const ALL: &'static [Self] = &[Self::Http];

    /// Parses a protocol token without trimming or case folding.
    pub fn parse(value: &str) -> Result<Self, ProtocolArgumentError> {
        match value {
            HTTP_PROTOCOL_IDENTIFIER => Ok(Self::Http),
            _ => Err(ProtocolArgumentError::new(value.to_owned())),
        }
    }

    /// Parses the explicit public `--protocol` value.
    ///
    /// This named entry point makes it clear at CLI call sites that validation
    /// must happen before any filesystem mutation or framework dispatch.
    pub fn parse_cli(value: &str) -> Result<Self, ProtocolArgumentError> {
        Self::parse(value)
    }

    /// Returns the canonical token used in paths, manifests, and runtime
    /// identity documents.
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Http => HTTP_PROTOCOL_IDENTIFIER,
        }
    }
}

impl FromStr for ManagedProtocol {
    type Err = ProtocolArgumentError;

    fn from_str(value: &str) -> Result<Self, Self::Err> {
        Self::parse(value)
    }
}

impl TryFrom<&str> for ManagedProtocol {
    type Error = ProtocolArgumentError;

    fn try_from(value: &str) -> Result<Self, Self::Error> {
        Self::parse(value)
    }
}

impl AsRef<str> for ManagedProtocol {
    fn as_ref(&self) -> &str {
        self.as_str()
    }
}

impl fmt::Display for ManagedProtocol {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(self.as_str())
    }
}

/// Failure to admit a protocol token at an external boundary.
///
/// The rejected value is retained verbatim so typed CLI/configuration errors
/// do not erase their cause.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct ProtocolArgumentError {
    rejected: String,
}

impl ProtocolArgumentError {
    fn new(rejected: String) -> Self {
        Self { rejected }
    }

    /// Returns the exact rejected UTF-8 token. No normalization has been
    /// applied to this value.
    pub fn rejected(&self) -> &str {
        &self.rejected
    }

    /// Consumes the error and returns the exact rejected token.
    pub fn into_rejected(self) -> String {
        self.rejected
    }
}

impl fmt::Display for ProtocolArgumentError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            formatter,
            "unsupported protocol {:?}; expected byte-exact {:?}",
            self.rejected, HTTP_PROTOCOL_IDENTIFIER
        )
    }
}

impl Error for ProtocolArgumentError {}

#[cfg(test)]
mod tests {
    use super::{HTTP_PROTOCOL_IDENTIFIER, ManagedProtocol, ProtocolArgumentError};

    #[test]
    fn byte_exact_http_is_the_only_accepted_token() {
        assert_eq!(
            ManagedProtocol::parse(HTTP_PROTOCOL_IDENTIFIER),
            Ok(ManagedProtocol::Http)
        );

        for rejected in [
            "",
            "HTTP",
            "Http",
            "hTtP",
            " http",
            "http ",
            "\thttp",
            "http\n",
            "https",
            "http\0",
        ] {
            assert_eq!(
                ManagedProtocol::parse(rejected),
                Err(ProtocolArgumentError {
                    rejected: rejected.to_owned(),
                }),
                "{rejected:?} must not be normalized into a supported token"
            );
        }
    }

    #[test]
    fn every_parser_uses_the_same_closed_grammar() {
        assert_eq!(
            ManagedProtocol::parse_cli("http"),
            Ok(ManagedProtocol::Http)
        );
        assert_eq!("http".parse(), Ok(ManagedProtocol::Http));
        assert_eq!(ManagedProtocol::try_from("http"), Ok(ManagedProtocol::Http));

        assert!(ManagedProtocol::parse_cli(" HTTP ").is_err());
        assert!("HTTP".parse::<ManagedProtocol>().is_err());
        assert!(ManagedProtocol::try_from("http ").is_err());
    }

    #[test]
    fn rejected_value_is_preserved_verbatim() {
        let rejected = "\tHTTP ";
        let error = ManagedProtocol::parse(rejected).unwrap_err();

        assert_eq!(error.rejected(), rejected);
        assert!(error.to_string().contains("\\tHTTP "));
        assert_eq!(error.into_rejected(), rejected);
    }

    #[test]
    fn canonical_rendering_is_stable() {
        assert_eq!(ManagedProtocol::ALL, &[ManagedProtocol::Http]);
        assert_eq!(ManagedProtocol::Http.as_str(), "http");
        assert_eq!(ManagedProtocol::Http.as_ref(), "http");
        assert_eq!(ManagedProtocol::Http.to_string(), "http");
    }

    #[test]
    fn protocol_value_is_copy() {
        fn assert_copy<T: Copy>() {}
        assert_copy::<ManagedProtocol>();
    }
}
