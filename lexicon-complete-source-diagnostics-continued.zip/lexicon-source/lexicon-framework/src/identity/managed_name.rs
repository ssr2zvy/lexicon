pub use lexicon_core::identity::{
    MAX_MANAGED_NAME_BYTES, ManagedName, ManagedNameError, RESERVED_NAMES,
};
