//! NAME-01 typed identity rules.

pub mod managed_name;
mod protocol;

pub use managed_name::{
    ManagedName, ManagedNameError, MAX_MANAGED_NAME_BYTES, RESERVED_NAMES,
};
pub use protocol::{ManagedProtocol, ProtocolArgumentError};
