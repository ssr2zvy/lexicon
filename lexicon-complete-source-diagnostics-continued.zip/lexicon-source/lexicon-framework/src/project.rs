use std::ffi::OsStr;
use std::fmt;
use std::fs;
use std::path::{Component, Path, PathBuf};

use serde::Deserialize;

use crate::identity::{ManagedName, ManagedNameError, ManagedProtocol};

pub const PROJECT_MANIFEST_SCHEMA_VERSION: u32 = 1;

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Project {
    root: PathBuf,
    name: ManagedName,
    sources_relative: PathBuf,
    sources_root: PathBuf,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct SourceLocation {
    project: Project,
    source: ManagedName,
    protocol: ManagedProtocol,
    source_root: PathBuf,
    protocol_root: PathBuf,
}

#[derive(Debug)]
pub enum ProjectError {
    StartMetadata { path: PathBuf, source: std::io::Error },
    StartIsNotDirectory(PathBuf),
    SymlinkNotPermitted(PathBuf),
    ManifestNotRegularFile(PathBuf),
    ManifestRead { path: PathBuf, source: std::io::Error },
    ManifestDecode { path: PathBuf, source: toml::de::Error },
    UnsupportedSchemaVersion { path: PathBuf, actual: u32 },
    InvalidProjectName { path: PathBuf, source: ManagedNameError },
    MissingPathsSection(PathBuf),
    InvalidSourcesDirectory { path: PathBuf, reason: &'static str },
    NonNormalDiscoveryPath(PathBuf),
    ManagedPathMetadata { path: PathBuf, source: std::io::Error },
    ManagedPathNotDirectory(PathBuf),
    ProjectNotFound { start: PathBuf, nearest_invalid: Option<Box<ProjectError>> },
    InvalidSourceName(ManagedNameError),
    SourceNotFound(PathBuf),
    ProtocolNotFound(PathBuf),
    ManagedFileNotRegular(PathBuf),
}

impl fmt::Display for ProjectError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::StartMetadata { path, source } => {
                write!(formatter, "failed to inspect discovery start '{}': {source}", path.display())
            }
            Self::StartIsNotDirectory(path) => {
                write!(formatter, "project discovery start '{}' is not a directory", path.display())
            }
            Self::SymlinkNotPermitted(path) => {
                write!(formatter, "managed path '{}' must not be a symbolic link", path.display())
            }
            Self::ManifestNotRegularFile(path) => {
                write!(formatter, "project manifest '{}' is not a regular file", path.display())
            }
            Self::ManifestRead { path, source } => {
                write!(formatter, "failed to read project manifest '{}': {source}", path.display())
            }
            Self::ManifestDecode { path, source } => {
                write!(formatter, "failed to decode project manifest '{}': {source}", path.display())
            }
            Self::UnsupportedSchemaVersion { path, actual } => write!(
                formatter,
                "project manifest '{}' has schema_version {actual}; expected {PROJECT_MANIFEST_SCHEMA_VERSION}",
                path.display()
            ),
            Self::InvalidProjectName { path, source } => {
                write!(formatter, "project manifest '{}' has an invalid project.name: {source}", path.display())
            }
            Self::MissingPathsSection(path) => write!(
                formatter,
                "project manifest '{}' is missing required [paths].sources_directory",
                path.display()
            ),
            Self::InvalidSourcesDirectory { path, reason } => write!(
                formatter,
                "project manifest '{}' has an invalid [paths].sources_directory: {reason}",
                path.display()
            ),
            Self::NonNormalDiscoveryPath(path) => write!(
                formatter,
                "project discovery path '{}' contains a non-normal component",
                path.display()
            ),
            Self::ManagedPathMetadata { path, source } => {
                write!(formatter, "failed to inspect managed path '{}': {source}", path.display())
            }
            Self::ManagedPathNotDirectory(path) => {
                write!(formatter, "managed path '{}' is not a directory", path.display())
            }
            Self::ProjectNotFound { start, nearest_invalid: Some(error) } => write!(
                formatter,
                "no valid Lexicon project was found at or above '{}'; nearest manifest was invalid: {error}",
                start.display()
            ),
            Self::ProjectNotFound { start, nearest_invalid: None } => write!(
                formatter,
                "no valid Lexicon project was found at or above '{}'",
                start.display()
            ),
            Self::InvalidSourceName(source) => write!(formatter, "invalid source name: {source}"),
            Self::SourceNotFound(path) => {
                write!(formatter, "source directory '{}' does not exist", path.display())
            }
            Self::ProtocolNotFound(path) => {
                write!(formatter, "protocol directory '{}' does not exist", path.display())
            }
            Self::ManagedFileNotRegular(path) => {
                write!(formatter, "managed file '{}' is not a regular file", path.display())
            }
        }
    }
}

impl std::error::Error for ProjectError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::StartMetadata { source, .. }
            | Self::ManifestRead { source, .. }
            | Self::ManagedPathMetadata { source, .. } => Some(source),
            Self::ManifestDecode { source, .. } => Some(source),
            Self::InvalidProjectName { source, .. } | Self::InvalidSourceName(source) => Some(source),
            Self::ProjectNotFound { nearest_invalid: Some(source), .. } => Some(source),
            _ => None,
        }
    }
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct ProjectDocumentV1 {
    schema_version: u32,
    project: ProjectSectionV1,
    paths: Option<PathsSectionV1>,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct ProjectSectionV1 {
    name: String,
}

#[derive(Debug, Deserialize)]
#[serde(deny_unknown_fields)]
struct PathsSectionV1 {
    sources_directory: String,
}

impl Project {
    pub fn discover_from(start: &Path) -> Result<Self, ProjectError> {
        let start = admit_absolute_real_directory(start)?;
        let mut nearest_invalid = None;

        for candidate in start.ancestors() {
            let marker = candidate.join("lexicon.toml");
            let metadata = match fs::symlink_metadata(&marker) {
                Ok(metadata) => metadata,
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => continue,
                Err(source) => {
                    let error = ProjectError::ManifestRead {
                        path: marker,
                        source,
                    };
                    if nearest_invalid.is_none() {
                        nearest_invalid = Some(Box::new(error));
                    }
                    continue;
                }
            };

            if metadata.file_type().is_symlink() {
                if nearest_invalid.is_none() {
                    nearest_invalid = Some(Box::new(ProjectError::SymlinkNotPermitted(marker)));
                }
                continue;
            }
            if !metadata.is_file() {
                if nearest_invalid.is_none() {
                    nearest_invalid = Some(Box::new(ProjectError::ManifestNotRegularFile(marker)));
                }
                continue;
            }

            match Self::load(candidate) {
                Ok(project) => return Ok(project),
                Err(error) => {
                    if nearest_invalid.is_none() {
                        nearest_invalid = Some(Box::new(error));
                    }
                }
            }
        }

        Err(ProjectError::ProjectNotFound {
            start,
            nearest_invalid,
        })
    }

    pub fn load(root: &Path) -> Result<Self, ProjectError> {
        let root = admit_absolute_real_directory(root)?;
        let manifest_path = root.join("lexicon.toml");
        let metadata = fs::symlink_metadata(&manifest_path).map_err(|source| {
            ProjectError::ManifestRead {
                path: manifest_path.clone(),
                source,
            }
        })?;
        if metadata.file_type().is_symlink() {
            return Err(ProjectError::SymlinkNotPermitted(manifest_path));
        }
        if !metadata.is_file() {
            return Err(ProjectError::ManifestNotRegularFile(manifest_path));
        }
        let contents = fs::read_to_string(&manifest_path).map_err(|source| {
            ProjectError::ManifestRead {
                path: manifest_path.clone(),
                source,
            }
        })?;
        let document: ProjectDocumentV1 = toml::from_str(&contents).map_err(|source| {
            ProjectError::ManifestDecode {
                path: manifest_path.clone(),
                source,
            }
        })?;
        if document.schema_version != PROJECT_MANIFEST_SCHEMA_VERSION {
            return Err(ProjectError::UnsupportedSchemaVersion {
                path: manifest_path,
                actual: document.schema_version,
            });
        }
        let name = ManagedName::parse(&document.project.name).map_err(|source| {
            ProjectError::InvalidProjectName {
                path: manifest_path.clone(),
                source,
            }
        })?;
        let paths = document
            .paths
            .ok_or_else(|| ProjectError::MissingPathsSection(manifest_path.clone()))?;
        let sources_relative = validate_sources_relative(&manifest_path, &paths.sources_directory)?;
        let sources_root = root.join(&sources_relative);
        validate_managed_descendant(&root, &sources_relative, false)?;

        Ok(Self {
            root,
            name,
            sources_relative,
            sources_root,
        })
    }

    pub fn root(&self) -> &Path {
        &self.root
    }

    pub fn name(&self) -> &ManagedName {
        &self.name
    }

    pub fn sources_relative(&self) -> &Path {
        &self.sources_relative
    }

    pub fn sources_root(&self) -> &Path {
        &self.sources_root
    }

    pub fn source(
        &self,
        source: ManagedName,
        protocol: ManagedProtocol,
    ) -> Result<SourceLocation, ProjectError> {
        let source_relative = self.sources_relative.join(source.as_str());
        validate_managed_descendant(&self.root, &source_relative, true)
            .map_err(|error| match error {
                ProjectError::ManagedPathMetadata { path, source: error }
                    if error.kind() == std::io::ErrorKind::NotFound =>
                {
                    ProjectError::SourceNotFound(path)
                }
                other => other,
            })?;
        let source_root = self.sources_root.join(source.as_str());
        let protocol_relative = source_relative.join(protocol.as_str());
        validate_managed_descendant(&self.root, &protocol_relative, true)
            .map_err(|error| match error {
                ProjectError::ManagedPathMetadata { path, source: error }
                    if error.kind() == std::io::ErrorKind::NotFound =>
                {
                    ProjectError::ProtocolNotFound(path)
                }
                other => other,
            })?;
        let protocol_root = source_root.join(protocol.as_str());
        Ok(SourceLocation {
            project: self.clone(),
            source,
            protocol,
            source_root,
            protocol_root,
        })
    }

    pub fn source_destination(
        &self,
        source: ManagedName,
        protocol: ManagedProtocol,
    ) -> Result<SourceLocation, ProjectError> {
        validate_managed_descendant(&self.root, &self.sources_relative, false)?;
        let source_root = self.sources_root.join(source.as_str());
        let source_relative = self.sources_relative.join(source.as_str());
        validate_managed_descendant(&self.root, &source_relative, false)?;
        let protocol_root = source_root.join(protocol.as_str());
        Ok(SourceLocation {
            project: self.clone(),
            source,
            protocol,
            source_root,
            protocol_root,
        })
    }
}

impl SourceLocation {
    pub fn project(&self) -> &Project {
        &self.project
    }

    pub fn source(&self) -> &ManagedName {
        &self.source
    }

    pub fn protocol(&self) -> ManagedProtocol {
        self.protocol
    }

    pub fn source_root(&self) -> &Path {
        &self.source_root
    }

    pub fn protocol_root(&self) -> &Path {
        &self.protocol_root
    }

    pub fn require_directory(&self, relative: &Path) -> Result<PathBuf, ProjectError> {
        validate_relative_shape(relative)?;
        let mut current = self.protocol_root.clone();
        for component in relative.components() {
            let Component::Normal(segment) = component else {
                unreachable!("validated above")
            };
            current.push(segment);
            let metadata = fs::symlink_metadata(&current).map_err(|source| {
                ProjectError::ManagedPathMetadata {
                    path: current.clone(),
                    source,
                }
            })?;
            if metadata.file_type().is_symlink() {
                return Err(ProjectError::SymlinkNotPermitted(current));
            }
            if !metadata.is_dir() {
                return Err(ProjectError::ManagedPathNotDirectory(current));
            }
        }
        Ok(current)
    }

    pub fn require_regular_file(&self, relative: &Path) -> Result<PathBuf, ProjectError> {
        validate_relative_shape(relative)?;
        let parent = relative.parent().unwrap_or_else(|| Path::new(""));
        let parent_path = if parent.as_os_str().is_empty() {
            self.protocol_root.clone()
        } else {
            self.require_directory(parent)?
        };
        let file_name = relative.file_name().ok_or_else(|| {
            ProjectError::ManagedFileNotRegular(self.protocol_root.join(relative))
        })?;
        let path = parent_path.join(file_name);
        let metadata = fs::symlink_metadata(&path).map_err(|source| {
            ProjectError::ManagedPathMetadata {
                path: path.clone(),
                source,
            }
        })?;
        if metadata.file_type().is_symlink() {
            return Err(ProjectError::SymlinkNotPermitted(path));
        }
        if !metadata.is_file() {
            return Err(ProjectError::ManagedFileNotRegular(path));
        }
        Ok(path)
    }
}

pub fn managed_name_from_os(value: &OsStr) -> Result<ManagedName, ManagedNameError> {
    ManagedName::parse_os(value)
}

fn admit_absolute_real_directory(path: &Path) -> Result<PathBuf, ProjectError> {
    if path.components().any(|component| {
        matches!(component, Component::CurDir | Component::ParentDir)
    }) {
        return Err(ProjectError::NonNormalDiscoveryPath(path.to_path_buf()));
    }
    let absolute = if path.is_absolute() {
        path.to_path_buf()
    } else {
        let cwd = std::env::current_dir().map_err(|source| ProjectError::StartMetadata {
            path: path.to_path_buf(),
            source,
        })?;
        cwd.join(path)
    };
    let mut admitted = PathBuf::new();
    for component in absolute.components() {
        match component {
            Component::Prefix(prefix) => admitted.push(prefix.as_os_str()),
            Component::RootDir => admitted.push(component.as_os_str()),
            Component::Normal(segment) => {
                admitted.push(segment);
                let metadata = fs::symlink_metadata(&admitted).map_err(|source| {
                    ProjectError::StartMetadata {
                        path: admitted.clone(),
                        source,
                    }
                })?;
                if metadata.file_type().is_symlink() {
                    return Err(ProjectError::SymlinkNotPermitted(admitted));
                }
                if !metadata.is_dir() {
                    return Err(ProjectError::StartIsNotDirectory(admitted));
                }
            }
            Component::CurDir | Component::ParentDir => {
                return Err(ProjectError::NonNormalDiscoveryPath(absolute));
            }
        }
    }
    Ok(admitted)
}

fn validate_sources_relative(manifest: &Path, value: &str) -> Result<PathBuf, ProjectError> {
    if value.is_empty() || value.contains('\\') {
        return Err(ProjectError::InvalidSourcesDirectory {
            path: manifest.to_path_buf(),
            reason: "the value must be a non-empty portable relative path",
        });
    }
    let path = Path::new(value);
    if path.is_absolute() {
        return Err(ProjectError::InvalidSourcesDirectory {
            path: manifest.to_path_buf(),
            reason: "absolute paths are prohibited",
        });
    }
    let mut normalized = PathBuf::new();
    for component in path.components() {
        match component {
            Component::Normal(segment) => {
                ManagedName::parse_os(segment).map_err(|_| ProjectError::InvalidSourcesDirectory {
                    path: manifest.to_path_buf(),
                    reason: "every component must use the managed-name grammar",
                })?;
                normalized.push(segment);
            }
            Component::Prefix(_) | Component::RootDir | Component::CurDir | Component::ParentDir => {
                return Err(ProjectError::InvalidSourcesDirectory {
                    path: manifest.to_path_buf(),
                    reason: "only normal relative path components are permitted",
                });
            }
        }
    }
    if normalized.as_os_str().is_empty() {
        return Err(ProjectError::InvalidSourcesDirectory {
            path: manifest.to_path_buf(),
            reason: "the value must not be empty",
        });
    }
    Ok(normalized)
}

fn validate_relative_shape(relative: &Path) -> Result<(), ProjectError> {
    if relative.as_os_str().is_empty()
        || relative.is_absolute()
        || relative.components().any(|component| !matches!(component, Component::Normal(_)))
    {
        return Err(ProjectError::InvalidSourcesDirectory {
            path: relative.to_path_buf(),
            reason: "managed descendants require a non-empty relative path of normal components",
        });
    }
    Ok(())
}

fn validate_managed_descendant(
    root: &Path,
    relative: &Path,
    require_final: bool,
) -> Result<(), ProjectError> {
    debug_assert!(relative.is_relative());
    let mut current = root.to_path_buf();
    let component_count = relative.components().count();
    for (index, component) in relative.components().enumerate() {
        let Component::Normal(segment) = component else {
            return Err(ProjectError::InvalidSourcesDirectory {
                path: root.join(relative),
                reason: "managed descendants must contain only normal components",
            });
        };
        current.push(segment);
        match fs::symlink_metadata(&current) {
            Ok(metadata) => {
                if metadata.file_type().is_symlink() {
                    return Err(ProjectError::SymlinkNotPermitted(current));
                }
                if !metadata.is_dir() {
                    return Err(ProjectError::ManagedPathNotDirectory(current));
                }
            }
            Err(error) if error.kind() == std::io::ErrorKind::NotFound && !require_final => {
                return Ok();
            }
            Err(source) => {
                return Err(ProjectError::ManagedPathMetadata {
                    path: current,
                    source,
                });
            }
        }
        if index + 1 == component_count {
            break;
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn write_project(root: &Path, name: &str, sources: &str) {
        fs::write(
            root.join("lexicon.toml"),
            format!(
                "schema_version = 1\n[project]\nname = {name:?}\n[paths]\nsources_directory = {sources:?}\n"
            ),
        )
        .unwrap();
    }

    #[test]
    fn nearest_valid_ancestor_wins_without_descendant_search() {
        let temp = tempfile::tempdir().unwrap();
        let outer = temp.path().join("outer");
        let inner = outer.join("nested");
        let child = inner.join("work");
        fs::create_dir_all(outer.join("sources")).unwrap();
        fs::create_dir_all(inner.join("sources")).unwrap();
        fs::create_dir_all(&child).unwrap();
        write_project(&outer, "outer-project", "sources");
        write_project(&inner, "inner-project", "sources");

        let project = Project::discover_from(&child).unwrap();
        assert_eq!(project.root(), inner);
        assert_eq!(project.name().as_str(), "inner-project");

        let unrelated = temp.path().join("unrelated");
        fs::create_dir(&unrelated).unwrap();
        assert!(matches!(
            Project::discover_from(&unrelated),
            Err(ProjectError::ProjectNotFound { .. })
        ));
    }

    #[test]
    fn invalid_nearer_manifest_does_not_hide_valid_ancestor() {
        let temp = tempfile::tempdir().unwrap();
        let outer = temp.path().join("outer");
        let child = outer.join("child");
        fs::create_dir_all(outer.join("sources")).unwrap();
        fs::create_dir_all(&child).unwrap();
        write_project(&outer, "outer-project", "sources");
        fs::write(child.join("lexicon.toml"), "not toml = [").unwrap();

        assert_eq!(Project::discover_from(&child).unwrap().root(), outer);
    }

    #[test]
    fn project_manifest_requires_paths_section() {
        let temp = tempfile::tempdir().unwrap();
        fs::write(
            temp.path().join("lexicon.toml"),
            "schema_version = 1\n[project]\nname = \"demo\"\n",
        )
        .unwrap();
        assert!(matches!(
            Project::load(temp.path()),
            Err(ProjectError::MissingPathsSection(_))
        ));
    }

    #[test]
    fn non_normal_sources_paths_are_rejected() {
        for value in ["", ".", "../sources", "/tmp/sources", "sources/../other", "C:\\sources"] {
            let temp = tempfile::tempdir().unwrap();
            write_project(temp.path(), "demo", value);
            assert!(Project::load(temp.path()).is_err(), "accepted {value:?}");
        }
    }

    #[test]
    fn non_normal_discovery_start_is_rejected_before_ancestor_search() {
        let temp = tempfile::tempdir().unwrap();
        let project = temp.path().join("project");
        let child = project.join("child");
        fs::create_dir_all(&child).unwrap();
        write_project(&project, "demo-project", "sources");

        let start = child.join("..").join("child");
        assert!(matches!(
            Project::discover_from(&start),
            Err(ProjectError::NonNormalDiscoveryPath(path)) if path == start
        ));
    }

    #[cfg(unix)]
    #[test]
    fn symlinked_discovery_ancestor_is_rejected() {
        let temp = tempfile::tempdir().unwrap();
        let real = temp.path().join("real-project");
        let child = real.join("child");
        fs::create_dir_all(&child).unwrap();
        write_project(&real, "real-project", "sources");
        let linked = temp.path().join("linked-project");
        std::os::unix::fs::symlink(&real, &linked).unwrap();

        assert!(matches!(
            Project::discover_from(&linked.join("child")),
            Err(ProjectError::SymlinkNotPermitted(path)) if path == linked
        ));
    }

    #[cfg(unix)]
    #[test]
    fn non_utf8_source_entry_is_rejected_without_lossy_conversion() {
        use std::os::unix::ffi::OsStringExt;
        let invalid = std::ffi::OsString::from_vec(vec![b's', 0xff]);
        assert_eq!(ManagedName::parse_os(&invalid), Err(ManagedNameError::NonUnicode));
    }
}
