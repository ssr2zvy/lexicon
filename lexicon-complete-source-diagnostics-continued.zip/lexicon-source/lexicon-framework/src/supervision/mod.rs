//! Internal operator-host invocation protocol.
//!
//! This is a small, versioned, internal protocol used only to re-execute the
//! current `lexicon` binary in the reserved `__operator-host` role for
//! background execution (contract.md section 3, "Background execution").
//! It is not a public framework API and must not be treated as a stable
//! external interface.
//!
//! It is deliberately distinct from `RuntimeInvocationEnvelopeV1` (the
//! source-runtime invocation contract), the session record schema, and the
//! source contract version, per the distinct-compatibility-surfaces
//! requirement in contract.md / specs.md section 16.
//!
//! Raw source arguments are never included in this reference. They continue
//! to travel only as the operator-host process's own trailing argv after
//! `--`, exactly as the ordinary `lexicon data ... -- <source-args>` path
//! already works. Everything else needed to relocate the exact session an
//! initiating process already prepared is either carried here or is
//! independently re-derivable by the operator host (for example, the project
//! is re-discovered from the operator host's own working directory, exactly
//! as the initiating process originally discovered it).

use std::fmt;

use lexicon_core::session::{HandoffToken, SessionIdentity};

use crate::data::request::DataOperation;

/// Schema version for the operator-host invocation reference.
///
/// Distinct from `RUNTIME_INVOCATION_PROTOCOL_VERSION`, the session schema
/// version, and the source contract version.
pub const OPERATOR_HOST_INVOCATION_SCHEMA_VERSION: u32 = 1;

/// Environment variable used only to carry the single-use handoff capability
/// across the private operator-host re-exec boundary.
///
/// The variable is removed by the operator host immediately after it is read
/// and is explicitly stripped from every source-runtime environment.
pub const OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE: &str =
    "LEXICON_OPERATOR_HOST_HANDOFF_TOKEN_V1";

/// Takes the private capability from the operator-host environment.
///
/// Removal happens before Unicode and capability validation so malformed
/// input cannot remain available to subsequently launched source processes.
pub fn take_operator_host_handoff_token()
    -> Result<HandoffToken, OperatorHostInvocationDecodingError>
{
    let encoded = std::env::var_os(OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE);
    // SAFETY: the hidden operator-host entrypoint calls this during
    // single-threaded CLI dispatch, before it starts any worker threads.
    unsafe {
        std::env::remove_var(OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE);
    }
    let encoded = encoded.ok_or_else(|| OperatorHostInvocationDecodingError::InvalidField(
        format!("missing private {OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE} capability"),
    ))?;
    let mut encoded = encoded.into_string().map_err(|_| {
        OperatorHostInvocationDecodingError::InvalidField(
            "operator-host handoff capability is not valid Unicode".into(),
        )
    })?;
    let decoded = HandoffToken::from_hex(&encoded).map_err(|error| {
        OperatorHostInvocationDecodingError::InvalidField(format!(
            "invalid operator-host handoff capability: {error}"
        ))
    });
    // SAFETY: replacing every byte with NUL preserves UTF-8 validity and the
    // string is not observed again before it is dropped.
    unsafe {
        encoded.as_bytes_mut().fill(0);
    }
    decoded
}

/// A reference the operator host uses to relocate the exact session an
/// initiating process already prepared with `RuntimeSupervisionMode::Background`.
///
/// This non-secret reference is transported as the operator-host process's
/// own argv (via [`OperatorHostInvocationV1::to_json`] encoded into a single
/// argument). The handoff capability is deliberately not part of this type or
/// its JSON representation; it travels through the dedicated private
/// environment variable above.
#[derive(PartialEq, Eq)]
pub struct OperatorHostInvocationV1 {
    source_name: String,
    protocol: String,
    operation: DataOperation,
    session: SessionIdentity,
    handoff_epoch: u64,
    operator_instance_nonce: String,
}

impl fmt::Debug for OperatorHostInvocationV1 {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.debug_struct("OperatorHostInvocationV1")
            .field("source_name", &self.source_name)
            .field("protocol", &self.protocol)
            .field("operation", &self.operation)
            .field("session", &self.session)
            .field("handoff_epoch", &self.handoff_epoch)
            .field("operator_instance_nonce", &self.operator_instance_nonce)
            .finish()
    }
}

impl OperatorHostInvocationV1 {
    pub fn new_reserved(
        source_name: impl Into<String>, protocol: impl Into<String>, operation: DataOperation,
        session: SessionIdentity, handoff_epoch: u64,
        operator_instance_nonce: impl Into<String>,
    ) -> Result<Self, OperatorHostInvocationDecodingError> {
        let value = Self { source_name: source_name.into(), protocol: protocol.into(), operation, session,
            handoff_epoch,
            operator_instance_nonce: operator_instance_nonce.into() };
        value.validate()?;
        Ok(value)
    }

    pub fn source_name(&self) -> &str {
        &self.source_name
    }

    pub fn protocol(&self) -> &str {
        &self.protocol
    }

    pub fn operation(&self) -> DataOperation {
        self.operation
    }

    pub fn session(&self) -> &SessionIdentity {
        &self.session
    }

    pub fn handoff_epoch(&self) -> u64 { self.handoff_epoch }
    pub fn operator_instance_nonce(&self) -> &str { &self.operator_instance_nonce }

    pub fn to_json(&self) -> Result<String, OperatorHostInvocationEncodingError> {
        let document = OperatorHostInvocationDocumentV1 {
            schema_version: OPERATOR_HOST_INVOCATION_SCHEMA_VERSION,
            source_name: self.source_name.clone(),
            protocol: self.protocol.clone(),
            operation: operation_identifier(self.operation).to_string(),
            session_id: self.session.id().to_string(),
            handoff_epoch: self.handoff_epoch,
            operator_instance_nonce: self.operator_instance_nonce.clone(),
        };

        serde_json::to_string(&document)
            .map_err(|error| OperatorHostInvocationEncodingError::Serialization(error.to_string()))
    }

    pub fn from_json(input: &str) -> Result<Self, OperatorHostInvocationDecodingError> {
        let document = serde_json::from_str::<OperatorHostInvocationDocumentV1>(input).map_err(
            |error| match error.classify() {
                serde_json::error::Category::Syntax => {
                    OperatorHostInvocationDecodingError::JsonSyntax(error.to_string())
                }
                _ => OperatorHostInvocationDecodingError::StructuralDocument(error.to_string()),
            },
        )?;

        if document.schema_version != OPERATOR_HOST_INVOCATION_SCHEMA_VERSION {
            return Err(OperatorHostInvocationDecodingError::UnknownSchemaVersion(
                document.schema_version,
            ));
        }

        let operation = operation_from_identifier(&document.operation).ok_or_else(|| {
            OperatorHostInvocationDecodingError::UnknownOperation(document.operation.clone())
        })?;

        let session = SessionIdentity::new(document.session_id.clone())
            .map_err(|error| OperatorHostInvocationDecodingError::InvalidSessionIdentity(error.to_string()))?;

        let value = Self {
            source_name: document.source_name,
            protocol: document.protocol,
            operation,
            session,
            handoff_epoch: document.handoff_epoch,
            operator_instance_nonce: document.operator_instance_nonce,
        };
        value.validate()?;
        Ok(value)
    }

    fn validate(&self) -> Result<(), OperatorHostInvocationDecodingError> {
        crate::identity::ManagedName::parse(&self.source_name)
            .map_err(|error| OperatorHostInvocationDecodingError::InvalidField(format!("invalid source name: {error}")))?;
        if self.protocol != "http" { return Err(OperatorHostInvocationDecodingError::InvalidProtocol(self.protocol.clone())); }
        if self.handoff_epoch == 0 { return Err(OperatorHostInvocationDecodingError::InvalidField("handoff epoch must be nonzero".into())); }
        if self.operator_instance_nonce.is_empty() || self.operator_instance_nonce.len() > 128
            || !self.operator_instance_nonce.bytes().all(|byte| byte.is_ascii_alphanumeric() || byte == b'-') {
            return Err(OperatorHostInvocationDecodingError::InvalidField("operator nonce is invalid".into()));
        }
        Ok(())
    }
}

fn operation_identifier(operation: DataOperation) -> &'static str {
    match operation {
        DataOperation::Acquisition => "get-raw-data",
        DataOperation::Processing => "process-data",
    }
}

fn operation_from_identifier(value: &str) -> Option<DataOperation> {
    match value {
        "get-raw-data" => Some(DataOperation::Acquisition),
        "process-data" => Some(DataOperation::Processing),
        _ => None,
    }
}

#[derive(serde::Serialize, serde::Deserialize)]
#[serde(deny_unknown_fields)]
struct OperatorHostInvocationDocumentV1 {
    schema_version: u32,
    source_name: String,
    protocol: String,
    operation: String,
    session_id: String,
    #[serde(default)]
    handoff_epoch: u64,
    #[serde(default)]
    operator_instance_nonce: String,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum OperatorHostInvocationEncodingError {
    Serialization(String),
}

impl fmt::Display for OperatorHostInvocationEncodingError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Serialization(message) => {
                write!(formatter, "operator-host invocation serialization error: {message}")
            }
        }
    }
}

impl std::error::Error for OperatorHostInvocationEncodingError {}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum OperatorHostInvocationDecodingError {
    JsonSyntax(String),
    StructuralDocument(String),
    UnknownSchemaVersion(u32),
    UnknownOperation(String),
    InvalidProtocol(String),
    InvalidSessionIdentity(String),
    InvalidField(String),
}

impl fmt::Display for OperatorHostInvocationDecodingError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::JsonSyntax(message) => write!(formatter, "invalid JSON: {message}"),
            Self::StructuralDocument(message) => {
                write!(formatter, "malformed operator-host invocation document: {message}")
            }
            Self::UnknownSchemaVersion(version) => write!(
                formatter,
                "unknown operator-host invocation schema version: {version}"
            ),
            Self::UnknownOperation(value) => {
                write!(formatter, "unknown operator-host invocation operation: {value}")
            }
            Self::InvalidProtocol(message) => {
                write!(formatter, "invalid operator-host invocation protocol: {message}")
            }
            Self::InvalidSessionIdentity(message) => {
                write!(formatter, "invalid operator-host invocation session identity: {message}")
            }
            Self::InvalidField(message) => write!(formatter, "invalid operator-host invocation field: {message}"),
        }
    }
}

impl std::error::Error for OperatorHostInvocationDecodingError {}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Mutex;

    static PRIVATE_ENVIRONMENT_LOCK: Mutex<()> = Mutex::new(());

    #[test]
    fn private_capability_is_taken_validated_and_removed() {
        let _guard = PRIVATE_ENVIRONMENT_LOCK.lock().unwrap();
        let encoded = "11".repeat(32);
        // SAFETY: this test serializes access to the unique private variable
        // and does not start threads while it is present.
        unsafe {
            std::env::set_var(
                OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE,
                &encoded,
            );
        }
        let token = take_operator_host_handoff_token().unwrap();
        assert_eq!(
            token.expose_hex_for_private_transport(),
            encoded,
        );
        assert!(
            std::env::var_os(OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE).is_none()
        );
    }

    #[test]
    fn malformed_private_capability_is_removed_before_rejection() {
        let _guard = PRIVATE_ENVIRONMENT_LOCK.lock().unwrap();
        // SAFETY: this test serializes access to the unique private variable
        // and does not start threads while it is present.
        unsafe {
            std::env::set_var(
                OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE,
                "not-a-capability",
            );
        }
        assert!(take_operator_host_handoff_token().is_err());
        assert!(
            std::env::var_os(OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE).is_none()
        );
    }

    #[test]
    fn round_trips_through_json() {
        let reference = OperatorHostInvocationV1::new_reserved(
            "example-source",
            "http",
            DataOperation::Acquisition,
            SessionIdentity::new("session-abc").unwrap(),
            1, "operator-1",
        ).unwrap();

        let json = reference.to_json().unwrap();
        let decoded = OperatorHostInvocationV1::from_json(&json).unwrap();

        assert_eq!(decoded, reference);
    }

    #[test]
    fn rejects_unknown_schema_version() {
        let json = r#"{"schema_version":999,"source_name":"s","protocol":"http","operation":"get-raw-data","session_id":"abc"}"#;
        let result = OperatorHostInvocationV1::from_json(json);
        assert!(matches!(
            result,
            Err(OperatorHostInvocationDecodingError::UnknownSchemaVersion(999))
        ));
    }

    #[test]
    fn rejects_unknown_operation() {
        let json = r#"{"schema_version":1,"source_name":"s","protocol":"http","operation":"bogus","session_id":"abc"}"#;
        let result = OperatorHostInvocationV1::from_json(json);
        assert!(matches!(
            result,
            Err(OperatorHostInvocationDecodingError::UnknownOperation(_))
        ));
    }

    #[test]
    fn rejects_invalid_protocol() {
        let json = r#"{"schema_version":1,"source_name":"s","protocol":"","operation":"get-raw-data","session_id":"abc"}"#;
        let result = OperatorHostInvocationV1::from_json(json);
        assert!(matches!(
            result,
            Err(OperatorHostInvocationDecodingError::InvalidProtocol(_))
        ));
    }

    #[test]
    fn processing_operation_round_trips() {
        let reference = OperatorHostInvocationV1::new_reserved(
            "example-source",
            "http",
            DataOperation::Processing,
            SessionIdentity::new("session-xyz").unwrap(),
            1, "operator-2",
        ).unwrap();
        let json = reference.to_json().unwrap();
        let decoded = OperatorHostInvocationV1::from_json(&json).unwrap();
        assert_eq!(decoded.operation(), DataOperation::Processing);
        assert_eq!(decoded.protocol(), "http");
        assert!(!json.contains("handoff_token"));
    }

    #[test]
    fn rejects_unknown_field() {
        let json = r#"{"schema_version":1,"source_name":"s","protocol":"http","operation":"get-raw-data","session_id":"abc","unexpected":true}"#;
        let result = OperatorHostInvocationV1::from_json(json);
        assert!(matches!(
            result,
            Err(OperatorHostInvocationDecodingError::StructuralDocument(_))
        ));
    }

    #[test]
    fn rejects_private_capability_in_argv_document() {
        let json = r#"{"schema_version":1,"source_name":"s","protocol":"http","operation":"get-raw-data","session_id":"abc","handoff_token":"1111111111111111111111111111111111111111111111111111111111111111","handoff_epoch":1,"operator_instance_nonce":"operator-1"}"#;
        let result = OperatorHostInvocationV1::from_json(json);
        assert!(matches!(
            result,
            Err(OperatorHostInvocationDecodingError::StructuralDocument(_))
        ));
    }

    #[test]
    fn rejects_syntactically_invalid_json() {
        let json = "{not valid json";
        let result = OperatorHostInvocationV1::from_json(json);
        assert!(matches!(
            result,
            Err(OperatorHostInvocationDecodingError::JsonSyntax(_))
        ));
    }

    #[test]
    fn rejects_invalid_session_identity() {
        let json = r#"{"schema_version":1,"source_name":"s","protocol":"http","operation":"get-raw-data","session_id":""}"#;
        let result = OperatorHostInvocationV1::from_json(json);
        assert!(matches!(
            result,
            Err(OperatorHostInvocationDecodingError::InvalidSessionIdentity(_))
        ));
    }
}
