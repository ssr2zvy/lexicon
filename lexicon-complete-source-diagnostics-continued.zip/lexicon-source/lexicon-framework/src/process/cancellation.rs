use std::sync::atomic::{AtomicU8, Ordering};

use super::{CancellationKind, CancellationSource};

const NONE: u8 = 0;
const INTERRUPT: u8 = 1;
const TERMINATE: u8 = 2;
const CONSOLE_CLOSE: u8 = 3;

/// Signal-safe cancellation state shared by the platform handler and supervisor.
#[derive(Debug, Default)]
pub struct CancellationState {
    pending: AtomicU8,
}

impl CancellationState {
    pub const fn new() -> Self {
        Self { pending: AtomicU8::new(NONE) }
    }

    pub fn record(&self, kind: CancellationKind) {
        self.pending.store(encode(kind), Ordering::Release);
    }

    pub fn poll(&self) -> Option<CancellationKind> {
        decode(self.pending.swap(NONE, Ordering::AcqRel))
    }

    /// Establish a new supervision-run boundary before spawning a child.
    ///
    /// A request left behind after an earlier child completed must not cancel
    /// a later child. Callers must invoke this immediately before spawn: a
    /// cancellation arriving after this drain remains pending for that run.
    pub fn begin_supervision_run(&self) {
        self.pending.store(NONE, Ordering::Release);
    }
}

impl CancellationSource for CancellationState {
    fn requested(&self) -> Option<CancellationKind> {
        self.poll()
    }
}

const fn encode(kind: CancellationKind) -> u8 {
    match kind {
        CancellationKind::Interrupt => INTERRUPT,
        CancellationKind::Terminate => TERMINATE,
        CancellationKind::ConsoleClose => CONSOLE_CLOSE,
    }
}

const fn decode(value: u8) -> Option<CancellationKind> {
    match value {
        INTERRUPT => Some(CancellationKind::Interrupt),
        TERMINATE => Some(CancellationKind::Terminate),
        CONSOLE_CLOSE => Some(CancellationKind::ConsoleClose),
        _ => None,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn cancellation_is_delivered_once() {
        let state = CancellationState::new();
        state.record(CancellationKind::Interrupt);
        assert_eq!(state.poll(), Some(CancellationKind::Interrupt));
        assert_eq!(state.poll(), None);
    }

    #[test]
    fn latest_cancellation_wins() {
        let state = CancellationState::new();
        state.record(CancellationKind::Interrupt);
        state.record(CancellationKind::Terminate);
        assert_eq!(state.poll(), Some(CancellationKind::Terminate));
    }


    #[test]
    fn run_boundary_discards_only_preexisting_cancellation() {
        let state = CancellationState::new();
        state.record(CancellationKind::Interrupt);
        state.begin_supervision_run();
        assert_eq!(state.poll(), None);
        state.record(CancellationKind::Terminate);
        assert_eq!(state.poll(), Some(CancellationKind::Terminate));
    }
}
