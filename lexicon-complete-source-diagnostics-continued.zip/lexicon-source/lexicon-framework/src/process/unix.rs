use std::ffi::{OsStr, OsString};
use std::io;
#[cfg(target_os = "linux")]
use std::os::fd::{FromRawFd, OwnedFd};
use std::os::unix::process::CommandExt;
use std::path::Path;
use std::process::{Child, Command, ExitStatus};
use std::sync::atomic::{AtomicPtr, Ordering};

use super::{CancellationKind, CancellationState, SupervisedChild};

static CANCELLATION_STATE: AtomicPtr<CancellationState> = AtomicPtr::new(std::ptr::null_mut());

extern "C" fn cancellation_handler(signal: libc::c_int) {
    let state = CANCELLATION_STATE.load(Ordering::Acquire);
    if state.is_null() {
        return;
    }
    let kind = match signal {
        libc::SIGINT => CancellationKind::Interrupt,
        libc::SIGTERM => CancellationKind::Terminate,
        libc::SIGHUP => CancellationKind::ConsoleClose,
        _ => return,
    };
    // SAFETY: registration requires a process-lifetime (`'static`) state.
    unsafe { (&*state).record(kind) };
}

pub(super) fn install_cancellation_handlers(
    state: &'static CancellationState,
) -> io::Result<()> {
    // Publish the process-lifetime target before the first handler becomes
    // active. The caller has already established the new-run boundary, so a
    // cancellation racing installation belongs to this run and must be
    // retained rather than silently ignored.
    CANCELLATION_STATE.store(state as *const _ as *mut _, Ordering::Release);
    let signals = [libc::SIGINT, libc::SIGTERM, libc::SIGHUP];
    let mut previous = Vec::with_capacity(signals.len());
    for signal in signals {
        let mut action: libc::sigaction = unsafe { std::mem::zeroed() };
        action.sa_sigaction = cancellation_handler as usize;
        action.sa_flags = 0;
        unsafe { libc::sigemptyset(&mut action.sa_mask) };
        let mut old_action: libc::sigaction = unsafe { std::mem::zeroed() };
        if unsafe { libc::sigaction(signal, &action, &mut old_action) } != 0 {
            let error = io::Error::last_os_error();
            for (installed_signal, installed_previous) in previous.into_iter().rev() {
                unsafe {
                    libc::sigaction(installed_signal, &installed_previous, std::ptr::null_mut());
                }
            }
            CANCELLATION_STATE.store(std::ptr::null_mut(), Ordering::Release);
            return Err(error);
        }
        previous.push((signal, old_action));
    }
    Ok(())
}

pub(super) fn launch(
    executable: &Path,
    arguments: &[OsString],
    context_environment: &OsStr,
    working_directory: &Path,
) -> io::Result<Box<dyn SupervisedChild>> {
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (executable, arguments, context_environment, working_directory);
        return Err(io::Error::new(
            io::ErrorKind::Unsupported,
            "fail-closed process-tree parent-death supervision is currently implemented only on Linux",
        ));
    }

    #[cfg(target_os = "linux")]
    {
    // Fork and arm the watchdog before the runtime is allowed to exec. The
    // child-side pre-exec hook registers its process group and blocks until
    // the watchdog acknowledges it, closing the spawn→watchdog orphan window.
    let (mut watchdog, registration_write, release_read) = ParentDeathWatchdog::spawn_pending()?;
    let supervisor_pid = unsafe { libc::getpid() };
    let mut command = Command::new(executable);
    command
        .args(arguments)
        .env("LEXICON_RUNTIME_CONTEXT_V1", context_environment)
        .env_remove("LEXICON_SOURCE_DIRECTORY")
        .env_remove(crate::supervision::OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE)
        .current_dir(working_directory);
    unsafe {
        command.pre_exec(move || {
            if libc::setpgid(0, 0) == -1 {
                return Err(io::Error::last_os_error());
            }
            if libc::prctl(libc::PR_SET_PDEATHSIG, libc::SIGKILL) == -1 {
                return Err(io::Error::last_os_error());
            }
            if libc::getppid() != supervisor_pid {
                return Err(io::Error::new(
                    io::ErrorKind::BrokenPipe,
                    "runtime supervisor exited before parent-death protection was installed",
                ));
            }
            use std::os::fd::AsRawFd;
            let process_group = libc::getpid().to_ne_bytes();
            let mut offset = 0usize;
            while offset < process_group.len() {
                let result = libc::write(
                    registration_write.as_raw_fd(),
                    process_group[offset..].as_ptr().cast(),
                    process_group.len() - offset,
                );
                if result == -1 && *libc::__errno_location() == libc::EINTR { continue; }
                if result <= 0 { return Err(io::Error::last_os_error()); }
                offset += result as usize;
            }
            let mut release = 0u8;
            loop {
                let result = libc::read(
                    release_read.as_raw_fd(),
                    (&mut release as *mut u8).cast(),
                    1,
                );
                if result == -1 && *libc::__errno_location() == libc::EINTR { continue; }
                if result != 1 || release != 1 {
                    return Err(io::Error::new(io::ErrorKind::BrokenPipe, "runtime watchdog did not authorize exec"));
                }
                break;
            }
            Ok(())
        });
    }
    let mut child = match command.spawn() {
        Ok(child) => child,
        Err(error) => {
            // Closing the parent copies of the registration/release
            // descriptors lets a watchdog waiting on a child that failed
            // before registration observe EOF and terminate deterministically.
            drop(command);
            return match watchdog.trigger_and_wait() {
                Ok(()) => Err(error),
                Err(cleanup) => Err(io::Error::new(
                    error.kind(),
                    format!("runtime spawn failed: {error}; watchdog cleanup also failed: {cleanup}"),
                )),
            };
        }
    };
    drop(command);
    let process_group = match i32::try_from(child.id()) {
        Ok(process_group) => process_group,
        Err(_) => {
            let primary = io::Error::new(io::ErrorKind::InvalidData, "child pid exceeds pid_t");
            let kill = child.kill().err();
            let reap = child.wait().err();
            let watchdog_error = watchdog.trigger_and_wait().err();
            return Err(io::Error::new(
                primary.kind(),
                format!("{primary}; kill={kill:?}; reap={reap:?}; watchdog={watchdog_error:?}"),
            ));
        }
    };
    if let Err(error) = watchdog.verify_registration(process_group) {
        let kill_error = if unsafe { libc::kill(-process_group, libc::SIGKILL) } == -1 {
            let error = io::Error::last_os_error();
            (error.raw_os_error() != Some(libc::ESRCH)).then_some(error)
        } else {
            None
        };
        let reap_error = loop {
            match child.wait() {
                Err(wait_error) if wait_error.kind() == io::ErrorKind::Interrupted => continue,
                Err(wait_error) => break Some(wait_error),
                Ok(_) => break None,
            }
        };
        let watchdog_error = watchdog.trigger_and_wait().err();
        return Err(io::Error::new(
            error.kind(),
            format!("{error}; kill={kill_error:?}; reap={reap_error:?}; watchdog={watchdog_error:?}"),
        ));
    }
    Ok(Box::new(UnixSupervisedChild { child, watchdog }))
    }
}

struct UnixSupervisedChild {
    child: Child,
    #[cfg(target_os = "linux")]
    watchdog: ParentDeathWatchdog,
}

impl Drop for UnixSupervisedChild {
    fn drop(&mut self) {
        let already_exited = matches!(self.child.try_wait(), Ok(Some(_)));
        if !already_exited {
            let _ = self.signal_group(libc::SIGKILL);
            loop {
                match self.child.wait() {
                    Err(error) if error.kind() == io::ErrorKind::Interrupted => continue,
                    _ => break,
                }
            }
        }
        #[cfg(target_os = "linux")]
        let _ = self.watchdog.trigger_and_wait();
    }
}

impl UnixSupervisedChild {
    fn signal_group(&self, signal: libc::c_int) -> io::Result<()> {
        let pid = i32::try_from(self.child.id())
            .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "child pid exceeds pid_t"))?;
        if unsafe { libc::kill(-pid, signal) } == 0 {
            return Ok(());
        }
        let error = io::Error::last_os_error();
        if error.raw_os_error() == Some(libc::ESRCH) {
            Ok(())
        } else {
            Err(error)
        }
    }
}

impl SupervisedChild for UnixSupervisedChild {
    fn id(&self) -> u32 { self.child.id() }

    fn try_wait(&mut self) -> io::Result<Option<ExitStatus>> {
        let status = self.child.try_wait()?;
        if status.is_some() {
            #[cfg(target_os = "linux")]
            self.watchdog.trigger_and_wait()?;
        }
        Ok(status)
    }

    fn request_graceful_shutdown(&mut self, kind: CancellationKind) -> io::Result<()> {
        self.signal_group(match kind {
            CancellationKind::Interrupt => libc::SIGINT,
            CancellationKind::Terminate => libc::SIGTERM,
            CancellationKind::ConsoleClose => libc::SIGHUP,
        })
    }

    fn force_terminate_tree(&mut self) -> io::Result<()> { self.signal_group(libc::SIGKILL) }

    fn wait_reaped(&mut self) -> io::Result<ExitStatus> {
        let status = loop {
            match self.child.wait() {
                Err(error) if error.kind() == io::ErrorKind::Interrupted => continue,
                result => break result?,
            }
        };
        #[cfg(target_os = "linux")]
        self.watchdog.trigger_and_wait()?;
        Ok(status)
    }
}

#[cfg(target_os = "linux")]
fn parent_death_pipe() -> io::Result<(OwnedFd, OwnedFd)> {
    let mut descriptors = [-1; 2];
    if unsafe { libc::pipe2(descriptors.as_mut_ptr(), libc::O_CLOEXEC) } == -1 {
        return Err(io::Error::last_os_error());
    }
    // SAFETY: pipe2 returned two new owned descriptors.
    Ok(unsafe {
        (
            OwnedFd::from_raw_fd(descriptors[0]),
            OwnedFd::from_raw_fd(descriptors[1]),
        )
    })
}

#[cfg(target_os = "linux")]
struct ParentDeathWatchdog {
    writer: Option<OwnedFd>,
    process_id: libc::pid_t,
}

#[cfg(target_os = "linux")]
impl ParentDeathWatchdog {
    fn spawn_pending() -> io::Result<(Self, OwnedFd, OwnedFd)> {
        use std::os::fd::AsRawFd;

        let (liveness_read, liveness_write) = parent_death_pipe()?;
        let (registration_read, registration_write) = parent_death_pipe()?;
        let (release_read, release_write) = parent_death_pipe()?;
        let liveness_read_raw = liveness_read.as_raw_fd();
        let liveness_write_raw = liveness_write.as_raw_fd();
        let registration_read_raw = registration_read.as_raw_fd();
        let registration_write_raw = registration_write.as_raw_fd();
        let release_read_raw = release_read.as_raw_fd();
        let release_write_raw = release_write.as_raw_fd();
        let process_id = unsafe { libc::fork() };
        if process_id == -1 {
            return Err(io::Error::last_os_error());
        }
        if process_id == 0 {
            unsafe {
                libc::close(liveness_write_raw);
                libc::close(registration_write_raw);
                libc::close(release_read_raw);
                // The watchdog must survive a signal directed at the operator
                // host's process group so it can still clean the independently
                // supervised runtime group.
                if libc::setpgid(0, 0) == -1 {
                    libc::_exit(1);
                }
                let mut registration = [0u8; std::mem::size_of::<libc::pid_t>()];
                let mut offset = 0usize;
                while offset < registration.len() {
                    let result = libc::read(
                        registration_read_raw,
                        registration[offset..].as_mut_ptr().cast(),
                        registration.len() - offset,
                    );
                    if result == -1 && *libc::__errno_location() == libc::EINTR { continue; }
                    if result <= 0 { libc::_exit(0); }
                    offset += result as usize;
                }
                let process_group = libc::pid_t::from_ne_bytes(registration);
                if process_group <= 0 { libc::_exit(1); }
                if libc::write(release_write_raw, [1u8].as_ptr().cast(), 1) != 1 {
                    libc::kill(-process_group, libc::SIGKILL);
                    libc::_exit(1);
                }
                libc::close(registration_read_raw);
                libc::close(release_write_raw);
                let mut byte = 0u8;
                loop {
                    let result = libc::read(liveness_read_raw, (&mut byte as *mut u8).cast(), 1);
                    if result == 0 {
                        break;
                    }
                    if result == -1 && *libc::__errno_location() == libc::EINTR {
                        continue;
                    }
                    if result == -1 {
                        break;
                    }
                }
                libc::close(liveness_read_raw);
                if libc::kill(-process_group, libc::SIGKILL) == -1
                    && *libc::__errno_location() != libc::ESRCH
                {
                    libc::_exit(1);
                }
                libc::_exit(0);
            }
        }
        drop(liveness_read);
        drop(registration_read);
        drop(release_write);
        Ok((
            Self { writer: Some(liveness_write), process_id },
            registration_write,
            release_read,
        ))
    }

    fn verify_registration(&mut self, process_group: libc::pid_t) -> io::Result<()> {
        if process_group <= 0 || self.process_id <= 0 {
            return Err(io::Error::new(io::ErrorKind::InvalidData, "runtime watchdog registration failed"));
        }
        let mut status = 0;
        let result = unsafe { libc::waitpid(self.process_id, &mut status, libc::WNOHANG) };
        if result == 0 {
            return Ok(());
        }
        if result == self.process_id {
            self.process_id = 0;
            return Err(io::Error::other("runtime watchdog exited during registration"));
        }
        Err(io::Error::last_os_error())
    }

    fn trigger_and_wait(&mut self) -> io::Result<()> {
        drop(self.writer.take());
        if self.process_id == 0 {
            return Ok(());
        }
        let mut status = 0;
        loop {
            let result = unsafe { libc::waitpid(self.process_id, &mut status, 0) };
            if result == self.process_id {
                self.process_id = 0;
                if libc::WIFEXITED(status) && libc::WEXITSTATUS(status) == 0 {
                    return Ok(());
                }
                return Err(io::Error::other("process-tree parent-death watchdog failed"));
            }
            if result == -1 && io::Error::last_os_error().raw_os_error() == Some(libc::EINTR) {
                continue;
            }
            return Err(io::Error::last_os_error());
        }
    }
}

#[cfg(all(test, target_os = "linux"))]
mod tests {
    use super::*;
    use std::time::{Duration, Instant};

    static TEST_CANCELLATION: CancellationState = CancellationState::new();

    #[test]
    fn native_unix_handler_records_sigint() {
        TEST_CANCELLATION.begin_supervision_run();
        install_cancellation_handlers(&TEST_CANCELLATION).unwrap();
        assert_eq!(unsafe { libc::raise(libc::SIGINT) }, 0);
        assert_eq!(TEST_CANCELLATION.poll(), Some(CancellationKind::Interrupt));
    }

    #[test]
    fn watchdog_release_waits_for_complete_process_group_registration() {
        use std::os::fd::AsRawFd;

        let (mut watchdog, registration, release) = ParentDeathWatchdog::spawn_pending().unwrap();
        let process_group = i32::MAX.to_ne_bytes();
        let first_half = process_group.len() / 2;
        assert_eq!(unsafe {
            libc::write(
                registration.as_raw_fd(),
                process_group[..first_half].as_ptr().cast(),
                first_half,
            )
        }, first_half as isize);

        let mut poll = libc::pollfd {
            fd: release.as_raw_fd(),
            events: libc::POLLIN,
            revents: 0,
        };
        assert_eq!(unsafe { libc::poll(&mut poll, 1, 100) }, 0,
            "watchdog released exec before receiving the complete process-group identity");

        assert_eq!(unsafe {
            libc::write(
                registration.as_raw_fd(),
                process_group[first_half..].as_ptr().cast(),
                process_group.len() - first_half,
            )
        }, (process_group.len() - first_half) as isize);
        assert_eq!(unsafe { libc::poll(&mut poll, 1, 2_000) }, 1,
            "watchdog did not release exec after complete registration");
        let mut release_byte = 0u8;
        assert_eq!(unsafe {
            libc::read(release.as_raw_fd(), (&mut release_byte as *mut u8).cast(), 1)
        }, 1);
        assert_eq!(release_byte, 1);
        drop(registration);
        drop(release);
        watchdog.trigger_and_wait().unwrap();
    }

    #[test]
    fn native_unix_graceful_request_reaches_the_process_group_and_reaps() {
        let directory = tempfile::tempdir().unwrap();
        let ready = directory.path().join("ready");
        let mut child = launch(
            Path::new("/bin/sh"),
            &[
                OsString::from("-c"),
                OsString::from("trap 'exit 23' TERM; : > \"$1\"; while :; do sleep 1; done"),
                OsString::from("lexicon-cancellation-test"),
                ready.as_os_str().to_owned(),
            ],
            OsStr::new("{}"),
            Path::new("/"),
        ).unwrap();
        let ready_deadline = Instant::now() + Duration::from_secs(5);
        while !ready.is_file() {
            assert!(Instant::now() < ready_deadline, "child did not publish its signal-ready barrier");
            std::thread::sleep(Duration::from_millis(10));
        }
        child.request_graceful_shutdown(CancellationKind::Terminate).unwrap();
        let deadline = Instant::now() + Duration::from_secs(5);
        let status = loop {
            if let Some(status) = child.try_wait().unwrap() { break status; }
            assert!(Instant::now() < deadline, "child ignored SIGTERM sent to its process group");
            std::thread::sleep(Duration::from_millis(10));
        };
        assert_eq!(status.code(), Some(23));
    }

    #[test]
    fn native_unix_force_termination_kills_group_and_reaps_direct_child() {
        let mut child = launch(
            Path::new("/bin/sh"),
            &[OsString::from("-c"), OsString::from("sleep 30 & wait")],
            OsStr::new("{}"),
            Path::new("/"),
        ).unwrap();
        let process_group = i32::try_from(child.id()).unwrap();
        child.force_terminate_tree().unwrap();
        let status = child.wait_reaped().unwrap();
        assert!(status.code().is_none());
        let deadline = Instant::now() + Duration::from_secs(5);
        loop {
            let result = unsafe { libc::kill(-process_group, 0) };
            if result != 0 && io::Error::last_os_error().raw_os_error() == Some(libc::ESRCH) {
                break;
            }
            assert!(Instant::now() < deadline, "a member of the forced process group survived");
            std::thread::sleep(Duration::from_millis(10));
        }
    }

    #[test]
    fn dropping_live_unix_child_kills_group_and_reaps() {
        let directory = tempfile::tempdir().unwrap();
        let ready = directory.path().join("ready");
        let process_group;
        {
            let child = launch(
                Path::new("/bin/sh"),
                &[
                    OsString::from("-c"),
                    OsString::from(": > \"$1\"; sleep 30 & wait"),
                    OsString::from("lexicon-drop-test"),
                    ready.as_os_str().to_owned(),
                ],
                OsStr::new("{}"),
                Path::new("/"),
            ).unwrap();
            process_group = i32::try_from(child.id()).unwrap();
            let deadline = Instant::now() + Duration::from_secs(5);
            while !ready.is_file() {
                assert!(Instant::now() < deadline, "child did not reach drop barrier");
                std::thread::sleep(Duration::from_millis(10));
            }
            drop(child);
        }
        let deadline = Instant::now() + Duration::from_secs(5);
        loop {
            if unsafe { libc::kill(-process_group, 0) } == -1
                && io::Error::last_os_error().raw_os_error() == Some(libc::ESRCH)
            {
                break;
            }
            assert!(Instant::now() < deadline, "a process-group member survived child drop");
            std::thread::sleep(Duration::from_millis(10));
        }
    }
}
