use std::{ffi::{OsStr, OsString}, io, path::Path, process::ExitStatus, sync::atomic::{AtomicPtr, Ordering}};
use std::os::windows::{ffi::OsStrExt, process::ExitStatusExt};
use windows_sys::Win32::{
    Foundation::{CloseHandle, HANDLE, WAIT_OBJECT_0, WAIT_TIMEOUT},
    System::{
        Console::{CTRL_BREAK_EVENT, CTRL_CLOSE_EVENT, CTRL_C_EVENT, CTRL_LOGOFF_EVENT,
            CTRL_SHUTDOWN_EVENT, GenerateConsoleCtrlEvent, SetConsoleCtrlHandler},
        JobObjects::{AssignProcessToJobObject, CreateJobObjectW, JobObjectExtendedLimitInformation,
            JOBOBJECT_EXTENDED_LIMIT_INFORMATION, JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE,
            SetInformationJobObject, TerminateJobObject},
        Threading::{CreateProcessW, GetExitCodeProcess, ResumeThread, WaitForSingleObject,
            TerminateProcess, PROCESS_INFORMATION, STARTUPINFOW},
    },
};
use super::{CancellationKind, CancellationState, SupervisedChild};

const CREATE_SUSPENDED: u32 = 4;
const CREATE_NEW_PROCESS_GROUP: u32 = 0x200;
const CREATE_UNICODE_ENVIRONMENT: u32 = 0x400;
static CANCELLATION: AtomicPtr<CancellationState> = AtomicPtr::new(std::ptr::null_mut());

unsafe extern "system" fn control(event: u32) -> i32 {
    let pointer = CANCELLATION.load(Ordering::Acquire);
    if pointer.is_null() { return 0; }
    let kind = match event {
        CTRL_C_EVENT => CancellationKind::Interrupt,
        CTRL_BREAK_EVENT => CancellationKind::Terminate,
        CTRL_CLOSE_EVENT | CTRL_LOGOFF_EVENT | CTRL_SHUTDOWN_EVENT => CancellationKind::ConsoleClose,
        _ => return 0,
    };
    unsafe { (&*pointer).record(kind) };
    1
}

pub(super) fn install_cancellation_handlers(state: &'static CancellationState) -> io::Result<()> {
    CANCELLATION.store(state as *const _ as *mut _, Ordering::Release);
    if unsafe { SetConsoleCtrlHandler(Some(control), 1) } == 0 {
        CANCELLATION.store(std::ptr::null_mut(), Ordering::Release);
        Err(io::Error::last_os_error())
    } else { Ok(()) }
}

struct Handle(HANDLE);
impl Handle {
    fn new(value: HANDLE) -> io::Result<Self> {
        if value.is_null() { Err(io::Error::last_os_error()) } else { Ok(Self(value)) }
    }
}
impl Drop for Handle { fn drop(&mut self) { unsafe { CloseHandle(self.0); } } }

pub(super) fn launch(executable: &Path, arguments: &[OsString], context: &OsStr,
    working_directory: &Path) -> io::Result<Box<dyn SupervisedChild>> {
    let job = Handle::new(unsafe { CreateJobObjectW(std::ptr::null(), std::ptr::null()) })?;
    let mut limits: JOBOBJECT_EXTENDED_LIMIT_INFORMATION = unsafe { std::mem::zeroed() };
    limits.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
    if unsafe { SetInformationJobObject(job.0, JobObjectExtendedLimitInformation,
        &limits as *const _ as *const _, std::mem::size_of_val(&limits) as u32) } == 0 {
        return Err(io::Error::last_os_error());
    }
    let application = nul(executable.as_os_str());
    let directory = nul(working_directory.as_os_str());
    let mut command = command_line(executable.as_os_str(), arguments);
    let mut environment = environment_block(context);
    let mut startup: STARTUPINFOW = unsafe { std::mem::zeroed() };
    startup.cb = std::mem::size_of::<STARTUPINFOW>() as u32;
    let mut info: PROCESS_INFORMATION = unsafe { std::mem::zeroed() };
    if unsafe { CreateProcessW(application.as_ptr(), command.as_mut_ptr(), std::ptr::null(),
        std::ptr::null(), 0, CREATE_SUSPENDED | CREATE_NEW_PROCESS_GROUP | CREATE_UNICODE_ENVIRONMENT,
        environment.as_mut_ptr() as *mut _, directory.as_ptr(), &startup, &mut info) } == 0 {
        return Err(io::Error::last_os_error());
    }
    let process = Handle::new(info.hProcess)?;
    let thread = Handle::new(info.hThread)?;
    if unsafe { AssignProcessToJobObject(job.0, process.0) } == 0 {
        let error = io::Error::last_os_error();
        // Assignment failed, so terminating the still-empty job object cannot
        // stop this suspended process. Terminate the direct process handle
        // before waiting; otherwise this failure path waits forever and leaks
        // a live suspended child outside Lexicon's supervision.
        unsafe { TerminateProcess(process.0, 1); WaitForSingleObject(process.0, u32::MAX); }
        return Err(error);
    }
    if unsafe { ResumeThread(thread.0) } == u32::MAX {
        let error = io::Error::last_os_error();
        unsafe { TerminateJobObject(job.0, 1); WaitForSingleObject(process.0, u32::MAX); }
        return Err(error);
    }
    drop(thread);
    Ok(Box::new(WindowsChild { process, job, id: info.dwProcessId }))
}

struct WindowsChild { process: Handle, job: Handle, id: u32 }
impl Drop for WindowsChild {
    fn drop(&mut self) {
        if unsafe { WaitForSingleObject(self.process.0, 0) } == WAIT_OBJECT_0 {
            return;
        }
        unsafe {
            TerminateJobObject(self.job.0, 1);
            WaitForSingleObject(self.process.0, u32::MAX);
        }
    }
}
impl WindowsChild {
    fn status(&self) -> io::Result<ExitStatus> {
        let mut code = 0;
        if unsafe { GetExitCodeProcess(self.process.0, &mut code) } == 0 {
            Err(io::Error::last_os_error())
        } else { Ok(ExitStatus::from_raw(code)) }
    }
}
impl SupervisedChild for WindowsChild {
    fn id(&self) -> u32 { self.id }
    fn try_wait(&mut self) -> io::Result<Option<ExitStatus>> {
        match unsafe { WaitForSingleObject(self.process.0, 0) } {
            WAIT_OBJECT_0 => self.status().map(Some), WAIT_TIMEOUT => Ok(None),
            _ => Err(io::Error::last_os_error()),
        }
    }
    fn request_graceful_shutdown(&mut self, _: CancellationKind) -> io::Result<()> {
        if unsafe { GenerateConsoleCtrlEvent(CTRL_BREAK_EVENT, self.id) } == 0 {
            Err(io::Error::last_os_error())
        } else { Ok(()) }
    }
    fn force_terminate_tree(&mut self) -> io::Result<()> {
        if unsafe { TerminateJobObject(self.job.0, 1) } == 0 { Err(io::Error::last_os_error()) } else { Ok(()) }
    }
    fn wait_reaped(&mut self) -> io::Result<ExitStatus> {
        if unsafe { WaitForSingleObject(self.process.0, u32::MAX) } == WAIT_OBJECT_0 {
            self.status()
        } else { Err(io::Error::last_os_error()) }
    }
}

fn nul(value: &OsStr) -> Vec<u16> { value.encode_wide().chain(Some(0)).collect() }
fn quote(value: &OsStr, out: &mut Vec<u16>) {
    let input: Vec<u16> = value.encode_wide().collect();
    // The Microsoft CRT command-line grammar requires quoting not only for
    // whitespace and empty arguments but also whenever an argument contains a
    // literal quote. Without this condition, the quote branch below is never
    // reached for values such as `embedded\"quote`, and CreateProcessW hands
    // the child a structurally different argv.
    let quoted = input.is_empty() || input.iter().any(|v| *v == 32 || *v == 9 || *v == 34);
    if !quoted { out.extend(input); return; }
    out.push(34); let mut slashes = 0;
    for unit in input {
        if unit == 92 { slashes += 1; continue; }
        out.extend(std::iter::repeat_n(92, if unit == 34 { slashes * 2 + 1 } else { slashes }));
        slashes = 0; out.push(unit);
    }
    out.extend(std::iter::repeat_n(92, slashes * 2)); out.push(34);
}
fn command_line(executable: &OsStr, args: &[OsString]) -> Vec<u16> {
    let mut out = Vec::new(); quote(executable, &mut out);
    for arg in args { out.push(32); quote(arg, &mut out); }
    out.push(0); out
}
fn environment_block(context: &OsStr) -> Vec<u16> {
    environment_block_from(std::env::vars_os().collect(), context)
}

fn environment_block_from(
    values: Vec<(OsString, OsString)>,
    context: &OsStr,
) -> Vec<u16> {
    let mut values: Vec<_> = values.into_iter().filter(|(key, _)|
        !key.as_os_str().eq_ignore_ascii_case(OsStr::new("LEXICON_RUNTIME_CONTEXT_V1")) &&
        !key.as_os_str().eq_ignore_ascii_case(OsStr::new("LEXICON_SOURCE_DIRECTORY")) &&
        !key.as_os_str().eq_ignore_ascii_case(OsStr::new(
            crate::supervision::OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE,
        ))).collect();
    values.push(("LEXICON_RUNTIME_CONTEXT_V1".into(), context.into()));
    values.sort_by_key(|(key, _)| key.to_string_lossy().to_uppercase());
    let mut out = Vec::new();
    for (key, value) in values { out.extend(key.encode_wide()); out.push(61); out.extend(value.encode_wide()); out.push(0); }
    out.push(0); out
}

#[cfg(test)]
mod tests {
    use super::*;

    static TEST_CANCELLATION: CancellationState = CancellationState::new();

    #[test]
    fn windows_callback_maps_ctrl_c_to_interrupt() {
        TEST_CANCELLATION.begin_supervision_run();
        install_cancellation_handlers(&TEST_CANCELLATION).unwrap();
        assert_eq!(unsafe { control(CTRL_C_EVENT) }, 1);
        assert_eq!(TEST_CANCELLATION.poll(), Some(CancellationKind::Interrupt));
    }

    fn decode_nul_terminated(value: &[u16]) -> String {
        String::from_utf16(&value[..value.len() - 1]).unwrap()
    }

    #[test]
    fn command_line_quotes_empty_whitespace_quotes_and_trailing_slashes() {
        let line = command_line(
            OsStr::new(r#"C:\Program Files\lexicon.exe"#),
            &[
                OsString::from(""),
                OsString::from("plain"),
                OsString::from(r#"embedded\"quote"#),
                OsString::from(r#"trailing slash\"#),
            ],
        );
        assert_eq!(
            decode_nul_terminated(&line),
            r#""C:\Program Files\lexicon.exe" "" plain "embedded\\\"quote" "trailing slash\\""#
        );
    }

    #[test]
    fn source_environment_strips_private_operator_host_capability() {
        let block = environment_block_from(
            vec![
                (OsString::from("PATH"), OsString::from("test-path")),
                (
                    OsString::from(
                        crate::supervision::OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE,
                    ),
                    OsString::from("secret-capability"),
                ),
            ],
            OsStr::new("runtime-context"),
        );
        let rendered = String::from_utf16_lossy(&block);
        assert!(rendered.contains("PATH=test-path"));
        assert!(rendered.contains("LEXICON_RUNTIME_CONTEXT_V1=runtime-context"));
        assert!(!rendered.contains("secret-capability"));
        assert!(!rendered.contains(
            crate::supervision::OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE,
        ));
    }

    #[test]
    fn environment_replaces_context_and_removes_legacy_source_directory() {
        let block = environment_block(OsStr::new("new-context"));
        assert_eq!(block.last(), Some(&0));
        assert!(block.ends_with(&[0, 0]));

        let entries = block
            .split(|unit| *unit == 0)
            .filter(|entry| !entry.is_empty())
            .map(|entry| String::from_utf16(entry).unwrap())
            .collect::<Vec<_>>();
        let context_entries = entries
            .iter()
            .filter(|entry| entry.starts_with("LEXICON_RUNTIME_CONTEXT_V1="))
            .collect::<Vec<_>>();
        assert_eq!(context_entries.len(), 1);
        assert_eq!(context_entries[0], "LEXICON_RUNTIME_CONTEXT_V1=new-context");
        assert!(
            entries
                .iter()
                .all(|entry| !entry.starts_with("LEXICON_SOURCE_DIRECTORY="))
        );
    }

    #[test]
    fn native_windows_job_force_termination_reaps_the_process() {
        let command = std::env::var_os("COMSPEC").unwrap_or_else(|| OsString::from("cmd.exe"));
        let executable = Path::new(&command);
        let working_directory = std::env::current_dir().unwrap();
        let mut child = launch(
            executable,
            &[
                OsString::from("/D"),
                OsString::from("/S"),
                OsString::from("/C"),
                OsString::from("start \"\" /B ping -n 30 127.0.0.1 >NUL & ping -n 30 127.0.0.1 >NUL"),
            ],
            OsStr::new("{}"),
            &working_directory,
        ).unwrap();
        child.force_terminate_tree().unwrap();
        let status = child.wait_reaped().unwrap();
        assert!(status.code().is_some());
        assert!(child.try_wait().unwrap().is_some());
    }


    #[test]
    fn dropping_live_windows_child_terminates_job_and_waits() {
        let command = std::env::var_os("COMSPEC").unwrap_or_else(|| OsString::from("cmd.exe"));
        let executable = Path::new(&command);
        let working_directory = std::env::current_dir().unwrap();
        let child = launch(
            executable,
            &[
                OsString::from("/D"),
                OsString::from("/S"),
                OsString::from("/C"),
                OsString::from("start \"\" /B ping -n 30 127.0.0.1 >NUL & ping -n 30 127.0.0.1 >NUL"),
            ],
            OsStr::new("{}"),
            &working_directory,
        ).unwrap();
        drop(child);
    }
}
