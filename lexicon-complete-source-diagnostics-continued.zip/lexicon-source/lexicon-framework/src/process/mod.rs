use std::ffi::{OsStr, OsString};
use std::fmt;
use std::path::Path;
use std::process::ExitStatus;
use std::time::{Duration, Instant};

pub mod cancellation;
#[cfg(unix)]
mod unix;
#[cfg(windows)]
mod windows;

pub use cancellation::CancellationState;

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CancellationKind {
    Interrupt,
    Terminate,
    ConsoleClose,
}

impl fmt::Display for CancellationKind {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(match self {
            Self::Interrupt => "interrupt",
            Self::Terminate => "terminate",
            Self::ConsoleClose => "console-close",
        })
    }
}

pub trait CancellationSource: Send + Sync {
    fn requested(&self) -> Option<CancellationKind>;
}

pub trait SupervisedChild: Send {
    fn id(&self) -> u32;
    fn try_wait(&mut self) -> std::io::Result<Option<ExitStatus>>;
    fn request_graceful_shutdown(&mut self, kind: CancellationKind) -> std::io::Result<()>;
    fn force_terminate_tree(&mut self) -> std::io::Result<()>;
    fn wait_reaped(&mut self) -> std::io::Result<ExitStatus>;
}

pub trait ProcessTreeLauncher: Send + Sync {
    fn spawn(
        &self,
        executable: &Path,
        arguments: &[OsString],
        context_environment: &OsStr,
        working_directory: &Path,
    ) -> std::io::Result<Box<dyn SupervisedChild>>;
}

#[derive(Clone, Copy, Debug)]
pub struct CancellationPolicy {
    pub graceful_timeout: Duration,
    pub poll_interval: Duration,
}

impl CancellationPolicy {
    pub const fn default_cli_policy() -> Self {
        Self { graceful_timeout: Duration::from_secs(15), poll_interval: Duration::from_millis(100) }
    }
}

pub struct ProductionLauncher;

impl ProcessTreeLauncher for ProductionLauncher {
    fn spawn(
        &self,
        executable: &Path,
        arguments: &[OsString],
        context_environment: &OsStr,
        working_directory: &Path,
    ) -> std::io::Result<Box<dyn SupervisedChild>> {
        #[cfg(unix)]
        { return unix::launch(executable, arguments, context_environment, working_directory); }
        #[cfg(windows)]
        { return windows::launch(executable, arguments, context_environment, working_directory); }
        #[cfg(not(any(unix, windows)))]
        {
            let _ = (executable, arguments, context_environment, working_directory);
            Err(std::io::Error::new(std::io::ErrorKind::Unsupported, "unsupported supervision platform"))
        }
    }
}

pub fn install_cancellation_handlers(state: &'static CancellationState) -> std::io::Result<()> {
    #[cfg(unix)]
    { return unix::install_cancellation_handlers(state); }
    #[cfg(windows)]
    { return windows::install_cancellation_handlers(state); }
    #[cfg(not(any(unix, windows)))]
    {
        let _ = state;
        Err(std::io::Error::new(std::io::ErrorKind::Unsupported, "unsupported cancellation platform"))
    }
}

#[derive(Debug)]
pub enum SupervisionOutcome {
    Completed { status: ExitStatus },
    CancelledGracefully { kind: CancellationKind, status: ExitStatus },
    CancelledForcefully { kind: CancellationKind, status: ExitStatus },
    CancellationControlFailedButTerminated {
        kind: CancellationKind,
        graceful_error: Option<std::io::Error>,
        force_error: std::io::Error,
        status: ExitStatus,
    },
}

pub fn wait_with_cancellation(
    child: &mut dyn SupervisedChild,
    cancellation: &dyn CancellationSource,
    policy: CancellationPolicy,
) -> std::io::Result<SupervisionOutcome> {
    loop {
        if let Some(status) = child.try_wait()? {
            return Ok(SupervisionOutcome::Completed { status });
        }
        if let Some(kind) = cancellation.requested() {
            let graceful_error = child.request_graceful_shutdown(kind).err();
            if graceful_error.is_some() {
                if let Err(force_error) = child.force_terminate_tree() {
                    let status = wait_until_reaped_after_control_failure(child, policy.poll_interval)?;
                    return Ok(SupervisionOutcome::CancellationControlFailedButTerminated {
                        kind,
                        graceful_error,
                        force_error,
                        status,
                    });
                }
                let status = child.wait_reaped()?;
                return Ok(SupervisionOutcome::CancelledForcefully { kind, status });
            }
            let deadline = Instant::now() + policy.graceful_timeout;
            loop {
                if let Some(status) = child.try_wait()? {
                    return Ok(SupervisionOutcome::CancelledGracefully { kind, status });
                }
                if let Some(escalation_kind) = cancellation.requested() {
                    if let Err(force_error) = child.force_terminate_tree() {
                        let status = wait_until_reaped_after_control_failure(
                            child,
                            policy.poll_interval,
                        )?;
                        return Ok(
                            SupervisionOutcome::CancellationControlFailedButTerminated {
                                kind: escalation_kind,
                                graceful_error: None,
                                force_error,
                                status,
                            },
                        );
                    }
                    let status = child.wait_reaped()?;
                    return Ok(SupervisionOutcome::CancelledForcefully {
                        kind: escalation_kind,
                        status,
                    });
                }
                if Instant::now() >= deadline {
                    if let Err(force_error) = child.force_terminate_tree() {
                        let status = wait_until_reaped_after_control_failure(child, policy.poll_interval)?;
                        return Ok(SupervisionOutcome::CancellationControlFailedButTerminated {
                            kind,
                            graceful_error: None,
                            force_error,
                            status,
                        });
                    }
                    let status = child.wait_reaped()?;
                    return Ok(SupervisionOutcome::CancelledForcefully { kind, status });
                }
                std::thread::sleep(policy.poll_interval);
            }
        }
        std::thread::sleep(policy.poll_interval);
    }
}

fn wait_until_reaped_after_control_failure(
    child: &mut dyn SupervisedChild,
    poll_interval: Duration,
) -> std::io::Result<ExitStatus> {
    // Returning while this probe says the child is live would drop both the
    // process handle and the session lease. Retain supervision until the OS
    // proves termination. A platform implementation may remain here if the
    // process is unkillable; that is safer than falsely returning control.
    loop {
        if let Some(status) = child.try_wait()? {
            return Ok(status);
        }
        std::thread::sleep(poll_interval);
    }
}

#[cfg(all(test, unix))]
mod tests {
    use super::*;
    use std::os::unix::process::ExitStatusExt;

    struct ImmediateCancellation;
    impl CancellationSource for ImmediateCancellation {
        fn requested(&self) -> Option<CancellationKind> { Some(CancellationKind::Interrupt) }
    }

    struct TwoCancellationRequests {
        polls: std::sync::atomic::AtomicUsize,
    }

    impl CancellationSource for TwoCancellationRequests {
        fn requested(&self) -> Option<CancellationKind> {
            match self
                .polls
                .fetch_add(1, std::sync::atomic::Ordering::AcqRel)
            {
                0 => Some(CancellationKind::Interrupt),
                1 => Some(CancellationKind::Terminate),
                _ => None,
            }
        }
    }

    struct FakeChild { graceful_fails: bool, force_fails: bool, force_attempted: bool, reaped: bool }
    impl SupervisedChild for FakeChild {
        fn id(&self) -> u32 { 1 }
        fn try_wait(&mut self) -> std::io::Result<Option<ExitStatus>> {
            if self.force_fails && self.force_attempted {
                self.reaped = true;
                Ok(Some(ExitStatus::from_raw(9)))
            } else { Ok(None) }
        }
        fn request_graceful_shutdown(&mut self, _: CancellationKind) -> std::io::Result<()> {
            if self.graceful_fails { Err(std::io::Error::other("graceful")) } else { Ok(()) }
        }
        fn force_terminate_tree(&mut self) -> std::io::Result<()> {
            self.force_attempted = true;
            if self.force_fails { Err(std::io::Error::other("force")) } else { Ok(()) }
        }
        fn wait_reaped(&mut self) -> std::io::Result<ExitStatus> {
            self.reaped = true;
            Ok(ExitStatus::from_raw(9))
        }
    }

    #[test]
    fn graceful_signal_failure_escalates_and_reaps() {
        let mut child = FakeChild { graceful_fails: true, force_fails: false, force_attempted: false, reaped: false };
        let outcome = wait_with_cancellation(
            &mut child,
            &ImmediateCancellation,
            CancellationPolicy { graceful_timeout: Duration::ZERO, poll_interval: Duration::ZERO },
        ).unwrap();
        assert!(matches!(outcome, SupervisionOutcome::CancelledForcefully { .. }));
        assert!(child.reaped);
    }

    #[test]
    fn failed_force_is_never_reported_as_completed() {
        let mut child = FakeChild { graceful_fails: true, force_fails: true, force_attempted: false, reaped: false };
        let outcome = wait_with_cancellation(
            &mut child,
            &ImmediateCancellation,
            CancellationPolicy { graceful_timeout: Duration::ZERO, poll_interval: Duration::ZERO },
        ).unwrap();
        assert!(matches!(outcome, SupervisionOutcome::CancellationControlFailedButTerminated { .. }));
        assert!(child.reaped);
    }

    #[test]
    fn second_cancellation_forces_immediate_escalation() {
        let mut child = FakeChild {
            graceful_fails: false,
            force_fails: false,
            force_attempted: false,
            reaped: false,
        };
        let cancellation = TwoCancellationRequests {
            polls: std::sync::atomic::AtomicUsize::new(0),
        };

        let outcome = wait_with_cancellation(
            &mut child,
            &cancellation,
            CancellationPolicy {
                graceful_timeout: Duration::from_secs(60),
                poll_interval: Duration::ZERO,
            },
        )
        .unwrap();

        assert!(matches!(
            outcome,
            SupervisionOutcome::CancelledForcefully {
                kind: CancellationKind::Terminate,
                ..
            }
        ));
        assert!(child.force_attempted);
        assert!(child.reaped);
    }
}
