use std::env;
use std::fmt;
use std::fs as std_fs;
use std::path::{Component, Path, PathBuf};

use serde::{Deserialize, Serialize};

pub mod build;
pub mod core_provenance;
pub mod data;
pub mod fs;
pub mod identity;
pub mod process;
pub mod project;
pub mod publication;
pub mod session;
pub mod supervision;
pub use publication::{
    PublishedRuntimePair, RuntimePairCleanupWarning, RuntimePairPublicationError,
    RuntimePairTransactionError,
    publish_runtime_pair,
};
pub use lexicon_core::MANAGED_RUNNER_TEMPLATE_VERSION;


#[derive(Debug)]
pub enum ManagedWorkspaceValidationError {
    CoreDependency(crate::build::CoreDependencyError),
    MissingManifest(String),
    ManifestParseFailed(String),
    InvalidMembers {
        expected: Vec<String>,
        found: Vec<String>,
    },
    MissingImplementation(String),
    MissingRunner(String),
    MissingLibrarySource(String),
    MissingRunnerSource(String),
    ImplNameMismatch {
        expected: String,
        found: String,
    },
    RunnerNameMismatch {
        expected: String,
        found: String,
    },
    BinaryNameMismatch {
        expected: String,
        found: String,
    },
    InvalidRunnerTemplate(String),
    CustomCargoProfile,
    LegacyLayout(String),
    ExtraWorkspaceMembers(Vec<String>),
}

impl fmt::Display for ManagedWorkspaceValidationError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::CoreDependency(error) => write!(formatter, "managed Core dependency admission failed: {error}"),
            Self::CustomCargoProfile => formatter.write_str(
                "managed workspaces may not define custom Cargo profiles",
            ),
            Self::MissingManifest(message)
            | Self::ManifestParseFailed(message)
            | Self::InvalidRunnerTemplate(message)
            | Self::LegacyLayout(message) => formatter.write_str(message),
            Self::InvalidMembers { expected, found } => write!(
                formatter,
                "managed workspace has incorrect members: expected {:?}, found {:?}",
                expected, found
            ),
            Self::MissingImplementation(operation) => {
                write!(
                    formatter,
                    "missing managed {operation} implementation manifest"
                )
            }
            Self::MissingRunner(operation) => {
                write!(formatter, "missing managed {operation} runner manifest")
            }
            Self::MissingLibrarySource(operation) => {
                write!(
                    formatter,
                    "missing managed {operation} implementation library"
                )
            }
            Self::MissingRunnerSource(operation) => {
                write!(formatter, "missing managed {operation} runner source")
            }
            Self::ImplNameMismatch { expected, found } => write!(
                formatter,
                "managed implementation package name mismatch: expected '{expected}', found '{found}'"
            ),
            Self::RunnerNameMismatch { expected, found } => write!(
                formatter,
                "managed runner package name mismatch: expected '{expected}', found '{found}'"
            ),
            Self::BinaryNameMismatch { expected, found } => write!(
                formatter,
                "managed runner binary name mismatch: expected '{expected}', found '{found}'"
            ),
            Self::ExtraWorkspaceMembers(members) => write!(
                formatter,
                "managed workspace contains unexpected extra members: {:?}",
                members
            ),
        }
    }
}

impl std::error::Error for ManagedWorkspaceValidationError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::CoreDependency(error) => Some(error),
            _ => None,
        }
    }
}

#[derive(Debug)]
pub enum ManagedWorkspaceMetadataError {
    CoreDependency(crate::build::CoreDependencyError),
    CoreMetadata(crate::build::CoreMetadataError),
    CommandFailed(crate::build::CargoExecutionError),
    Decode { path: PathBuf, source: serde_json::Error },
    OutputInvalid(String),
    PackageNotFound { name: String },
}

impl fmt::Display for ManagedWorkspaceMetadataError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::CoreDependency(error) => write!(formatter, "managed Core dependency admission failed: {error}"),
            Self::CoreMetadata(error) => write!(formatter, "managed Core resolution failed: {error}"),
            Self::CommandFailed(error) => write!(formatter, "managed Cargo metadata failed: {error}"),
            Self::Decode { path, source } => write!(formatter, "failed to decode Cargo metadata for {}: {source}", path.display()),
            Self::OutputInvalid(message) => formatter.write_str(message),
            Self::PackageNotFound { name } => {
                write!(formatter, "workspace metadata package not found: {name}")
            }
        }
    }
}

impl std::error::Error for ManagedWorkspaceMetadataError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::CoreDependency(error) => Some(error),
            Self::CoreMetadata(error) => Some(error),
            Self::CommandFailed(error) => Some(error),
            Self::Decode { source, .. } => Some(source),
            _ => None,
        }
    }
}

#[derive(Debug)]
pub enum ManagedRunnerArtifactSelectionError {
    MetadataDependency(crate::build::CoreDependencyError),
    MetadataCore(crate::build::CoreMetadataError),
    MetadataCommand(crate::build::CargoExecutionError),
    MetadataDecode { path: PathBuf, source: serde_json::Error },
    MetadataOutput(String),
    PackageNotFound {
        name: String,
    },
    NoMatchingArtifact {
        package_id: String,
        binary_name: String,
    },
    MultipleMatchingArtifacts {
        package_id: String,
        binary_name: String,
    },
    MissingExecutablePath {
        package_id: String,
        binary_name: String,
    },
    ExecutableUnavailable {
        path: PathBuf,
        source: std::io::Error,
    },
    ExecutableOutsideTarget {
        path: PathBuf,
        target: PathBuf,
    },
    MalformedJsonLine {
        line: String,
        source: serde_json::Error,
    },
}

impl fmt::Display for ManagedRunnerArtifactSelectionError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::MetadataDependency(error) => write!(formatter, "managed Core dependency metadata failed: {error}"),
            Self::MetadataCore(error) => write!(formatter, "managed Core resolution metadata failed: {error}"),
            Self::MetadataCommand(error) => write!(formatter, "managed Cargo metadata failed: {error}"),
            Self::MetadataDecode { path, source } => write!(formatter, "failed to decode Cargo metadata for {}: {source}", path.display()),
            Self::MetadataOutput(message) => formatter.write_str(message),
            Self::PackageNotFound { name } => {
                write!(
                    formatter,
                    "workspace package not found for managed runner build: {name}"
                )
            }
            Self::NoMatchingArtifact {
                package_id,
                binary_name,
            } => write!(
                formatter,
                "no matching managed runner artifact for package '{package_id}' binary '{binary_name}'"
            ),
            Self::MultipleMatchingArtifacts {
                package_id,
                binary_name,
            } => write!(
                formatter,
                "multiple managed runner artifacts matched package '{package_id}' binary '{binary_name}'"
            ),
            Self::MissingExecutablePath {
                package_id,
                binary_name,
            } => write!(
                formatter,
                "managed runner artifact for package '{package_id}' binary '{binary_name}' did not include an executable path"
            ),
            Self::ExecutableUnavailable { path, source } => write!(
                formatter,
                "managed runner artifact executable {} is unavailable: {source}",
                path.display()
            ),
            Self::ExecutableOutsideTarget { path, target } => write!(
                formatter,
                "managed runner artifact executable {} is outside the isolated release directory {}",
                path.display(),
                target.display()
            ),
            Self::MalformedJsonLine { line, source } => {
                write!(formatter, "malformed cargo JSON line '{line}': {source}")
            }
        }
    }
}

impl std::error::Error for ManagedRunnerArtifactSelectionError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::MetadataDependency(error) => Some(error),
            Self::MetadataCore(error) => Some(error),
            Self::MetadataCommand(error) => Some(error),
            Self::MetadataDecode { source, .. } => Some(source),
            Self::ExecutableUnavailable { source, .. } => Some(source),
            Self::MalformedJsonLine { source, .. } => Some(source),
            _ => None,
        }
    }
}

#[derive(Debug)]
pub enum ManagedRunnerBuildError {
    ArtifactSelection(ManagedRunnerArtifactSelectionError),
    CargoExecution(crate::build::CargoExecutionError),
    ExecutableNotFile(PathBuf),
}

impl fmt::Display for ManagedRunnerBuildError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::ArtifactSelection(error) => write!(
                formatter,
                "managed runner artifact selection failed: {error}"
            ),
            Self::CargoExecution(error) => write!(formatter, "managed Cargo execution failed: {error}"),
            Self::ExecutableNotFile(path) => write!(
                formatter,
                "managed runner build did not yield a regular executable file: {}",
                path.display()
            ),
        }
    }
}

impl std::error::Error for ManagedRunnerBuildError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::ArtifactSelection(error) => Some(error),
            Self::CargoExecution(error) => Some(error),
            Self::ExecutableNotFile(_) => None,
        }
    }
}

#[derive(Debug)]
pub enum ManagedSourceBuildError {
    InvalidName(crate::identity::ManagedNameError),
    InvalidProtocol(crate::identity::ProtocolArgumentError),
    CurrentDirectory(std::io::Error),
    Project(crate::project::ProjectError),
    SourceLocation(crate::project::ProjectError),
    SourceManifest { path: PathBuf, source: SourceManifestError },
    SourceManifestRead { path: PathBuf, source: std::io::Error },
    WorkspaceValidation(ManagedWorkspaceValidationError),
    Metadata(ManagedWorkspaceMetadataError),
    CargoBuild(ManagedRunnerBuildError),
    AcquisitionVerification(crate::build::HttpRuntimeVerificationError),
    ProcessingVerification(crate::build::ProcessingRuntimeVerificationError),
    AcquisitionStaging(crate::build::RuntimeBundleStagingError),
    ProcessingStaging(crate::build::ProcessingRuntimeBundleStagingError),
    Publication(crate::publication::RuntimePairPublicationError),
    MissingLockfile(PathBuf),
    LockfileRead { path: PathBuf, source: std::io::Error },
    LockfileModified(PathBuf),
    RuntimeDirectory { path: PathBuf, source: std::io::Error },
    TemporaryBuildDirectory { operation: String, source: std::io::Error },
}

impl fmt::Display for ManagedSourceBuildError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidName(error) => write!(formatter, "invalid source name: {error}"),
            Self::InvalidProtocol(error) => write!(formatter, "invalid protocol: {error}"),
            Self::CurrentDirectory(error) => write!(formatter, "failed to determine current directory: {error}"),
            Self::Project(error) => write!(formatter, "project discovery failed: {error}"),
            Self::SourceLocation(error) => write!(formatter, "source location admission failed: {error}"),
            Self::SourceManifest { path, source } => write!(formatter, "source manifest {} failed admission: {source}", path.display()),
            Self::SourceManifestRead { path, source } => write!(formatter, "failed to read source manifest {}: {source}", path.display()),
            Self::WorkspaceValidation(error) => {
                write!(formatter, "managed workspace validation failed: {error}")
            }
            Self::Metadata(error) => {
                write!(formatter, "managed workspace metadata failed: {error}")
            }
            Self::CargoBuild(error) => write!(formatter, "managed runner build failed: {error}"),
            Self::AcquisitionVerification(error) => {
                write!(formatter, "HTTP runtime verification failed: {error}")
            }
            Self::ProcessingVerification(error) => {
                write!(formatter, "processing runtime verification failed: {error}")
            }
            Self::AcquisitionStaging(error) => {
                write!(formatter, "HTTP bundle staging failed: {error}")
            }
            Self::ProcessingStaging(error) => {
                write!(formatter, "processing bundle staging failed: {error}")
            }
            Self::Publication(error) => {
                write!(formatter, "paired runtime publication failed: {error}")
            }
            Self::MissingLockfile(path) => {
                write!(
                    formatter,
                    "missing Cargo.lock for managed workspace: {}",
                    path.display()
                )
            }
            Self::LockfileRead { path, source } => write!(formatter, "failed to read managed lockfile {}: {source}", path.display()),
            Self::LockfileModified(path) => {
                write!(
                    formatter,
                    "managed workspace lockfile changed during build: {}",
                    path.display()
                )
            }
            Self::RuntimeDirectory { path, source } => write!(formatter, "failed to create runtime directory {}: {source}", path.display()),
            Self::TemporaryBuildDirectory { operation, source } => write!(formatter, "failed to allocate isolated {operation} build directory: {source}"),
        }
    }
}

impl std::error::Error for ManagedSourceBuildError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::InvalidName(error) => Some(error),
            Self::InvalidProtocol(error) => Some(error),
            Self::CurrentDirectory(error) => Some(error),
            Self::Project(error) | Self::SourceLocation(error) => Some(error),
            Self::SourceManifest { source, .. } => Some(source),
            Self::SourceManifestRead { source, .. } => Some(source),
            Self::WorkspaceValidation(error) => Some(error),
            Self::Metadata(error) => Some(error),
            Self::CargoBuild(error) => Some(error),
            Self::AcquisitionVerification(error) => Some(error),
            Self::ProcessingVerification(error) => Some(error),
            Self::AcquisitionStaging(error) => Some(error),
            Self::ProcessingStaging(error) => Some(error),
            Self::Publication(error) => Some(error),
            Self::LockfileRead { source, .. }
            | Self::RuntimeDirectory { source, .. }
            | Self::TemporaryBuildDirectory { source, .. } => Some(source),
            Self::MissingLockfile(_) | Self::LockfileModified(_) => None,
        }
    }
}

impl lexicon_core::diagnostic::ReportableDiagnostic for ManagedSourceBuildError {
    fn diagnostic(&self) -> lexicon_core::diagnostic::Diagnostic {
        use lexicon_core::diagnostic::{Diagnostic, codes};

        match self {
            Self::InvalidName(_) => Diagnostic::operational(
                codes::SOURCE_NAME_INVALID,
                "The source name is invalid.",
            ),
            Self::InvalidProtocol(_) => Diagnostic::operational(
                codes::SOURCE_PROTOCOL_INVALID,
                "The source protocol is invalid or unsupported.",
            ),
            Self::CurrentDirectory(_) => Diagnostic::operational(
                codes::PROJECT_CURRENT_DIRECTORY_FAILED,
                "Lexicon could not determine the current directory.",
            ),
            Self::Project(_) => Diagnostic::operational(
                codes::PROJECT_DISCOVERY_FAILED,
                "Lexicon could not discover a valid project.",
            ),
            Self::SourceLocation(_) => Diagnostic::operational(
                codes::BUILD_SOURCE_LOCATION_INVALID,
                "The managed source location failed validation.",
            ),
            Self::SourceManifest { .. } => Diagnostic::operational(
                codes::SOURCE_MANIFEST_INVALID,
                "The source manifest failed validation.",
            ),
            Self::SourceManifestRead { .. } => Diagnostic::operational(
                codes::SOURCE_MANIFEST_INVALID,
                "The source manifest could not be read safely.",
            ),
            Self::WorkspaceValidation(_) => Diagnostic::operational(
                codes::BUILD_WORKSPACE_INVALID,
                "The managed source workspace failed validation.",
            ),
            Self::Metadata(_) => Diagnostic::operational(
                codes::BUILD_METADATA_FAILED,
                "Cargo metadata could not be admitted for the managed workspace.",
            ),
            Self::CargoBuild(_) => Diagnostic::operational(
                codes::BUILD_CARGO_FAILED,
                "The locked managed Cargo build failed.",
            ),
            Self::AcquisitionVerification(_) => Diagnostic::operational(
                codes::BUILD_ACQUISITION_VERIFICATION_FAILED,
                "The acquisition runtime failed verification.",
            ),
            Self::ProcessingVerification(_) => Diagnostic::operational(
                codes::BUILD_PROCESSING_VERIFICATION_FAILED,
                "The processing runtime failed verification.",
            ),
            Self::AcquisitionStaging(_) => Diagnostic::operational(
                codes::BUILD_ACQUISITION_STAGING_FAILED,
                "The acquisition runtime bundle could not be staged safely.",
            ),
            Self::ProcessingStaging(_) => Diagnostic::operational(
                codes::BUILD_PROCESSING_STAGING_FAILED,
                "The processing runtime bundle could not be staged safely.",
            ),
            Self::Publication(_) => Diagnostic::operational(
                codes::BUILD_PUBLICATION_FAILED,
                "The verified runtime pair could not be published transactionally.",
            ),
            Self::MissingLockfile(_) => Diagnostic::operational(
                codes::BUILD_LOCKFILE_MISSING,
                "A managed source workspace is missing Cargo.lock.",
            ),
            Self::LockfileRead { .. } => Diagnostic::operational(
                codes::BUILD_LOCKFILE_READ_FAILED,
                "A managed Cargo.lock could not be read safely.",
            ),
            Self::LockfileModified(_) => Diagnostic::operational(
                codes::BUILD_LOCKFILE_MODIFIED,
                "A managed Cargo.lock changed during the locked build.",
            ),
            Self::RuntimeDirectory { .. } => Diagnostic::operational(
                codes::BUILD_RUNTIME_DIRECTORY_FAILED,
                "A managed runtime directory could not be prepared.",
            ),
            Self::TemporaryBuildDirectory { .. } => Diagnostic::operational(
                codes::BUILD_TEMPORARY_DIRECTORY_FAILED,
                "An isolated build directory could not be allocated.",
            ),
        }
    }
}

#[derive(Debug, Deserialize)]
struct CargoMetadataDocument {
    workspace_members: Vec<String>,
    packages: Vec<CargoMetadataPackage>,
}

#[derive(Debug, Deserialize)]
struct CargoMetadataPackage {
    id: String,
    name: String,
    manifest_path: PathBuf,
    targets: Vec<CargoMetadataTarget>,
}

#[derive(Debug, Deserialize)]
struct CargoMetadataTarget {
    name: String,
    kind: Vec<String>,
    src_path: PathBuf,
}

/// Source manifest schema. spec §5 requires new sources to use schema 2 with
/// `[source]`, `[acquisition]`, and `[processing]` sections and four distinct
/// version fields per operation. This module rejects schema-1 documents
/// explicitly through [`SourceManifestError::UnsupportedSchemaVersion`].
pub(crate) const SOURCE_MANIFEST_SCHEMA_VERSION: u32 = 2;

#[derive(Debug, Serialize, Deserialize)]
struct SourceTomlDocument {
    schema_version: u32,
    source: Option<SourceTomlSection>,
    acquisition: Option<SourceOperationSection>,
    processing: Option<SourceOperationSection>,
}

#[derive(Debug, Serialize, Deserialize, Default)]
struct SourceTomlSection {
    name: String,
    protocol: String,
}

#[derive(Debug, Serialize, Deserialize, Default)]
struct SourceOperationSection {
    /// Canonical contract identifier (e.g. `"native-rust-http-source-v1"`).
    contract: String,
    runner_template: u32,
    core_contract: u32,
    runtime_protocol: u32,
}

/// Distinct per-operation contract version fields parsed out of a schema-2
/// source manifest, with the canonical Core-side contract identifier stripped
/// out (the struct holds the parsed numeric versions; the parsed identifier is
/// validated separately in [`load_source_metadata`]).
#[derive(Debug, PartialEq, Eq)]
pub(crate) struct SourceOperationVersions {
    pub(crate) runner_template: u32,
    pub(crate) core_contract: u32,
    pub(crate) runtime_protocol: u32,
}

/// Typed source-manifest validation/parse errors. Replaces the schema-1 era
/// of returning ad-hoc `String` errors so tests can assert on a stable
/// variant instead of substring matching. `expected` carries owned `String`
/// values because the caller-supplied `(source_name, protocol)` pair may not
/// live for `'static`; literals for the Core-owned contract identifier are
/// converted with `.to_string()` at the construction site.
#[derive(Debug)]
pub enum SourceManifestError {
    DecodeToml(toml::de::Error),
    UnsupportedSchemaVersion { actual: u32 },
    MissingSourceSection,
    MissingSourceField { field: &'static str },
    MissingOperationSection { operation: &'static str },
    MissingOperationField { operation: &'static str, field: &'static str },
    UnexpectedContractIdentifier {
        operation: &'static str,
        expected: String,
        actual: String,
    },
    InvalidVersion {
        operation: &'static str,
        field: &'static str,
        value: u32,
        expected: u32,
    },
}

#[derive(Debug)]
pub enum SourceCreateError {
    InvalidName(crate::identity::ManagedNameError),
    InvalidProtocol(crate::identity::ProtocolArgumentError),
    CurrentDirectory(std::io::Error),
    Project(crate::project::ProjectError),
    Destination(crate::project::ProjectError),
    DestinationExists(PathBuf),
    Io {
        stage: &'static str,
        path: PathBuf,
        source: std::io::Error,
    },
    DurableFile {
        stage: &'static str,
        path: PathBuf,
        source: crate::fs::durable::DurableFileError,
    },
    Core(crate::core_provenance::CoreProvenanceError),
    SessionIdentity(lexicon_core::runtime::RuntimeInvocationValueError),
    SessionEncoding(lexicon_core::session::SessionEncodingError),
    Publication(SourcePublicationError),
}

impl fmt::Display for SourceCreateError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidName(error) => write!(formatter, "invalid source name: {error}"),
            Self::InvalidProtocol(error) => write!(formatter, "invalid source protocol: {error}"),
            Self::CurrentDirectory(error) => write!(formatter, "failed to determine current directory: {error}"),
            Self::Project(error) => write!(formatter, "failed to discover project: {error}"),
            Self::Destination(error) => write!(formatter, "invalid source destination: {error}"),
            Self::DestinationExists(path) => write!(formatter, "source destination already exists: {}", path.display()),
            Self::Io { stage, path, source } => write!(formatter, "source creation {stage} failed at {}: {source}", path.display()),
            Self::DurableFile { stage, path, source } => write!(formatter, "source creation {stage} failed at {}: {source}", path.display()),
            Self::Core(error) => write!(formatter, "managed Core materialization failed: {error}"),
            Self::SessionIdentity(error) => write!(formatter, "session identity construction failed: {error}"),
            Self::SessionEncoding(error) => write!(formatter, "initial session status encoding failed: {error}"),
            Self::Publication(error) => write!(formatter, "source publication failed: {error}"),
        }
    }
}

impl std::error::Error for SourceCreateError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::InvalidName(error) => Some(error),
            Self::InvalidProtocol(error) => Some(error),
            Self::CurrentDirectory(error) => Some(error),
            Self::Project(error) | Self::Destination(error) => Some(error),
            Self::Io { source, .. } => Some(source),
            Self::DurableFile { source, .. } => Some(source),
            Self::Core(error) => Some(error),
            Self::SessionEncoding(error) => Some(error),
            Self::Publication(error) => Some(error),
            Self::SessionIdentity(error) => Some(error),
            Self::DestinationExists(_) => None,
        }
    }
}

impl lexicon_core::diagnostic::ReportableDiagnostic for SourceCreateError {
    fn diagnostic(&self) -> lexicon_core::diagnostic::Diagnostic {
        use lexicon_core::diagnostic::{Diagnostic, codes};

        match self {
            Self::InvalidName(_) => Diagnostic::operational(
                codes::SOURCE_NAME_INVALID,
                "The source name is invalid.",
            ),
            Self::InvalidProtocol(_) => Diagnostic::operational(
                codes::SOURCE_PROTOCOL_INVALID,
                "The source protocol is invalid or unsupported.",
            ),
            Self::CurrentDirectory(_) => Diagnostic::operational(
                codes::PROJECT_CURRENT_DIRECTORY_FAILED,
                "Lexicon could not determine the current directory.",
            ),
            Self::Project(_) => Diagnostic::operational(
                codes::PROJECT_DISCOVERY_FAILED,
                "Lexicon could not discover a valid project.",
            ),
            Self::Destination(_) => Diagnostic::operational(
                codes::SOURCE_DESTINATION_INVALID,
                "The managed source destination failed validation.",
            ),
            Self::DestinationExists(_) => Diagnostic::operational(
                codes::SOURCE_DESTINATION_EXISTS,
                "The source destination already exists.",
            ),
            Self::Io { .. } | Self::DurableFile { .. } => Diagnostic::operational(
                codes::SOURCE_SCAFFOLD_IO_FAILED,
                "The source scaffold could not be created durably.",
            ),
            Self::Core(_) => Diagnostic::operational(
                codes::SOURCE_CORE_MATERIALIZATION_FAILED,
                "The pinned managed Core dependency could not be materialized.",
            ),
            Self::SessionIdentity(_) => Diagnostic::operational(
                codes::SOURCE_SESSION_IDENTITY_FAILED,
                "The initial source session identity could not be constructed.",
            ),
            Self::SessionEncoding(_) => Diagnostic::operational(
                codes::SOURCE_SESSION_ENCODING_FAILED,
                "The initial source session state could not be encoded.",
            ),
            Self::Publication(_) => Diagnostic::operational(
                codes::SOURCE_PUBLICATION_FAILED,
                "The complete source scaffold could not be published atomically.",
            ),
        }
    }
}

impl fmt::Display for SourceManifestError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::DecodeToml(error) => write!(formatter, "source manifest TOML is invalid: {error}"),
            Self::UnsupportedSchemaVersion { actual } => write!(
                formatter,
                "unsupported source-manifest schema_version: expected {SOURCE_MANIFEST_SCHEMA_VERSION} but found {actual}"
            ),
            Self::MissingSourceSection => formatter.write_str(
                "source manifest is missing the [source] section",
            ),
            Self::MissingSourceField { field } => write!(
                formatter,
                "source manifest [source] section is missing required field '{field}'"
            ),
            Self::MissingOperationSection { operation } => write!(
                formatter,
                "source manifest is missing the [{operation}] section; schema 2 requires both [acquisition] and [processing]"
            ),
            Self::MissingOperationField { operation, field } => write!(
                formatter,
                "source manifest [{operation}] section is missing required field '{field}'"
            ),
            Self::UnexpectedContractIdentifier {
                operation,
                expected,
                actual,
            } => write!(
                formatter,
                "source manifest [{operation}].contract identifier is '{actual}'; expected '{expected}'"
            ),
            Self::InvalidVersion {
                operation,
                field,
                value,
                expected,
            } => write!(
                formatter,
                "source manifest [{operation}].{field} = {value} does not match the expected Core version {expected}"
            ),
        }
    }
}

impl std::error::Error for SourceManifestError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::DecodeToml(error) => Some(error),
            _ => None,
        }
    }
}

#[derive(Debug)]
pub enum ProjectRootDiscoveryError {
    InvalidProject(crate::project::ProjectError),
}

impl fmt::Display for ProjectRootDiscoveryError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self { Self::InvalidProject(error) => write!(formatter, "{error}") }
    }
}

impl std::error::Error for ProjectRootDiscoveryError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self { Self::InvalidProject(error) => Some(error) }
    }
}

#[derive(Debug)]
pub enum ProjectConfigLoadError {
    InvalidProject(crate::project::ProjectError),
}

impl fmt::Display for ProjectConfigLoadError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self { Self::InvalidProject(error) => write!(formatter, "{error}") }
    }
}

impl std::error::Error for ProjectConfigLoadError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self { Self::InvalidProject(error) => Some(error) }
    }
}

pub mod commands {
    use super::*;
    use std::path::{Path, PathBuf};

    #[derive(Debug)]
    pub struct InitResult {
        pub project_directory: PathBuf,
    }

    #[derive(Debug)]
    pub struct SourceCreateResult {
        pub source_name: String,
        pub protocol: String,
        pub protocol_dir: PathBuf,
        pub created_files: Vec<PathBuf>,
    }

    #[derive(Debug)]
    pub struct SourceBuildResult {
        pub source_name: String,
        pub protocol: String,
        pub get_runtime: PathBuf,
        pub process_runtime: PathBuf,
        pub cleanup_warnings: Vec<RuntimePairCleanupWarning>,
    }

    pub fn init(parent_path: &Path, project_name: &str) -> Result<InitResult, String> {
        let project_directory = initialize_project(parent_path, project_name)?;
        Ok(InitResult { project_directory })
    }

    pub fn source_create(source_name: &str, protocol: &str) -> Result<SourceCreateResult, SourceCreateError> {
        generate_source_scaffold(source_name, protocol)
    }

    pub fn source_build(source_name: &str, protocol: &str) -> Result<SourceBuildResult, ManagedSourceBuildError> {
        build_source(source_name, protocol)
    }

    /// A single discovered source/protocol pairing that failed the per-source
    /// build pipeline during a workspace-wide `lexicon build` run.
    #[derive(Debug)]
    pub struct SourceBuildFailure {
        pub source_name: String,
        pub protocol: String,
        pub error: ManagedSourceBuildError,
    }

    /// Aggregate result of a `lexicon build` workspace-wide discovery-and-build
    /// run. Every discovered source/protocol pairing is attempted independently;
    /// a failure in one pairing does not prevent the others from being attempted.
    #[derive(Debug)]
    pub struct BuildAllOutcome {
        pub succeeded: Vec<SourceBuildResult>,
        pub failed: Vec<SourceBuildFailure>,
    }

    impl BuildAllOutcome {
        pub fn is_success(&self) -> bool {
            self.failed.is_empty()
        }
    }

    /// Deterministically discover every supported source/protocol pairing
    /// under the project's configured sources directory, then run the same
    /// validated per-source build pipeline used by [`source_build`] for each
    /// pair in stable order. Every discovered pair is attempted, even if
    /// earlier pairs fail. See [`super::BuildAllError`] for the typed error
    /// surface used by this function.
    pub fn build_all() -> Result<BuildAllOutcome, BuildAllError> {
        let targets = discover_build_targets()?;

        let mut succeeded = Vec::new();
        let mut failed = Vec::new();
        for (source_name, protocol) in targets {
            match source_build(&source_name, &protocol) {
                Ok(result) => succeeded.push(result),
                Err(error) => failed.push(SourceBuildFailure {
                    source_name,
                    protocol,
                    error,
                }),
            }
        }

        Ok(BuildAllOutcome { succeeded, failed })
    }
}

/// Errors produced by [`commands::build_all`] during the discovery phase or
/// for sources that fail the per-source build pipeline. Per-pairing build
/// failures are captured in [`commands::SourceBuildFailure`] inside
/// [`commands::BuildAllOutcome`]; only discovery-phase failures raise this
/// typed error to abort the workspace-wide run before any `cargo build` runs.
#[derive(Debug)]
pub enum BuildAllError {
    /// The current directory cannot be determined.
    CurrentDirectory(std::io::Error),
    /// The containing Lexicon project could not be discovered or configured.
    ProjectDiscovery(ProjectRootDiscoveryError),
    /// The sources directory entry under the project root is not a directory.
    SourcesRootNotADirectory { path: PathBuf },
    SymlinkNotPermitted { path: PathBuf },
    InvalidSourceIdentity {
        path: PathBuf,
        error: crate::identity::ManagedNameError,
    },
    InvalidProtocolIdentity { path: PathBuf },
    /// A non-directory entry exists directly inside the sources root.
    NonDirectoryInSourcesRoot { path: PathBuf },
    /// A non-directory entry exists inside a source directory.
    NonDirectoryInSource { source: PathBuf, path: PathBuf },
    /// A source directory contains no recognized protocol directories.
    NoRecognizedProtocolDirectories { source: PathBuf },
    /// `source.toml` is missing or failed schema-2 pre-flight validation.
    InvalidSourceManifest {
        source: PathBuf,
        manifest: PathBuf,
        error: SourceManifestError,
    },
}

impl fmt::Display for BuildAllError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::CurrentDirectory(error) => {
                write!(formatter, "failed to determine current directory: {error}")
            }
            Self::ProjectDiscovery(error) => {
                write!(formatter, "failed to discover Lexicon project: {error}")
            }
            Self::SourcesRootNotADirectory { path } => write!(
                formatter,
                "configured sources directory '{}' is not a directory",
                path.display()
            ),
            Self::SymlinkNotPermitted { path } => write!(
                formatter,
                "managed build-discovery path '{}' must not be a symbolic link",
                path.display()
            ),
            Self::InvalidSourceIdentity { path, error } => write!(
                formatter,
                "source directory '{}' has an invalid exact identity: {error}",
                path.display()
            ),
            Self::InvalidProtocolIdentity { path } => write!(
                formatter,
                "protocol directory '{}' is not the exact supported protocol 'http'",
                path.display()
            ),
            Self::NonDirectoryInSourcesRoot { path } => write!(
                formatter,
                "sources directory contains a non-directory entry '{}'; only source directories are permitted",
                path.display()
            ),
            Self::NonDirectoryInSource { source, path } => write!(
                formatter,
                "source directory '{}' contains a non-directory entry '{}'; only protocol directories are permitted",
                source.display(),
                path.display()
            ),
            Self::NoRecognizedProtocolDirectories { source } => write!(
                formatter,
                "source directory '{}' does not contain any recognized protocol directories",
                source.display()
            ),
            Self::InvalidSourceManifest {
                source,
                manifest,
                error,
            } => write!(
                formatter,
                "source manifest failed validation: source='{}' manifest='{}' error={}",
                source.display(),
                manifest.display(),
                error
            ),
        }
    }
}

impl std::error::Error for BuildAllError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::CurrentDirectory(error) => Some(error),
            Self::ProjectDiscovery(error) => Some(error),
            _ => None,
        }
    }
}

impl lexicon_core::diagnostic::ReportableDiagnostic for BuildAllError {
    fn diagnostic(&self) -> lexicon_core::diagnostic::Diagnostic {
        use lexicon_core::diagnostic::{Diagnostic, codes};

        match self {
            Self::CurrentDirectory(_) => Diagnostic::operational(
                codes::PROJECT_CURRENT_DIRECTORY_FAILED,
                "Lexicon could not determine the current directory.",
            ),
            Self::ProjectDiscovery(_) => Diagnostic::operational(
                codes::PROJECT_DISCOVERY_FAILED,
                "Lexicon could not discover a valid project.",
            ),
            Self::SourcesRootNotADirectory { .. }
            | Self::SymlinkNotPermitted { .. }
            | Self::InvalidSourceIdentity { .. }
            | Self::InvalidProtocolIdentity { .. }
            | Self::NonDirectoryInSourcesRoot { .. }
            | Self::NonDirectoryInSource { .. }
            | Self::NoRecognizedProtocolDirectories { .. } => Diagnostic::operational(
                codes::BUILD_DISCOVERY_LAYOUT_INVALID,
                "The project source layout is not valid for deterministic build discovery.",
            ),
            Self::InvalidSourceManifest { .. } => Diagnostic::operational(
                codes::SOURCE_MANIFEST_INVALID,
                "A discovered source manifest failed validation.",
            ),
        }
    }
}

fn initialize_project(parent_path: &Path, project_name: &str) -> Result<PathBuf, String> {
    let project_name = crate::identity::ManagedName::parse(project_name)
        .map_err(|error| format!("invalid project name {project_name:?}: {error}"))?;
    let project_name = project_name.as_str();

    if !parent_path.exists() {
        return Err(format!(
            "parent path '{}' does not exist",
            parent_path.display()
        ));
    }
    if !parent_path.is_dir() {
        return Err(format!(
            "parent path '{}' is not a directory",
            parent_path.display()
        ));
    }

    let canonical_parent = parent_path.canonicalize().map_err(|error| {
        format!(
            "failed to canonicalize parent path '{}': {error}",
            parent_path.display()
        )
    })?;

    let project_directory = canonical_parent.join(project_name);
    if project_directory.exists() {
        return Err(format!(
            "project '{}' already exists at {}",
            project_name,
            project_directory.display()
        ));
    }

    let staging = tempfile::Builder::new()
        .prefix(&format!(".{project_name}.tmp-"))
        .tempdir_in(&canonical_parent)
        .map_err(|error| format!("failed to create temporary project: {error}"))?;

    std_fs::create_dir(staging.path().join("sources"))
        .map_err(|error| format!("failed to create sources directory: {error}"))?;

    let config = toml::Value::Table({
        let mut root = toml::map::Map::new();
        root.insert("schema_version".to_string(), toml::Value::Integer(1));

        let mut project = toml::map::Map::new();
        project.insert(
            "name".to_string(),
            toml::Value::String(project_name.to_string()),
        );
        root.insert("project".to_string(), toml::Value::Table(project));

        let mut paths = toml::map::Map::new();
        paths.insert(
            "sources_directory".to_string(),
            toml::Value::String("sources".to_string()),
        );
        root.insert("paths".to_string(), toml::Value::Table(paths));

        root
    });

    let toml_text = toml::to_string_pretty(&config)
        .map_err(|error| format!("failed to serialize project config: {error}"))?;

    crate::fs::durable::write_new_file(
        &staging.path().join("lexicon.toml"),
        toml_text.as_bytes(),
    )
    .map_err(|error| format!("failed to durably write lexicon.toml: {error}"))?;
    crate::fs::durable::sync_subtree_bottom_up(staging.path())
        .map_err(|error| format!("failed to sync staged project tree: {error}"))?;

    let staging_path = staging.keep();
    if let Err(error) = std_fs::rename(&staging_path, &project_directory) {
        let _ = std_fs::remove_dir_all(&staging_path);
        return Err(format!(
            "failed to finalize project '{}': {error}",
            project_directory.display()
        ));
    }
    crate::fs::durable::sync_directory(&canonical_parent)
        .map_err(|error| format!("failed to sync project parent after publication: {error}"))?;

    Ok(project_directory)
}

fn generate_source_scaffold(
    source_name: &str,
    protocol: &str,
) -> Result<commands::SourceCreateResult, SourceCreateError> {
    let source = crate::identity::ManagedName::parse(source_name)
        .map_err(SourceCreateError::InvalidName)?;
    let protocol = crate::identity::ManagedProtocol::parse(protocol)
        .map_err(SourceCreateError::InvalidProtocol)?;
    let current_dir = env::current_dir()
        .map_err(SourceCreateError::CurrentDirectory)?;
    let project = crate::project::Project::discover_from(&current_dir)
        .map_err(SourceCreateError::Project)?;
    let destination = project
        .source_destination(source.clone(), protocol)
        .map_err(SourceCreateError::Destination)?;
    let source_root = project.sources_root().to_path_buf();
    let source_dir = destination.source_root().to_path_buf();
    let protocol_dir = destination.protocol_root().to_path_buf();

    match std_fs::symlink_metadata(&source_dir) {
        Ok(_) => {
            return Err(SourceCreateError::DestinationExists(source_dir));
        }
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
        Err(error) => {
            return Err(SourceCreateError::Io {
                stage: "destination inspection",
                path: source_dir,
                source: error,
            });
        }
    }

    std_fs::create_dir_all(&source_root).map_err(|source| SourceCreateError::Io {
        stage: "sources-root creation",
        path: source_root.clone(),
        source,
    })?;

    let staging = tempfile::Builder::new()
        .prefix(&format!("{source_name}-"))
        .tempdir_in(&source_root)
        .map_err(|source| SourceCreateError::Io {
            stage: "staging allocation",
            path: source_root.clone(),
            source,
        })?;
    let staging_path = staging.path().to_path_buf();

    let directories = [
        Path::new("http/data/raw"),
        Path::new("http/data/processed"),
        Path::new("http/get-raw-data/sessions"),
        Path::new("http/get-raw-data/get-raw-data-impl/src"),
        Path::new("http/get-raw-data/lexicon-runner/src"),
        Path::new("http/get-raw-data/runtime"),
        Path::new("http/get-raw-data/state"),
        Path::new("http/process-data/sessions"),
        Path::new("http/process-data/process-data-impl/src"),
        Path::new("http/process-data/lexicon-runner/src"),
        Path::new("http/process-data/runtime"),
    ];

    for directory in &directories {
        let path = staging_path.join(directory);
        std_fs::create_dir_all(&path).map_err(|source| SourceCreateError::Io {
            stage: "staged directory creation",
            path: path.clone(),
            source,
        })?;
    }

    let get_name = format!("{source_name}-get-raw-data");
    let process_name = format!("{source_name}-process-data");
    let get_runner_name = format!("{source_name}-get-raw-data-runner");
    let process_runner_name = format!("{source_name}-process-data-runner");
    let get_binary_name = format!("{source_name}-get-raw-data");
    let process_binary_name = format!("{source_name}-process-data");

    crate::core_provenance::materialize_embedded_core(&staging_path.join("http/vendor"))
        .map_err(SourceCreateError::Core)?;

    let get_lockfile = crate::core_provenance::managed_workspace_lockfile(
        &get_name,
        &get_runner_name,
    )
    .map_err(SourceCreateError::Core)?;
    let process_lockfile = crate::core_provenance::managed_workspace_lockfile(
        &process_name,
        &process_runner_name,
    )
    .map_err(SourceCreateError::Core)?;
    let project_identity = lexicon_core::runtime::ProjectInvocationIdentity::new(
        project.name().as_str(),
    )
    .map_err(SourceCreateError::SessionIdentity)?;
    let acquisition_status = lexicon_core::session::SessionStatusV1::initial(
        project_identity.clone(),
        lexicon_core::runtime::OwnedRuntimeIdentity::http_acquisition(
            source.as_str(),
            lexicon_core::protocols::http::HttpSourceContractV1::CONTRACT_VERSION,
        ),
        lexicon_core::session::SessionOperation::Acquisition,
        &lexicon_core::session::SystemClock,
    )
    .to_json()
    .map_err(SourceCreateError::SessionEncoding)?;
    let processing_status = lexicon_core::session::SessionStatusV1::initial(
        project_identity,
        lexicon_core::runtime::OwnedRuntimeIdentity::http_processing(
            source.as_str(),
            lexicon_core::processing::ProcessingSourceContractV1::CONTRACT_VERSION,
        ),
        lexicon_core::session::SessionOperation::Processing,
        &lexicon_core::session::SystemClock,
    )
    .to_json()
    .map_err(SourceCreateError::SessionEncoding)?;

    let files = [
        (
            "http/source.toml",
            format_source_toml(source.as_str(), protocol.as_str()),
        ),
        ("http/discovery.md", format_discovery_markdown(source_name)),
        (
            "http/get-raw-data/Cargo.toml",
            format_workspace_cargo_toml("get-raw-data", &["get-raw-data-impl", "lexicon-runner"]),
        ),
        ("http/get-raw-data/Cargo.lock", get_lockfile),
        (
            "http/get-raw-data/get-raw-data-impl/Cargo.toml",
            format_implementation_cargo_toml(&get_name),
        ),
        (
            "http/get-raw-data/get-raw-data-impl/src/lib.rs",
            format_http_implementation_library(source_name),
        ),
        (
            "http/get-raw-data/lexicon-runner/Cargo.toml",
            format_runner_cargo_toml(
                &get_runner_name,
                &get_binary_name,
                &get_name,
                "../get-raw-data-impl",
            ),
        ),
        (
            "http/get-raw-data/lexicon-runner/src/main.rs",
            format_http_managed_runner_main(source_name),
        ),
        (
            "http/get-raw-data/runtime/.gitignore",
            "*\n!.gitignore\n".to_string(),
        ),
        ("http/get-raw-data/session_status.json", acquisition_status),
        (
            "http/process-data/Cargo.toml",
            format_workspace_cargo_toml("process-data", &["process-data-impl", "lexicon-runner"]),
        ),
        ("http/process-data/Cargo.lock", process_lockfile),
        (
            "http/process-data/process-data-impl/Cargo.toml",
            format_implementation_cargo_toml(&process_name),
        ),
        (
            "http/process-data/process-data-impl/src/lib.rs",
            format_processing_implementation_library(source_name),
        ),
        (
            "http/process-data/lexicon-runner/Cargo.toml",
            format_runner_cargo_toml(
                &process_runner_name,
                &process_binary_name,
                &process_name,
                "../process-data-impl",
            ),
        ),
        (
            "http/process-data/lexicon-runner/src/main.rs",
            format_processing_managed_runner_main(source_name),
        ),
        (
            "http/process-data/runtime/.gitignore",
            "*\n!.gitignore\n".to_string(),
        ),
        ("http/process-data/session_status.json", processing_status),
    ];

    for (relative_path, contents) in &files {
        let path = staging_path.join(relative_path);
        if let Some(parent) = path.parent() {
            std_fs::create_dir_all(parent).map_err(|source| SourceCreateError::Io {
                stage: "staged file parent creation",
                path: parent.to_path_buf(),
                source,
            })?;
        }
        crate::fs::durable::write_new_file(&path, contents.as_bytes()).map_err(|source| {
            SourceCreateError::DurableFile {
                stage: "durable staged file write",
                path: path.clone(),
                source,
            }
        })?;
    }

    crate::fs::durable::sync_subtree_bottom_up(&staging_path).map_err(|source| {
        SourceCreateError::Io {
            stage: "staged tree sync",
            path: staging_path.clone(),
            source,
        }
    })?;

    finalize_source_staging_with_sync(staging, &source_dir, |path| {
        crate::fs::durable::sync_directory(path).map(|_| ())
    })
        .map_err(SourceCreateError::Publication)?;

    let output_files = [
        "http/source.toml",
        "http/discovery.md",
        "http/get-raw-data/Cargo.toml",
        "http/get-raw-data/Cargo.lock",
        "http/get-raw-data/get-raw-data-impl/src/lib.rs",
        "http/get-raw-data/lexicon-runner/src/main.rs",
        "http/get-raw-data/session_status.json",
        "http/process-data/Cargo.toml",
        "http/process-data/Cargo.lock",
        "http/process-data/process-data-impl/src/lib.rs",
        "http/process-data/lexicon-runner/src/main.rs",
        "http/process-data/session_status.json",
    ];
    let created_files: Vec<PathBuf> = output_files.iter().map(|f| source_dir.join(f)).collect();

    Ok(commands::SourceCreateResult {
        source_name: source.into_string(),
        protocol: protocol.as_str().to_owned(),
        protocol_dir,
        created_files,
    })
}

fn build_source(
    source_name: &str,
    protocol: &str,
) -> Result<commands::SourceBuildResult, ManagedSourceBuildError> {
    let executor = crate::build::ProductionCargoExecutor::new();
    build_source_with_executor(source_name, protocol, &executor)
}

fn build_source_with_executor<E: crate::build::CargoExecutor>(
    source_name: &str,
    protocol: &str,
    executor: &E,
) -> Result<commands::SourceBuildResult, ManagedSourceBuildError> {
    let source = crate::identity::ManagedName::parse(source_name)
        .map_err(ManagedSourceBuildError::InvalidName)?;
    let protocol = crate::identity::ManagedProtocol::parse(protocol)
        .map_err(ManagedSourceBuildError::InvalidProtocol)?;

    let current_dir = env::current_dir().map_err(ManagedSourceBuildError::CurrentDirectory)?;
    let project = crate::project::Project::discover_from(&current_dir)
        .map_err(ManagedSourceBuildError::Project)?;
    let location = project.source(source.clone(), protocol)
        .map_err(ManagedSourceBuildError::SourceLocation)?;
    let protocol_root = location.protocol_root().to_path_buf();

    let source_toml = location.require_regular_file(Path::new("source.toml"))
        .map_err(ManagedSourceBuildError::SourceLocation)?;
    let source_text = std_fs::read_to_string(&source_toml).map_err(|source| {
        ManagedSourceBuildError::SourceManifestRead {
            path: source_toml.clone(),
            source,
        }
    })?;
    validate_source_toml_text(&source_text, source.as_str(), protocol.as_str()).map_err(|source| {
        ManagedSourceBuildError::SourceManifest {
            path: source_toml.clone(),
            source,
        }
    })?;

    let admit = |relative: &str| {
        location.require_directory(Path::new(relative))
            .map_err(ManagedSourceBuildError::SourceLocation)
    };
    let admit_file = |relative: &str| {
        location.require_regular_file(Path::new(relative))
            .map_err(ManagedSourceBuildError::SourceLocation)
    };
    let get_workspace = admit("get-raw-data")?;
    let process_workspace = admit("process-data")?;
    let get_workspace_manifest = admit_file("get-raw-data/Cargo.toml")?;
    let process_workspace_manifest = admit_file("process-data/Cargo.toml")?;
    let _get_lockfile = admit_file("get-raw-data/Cargo.lock")?;
    let _process_lockfile = admit_file("process-data/Cargo.lock")?;
    for required in [
        "get-raw-data/get-raw-data-impl",
        "get-raw-data/get-raw-data-impl/src",
        "get-raw-data/lexicon-runner",
        "get-raw-data/lexicon-runner/src",
        "get-raw-data/runtime",
        "process-data/process-data-impl",
        "process-data/process-data-impl/src",
        "process-data/lexicon-runner",
        "process-data/lexicon-runner/src",
        "process-data/runtime",
    ] {
        admit(required)?;
    }
    for required in [
        "get-raw-data/get-raw-data-impl/Cargo.toml",
        "get-raw-data/get-raw-data-impl/src/lib.rs",
        "get-raw-data/lexicon-runner/Cargo.toml",
        "get-raw-data/lexicon-runner/src/main.rs",
        "process-data/process-data-impl/Cargo.toml",
        "process-data/process-data-impl/src/lib.rs",
        "process-data/lexicon-runner/Cargo.toml",
        "process-data/lexicon-runner/src/main.rs",
    ] {
        admit_file(required)?;
    }

    validate_managed_workspace_layout(
        &get_workspace,
        source_name,
        "get-raw-data",
        &format!("{source_name}-get-raw-data"),
        &format!("{source_name}-get-raw-data-runner"),
        &format!("{source_name}-get-raw-data"),
    )
    .map_err(ManagedSourceBuildError::WorkspaceValidation)?;
    validate_managed_workspace_metadata_with(
        executor,
        &get_workspace,
        "get-raw-data",
        &format!("{source_name}-get-raw-data"),
        &format!("{source_name}-get-raw-data-runner"),
        &format!("{source_name}-get-raw-data"),
    )
    .map_err(ManagedSourceBuildError::Metadata)?;
    validate_managed_workspace_layout(
        &process_workspace,
        source_name,
        "process-data",
        &format!("{source_name}-process-data"),
        &format!("{source_name}-process-data-runner"),
        &format!("{source_name}-process-data"),
    )
    .map_err(ManagedSourceBuildError::WorkspaceValidation)?;
    validate_managed_workspace_metadata_with(
        executor,
        &process_workspace,
        "process-data",
        &format!("{source_name}-process-data"),
        &format!("{source_name}-process-data-runner"),
        &format!("{source_name}-process-data"),
    )
    .map_err(ManagedSourceBuildError::Metadata)?;

    let get_lockfile = get_workspace.join("Cargo.lock");
    let process_lockfile = process_workspace.join("Cargo.lock");
    let get_lockfile_before = read_lockfile_snapshot(&get_lockfile)?;
    let process_lockfile_before = read_lockfile_snapshot(&process_lockfile)?;

    let (get_runner, process_runner) = build_managed_runner_pair(
        || build_managed_runner_with_executor(
            executor,
            &get_workspace_manifest,
            &format!("{source_name}-get-raw-data-runner"),
            &format!("{source_name}-get-raw-data"),
            "get-raw-data",
        ),
        || build_managed_runner_with_executor(
            executor,
            &process_workspace_manifest,
            &format!("{source_name}-process-data-runner"),
            &format!("{source_name}-process-data"),
            "process-data",
        ),
    )?;

    ensure_lockfile_unchanged(&get_lockfile, &get_lockfile_before)?;
    ensure_lockfile_unchanged(&process_lockfile, &process_lockfile_before)?;

    let get_expected_identity = lexicon_core::runtime::OwnedRuntimeIdentity::http_acquisition(
        source_name,
        lexicon_core::protocols::http::HttpSourceContractV1::CONTRACT_VERSION,
    );
    let process_expected_identity = lexicon_core::runtime::OwnedRuntimeIdentity::http_processing(
        source_name,
        lexicon_core::processing::ProcessingSourceContractV1::CONTRACT_VERSION,
    );

    let get_verified = crate::build::verify_http_runtime_candidate_owned(
        get_runner.executable(),
        &get_expected_identity,
    )
    .map_err(ManagedSourceBuildError::AcquisitionVerification)?;
    let process_verified = crate::build::verify_processing_runtime_candidate_owned(
        process_runner.executable(),
        &process_expected_identity,
    )
    .map_err(ManagedSourceBuildError::ProcessingVerification)?;

    let get_runtime_dir = protocol_root.join("get-raw-data/runtime");
    let process_runtime_dir = protocol_root.join("process-data/runtime");
    std_fs::create_dir_all(&get_runtime_dir).map_err(|source| {
        ManagedSourceBuildError::RuntimeDirectory {
            path: get_runtime_dir.clone(),
            source,
        }
    })?;
    std_fs::create_dir_all(&process_runtime_dir).map_err(|source| {
        ManagedSourceBuildError::RuntimeDirectory {
            path: process_runtime_dir.clone(),
            source,
        }
    })?;

    let get_runtime_executable_name = format!(
        "{source_name}-get-raw-data{}",
        std::env::consts::EXE_SUFFIX,
    );
    let process_runtime_executable_name = format!(
        "{source_name}-process-data{}",
        std::env::consts::EXE_SUFFIX,
    );

    let get_bundle = crate::build::stage_verified_http_runtime_bundle(
        &get_workspace,
        &get_runtime_executable_name,
        &get_verified,
    )
    .map_err(ManagedSourceBuildError::AcquisitionStaging)?;
    let process_bundle = crate::build::stage_verified_processing_runtime_bundle(
        &process_workspace,
        &process_runtime_executable_name,
        &process_verified,
    )
    .map_err(ManagedSourceBuildError::ProcessingStaging)?;

    let mut published = crate::publication::publish_runtime_pair(
        get_bundle,
        process_bundle,
        &get_runtime_dir,
        &process_runtime_dir,
        get_verified.information().identity(),
        process_verified.information().identity(),
    )
    .map_err(ManagedSourceBuildError::Publication)?;

    let cleanup_warnings = published.take_cleanup_warnings();
    Ok(commands::SourceBuildResult {
        source_name: source.into_string(),
        protocol: protocol.as_str().to_owned(),
        get_runtime: published.acquisition_directory().to_path_buf(),
        process_runtime: published.processing_directory().to_path_buf(),
        cleanup_warnings,
    })
}

/// Deterministically discovers every supported source/protocol pairing under
/// the project's configured sources directory for a workspace-wide `lexicon build`.
///
/// A pairing is a build target only when `sources/<source>/<protocol>/source.toml`
/// exists and passes pre-flight schema-2 validation. Discovery rejects ambiguous or
/// invalid layouts (non-directory entries, invalid source names, unrecognized
/// protocol directories, protocol directories missing their `source.toml` marker,
/// malformed manifests, or a source directory containing no recognized protocol
/// directory at all) with an actionable error identifying the offending path,
/// rather than silently skipping them. An entirely absent or empty sources
/// directory is not an error; it simply yields zero targets.
///
/// The returned list is sorted lexicographically by source name, then by
/// protocol, so callers observe a stable, deterministic build order.
fn discover_build_targets() -> Result<Vec<(String, String)>, BuildAllError> {
    let current_dir = env::current_dir().map_err(BuildAllError::CurrentDirectory)?;
    let project = crate::project::Project::discover_from(&current_dir).map_err(|error| {
        BuildAllError::ProjectDiscovery(ProjectRootDiscoveryError::InvalidProject(error))
    })?;
    let sources_root = project.sources_root().to_path_buf();

    match std_fs::symlink_metadata(&sources_root) {
        Ok(metadata) if metadata.file_type().is_symlink() => {
            return Err(BuildAllError::SymlinkNotPermitted { path: sources_root });
        }
        Ok(metadata) if !metadata.is_dir() => {
            return Err(BuildAllError::SourcesRootNotADirectory { path: sources_root });
        }
        Ok(_) => {}
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => return Ok(Vec::new()),
        Err(error) => return Err(BuildAllError::CurrentDirectory(error)),
    }

    let mut source_entries = std_fs::read_dir(&sources_root)
        .map_err(BuildAllError::CurrentDirectory)?
        .collect::<Result<Vec<_>, std::io::Error>>()
        .map_err(BuildAllError::CurrentDirectory)?;
    source_entries.sort_by_key(|entry| entry.file_name());

    let mut targets = Vec::new();
    for source_entry in source_entries {
        let source_path = source_entry.path();
        let source_file_type = source_entry.file_type().map_err(BuildAllError::CurrentDirectory)?;
        if source_file_type.is_symlink() {
            return Err(BuildAllError::SymlinkNotPermitted { path: source_path });
        }
        if !source_file_type.is_dir() {
            return Err(BuildAllError::NonDirectoryInSourcesRoot {
                path: source_path,
            });
        }

        let source_name = crate::identity::ManagedName::parse_os(&source_entry.file_name())
            .map_err(|error| BuildAllError::InvalidSourceIdentity {
                path: source_path.clone(),
                error,
            })?;

        let mut protocol_entries = std_fs::read_dir(&source_path)
            .map_err(BuildAllError::CurrentDirectory)?
            .collect::<Result<Vec<_>, std::io::Error>>()
            .map_err(BuildAllError::CurrentDirectory)?;
        protocol_entries.sort_by_key(|entry| entry.file_name());

        let mut discovered_protocol_for_source = false;
        for protocol_entry in protocol_entries {
            let protocol_path = protocol_entry.path();
            let protocol_file_type = protocol_entry.file_type().map_err(BuildAllError::CurrentDirectory)?;
            if protocol_file_type.is_symlink() {
                return Err(BuildAllError::SymlinkNotPermitted { path: protocol_path });
            }
            if !protocol_file_type.is_dir() {
                return Err(BuildAllError::NonDirectoryInSource {
                    source: source_path.clone(),
                    path: protocol_path,
                });
            }

            let protocol_name = protocol_entry
                .file_name()
                .to_str()
                .and_then(|value| crate::identity::ManagedProtocol::parse(value).ok())
                .ok_or_else(|| BuildAllError::InvalidProtocolIdentity {
                    path: protocol_path.clone(),
                })?;

            let manifest_path = protocol_path.join("source.toml");
            let manifest_is_regular = std_fs::symlink_metadata(&manifest_path)
                .map(|metadata| metadata.is_file() && !metadata.file_type().is_symlink())
                .unwrap_or(false);
            if !manifest_is_regular {
                return Err(BuildAllError::InvalidSourceManifest {
                    source: source_path.clone(),
                    manifest: manifest_path,
                    error: SourceManifestError::MissingSourceSection,
                });
            }

            let manifest_contents = std_fs::read_to_string(&manifest_path)
                .map_err(BuildAllError::CurrentDirectory)?;
            validate_source_toml_text(
                &manifest_contents,
                source_name.as_str(),
                protocol_name.as_str(),
            )
                .map_err(|error| BuildAllError::InvalidSourceManifest {
                    source: source_path.clone(),
                    manifest: manifest_path,
                    error,
                })?;

            targets.push((source_name.as_str().to_owned(), protocol_name.as_str().to_owned()));
            discovered_protocol_for_source = true;
        }

        if !discovered_protocol_for_source {
            return Err(BuildAllError::NoRecognizedProtocolDirectories {
                source: source_path,
            });
        }
    }

    Ok(targets)
}

/// Parse and validate a schema-2 source manifest. Rejects non-schema-2 documents
/// with a typed [`SourceManifestError`]; rejects schema-2 documents whose
/// `contract` identifier or numeric version fields do not match the
/// canonical Core-side values; and asserts the `[source]` section identity
/// matches `(expected_name, expected_protocol)`.
fn load_source_metadata(
    path: &Path,
    expected_name: &str,
    expected_protocol: &str,
) -> Result<(), String> {
    if !path.is_file() {
        return Err(format!(
            "source manifest {} does not exist or is not a regular file",
            path.display()
        ));
    }

    let contents = std_fs::read_to_string(path)
        .map_err(|error| format!("failed to read {}: {error}", path.display()))?;
    validate_source_toml_text(&contents, expected_name, expected_protocol)
        .map_err(|error| format!("{}: {}", path.display(), error))
}

// `parse_source_toml_document` is used to validate after the structural
// validator passes; kept here only to silence dead-code warnings if the
// constructor-style parsing path is ever reintroduced.
#[allow(dead_code)]
fn parse_source_toml_document(contents: &str) -> Result<SourceTomlDocument, toml::de::Error> {
    toml::from_str(contents)
}

/// Pure-text schema-2 validator shared by tests and the file-loading helper.
fn validate_source_toml_text(
    contents: &str,
    expected_name: &str,
    expected_protocol: &str,
) -> Result<(), SourceManifestError> {
    let parsed: SourceTomlDocument = toml::from_str(contents)
        .map_err(SourceManifestError::DecodeToml)?;

    if parsed.schema_version != SOURCE_MANIFEST_SCHEMA_VERSION {
        return Err(SourceManifestError::UnsupportedSchemaVersion {
            actual: parsed.schema_version,
        });
    }

    let source = parsed.source.ok_or(SourceManifestError::MissingSourceSection)?;
    let acquisition = parsed.acquisition.ok_or(SourceManifestError::MissingOperationSection {
        operation: "acquisition",
    })?;
    let processing = parsed.processing.ok_or(SourceManifestError::MissingOperationSection {
        operation: "processing",
    })?;
    if source.name.is_empty() {
        return Err(SourceManifestError::MissingSourceField { field: "name" });
    }
    if source.protocol.is_empty() {
        return Err(SourceManifestError::MissingSourceField { field: "protocol" });
    }
    crate::identity::ManagedName::parse(&source.name).map_err(|_| {
        SourceManifestError::UnexpectedContractIdentifier {
            operation: "source",
            expected: expected_name.to_string(),
            actual: source.name.clone(),
        }
    })?;
    crate::identity::ManagedProtocol::parse(&source.protocol).map_err(|_| {
        SourceManifestError::UnexpectedContractIdentifier {
            operation: "source",
            expected: expected_protocol.to_string(),
            actual: source.protocol.clone(),
        }
    })?;
    if source.name != expected_name {
        return Err(SourceManifestError::UnexpectedContractIdentifier {
            operation: "source",
            expected: expected_name.to_string(),
            actual: source.name,
        });
    }
    if source.protocol != expected_protocol {
        return Err(SourceManifestError::UnexpectedContractIdentifier {
            operation: "source",
            expected: expected_protocol.to_string(),
            actual: source.protocol,
        });
    }

    validate_source_operation_manifest("acquisition", &acquisition)?;
    validate_source_operation_manifest("processing", &processing)?;
    Ok(())
}

fn validate_source_operation_manifest(
    operation: &'static str,
    section: &SourceOperationSection,
) -> Result<(), SourceManifestError> {
    let expected_identifier = match operation {
        "acquisition" => lexicon_core::protocols::http::HTTP_SOURCE_CONTRACT_IDENTIFIER,
        "processing" => lexicon_core::processing::PROCESSING_SOURCE_CONTRACT_IDENTIFIER,
        _ => unreachable!("only acquisition and processing are recognized as source operations"),
    };
    if section.contract.trim().is_empty() {
        return Err(SourceManifestError::MissingOperationField {
            operation,
            field: "contract",
        });
    }
    if section.contract != expected_identifier {
        return Err(SourceManifestError::UnexpectedContractIdentifier {
            operation,
            expected: expected_identifier.to_string(),
            actual: section.contract.clone(),
        });
    }

    check_source_operation_version(operation, section, "runner_template", lexicon_core::MANAGED_RUNNER_TEMPLATE_VERSION)?;
    check_source_operation_version(operation, section, "core_contract", lexicon_core::CORE_CONTRACT_VERSION)?;
    check_source_operation_version(operation, section, "runtime_protocol", lexicon_core::RUNTIME_PROTOCOL_VERSION)?;
    Ok(())
}

fn check_source_operation_version(
    operation: &'static str,
    section: &SourceOperationSection,
    field: &'static str,
    expected: u32,
) -> Result<(), SourceManifestError> {
    let actual = match field {
        "runner_template" => section.runner_template,
        "core_contract" => section.core_contract,
        "runtime_protocol" => section.runtime_protocol,
        _ => unreachable!("unknown source-manifest version field: {field}"),
    };
    if actual == 0 {
        return Err(SourceManifestError::InvalidVersion {
            operation,
            field,
            value: 0,
            expected,
        });
    }
    if actual != expected {
        return Err(SourceManifestError::InvalidVersion {
            operation,
            field,
            value: actual,
            expected,
        });
    }
    Ok(())
}

pub struct BuiltManagedRunner {
    executable: PathBuf,
    #[allow(dead_code)]
    target_directory: tempfile::TempDir,
}

impl BuiltManagedRunner {
    pub fn executable(&self) -> &Path {
        &self.executable
    }
}

fn read_lockfile_snapshot(lockfile: &Path) -> Result<Vec<u8>, ManagedSourceBuildError> {
    if !lockfile.is_file() {
        return Err(ManagedSourceBuildError::MissingLockfile(
            lockfile.to_path_buf(),
        ));
    }
    std_fs::read(lockfile).map_err(|source| {
        ManagedSourceBuildError::LockfileRead {
            path: lockfile.to_path_buf(),
            source,
        }
    })
}

fn ensure_lockfile_unchanged(
    lockfile: &Path,
    original: &[u8],
) -> Result<(), ManagedSourceBuildError> {
    let current = read_lockfile_snapshot(lockfile)?;
    if current != original {
        return Err(ManagedSourceBuildError::LockfileModified(
            lockfile.to_path_buf(),
        ));
    }
    Ok(())
}

fn load_managed_workspace_metadata(
    workspace_manifest: &Path,
) -> Result<CargoMetadataDocument, ManagedWorkspaceMetadataError> {
    let executor = crate::build::ProductionCargoExecutor::new();
    load_managed_workspace_metadata_with(&executor, workspace_manifest)
}

fn load_managed_workspace_metadata_with<E: crate::build::CargoExecutor>(
    executor: &E,
    workspace_manifest: &Path,
) -> Result<CargoMetadataDocument, ManagedWorkspaceMetadataError> {
    let invocation = crate::build::CargoInvocation::MetadataWorkspaceLockedNoDeps {
        manifest: workspace_manifest.to_path_buf(),
    };
    let output = crate::build::CargoExecutor::run(&executor, &invocation)
        .map_err(ManagedWorkspaceMetadataError::CommandFailed)?;
    serde_json::from_slice(&output.stdout).map_err(|source| {
        ManagedWorkspaceMetadataError::Decode {
            path: workspace_manifest.to_path_buf(),
            source,
        }
    })
}

fn target_has_kind(target: &CargoMetadataTarget, expected_kind: &str) -> bool {
    target.kind.iter().any(|kind| kind == expected_kind)
}

fn validate_managed_workspace_metadata(
    workspace_root: &Path,
    operation_name: &str,
    expected_impl_name: &str,
    expected_runner_name: &str,
    expected_binary_name: &str,
) -> Result<(), ManagedWorkspaceMetadataError> {
    let executor = crate::build::ProductionCargoExecutor::new();
    validate_managed_workspace_metadata_with(
        &executor,
        workspace_root,
        operation_name,
        expected_impl_name,
        expected_runner_name,
        expected_binary_name,
    )
}

fn validate_managed_workspace_metadata_with<E: crate::build::CargoExecutor>(
    executor: &E,
    workspace_root: &Path,
    operation_name: &str,
    expected_impl_name: &str,
    expected_runner_name: &str,
    expected_binary_name: &str,
) -> Result<(), ManagedWorkspaceMetadataError> {
    let admitted = crate::build::admit_managed_core_dependency(workspace_root)
        .map_err(ManagedWorkspaceMetadataError::CoreDependency)?;
    crate::build::verify_lexicon_core_metadata_with(executor, &admitted)
        .map_err(ManagedWorkspaceMetadataError::CoreMetadata)?;
    let metadata = load_managed_workspace_metadata_with(executor, &workspace_root.join("Cargo.toml"))?;
    if metadata.packages.len() != 2 {
        return Err(ManagedWorkspaceMetadataError::OutputInvalid(format!(
            "managed {operation_name} workspace metadata must contain exactly two packages, found {}",
            metadata.packages.len()
        )));
    }

    let implementation = metadata
        .packages
        .iter()
        .find(|package| package.name == expected_impl_name)
        .ok_or_else(|| ManagedWorkspaceMetadataError::PackageNotFound {
            name: expected_impl_name.to_owned(),
        })?;
    let runner = metadata
        .packages
        .iter()
        .find(|package| package.name == expected_runner_name)
        .ok_or_else(|| ManagedWorkspaceMetadataError::PackageNotFound {
            name: expected_runner_name.to_owned(),
        })?;

    let mut expected_members = vec![implementation.id.clone(), runner.id.clone()];
    expected_members.sort();
    let mut actual_members = metadata.workspace_members;
    actual_members.sort();
    if actual_members != expected_members {
        return Err(ManagedWorkspaceMetadataError::OutputInvalid(format!(
            "managed {operation_name} workspace metadata has incorrect members: expected {:?}, found {:?}",
            expected_members, actual_members
        )));
    }

    let expected_impl_manifest = workspace_root.join(format!("{operation_name}-impl/Cargo.toml"));
    if implementation.manifest_path != expected_impl_manifest {
        return Err(ManagedWorkspaceMetadataError::OutputInvalid(format!(
            "managed {operation_name} implementation manifest path mismatch: expected {}, found {}",
            expected_impl_manifest.display(),
            implementation.manifest_path.display()
        )));
    }
    let expected_runner_manifest = workspace_root.join("lexicon-runner/Cargo.toml");
    if runner.manifest_path != expected_runner_manifest {
        return Err(ManagedWorkspaceMetadataError::OutputInvalid(format!(
            "managed {operation_name} runner manifest path mismatch: expected {}, found {}",
            expected_runner_manifest.display(),
            runner.manifest_path.display()
        )));
    }

    let implementation_lib = implementation
        .targets
        .iter()
        .find(|target| target_has_kind(target, "lib"))
        .ok_or_else(|| {
            ManagedWorkspaceMetadataError::OutputInvalid(format!(
                "managed {operation_name} implementation metadata has no library target"
            ))
        })?;
    if implementation.targets.len() != 1
        || implementation_lib.kind != ["lib"]
        || implementation_lib.name.replace('_', "-") != expected_impl_name
    {
        return Err(ManagedWorkspaceMetadataError::OutputInvalid(format!(
            "managed {operation_name} implementation must expose exactly its expected library target"
        )));
    }
    if implementation_lib.src_path
        != workspace_root.join(format!("{operation_name}-impl/src/lib.rs"))
    {
        return Err(ManagedWorkspaceMetadataError::OutputInvalid(format!(
            "managed {operation_name} implementation library target path mismatch: expected {}, found {}",
            workspace_root
                .join(format!("{operation_name}-impl/src/lib.rs"))
                .display(),
            implementation_lib.src_path.display()
        )));
    }
    if implementation
        .targets
        .iter()
        .any(|target| target_has_kind(target, "bin"))
    {
        return Err(ManagedWorkspaceMetadataError::OutputInvalid(format!(
            "managed {operation_name} implementation metadata unexpectedly exposes a binary target"
        )));
    }

    let runner_bins: Vec<&CargoMetadataTarget> = runner
        .targets
        .iter()
        .filter(|target| target_has_kind(target, "bin"))
        .collect();
    if runner.targets.len() != 1 || runner_bins.len() != 1 {
        return Err(ManagedWorkspaceMetadataError::OutputInvalid(format!(
            "managed {operation_name} runner metadata must expose exactly one binary target, found {}",
            runner_bins.len()
        )));
    }
    let runner_bin = runner_bins[0];
    if runner_bin.name != expected_binary_name {
        return Err(ManagedWorkspaceMetadataError::OutputInvalid(format!(
            "managed {operation_name} runner metadata binary mismatch: expected '{expected_binary_name}', found '{}'",
            runner_bin.name
        )));
    }
    if runner_bin.src_path != workspace_root.join("lexicon-runner/src/main.rs") {
        return Err(ManagedWorkspaceMetadataError::OutputInvalid(format!(
            "managed {operation_name} runner binary target path mismatch: expected {}, found {}",
            workspace_root.join("lexicon-runner/src/main.rs").display(),
            runner_bin.src_path.display()
        )));
    }

    Ok(())
}

fn resolve_managed_package_id(
    workspace_manifest: &Path,
    package_name: &str,
) -> Result<String, ManagedRunnerArtifactSelectionError> {
    let executor = crate::build::ProductionCargoExecutor::new();
    resolve_managed_package_id_with(&executor, workspace_manifest, package_name)
}

fn resolve_managed_package_id_with<E: crate::build::CargoExecutor>(
    executor: &E,
    workspace_manifest: &Path,
    package_name: &str,
) -> Result<String, ManagedRunnerArtifactSelectionError> {
    let metadata =
        load_managed_workspace_metadata_with(executor, workspace_manifest).map_err(|error| match error {
            ManagedWorkspaceMetadataError::CommandFailed(error) => {
                ManagedRunnerArtifactSelectionError::MetadataCommand(error)
            }
            ManagedWorkspaceMetadataError::Decode { path, source } => {
                ManagedRunnerArtifactSelectionError::MetadataDecode { path, source }
            }
            ManagedWorkspaceMetadataError::OutputInvalid(message) => {
                ManagedRunnerArtifactSelectionError::MetadataOutput(message)
            }
            ManagedWorkspaceMetadataError::PackageNotFound { name } => {
                ManagedRunnerArtifactSelectionError::PackageNotFound { name }
            }
            ManagedWorkspaceMetadataError::CoreDependency(error) => {
                ManagedRunnerArtifactSelectionError::MetadataDependency(error)
            }
            ManagedWorkspaceMetadataError::CoreMetadata(error) => {
                ManagedRunnerArtifactSelectionError::MetadataCore(error)
            }
        })?;

    metadata
        .packages
        .into_iter()
        .find(|package| package.name == package_name)
        .map(|package| package.id)
        .ok_or_else(|| ManagedRunnerArtifactSelectionError::PackageNotFound {
            name: package_name.to_owned(),
        })
}

/// Strongly-typed view of a Cargo JSON `compiler-artifact` record (BUILD-01).
///
/// We deliberately reject artifacts that carry non-bin kinds, missing
/// executables, test-profile entries, or a wrong `target.name`. Previously
/// the selector matched on `serde_json::Value` lookups; this struct pins
/// every required field so a malformed record fails at the type boundary
/// instead of propagating through.
#[derive(Debug, serde::Deserialize)]
struct CompilerArtifact {
    reason: String,
    package_id: String,
    target: CargoTarget,
    profile: CargoProfile,
    executable: Option<PathBuf>,
}

#[derive(Debug, serde::Deserialize)]
struct CargoTarget {
    kind: Vec<String>,
    crate_types: Vec<String>,
    name: String,
}

#[derive(Debug, serde::Deserialize)]
struct CargoProfile {
    test: bool,
}

fn select_artifact_from_cargo_output(
    cargo_output: &str,
    expected_package_id: &str,
    expected_binary_name: &str,
    expected_target_directory: &Path,
) -> Result<PathBuf, ManagedRunnerArtifactSelectionError> {
    let expected_release_directory = expected_target_directory.join("release");
    let expected_release_canonical = expected_release_directory
        .canonicalize()
        .map_err(|source| ManagedRunnerArtifactSelectionError::ExecutableUnavailable {
            path: expected_release_directory.clone(),
            source,
        })?;

    let mut matches = Vec::new();
    let mut missing_executable_path = false;

    for line in cargo_output.lines() {
        let trimmed = line.trim();
        if trimmed.is_empty() {
            continue;
        }

        let envelope: serde_json::Value = serde_json::from_str(trimmed).map_err(|source| {
            ManagedRunnerArtifactSelectionError::MalformedJsonLine {
                line: trimmed.to_owned(),
                source,
            }
        })?;
        if envelope.get("reason").and_then(serde_json::Value::as_str) != Some("compiler-artifact") {
            continue;
        }
        let artifact: CompilerArtifact = serde_json::from_value(envelope).map_err(|source| {
            ManagedRunnerArtifactSelectionError::MalformedJsonLine {
                line: trimmed.to_owned(),
                source,
            }
        })?;
        if artifact.reason != "compiler-artifact" {
            continue;
        }
        if artifact.package_id != expected_package_id {
            continue;
        }
        if artifact.target.kind != ["bin"] {
            continue;
        }
        if artifact.target.crate_types != ["bin"] {
            continue;
        }
        if artifact.target.name != expected_binary_name {
            continue;
        }
        if artifact.profile.test {
            continue;
        }

        match artifact.executable {
            Some(path) => {
                let canonical = path.canonicalize().map_err(|source| {
                    ManagedRunnerArtifactSelectionError::ExecutableUnavailable {
                        path: path.clone(),
                        source,
                    }
                })?;
                let expected_file_name = if cfg!(windows) {
                    format!("{expected_binary_name}.exe")
                } else {
                    expected_binary_name.to_owned()
                };
                if canonical.parent() != Some(expected_release_canonical.as_path())
                    || canonical.file_name().and_then(|name| name.to_str())
                        != Some(expected_file_name.as_str())
                {
                    return Err(ManagedRunnerArtifactSelectionError::ExecutableOutsideTarget {
                        path: canonical,
                        target: expected_release_canonical.clone(),
                    });
                }
                matches.push(canonical)
            }
            None => missing_executable_path = true,
        }
    }

    match matches.len() {
        0 if missing_executable_path => {
            Err(ManagedRunnerArtifactSelectionError::MissingExecutablePath {
                package_id: expected_package_id.to_owned(),
                binary_name: expected_binary_name.to_owned(),
            })
        }
        0 => Err(ManagedRunnerArtifactSelectionError::NoMatchingArtifact {
            package_id: expected_package_id.to_owned(),
            binary_name: expected_binary_name.to_owned(),
        }),
        1 => Ok(matches.remove(0)),
        _ => Err(
            ManagedRunnerArtifactSelectionError::MultipleMatchingArtifacts {
                package_id: expected_package_id.to_owned(),
                binary_name: expected_binary_name.to_owned(),
            },
        ),
    }
}

pub fn select_managed_runner_executable(
    cargo_output: &str,
    workspace_manifest: &Path,
    expected_package_name: &str,
    expected_binary_name: &str,
    expected_target_directory: &Path,
) -> Result<PathBuf, ManagedRunnerArtifactSelectionError> {
    let executor = crate::build::ProductionCargoExecutor::new();
    select_managed_runner_executable_with(
        &executor,
        cargo_output,
        workspace_manifest,
        expected_package_name,
        expected_binary_name,
        expected_target_directory,
    )
}

fn select_managed_runner_executable_with<E: crate::build::CargoExecutor>(
    executor: &E,
    cargo_output: &str,
    workspace_manifest: &Path,
    expected_package_name: &str,
    expected_binary_name: &str,
    expected_target_directory: &Path,
) -> Result<PathBuf, ManagedRunnerArtifactSelectionError> {
    let package_id = resolve_managed_package_id_with(executor, workspace_manifest, expected_package_name)?;
    select_artifact_from_cargo_output(
        cargo_output,
        &package_id,
        expected_binary_name,
        expected_target_directory,
    )
}

pub fn move_to_backup(path: &Path) -> Result<PathBuf, String> {
    let unique = format!(
        ".backup-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap_or_default()
            .as_nanos()
    );
    let backup = path.parent().unwrap().join(unique);
    std_fs::rename(path, &backup)
        .map_err(|error| format!("failed to create backup for {}: {error}", path.display()))?;
    Ok(backup)
}

#[derive(Debug)]
pub enum SourcePublicationError {
    InvalidDestination(PathBuf),
    CreateParent { path: PathBuf, source: std::io::Error },
    Publish(std::io::Error),
    ParentSyncRolledBack(std::io::Error),
    RollbackRenameFailed {
        sync_error: std::io::Error,
        rollback_error: std::io::Error,
    },
    RollbackParentSyncFailed {
        sync_error: std::io::Error,
        rollback_sync_error: std::io::Error,
    },
}

impl fmt::Display for SourcePublicationError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidDestination(path) => write!(formatter, "source destination has no parent: {}", path.display()),
            Self::CreateParent { path, source } => write!(formatter, "failed to create source parent {}: {source}", path.display()),
            Self::Publish(error) => write!(formatter, "atomic source publication failed: {error}"),
            Self::ParentSyncRolledBack(error) => write!(
                formatter,
                "source publication parent sync failed and the final destination was removed: {error}"
            ),
            Self::RollbackRenameFailed { sync_error, rollback_error } => write!(
                formatter,
                "source publication durability is ambiguous after parent sync failure ({sync_error}); rollback rename failed: {rollback_error}"
            ),
            Self::RollbackParentSyncFailed { sync_error, rollback_sync_error } => write!(
                formatter,
                "source publication durability is ambiguous after parent sync failure ({sync_error}); rollback parent sync failed: {rollback_sync_error}"
            ),
        }
    }
}

impl std::error::Error for SourcePublicationError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::CreateParent { source, .. } | Self::Publish(source)
            | Self::ParentSyncRolledBack(source) => Some(source),
            Self::RollbackRenameFailed { sync_error, .. }
            | Self::RollbackParentSyncFailed { sync_error, .. } => Some(sync_error),
            Self::InvalidDestination(_) => None,
        }
    }
}

fn finalize_source_staging(staging: tempfile::TempDir, source_dir: &Path) -> Result<(), String> {
    finalize_source_staging_with_sync(staging, source_dir, |path| {
        crate::fs::durable::sync_directory(path).map(|_| ())
    })
        .map_err(|error| error.to_string())
}

fn finalize_source_staging_with_sync<F>(
    staging: tempfile::TempDir,
    source_dir: &Path,
    sync_parent: F,
) -> Result<(), SourcePublicationError>
where
    F: Fn(&Path) -> std::io::Result<()>,
{
    let staging_path = staging.path().to_path_buf();
    let source_parent = source_dir
        .parent()
        .ok_or_else(|| SourcePublicationError::InvalidDestination(source_dir.to_path_buf()))?;

    if !source_parent.exists() {
        std_fs::create_dir_all(source_parent).map_err(|source| SourcePublicationError::CreateParent {
            path: source_parent.to_path_buf(),
            source,
        })?;
    }

    let rename_result = std_fs::rename(&staging_path, source_dir);

    if let Err(error) = rename_result {
        let _ = std_fs::remove_dir_all(&staging_path);
        drop(staging);
        return Err(SourcePublicationError::Publish(error));
    }

    if let Err(sync_error) = sync_parent(source_parent) {
        if let Err(rollback_error) = std_fs::rename(source_dir, &staging_path) {
            return Err(SourcePublicationError::RollbackRenameFailed {
                sync_error,
                rollback_error,
            });
        }
        if let Err(rollback_sync_error) = sync_parent(source_parent) {
            drop(staging);
            return Err(SourcePublicationError::RollbackParentSyncFailed {
                sync_error,
                rollback_sync_error,
            });
        }
        drop(staging);
        return Err(SourcePublicationError::ParentSyncRolledBack(sync_error));
    }

    drop(staging);
    Ok(())
}

fn format_source_toml(source_name: &str, protocol: &str) -> String {
    let document = SourceTomlDocument {
        schema_version: SOURCE_MANIFEST_SCHEMA_VERSION,
        source: Some(SourceTomlSection {
            name: source_name.to_owned(),
            protocol: protocol.to_owned(),
        }),
        acquisition: Some(SourceOperationSection {
            contract: lexicon_core::protocols::http::HTTP_SOURCE_CONTRACT_IDENTIFIER
                .to_string(),
            runner_template: lexicon_core::MANAGED_RUNNER_TEMPLATE_VERSION,
            core_contract: lexicon_core::CORE_CONTRACT_VERSION,
            runtime_protocol: lexicon_core::RUNTIME_PROTOCOL_VERSION,
        }),
        processing: Some(SourceOperationSection {
            contract: lexicon_core::processing::PROCESSING_SOURCE_CONTRACT_IDENTIFIER
                .to_string(),
            runner_template: lexicon_core::MANAGED_RUNNER_TEMPLATE_VERSION,
            core_contract: lexicon_core::CORE_CONTRACT_VERSION,
            runtime_protocol: lexicon_core::RUNTIME_PROTOCOL_VERSION,
        }),
    };

    toml::to_string_pretty(&document)
        .unwrap_or_else(|error| panic!("failed to serialize source.toml: {error}"))
}

fn format_discovery_markdown(source_name: &str) -> String {
    let mut out = String::new();
    out.push_str(&format!("# {source_name}\n\n"));
    out.push_str("## Source description\n\n");
    out.push_str("Describe the source and the data it produces.\n\n");
    out.push_str("## Discovery method\n\n");
    out.push_str("Document how this source was discovered and why it belongs in this project.\n\n");
    out.push_str("## Acquisition endpoint or location\n\n");
    out.push_str("Record the upstream endpoint, dataset, or location used for acquisition.\n\n");
    out.push_str("## Why HTTP is the correct acquisition protocol\n\n");
    out.push_str("Explain why HTTP is the correct protocol for this source and how it matches the project contract.\n\n");
    out.push_str("## Required authentication or access conditions\n\n");
    out.push_str("List any required credentials, access restrictions, or network constraints.\n\n");
    out.push_str("## Attribution and usage notes\n\n");
    out.push_str("Capture attribution, licensing, and usage guidance for this source.\n\n");
    out.push_str("## Operational observations\n\n");
    out.push_str("Record operational notes, expected cadence, and troubleshooting observations.\n");
    out
}

fn format_workspace_cargo_toml(operation_name: &str, members: &[&str]) -> String {
    let mut out = String::new();
    out.push_str("[workspace]\n");
    out.push_str("resolver = \"2\"\n");
    out.push_str("members = [\n");
    for member in members {
        out.push_str(&format!("    \"{member}\",\n"));
    }
    out.push_str("]\n\n");
    out.push_str("[workspace.dependencies]\n");
    out.push_str("lexicon_core = { package = \"");
    out.push_str(crate::core_provenance::EMBEDDED_CORE_PACKAGE);
    out.push_str("\", path = \"");
    out.push_str(crate::core_provenance::MANAGED_CORE_RELATIVE_PATH);
    out.push_str("\", version = \"=");
    out.push_str(crate::core_provenance::EMBEDDED_CORE_VERSION);
    out.push_str("\" }\n");
    let _ = operation_name;
    out
}

fn format_implementation_cargo_toml(package_name: &str) -> String {
    let mut out = String::new();
    out.push_str("[package]\n");
    out.push_str(&format!("name = \"{package_name}\"\n"));
    out.push_str("version = \"0.1.0\"\n");
    out.push_str("edition = \"2024\"\n\n");
    out.push_str("[lib]\n");
    out.push_str("path = \"src/lib.rs\"\n\n");
    out.push_str("[dependencies]\n");
    out.push_str("lexicon_core = { workspace = true }\n");
    out
}

fn format_runner_cargo_toml(
    package_name: &str,
    binary_name: &str,
    implementation_package_name: &str,
    implementation_path: &str,
) -> String {
    let mut out = String::new();
    out.push_str("[package]\n");
    out.push_str(&format!("name = \"{package_name}\"\n"));
    out.push_str("version = \"0.1.0\"\n");
    out.push_str("edition = \"2024\"\n\n");
    out.push_str("[[bin]]\n");
    out.push_str(&format!("name = \"{binary_name}\"\n"));
    out.push_str("path = \"src/main.rs\"\n\n");
    out.push_str("[dependencies]\n");
    out.push_str(&format!(
        "source_implementation = {{ package = \"{implementation_package_name}\", path = \"{implementation_path}\" }}\n"
    ));
    out.push_str("lexicon_core = { workspace = true }\n");
    out
}

fn format_http_implementation_library(source_name: &str) -> String {
    let _ = source_name;
    let mut out = String::new();
    out.push_str("use std::ffi::OsString;\n");
    out.push_str("use lexicon_core::http::{\n");
    out.push_str("    AcquisitionResult,\n");
    out.push_str("    HttpAcquisitionContext,\n");
    out.push_str("    HttpSourceContractV1,\n");
    out.push_str("};\n\n");
    out.push_str("pub const SOURCE: HttpSourceContractV1 =\n");
    out.push_str("    HttpSourceContractV1::new(acquire);\n\n");
    out.push_str("pub fn acquire(\n");
    out.push_str("    context: &mut HttpAcquisitionContext,\n");
    out.push_str("    arguments: &[OsString],\n");
    out.push_str(") -> AcquisitionResult<()> {\n");
    out.push_str("    let _ = (context, arguments);\n");
    out.push_str("    todo!(\"implement HTTP acquisition\")\n");
    out.push_str("}\n");
    out
}

fn format_processing_implementation_library(source_name: &str) -> String {
    let _ = source_name;
    let mut out = String::new();
    out.push_str("use std::ffi::OsString;\n");
    out.push_str("use lexicon_core::processing::{\n");
    out.push_str("    ProcessingContext,\n");
    out.push_str("    ProcessingError,\n");
    out.push_str("    ProcessingResult,\n");
    out.push_str("    ProcessingSourceContractV1,\n");
    out.push_str("};\n\n");
    out.push_str("pub const PROCESSOR: ProcessingSourceContractV1 =\n");
    out.push_str("    ProcessingSourceContractV1::new(process);\n\n");
    out.push_str("pub fn process(\n");
    out.push_str("    context: &mut ProcessingContext,\n");
    out.push_str("    arguments: &[OsString],\n");
    out.push_str(") -> ProcessingResult<()> {\n");
    out.push_str("    let _ = (context, arguments);\n\n");
    out.push_str("    // Use the complete Core-managed processing protocol:\n");
    out.push_str("    //\n");
    out.push_str("    // let transactions = context.raw_transactions()?;\n");
    out.push_str("    // let database = context.create_staged_database()?;\n");
    out.push_str("    // for entry in transactions.entries() {\n");
    out.push_str("    //     match entry {\n");
    out.push_str("    //         lexicon_core::processing::ProcessingHttpRawEntry::Complete(transaction) => {\n");
    out.push_str("    //             let _ = transaction.transaction();\n");
    out.push_str("    //             // Parse recorded bodies, then insert or update rows.\n");
    out.push_str("    //         }\n");
    out.push_str("    //         lexicon_core::processing::ProcessingHttpRawEntry::Incomplete(attempt) => {\n");
    out.push_str("    //             let _ = attempt.attempt().phase();\n");
    out.push_str("    //             // Apply the source's explicit incomplete-evidence policy.\n");
    out.push_str("    //         }\n");
    out.push_str("    //     }\n");
    out.push_str("    //     // database.execute(/* source-owned SQL */)?;\n");
    out.push_str("    // }\n");
    out.push_str("    // context.publish_database(database)?;\n");
    out.push_str("    //\n");
    out.push_str("    // The source owns the schema and all SQL. Return Ok(()) only after\n");
    out.push_str("    // requesting Core-managed publication as shown above.\n\n");
    out.push_str("    Err(ProcessingError::source_message(\n");
    out.push_str("        \"processing implementation is not configured\",\n");
    out.push_str("    ))\n");
    out.push_str("}\n");
    out
}

fn format_http_managed_runner_main(source_name: &str) -> String {
    format!(
        "use std::process::ExitCode;\n\n\
use lexicon_core::http::HttpSourceContractV1;\n\
use lexicon_core::runtime::RuntimeIdentity;\n\n\
use source_implementation::SOURCE;\n\n\
const IDENTITY: RuntimeIdentity = RuntimeIdentity::http_acquisition(\"{source_name}\", HttpSourceContractV1::CONTRACT_VERSION);\n\
const LEXICON_MANAGED_RUNNER_TEMPLATE_VERSION: u32 = {MANAGED_RUNNER_TEMPLATE_VERSION};\n\n\
fn main() -> ExitCode {{\n\
    lexicon_core::runner::run_http_source(IDENTITY, &SOURCE)\n\
}}\n"
    )
}

fn format_processing_managed_runner_main(source_name: &str) -> String {
    format!(
        "use std::process::ExitCode;\n\n\
use lexicon_core::processing::ProcessingSourceContractV1;\n\
use lexicon_core::runtime::RuntimeIdentity;\n\n\
use source_implementation::PROCESSOR;\n\n\
const IDENTITY: RuntimeIdentity = RuntimeIdentity::http_processing(\"{source_name}\", ProcessingSourceContractV1::CONTRACT_VERSION);\n\
const LEXICON_MANAGED_RUNNER_TEMPLATE_VERSION: u32 = {MANAGED_RUNNER_TEMPLATE_VERSION};\n\n\
fn main() -> ExitCode {{\n\
    lexicon_core::runner::run_processing_source(IDENTITY, &PROCESSOR)\n\
}}\n"
    )
}

fn validate_managed_workspace_layout(
    workspace_root: &Path,
    source_name: &str,
    operation_name: &str,
    expected_impl_name: &str,
    expected_runner_name: &str,
    expected_binary_name: &str,
) -> Result<(), ManagedWorkspaceValidationError> {
    let manifest_path = workspace_root.join("Cargo.toml");
    if !manifest_path.is_file() {
        return Err(ManagedWorkspaceValidationError::MissingManifest(format!(
            "missing managed workspace manifest for {} at {}",
            operation_name,
            workspace_root.display()
        )));
    }

    crate::build::admit_managed_core_dependency(workspace_root)
        .map_err(ManagedWorkspaceValidationError::CoreDependency)?;

    let lockfile = workspace_root.join("Cargo.lock");
    if !lockfile.is_file() {
        return Err(ManagedWorkspaceValidationError::LegacyLayout(
            "missing Cargo.lock for managed workspace".to_owned(),
        ));
    }

    let contents = std_fs::read_to_string(&manifest_path).map_err(|error| {
        ManagedWorkspaceValidationError::ManifestParseFailed(format!(
            "failed to read {}: {error}",
            manifest_path.display()
        ))
    })?;
    let parsed: toml::Value = toml::from_str(&contents).map_err(|error| {
        ManagedWorkspaceValidationError::ManifestParseFailed(format!(
            "failed to parse {}: {error}",
            manifest_path.display()
        ))
    })?;
    if parsed.get("profile").is_some() {
        return Err(ManagedWorkspaceValidationError::CustomCargoProfile);
    }

    let members = parsed
        .get("workspace")
        .and_then(|value| value.get("members"))
        .and_then(toml::Value::as_array)
        .ok_or_else(|| ManagedWorkspaceValidationError::InvalidMembers {
            expected: vec![
                format!("{operation_name}-impl"),
                "lexicon-runner".to_string(),
            ],
            found: Vec::new(),
        })?;
    let member_names: Vec<String> = members
        .iter()
        .filter_map(|value| value.as_str().map(str::to_owned))
        .collect();
    let expected_members = vec![
        format!("{operation_name}-impl"),
        "lexicon-runner".to_string(),
    ];
    let extra_members: Vec<String> = member_names
        .iter()
        .filter(|member| !expected_members.contains(member))
        .cloned()
        .collect();
    if !extra_members.is_empty() {
        return Err(ManagedWorkspaceValidationError::ExtraWorkspaceMembers(
            extra_members,
        ));
    }
    if member_names != expected_members {
        return Err(ManagedWorkspaceValidationError::InvalidMembers {
            expected: expected_members,
            found: member_names,
        });
    }

    let impl_manifest = workspace_root.join(format!("{operation_name}-impl/Cargo.toml"));
    let runner_manifest = workspace_root.join("lexicon-runner/Cargo.toml");
    let impl_lib = workspace_root.join(format!("{operation_name}-impl/src/lib.rs"));
    let impl_main = workspace_root.join(format!("{operation_name}-impl/src/main.rs"));
    let runner_main = workspace_root.join("lexicon-runner/src/main.rs");

    if !impl_manifest.is_file() {
        return Err(ManagedWorkspaceValidationError::MissingImplementation(
            operation_name.to_owned(),
        ));
    }
    if !runner_manifest.is_file() {
        return Err(ManagedWorkspaceValidationError::MissingRunner(
            operation_name.to_owned(),
        ));
    }
    if !impl_lib.is_file() {
        return Err(ManagedWorkspaceValidationError::MissingLibrarySource(
            operation_name.to_owned(),
        ));
    }
    if !runner_main.is_file() {
        return Err(ManagedWorkspaceValidationError::MissingRunnerSource(
            operation_name.to_owned(),
        ));
    }
    if impl_main.is_file() {
        return Err(ManagedWorkspaceValidationError::LegacyLayout(format!(
            "managed {} implementation still includes a source-owned main entrypoint at {}",
            operation_name,
            impl_main.display()
        )));
    }

    let impl_doc: toml::Value =
        toml::from_str(&std_fs::read_to_string(&impl_manifest).map_err(|error| {
            ManagedWorkspaceValidationError::ManifestParseFailed(format!(
                "failed to read {}: {error}",
                impl_manifest.display()
            ))
        })?)
        .map_err(|error| {
            ManagedWorkspaceValidationError::ManifestParseFailed(format!(
                "failed to parse {}: {error}",
                impl_manifest.display()
            ))
        })?;
    let impl_name = impl_doc
        .get("package")
        .and_then(|value| value.get("name"))
        .and_then(toml::Value::as_str)
        .ok_or_else(|| {
            ManagedWorkspaceValidationError::ManifestParseFailed(format!(
                "managed {} implementation manifest has no package name",
                operation_name
            ))
        })?;
    if impl_name != expected_impl_name {
        return Err(ManagedWorkspaceValidationError::ImplNameMismatch {
            expected: expected_impl_name.to_owned(),
            found: impl_name.to_owned(),
        });
    }
    let impl_lib_path = impl_doc
        .get("lib")
        .and_then(|value| value.get("path"))
        .and_then(toml::Value::as_str)
        .ok_or_else(|| {
            ManagedWorkspaceValidationError::ManifestParseFailed(format!(
                "managed {} implementation manifest has no library target path",
                operation_name
            ))
        })?;
    if impl_lib_path != "src/lib.rs" {
        return Err(ManagedWorkspaceValidationError::ManifestParseFailed(
            format!(
                "managed {} implementation library path mismatch: expected 'src/lib.rs', found '{}'",
                operation_name, impl_lib_path
            ),
        ));
    }
    if impl_doc
        .get("bin")
        .and_then(toml::Value::as_array)
        .is_some_and(|items| !items.is_empty())
    {
        return Err(ManagedWorkspaceValidationError::LegacyLayout(format!(
            "managed {} implementation manifest unexpectedly exposes a binary target",
            operation_name
        )));
    }
    let impl_dependencies = impl_doc
        .get("dependencies")
        .and_then(toml::Value::as_table)
        .ok_or_else(|| {
            ManagedWorkspaceValidationError::ManifestParseFailed(format!(
                "managed {} implementation manifest has no dependencies table",
                operation_name
            ))
        })?;
    let impl_lexicon_core = impl_dependencies
        .get("lexicon_core")
        .and_then(toml::Value::as_table)
        .ok_or_else(|| {
            ManagedWorkspaceValidationError::ManifestParseFailed(format!(
                "managed {} implementation manifest must depend on workspace lexicon_core",
                operation_name
            ))
        })?;
    if impl_lexicon_core
        .get("workspace")
        .and_then(toml::Value::as_bool)
        != Some(true)
    {
        return Err(ManagedWorkspaceValidationError::ManifestParseFailed(
            format!(
                "managed {} implementation manifest must resolve lexicon_core through the workspace dependency",
                operation_name
            ),
        ));
    }

    let runner_contents = std_fs::read_to_string(&runner_manifest).map_err(|error| {
        ManagedWorkspaceValidationError::ManifestParseFailed(format!(
            "failed to read {}: {error}",
            runner_manifest.display()
        ))
    })?;
    let runner_doc: toml::Value =
        toml::from_str(&runner_contents)
        .map_err(|error| {
            ManagedWorkspaceValidationError::ManifestParseFailed(format!(
                "failed to parse {}: {error}",
                runner_manifest.display()
            ))
        })?;
    let runner_name = runner_doc
        .get("package")
        .and_then(|value| value.get("name"))
        .and_then(toml::Value::as_str)
        .ok_or_else(|| {
            ManagedWorkspaceValidationError::ManifestParseFailed(format!(
                "managed {} runner manifest has no package name",
                operation_name
            ))
        })?;
    if runner_name != expected_runner_name {
        return Err(ManagedWorkspaceValidationError::RunnerNameMismatch {
            expected: expected_runner_name.to_owned(),
            found: runner_name.to_owned(),
        });
    }

    let bins = runner_doc
        .get("bin")
        .and_then(|array| array.as_array())
        .ok_or_else(|| {
            ManagedWorkspaceValidationError::ManifestParseFailed(format!(
                "managed {} runner manifest has no binary target",
                operation_name
            ))
        })?;
    if bins.len() != 1 {
        return Err(ManagedWorkspaceValidationError::ManifestParseFailed(
            format!(
                "managed {} runner manifest must define exactly one binary target",
                operation_name
            ),
        ));
    }
    let runner_bin = &bins[0];
    let bin_name = runner_bin
        .get("name")
        .and_then(toml::Value::as_str)
        .ok_or_else(|| {
            ManagedWorkspaceValidationError::ManifestParseFailed(format!(
                "managed {} runner manifest has no binary target name",
                operation_name
            ))
        })?;
    if bin_name != expected_binary_name {
        return Err(ManagedWorkspaceValidationError::BinaryNameMismatch {
            expected: expected_binary_name.to_owned(),
            found: bin_name.to_owned(),
        });
    }
    let runner_bin_path = runner_bin
        .get("path")
        .and_then(toml::Value::as_str)
        .ok_or_else(|| {
            ManagedWorkspaceValidationError::ManifestParseFailed(format!(
                "managed {} runner manifest has no binary target path",
                operation_name
            ))
        })?;
    if runner_bin_path != "src/main.rs" {
        return Err(ManagedWorkspaceValidationError::ManifestParseFailed(
            format!(
                "managed {} runner binary path mismatch: expected 'src/main.rs', found '{}'",
                operation_name, runner_bin_path
            ),
        ));
    }
    let runner_dependencies = runner_doc
        .get("dependencies")
        .and_then(toml::Value::as_table)
        .ok_or_else(|| {
            ManagedWorkspaceValidationError::ManifestParseFailed(format!(
                "managed {} runner manifest has no dependencies table",
                operation_name
            ))
        })?;
    let runner_implementation_dependency = runner_dependencies
        .get("source_implementation")
        .and_then(toml::Value::as_table)
        .ok_or_else(|| {
            ManagedWorkspaceValidationError::ManifestParseFailed(format!(
                "managed {} runner manifest must depend on source_implementation",
                operation_name
            ))
        })?;
    let expected_implementation_path = format!("../{operation_name}-impl");
    if runner_implementation_dependency
        .get("path")
        .and_then(toml::Value::as_str)
        != Some(expected_implementation_path.as_str())
    {
        return Err(ManagedWorkspaceValidationError::ManifestParseFailed(
            format!(
                "managed {} runner manifest must depend on the implementation at '{}'",
                operation_name, expected_implementation_path
            ),
        ));
    }
    let runner_lexicon_core = runner_dependencies
        .get("lexicon_core")
        .and_then(toml::Value::as_table)
        .ok_or_else(|| {
            ManagedWorkspaceValidationError::ManifestParseFailed(format!(
                "managed {} runner manifest must depend on workspace lexicon_core",
                operation_name
            ))
        })?;
    if runner_lexicon_core
        .get("workspace")
        .and_then(toml::Value::as_bool)
        != Some(true)
    {
        return Err(ManagedWorkspaceValidationError::ManifestParseFailed(
            format!(
                "managed {} runner manifest must resolve lexicon_core through the workspace dependency",
                operation_name
            ),
        ));
    }
    let workspace_dependencies = parsed
        .get("workspace")
        .and_then(|value| value.get("dependencies"))
        .and_then(toml::Value::as_table)
        .ok_or_else(|| {
            ManagedWorkspaceValidationError::ManifestParseFailed(format!(
                "managed {} workspace manifest has no workspace dependencies table",
                operation_name
            ))
        })?;
    if !workspace_dependencies.contains_key("lexicon_core") {
        return Err(ManagedWorkspaceValidationError::ManifestParseFailed(
            format!(
                "managed {} workspace manifest must define workspace dependency lexicon_core",
                operation_name
            ),
        ));
    }
    let workspace_lexicon_core = workspace_dependencies
        .get("lexicon_core")
        .and_then(toml::Value::as_table)
        .ok_or_else(|| {
            ManagedWorkspaceValidationError::ManifestParseFailed(format!(
                "managed {} workspace dependency lexicon_core must be a table",
                operation_name
            ))
        })?;
    if workspace_lexicon_core
        .get("package")
        .and_then(toml::Value::as_str)
        != Some("lexicon-core")
    {
        return Err(ManagedWorkspaceValidationError::ManifestParseFailed(
            format!(
                "managed {} workspace dependency lexicon_core must target package 'lexicon-core'",
                operation_name
            ),
        ));
    }

    let expected_implementation_member = format!("{operation_name}-impl");
    let expected_workspace_manifest = format_workspace_cargo_toml(
        operation_name,
        &[expected_implementation_member.as_str(), "lexicon-runner"],
    );
    if contents != expected_workspace_manifest {
        return Err(ManagedWorkspaceValidationError::ManifestParseFailed(
            format!(
                "managed {} workspace manifest differs from the Lexicon-controlled canonical manifest",
                operation_name
            ),
        ));
    }

    let expected_runner_manifest = format_runner_cargo_toml(
        expected_runner_name,
        expected_binary_name,
        expected_impl_name,
        &expected_implementation_path,
    );
    if runner_contents != expected_runner_manifest {
        return Err(ManagedWorkspaceValidationError::ManifestParseFailed(
            format!(
                "managed {} runner manifest differs from the Lexicon-controlled canonical manifest",
                operation_name
            ),
        ));
    }

    let runner_src = std_fs::read_to_string(&runner_main).map_err(|error| {
        ManagedWorkspaceValidationError::ManifestParseFailed(format!(
            "failed to read {}: {error}",
            runner_main.display()
        ))
    })?;
    let expected_template_marker = format!(
        "const LEXICON_MANAGED_RUNNER_TEMPLATE_VERSION: u32 = {};",
        MANAGED_RUNNER_TEMPLATE_VERSION
    );
    if !runner_src.contains("const LEXICON_MANAGED_RUNNER_TEMPLATE_VERSION: u32 =") {
        return Err(ManagedWorkspaceValidationError::InvalidRunnerTemplate(
            format!(
                "managed {} runner is missing the template version marker",
                operation_name
            ),
        ));
    }
    if !runner_src.contains(&expected_template_marker) {
        return Err(ManagedWorkspaceValidationError::InvalidRunnerTemplate(
            format!(
                "managed {} runner template version mismatch: expected {}",
                operation_name, MANAGED_RUNNER_TEMPLATE_VERSION
            ),
        ));
    }
    let expected_runner_src = if operation_name == "get-raw-data" {
        format_http_managed_runner_main(source_name)
    } else {
        format_processing_managed_runner_main(source_name)
    };
    if runner_src != expected_runner_src {
        return Err(ManagedWorkspaceValidationError::InvalidRunnerTemplate(
            format!(
                "managed {} runner template content differs from the managed canonical template",
                operation_name
            ),
        ));
    }

    if impl_manifest.exists()
        && std_fs::read_to_string(&impl_manifest)
            .map(|text| text.contains("src/main.rs"))
            .unwrap_or(false)
    {
        return Err(ManagedWorkspaceValidationError::LegacyLayout(format!(
            "managed {} implementation manifest still references a source-owned main entrypoint",
            operation_name
        )));
    }
    if runner_implementation_dependency
        .get("package")
        .and_then(toml::Value::as_str)
        != Some(expected_impl_name)
    {
        return Err(ManagedWorkspaceValidationError::ManifestParseFailed(
            format!(
                "managed {} runner manifest must rename source_implementation from package '{}'",
                operation_name, expected_impl_name
            ),
        ));
    }

    Ok(())
}

fn build_managed_runner(
    workspace_manifest: &Path,
    expected_package: &str,
    expected_binary: &str,
    operation_name: &str,
) -> Result<BuiltManagedRunner, ManagedSourceBuildError> {
    let executor = crate::build::ProductionCargoExecutor::new();
    build_managed_runner_with_executor(
        &executor,
        workspace_manifest,
        expected_package,
        expected_binary,
        operation_name,
    )
}

fn build_managed_runner_with_executor<E: crate::build::CargoExecutor>(
    executor: &E,
    workspace_manifest: &Path,
    expected_package: &str,
    expected_binary: &str,
    operation_name: &str,
) -> Result<BuiltManagedRunner, ManagedSourceBuildError> {
    let tempdir = tempfile::Builder::new()
        .prefix(&format!("lexicon-{operation_name}-runner-build-"))
        .tempdir()
        .map_err(|source| {
            ManagedSourceBuildError::TemporaryBuildDirectory {
                operation: operation_name.to_owned(),
                source,
            }
        })?;
    let target_dir = tempdir.path().to_path_buf();

    let invocation = crate::build::CargoInvocation::BuildReleaseLocked {
        manifest: workspace_manifest.to_path_buf(),
        package: expected_package.to_owned(),
        binary: expected_binary.to_owned(),
        target_dir: target_dir.clone(),
    };
    let output = crate::build::CargoExecutor::run(executor, &invocation).map_err(|error| {
        ManagedSourceBuildError::CargoBuild(ManagedRunnerBuildError::CargoExecution(error))
    })?;

    let cargo_json = String::from_utf8_lossy(&output.stdout);
    let artifact = select_managed_runner_executable_with(
        executor,
        &cargo_json,
        workspace_manifest,
        expected_package,
        expected_binary,
        &target_dir,
    )
    .map_err(|error| {
        ManagedSourceBuildError::CargoBuild(ManagedRunnerBuildError::ArtifactSelection(error))
    })?;
    if !artifact.is_file() {
        return Err(ManagedSourceBuildError::CargoBuild(
            ManagedRunnerBuildError::ExecutableNotFile(artifact),
        ));
    }

    Ok(BuiltManagedRunner {
        executable: artifact,
        target_directory: tempdir,
    })
}

fn build_managed_runner_pair<T, FAcquisition, FProcessing>(
    acquisition: FAcquisition,
    processing: FProcessing,
) -> Result<(T, T), ManagedSourceBuildError>
where
    FAcquisition: FnOnce() -> Result<T, ManagedSourceBuildError>,
    FProcessing: FnOnce() -> Result<T, ManagedSourceBuildError>,
{
    let acquisition = acquisition()?;
    let processing = processing()?;
    Ok((acquisition, processing))
}

#[cfg(test)]
mod tests {
    use std::fs as std_fs;
    use std::path::{Path, PathBuf};

    use lexicon_core::runtime::{OwnedRuntimeIdentity, RuntimeOperation, RuntimeProtocol};

    use super::commands::{build_all, init, source_create};
    use super::{
        BuildAllError, BuiltManagedRunner, MANAGED_RUNNER_TEMPLATE_VERSION,
        ManagedRunnerArtifactSelectionError, ManagedRunnerBuildError, ManagedSourceBuildError,
        ManagedWorkspaceMetadataError, ManagedWorkspaceValidationError, SourceManifestError,
        SourceCreateError, SourcePublicationError, discover_build_targets,
        finalize_source_staging, finalize_source_staging_with_sync,
        format_http_managed_runner_main,
        format_implementation_cargo_toml, format_processing_managed_runner_main,
        format_runner_cargo_toml, format_source_toml, format_workspace_cargo_toml,
        build_source_with_executor, load_source_metadata,
        select_artifact_from_cargo_output,
        validate_managed_workspace_layout, validate_managed_workspace_metadata,
        validate_source_toml_text,
    };

    // `with_test_cwd` changes the process-global current working directory, which is
    // shared by every thread in this test binary. `crate::data::test_support` defines
    // the single lock serializing every such change across this whole crate's test
    // suite; a second, disjoint lock here would not protect against concurrent CWD
    // changes made through that one (see `TEST_CWD_LOCK`'s doc comment there), which
    // previously let unrelated tests that spawn subprocesses (e.g. `cargo metadata`)
    // observe a momentarily-invalid working directory.
    use crate::data::test_support::with_test_cwd;

    fn unique_test_dir(prefix: &str) -> tempfile::TempDir {
        tempfile::Builder::new().prefix(prefix).tempdir().unwrap()
    }

    fn write_valid_managed_workspace(root: &Path, source_name: &str, operation_name: &str) {
        let impl_name = if operation_name == "get-raw-data" {
            format!("{source_name}-get-raw-data")
        } else {
            format!("{source_name}-process-data")
        };
        let runner_name = if operation_name == "get-raw-data" {
            format!("{source_name}-get-raw-data-runner")
        } else {
            format!("{source_name}-process-data-runner")
        };
        let binary_name = impl_name.clone();
        let impl_dir = root.join(format!("{operation_name}-impl/src"));
        let runner_dir = root.join("lexicon-runner/src");
        std_fs::create_dir_all(&impl_dir).unwrap();
        std_fs::create_dir_all(&runner_dir).unwrap();
        std_fs::write(
            root.join("Cargo.toml"),
            format_workspace_cargo_toml(
                operation_name,
                &[&format!("{operation_name}-impl"), "lexicon-runner"],
            ),
        )
        .unwrap();
        let vendor = root.parent().unwrap().join("vendor");
        if !vendor.exists() {
            crate::core_provenance::materialize_embedded_core(&vendor).unwrap();
        }
        std_fs::write(
            root.join("Cargo.lock"),
            crate::core_provenance::managed_workspace_lockfile(&impl_name, &runner_name).unwrap(),
        )
        .unwrap();
        std_fs::write(
            root.join(format!("{operation_name}-impl/Cargo.toml")),
            format_implementation_cargo_toml(&impl_name),
        )
        .unwrap();
        std_fs::write(
            root.join(format!("{operation_name}-impl/src/lib.rs")),
            "pub fn placeholder() {}\n",
        )
        .unwrap();
        std_fs::write(
            root.join("lexicon-runner/Cargo.toml"),
            format_runner_cargo_toml(
                &runner_name,
                &binary_name,
                &impl_name,
                &format!("../{operation_name}-impl"),
            ),
        )
        .unwrap();
        let main = if operation_name == "get-raw-data" {
            format_http_managed_runner_main(source_name)
        } else {
            format_processing_managed_runner_main(source_name)
        };
        std_fs::write(root.join("lexicon-runner/src/main.rs"), main).unwrap();
    }

    #[derive(Clone, Copy)]
    enum InjectedBuildFailure { Acquisition, Processing }

    struct SourcePipelineExecutor {
        failure: InjectedBuildFailure,
        invocations: std::sync::Mutex<Vec<crate::build::CargoInvocation>>,
    }

    impl SourcePipelineExecutor {
        fn new(failure: InjectedBuildFailure) -> Self {
            Self { failure, invocations: std::sync::Mutex::new(Vec::new()) }
        }

        fn invocations(&self) -> Vec<crate::build::CargoInvocation> {
            self.invocations.lock().unwrap().clone()
        }
    }

    impl crate::build::CargoExecutor for SourcePipelineExecutor {
        fn run(&self, invocation: &crate::build::CargoInvocation) -> Result<crate::build::CargoOutput, crate::build::CargoExecutionError> {
            self.invocations.lock().unwrap().push(invocation.clone());
            match invocation {
                crate::build::CargoInvocation::MetadataLocked { manifest } => {
                    let core_manifest = manifest.parent().unwrap().parent().unwrap().join("vendor/lexicon-core/Cargo.toml");
                    let id = format!("lexicon-core@{}", crate::core_provenance::EMBEDDED_CORE_VERSION);
                    let json = serde_json::json!({
                        "packages": [{
                            "id": id,
                            "name": crate::core_provenance::EMBEDDED_CORE_PACKAGE,
                            "version": crate::core_provenance::EMBEDDED_CORE_VERSION,
                            "source": null,
                            "manifest_path": core_manifest,
                        }],
                        "workspace_members": [],
                        "resolve": { "nodes": [{ "id": id }] },
                    });
                    Ok(crate::build::CargoOutput { status_code: Some(0), stdout: serde_json::to_vec(&json).unwrap(), stderr: Vec::new() })
                }
                crate::build::CargoInvocation::MetadataWorkspaceLockedNoDeps { manifest } => {
                    let workspace = manifest.parent().unwrap();
                    let operation = workspace.file_name().unwrap().to_str().unwrap();
                    let source = "example-source";
                    let (implementation, runner, binary) = if operation == "get-raw-data" {
                        (format!("{source}-get-raw-data"), format!("{source}-get-raw-data-runner"), format!("{source}-get-raw-data"))
                    } else {
                        (format!("{source}-process-data"), format!("{source}-process-data-runner"), format!("{source}-process-data"))
                    };
                    let implementation_id = format!("{implementation}@0.1.0");
                    let runner_id = format!("{runner}@0.1.0");
                    let json = serde_json::json!({
                        "workspace_members": [implementation_id, runner_id],
                        "packages": [
                            { "id": implementation_id, "name": implementation, "manifest_path": workspace.join(format!("{operation}-impl/Cargo.toml")), "targets": [{ "name": implementation.replace('-', "_"), "kind": ["lib"], "src_path": workspace.join(format!("{operation}-impl/src/lib.rs")) }] },
                            { "id": runner_id, "name": runner, "manifest_path": workspace.join("lexicon-runner/Cargo.toml"), "targets": [{ "name": binary, "kind": ["bin"], "src_path": workspace.join("lexicon-runner/src/main.rs") }] }
                        ]
                    });
                    Ok(crate::build::CargoOutput { status_code: Some(0), stdout: serde_json::to_vec(&json).unwrap(), stderr: Vec::new() })
                }
                crate::build::CargoInvocation::BuildReleaseLocked {
                    package,
                    binary,
                    target_dir,
                    ..
                } => {
                    let acquisition = package.ends_with("get-raw-data-runner");
                    if matches!((self.failure, acquisition), (InjectedBuildFailure::Acquisition, true) | (InjectedBuildFailure::Processing, false)) {
                        return Err(crate::build::CargoExecutionError::NonZeroExit {
                            invocation: invocation.clone(),
                            status_code: Some(101),
                            stdout: Vec::new(),
                            stderr: format!("injected {package} failure").into_bytes(),
                        });
                    }
                    let release = target_dir.join("release");
                    std_fs::create_dir_all(&release).unwrap();
                    let executable = release.join(if cfg!(windows) {
                        format!("{binary}.exe")
                    } else {
                        binary.clone()
                    });
                    std_fs::write(&executable, b"injected acquisition artifact").unwrap();
                    let package_id = format!("{package}@0.1.0");
                    let artifact = serde_json::json!({
                        "reason": "compiler-artifact",
                        "package_id": package_id,
                        "target": {
                            "kind": ["bin"],
                            "crate_types": ["bin"],
                            "name": binary,
                        },
                        "profile": { "test": false },
                        "executable": executable,
                    });
                    Ok(crate::build::CargoOutput {
                        status_code: Some(0),
                        stdout: format!("{artifact}\n").into_bytes(),
                        stderr: Vec::new(),
                    })
                }
                crate::build::CargoInvocation::GenerateLockfile { .. } => unreachable!(),
            }
        }
    }

    #[test]
    fn generated_source_toml_matches_required_schema_2_contract() {
        let source = format_source_toml("example-source", "http");

        assert!(source.contains("schema_version = 2"));
        assert!(source.contains("[source]"));
        assert!(source.contains("name = \"example-source\""));
        assert!(source.contains("protocol = \"http\""));

        assert!(source.contains("[acquisition]"));
        assert!(source.contains(
            "contract = \"native-rust-http-source-v1\""
        ));
        assert!(source.contains("[processing]"));
        assert!(source.contains(
            "contract = \"native-rust-processing-v1\""
        ));

        assert!(source.contains(&format!(
            "runner_template = {}",
            lexicon_core::MANAGED_RUNNER_TEMPLATE_VERSION
        )));
        assert!(source.contains(&format!(
            "core_contract = {}",
            lexicon_core::CORE_CONTRACT_VERSION
        )));
        assert!(source.contains(&format!(
            "runtime_protocol = {}",
            lexicon_core::RUNTIME_PROTOCOL_VERSION
        )));

        assert!(!source.contains("id = \"example-source\""));
    }

    #[test]
    fn schema_2_text_round_trips_through_validator() {
        let canonical = format_source_toml("example-source", "http");
        let result = validate_source_toml_text(&canonical, "example-source", "http");
        assert!(result.is_ok(), "validator error: {result:?}");
    }

    #[test]
    fn schema_1_source_manifest_is_rejected_with_typed_error() {
        let schema_1 = r#"
schema_version = 1
[source]
name = "example-source"
protocol = "http"
"#;
        let error = validate_source_toml_text(schema_1, "example-source", "http")
            .expect_err("schema 1 must be rejected");
        assert!(matches!(
            error,
            SourceManifestError::UnsupportedSchemaVersion { actual: 1 }
        ));
    }

    #[test]
    fn schema_2_with_wrong_acquisition_contract_identifier_is_rejected() {
        let mut canonical = format_source_toml("example-source", "http");
        canonical = canonical.replace(
            "native-rust-http-source-v1",
            "some-other-source-v9",
        );
        let error = validate_source_toml_text(&canonical, "example-source", "http")
            .expect_err("wrong contract identifier must be rejected");
        assert!(matches!(
            error,
            SourceManifestError::UnexpectedContractIdentifier { operation: "acquisition", .. }
        ));
    }

    #[test]
    fn schema_2_with_wrong_processing_contract_identifier_is_rejected() {
        let mut canonical = format_source_toml("example-source", "http");
        canonical = canonical.replace(
            "native-rust-processing-v1",
            "some-other-source-v9",
        );
        let error = validate_source_toml_text(&canonical, "example-source", "http")
            .expect_err("wrong contract identifier must be rejected");
        assert!(matches!(
            error,
            SourceManifestError::UnexpectedContractIdentifier { operation: "processing", .. }
        ));
    }

    #[test]
    fn schema_2_with_zero_core_contract_version_is_rejected() {
        // Hand-author a manifest with `core_contract = 0` in the acquisition
        // section. The validator must surface a precise per-field error.
        let custom = r#"
schema_version = 2
[source]
name = "example-source"
protocol = "http"
[acquisition]
contract = "native-rust-http-source-v1"
runner_template = 1
core_contract = 0
runtime_protocol = 1
[processing]
contract = "native-rust-processing-v1"
runner_template = 1
core_contract = 1
runtime_protocol = 1
"#;
        let error = validate_source_toml_text(custom, "example-source", "http")
            .expect_err("zero-version must be rejected");
        assert!(matches!(
            error,
            SourceManifestError::InvalidVersion {
                operation: "acquisition",
                field: "core_contract",
                value: 0,
                expected: _,
            }
        ));
    }

    #[test]
    fn schema_2_with_wrong_runner_template_version_is_rejected() {
        let custom = r#"
schema_version = 2
[source]
name = "example-source"
protocol = "http"
[acquisition]
contract = "native-rust-http-source-v1"
runner_template = 999
core_contract = 1
runtime_protocol = 1
[processing]
contract = "native-rust-processing-v1"
runner_template = 1
core_contract = 1
runtime_protocol = 1
"#;
        let error = validate_source_toml_text(custom, "example-source", "http")
            .expect_err("wrong runner_template must be rejected");
        assert!(matches!(
            error,
            SourceManifestError::InvalidVersion {
                operation: "acquisition",
                field: "runner_template",
                value: 999,
                expected: _,
            }
        ));
    }

    #[test]
    fn schema_2_with_wrong_source_name_is_rejected() {
        let canonical = format_source_toml("example-source", "http");
        let error =
            validate_source_toml_text(&canonical, "other-source", "http")
                .expect_err("wrong source name must be rejected");
        assert!(matches!(
            error,
            SourceManifestError::UnexpectedContractIdentifier { operation: "source", .. }
        ));
    }

    #[test]
    fn load_source_metadata_rejects_missing_manifest_file() {
        let root = unique_test_dir("lexicon-source-meta-missing-");
        let manifest = root.path().join("sources/example-source/http/source.toml");
        let result = load_source_metadata(&manifest, "example-source", "http");
        assert!(result.is_err());
        assert!(result.unwrap_err().contains("does not exist"));
    }

    #[test]
    fn typed_source_name_and_protocol_require_safe_values() {
        assert!(crate::identity::ManagedName::parse("example-source").is_ok());
        assert!(crate::identity::ManagedName::parse("/bad").is_err());
        assert!(crate::identity::ManagedName::parse(".").is_err());
        assert!(crate::identity::ManagedName::parse("..").is_err());
        assert!(crate::identity::ManagedProtocol::parse("http").is_ok());
        assert!(crate::identity::ManagedProtocol::parse("browser").is_err());
    }

    #[test]
    fn generated_acquisition_runner_delegates_startup_to_core() {
        let source = format_http_managed_runner_main("example-source");

        assert!(source.contains("lexicon_core::runner::run_http_source(IDENTITY, &SOURCE)"));
        assert!(!source.contains("args_os"));
        assert!(!source.contains("try_write_runtime_information_probe"));
    }

    #[test]
    fn generated_processing_runner_delegates_startup_to_core() {
        let source = format_processing_managed_runner_main("example-source");

        assert!(source.contains(
            "lexicon_core::runner::run_processing_source(IDENTITY, &PROCESSOR)"
        ));
        assert!(!source.contains("args_os"));
        assert!(!source.contains("try_write_runtime_information_probe"));
    }

    #[test]
    fn generated_acquisition_runner_includes_template_version_marker() {
        let source = format_http_managed_runner_main("example-source");

        assert!(source.contains("use source_implementation::SOURCE;"));
        assert!(!source.contains("source_implementation::PROCESSOR"));

        assert!(source.contains(&format!(
            "const LEXICON_MANAGED_RUNNER_TEMPLATE_VERSION: u32 = {};",
            MANAGED_RUNNER_TEMPLATE_VERSION
        )));
    }

    #[test]
    fn generated_processing_runner_includes_template_version_marker() {
        let source = format_processing_managed_runner_main("example-source");

        assert!(source.contains("use source_implementation::PROCESSOR;"));
        assert!(!source.contains("source_implementation::SOURCE"));

        assert!(source.contains(&format!(
            "const LEXICON_MANAGED_RUNNER_TEMPLATE_VERSION: u32 = {};",
            MANAGED_RUNNER_TEMPLATE_VERSION
        )));
    }

    #[test]
    fn workspace_manifest_uses_exact_lexicon_core_package_name() {
        let manifest =
            format_workspace_cargo_toml("get-raw-data", &["get-raw-data-impl", "lexicon-runner"]);

        assert!(manifest.contains(&format!(
            "lexicon_core = {{ package = \"{}\", path = \"{}\", version = \"={}\" }}",
            crate::core_provenance::EMBEDDED_CORE_PACKAGE,
            crate::core_provenance::MANAGED_CORE_RELATIVE_PATH,
            crate::core_provenance::EMBEDDED_CORE_VERSION,
        )));
    }

    #[test]
    fn scaffold_generation_uses_embedded_core_identity_without_runtime_git() {
        let parent_dir = unique_test_dir("lexicon-scaffold-embedded-");
        let parent = parent_dir.path().to_path_buf();
        let init_result = init(&parent, "embedded-core-proj").unwrap();

        let create_result = with_test_cwd(&init_result.project_directory, || {
            source_create("test-source", "http")
        })
        .unwrap();

        let acq_cargo = std_fs::read_to_string(
            create_result.protocol_dir.join("get-raw-data/Cargo.toml"),
        )
        .unwrap();
        assert!(acq_cargo.contains(crate::core_provenance::MANAGED_CORE_RELATIVE_PATH));

        let proc_cargo = std_fs::read_to_string(
            create_result.protocol_dir.join("process-data/Cargo.toml"),
        )
        .unwrap();
        assert!(proc_cargo.contains(crate::core_provenance::MANAGED_CORE_RELATIVE_PATH));
        assert!(create_result.protocol_dir.join("vendor/lexicon-core/Cargo.toml").is_file());
        crate::core_provenance::validate_managed_core(
            &create_result.protocol_dir.join("vendor/lexicon-core"),
        )
        .unwrap();
    }

    #[test]
    fn source_create_publishes_complete_schema_2_library_and_managed_runner_tree() {
        let parent = unique_test_dir("lexicon-scaffold-layout-");
        let project = init(parent.path(), "layout-project").unwrap();
        let created = with_test_cwd(&project.project_directory, || {
            source_create("example-source", "http")
        })
        .unwrap();
        let root = created.protocol_dir;
        for directory in [
            "data/raw",
            "data/processed",
            "get-raw-data/sessions",
            "get-raw-data/runtime",
            "get-raw-data/state",
            "process-data/sessions",
            "process-data/runtime",
            "vendor/lexicon-core/src",
        ] {
            assert!(root.join(directory).is_dir(), "missing {directory}");
        }
        for file in [
            "source.toml",
            "discovery.md",
            "get-raw-data/Cargo.toml",
            "get-raw-data/Cargo.lock",
            "get-raw-data/get-raw-data-impl/Cargo.toml",
            "get-raw-data/get-raw-data-impl/src/lib.rs",
            "get-raw-data/lexicon-runner/Cargo.toml",
            "get-raw-data/lexicon-runner/src/main.rs",
            "get-raw-data/session_status.json",
            "process-data/Cargo.toml",
            "process-data/Cargo.lock",
            "process-data/process-data-impl/Cargo.toml",
            "process-data/process-data-impl/src/lib.rs",
            "process-data/lexicon-runner/Cargo.toml",
            "process-data/lexicon-runner/src/main.rs",
            "process-data/session_status.json",
        ] {
            assert!(root.join(file).is_file(), "missing {file}");
        }
        assert!(!root.join("get-raw-data/get-raw-data-impl/src/main.rs").exists());
        assert!(!root.join("process-data/process-data-impl/src/main.rs").exists());
        assert!(std_fs::read_to_string(root.join("get-raw-data/get-raw-data-impl/src/lib.rs")).unwrap().contains("pub const SOURCE:"));
        let processing_implementation = std_fs::read_to_string(
            root.join("process-data/process-data-impl/src/lib.rs"),
        ).unwrap();
        assert!(processing_implementation.contains("pub const PROCESSOR:"));
        assert!(processing_implementation.contains("context.raw_transactions()?"));
        assert!(processing_implementation.contains("ProcessingHttpRawEntry::Incomplete"));
        assert!(processing_implementation.contains("context.create_staged_database()?"));
        assert!(processing_implementation.contains("context.publish_database(database)?"));
        assert!(!processing_implementation.contains("context.resources()"));
        assert!(std_fs::read_to_string(root.join("process-data/lexicon-runner/src/main.rs")).unwrap().contains("source_implementation::PROCESSOR"));
        for (path, operation) in [
            ("get-raw-data/session_status.json", lexicon_core::session::SessionOperation::Acquisition),
            ("process-data/session_status.json", lexicon_core::session::SessionOperation::Processing),
        ] {
            let status = lexicon_core::session::SessionStatusV1::from_json(
                &std_fs::read_to_string(root.join(path)).unwrap(),
            )
            .unwrap();
            assert_eq!(status.operation(), operation);
            assert!(status.current_session().is_none());
            assert!(status.current_state().is_none());
            assert_eq!(status.revision(), 0);
        }
        validate_source_toml_text(
            &std_fs::read_to_string(root.join("source.toml")).unwrap(),
            "example-source",
            "http",
        )
        .unwrap();
    }

    #[cfg(unix)]
    #[test]
    fn project_model_rejects_symlinked_sources_directory() {
        let outside_dir = unique_test_dir("lexicon-sources-outside-");
        let root_dir = unique_test_dir("lexicon-sources-symlink-");
        let root = root_dir.path().to_path_buf();
        let outside = outside_dir.path().to_path_buf();

        let symlink_path = root.join("sources");
        std::os::unix::fs::symlink(&outside, &symlink_path).unwrap();
        std_fs::write(
            root.join("lexicon.toml"),
            "schema_version = 1\n[project]\nname = \"demo\"\n[paths]\nsources_directory = \"sources\"\n",
        )
        .unwrap();

        let result = crate::project::Project::load(&root);
        assert!(result.is_err(), "symlink escape should be rejected");
    }

    #[cfg(unix)]
    #[test]
    fn project_model_rejects_symlinked_sources_ancestor() {
        let outside_dir = unique_test_dir("lexicon-sources-escape-outside-");
        let root_dir = unique_test_dir("lexicon-sources-escape-child-");
        let root = root_dir.path().to_path_buf();
        let outside = outside_dir.path().to_path_buf();

        let link = root.join("link");
        std::os::unix::fs::symlink(&outside, &link).unwrap();
        std_fs::write(
            root.join("lexicon.toml"),
            "schema_version = 1\n[project]\nname = \"demo\"\n[paths]\nsources_directory = \"link/nonexistent-child\"\n",
        )
        .unwrap();

        let result = crate::project::Project::load(&root);
        assert!(
            result.is_err(),
            "escaped symlink path with missing child should be rejected"
        );
    }

    #[test]
    fn project_discovery_does_not_scan_or_reject_descendants() {
        let root_dir = unique_test_dir("lexicon-nested-root-");
        let root = root_dir.path().to_path_buf();
        let nested = root.join("tools/inner");
        std_fs::create_dir_all(root.join("sources")).unwrap();
        std_fs::create_dir_all(nested.join("sources")).unwrap();
        std_fs::write(
            root.join("lexicon.toml"),
            "schema_version = 1\n[project]\nname = \"outer\"\n[paths]\nsources_directory = \"sources\"\n",
        )
        .unwrap();
        std_fs::write(
            nested.join("lexicon.toml"),
            "schema_version = 1\n[project]\nname = \"inner\"\n[paths]\nsources_directory = \"sources\"\n",
        )
        .unwrap();

        let project = crate::project::Project::discover_from(&root).unwrap();
        assert_eq!(project.root(), root);
    }

    #[test]
    fn generated_discovery_markdown_contains_required_prompts() {
        let markdown = super::format_discovery_markdown("example-source");
        let required = [
            "# example-source",
            "## Source description",
            "Describe the source and the data it produces.",
            "## Discovery method",
            "Document how this source was discovered and why it belongs in this project.",
            "## Acquisition endpoint or location",
            "Record the upstream endpoint, dataset, or location used for acquisition.",
            "## Why HTTP is the correct acquisition protocol",
            "Explain why HTTP is the correct protocol for this source and how it matches the project contract.",
            "## Required authentication or access conditions",
            "List any required credentials, access restrictions, or network constraints.",
            "## Attribution and usage notes",
            "Capture attribution, licensing, and usage guidance for this source.",
            "## Operational observations",
            "Record operational notes, expected cadence, and troubleshooting observations.",
        ];

        for fragment in &required {
            assert!(
                markdown.contains(fragment),
                "discovery.md is missing required prompt: {fragment}\n---\n{markdown}"
            );
        }
    }

    #[test]
    fn built_managed_runner_struct_keeps_executable_accessible() {
        let runner = BuiltManagedRunner {
            executable: PathBuf::from("/tmp/test-binary"),
            target_directory: tempfile::tempdir().unwrap(),
        };

        assert_eq!(runner.executable(), Path::new("/tmp/test-binary"));
        assert!(runner.target_directory.path().is_dir());
    }

    #[test]
    fn acquisition_build_failure_prevents_processing_and_preserves_published_pair() {
        assert_real_pipeline_failure_preserves_pair(InjectedBuildFailure::Acquisition);
    }

    #[test]
    fn processing_build_failure_discards_staged_acquisition_and_preserves_published_pair() {
        assert_real_pipeline_failure_preserves_pair(InjectedBuildFailure::Processing);
    }

    fn assert_real_pipeline_failure_preserves_pair(failure: InjectedBuildFailure) {
        let parent = unique_test_dir("lexicon-build-preservation-");
        let project = init(parent.path(), "preservation-project").unwrap();
        let created = with_test_cwd(&project.project_directory, || {
            source_create("example-source", "http")
        })
        .unwrap();
        let acquisition_marker = created.protocol_dir.join("get-raw-data/runtime/prior-runtime");
        let processing_marker = created.protocol_dir.join("process-data/runtime/prior-runtime");
        std_fs::write(&acquisition_marker, b"prior acquisition bytes").unwrap();
        std_fs::write(&processing_marker, b"prior processing bytes").unwrap();

        let executor = SourcePipelineExecutor::new(failure);
        let result = with_test_cwd(&project.project_directory, || {
            build_source_with_executor("example-source", "http", &executor)
        });
        assert!(matches!(
            result,
            Err(ManagedSourceBuildError::CargoBuild(
                ManagedRunnerBuildError::CargoExecution(
                    crate::build::CargoExecutionError::NonZeroExit {
                        status_code: Some(101),
                        ..
                    }
                )
            ))
        ));

        assert_eq!(std_fs::read(&acquisition_marker).unwrap(), b"prior acquisition bytes");
        assert_eq!(std_fs::read(&processing_marker).unwrap(), b"prior processing bytes");
        let invocations = executor.invocations();
        let builds: Vec<_> = invocations
            .iter()
            .filter_map(|invocation| match invocation {
                crate::build::CargoInvocation::BuildReleaseLocked {
                    package,
                    target_dir,
                    ..
                } => Some((package.as_str(), target_dir)),
                _ => None,
            })
            .collect();
        match failure {
            InjectedBuildFailure::Acquisition => {
                assert_eq!(builds.len(), 1);
                assert!(builds[0].0.ends_with("get-raw-data-runner"));
            }
            InjectedBuildFailure::Processing => {
                assert_eq!(builds.len(), 2);
                assert!(builds[0].0.ends_with("get-raw-data-runner"));
                assert!(builds[1].0.ends_with("process-data-runner"));
            }
        }
        for (_, target_dir) in builds {
            assert!(!target_dir.exists(), "temporary build target leaked: {}", target_dir.display());
        }
        for runtime in [
            created.protocol_dir.join("get-raw-data/runtime"),
            created.protocol_dir.join("process-data/runtime"),
        ] {
            for entry in std_fs::read_dir(runtime).unwrap() {
                let name = entry.unwrap().file_name().to_string_lossy().into_owned();
                assert!(!name.contains("staged") && !name.contains("backup"), "publication debris leaked: {name}");
            }
        }
    }

    #[test]
    fn select_managed_runner_executable_rejects_no_artifact() {
        let target_dir = tempfile::tempdir().unwrap();
        std_fs::create_dir(target_dir.path().join("release")).unwrap();
        let output = r#"{"reason":"compiler-artifact","package_id":"pkg 0.1.0","target":{"kind":["bin"],"crate_types":["bin"],"name":"other"},"profile":{"test":false,"opt_level":"3","debug_assertions":false},"executable":"/bin/other"}"#;
        let result = select_artifact_from_cargo_output(
            output,
            "expected 0.1.0",
            "expected-bin",
            target_dir.path(),
        );

        assert!(matches!(
            result,
            Err(ManagedRunnerArtifactSelectionError::NoMatchingArtifact { .. })
        ));
    }

    #[test]
    fn select_managed_runner_executable_rejects_multiple_artifacts() {
        let target_dir = tempfile::tempdir().unwrap();
        let release = target_dir.path().join("release");
        std_fs::create_dir(&release).unwrap();
        let executable = release.join(expected_test_binary_name());
        std_fs::write(&executable, b"runtime").unwrap();
        let record = |path: &Path| serde_json::json!({
            "reason": "compiler-artifact",
            "package_id": "expected 0.1.0",
            "target": { "kind": ["bin"], "crate_types": ["bin"], "name": "expected-bin" },
            "profile": { "test": false },
            "executable": path,
        });
        let output = format!("{}\n{}", record(&executable), record(&executable));

        let result = select_artifact_from_cargo_output(
            &output,
            "expected 0.1.0",
            "expected-bin",
            target_dir.path(),
        );

        assert!(matches!(
            result,
            Err(ManagedRunnerArtifactSelectionError::MultipleMatchingArtifacts { .. })
        ));
    }

    #[test]
    fn select_managed_runner_executable_exact_package_id_required() {
        let target_dir = tempfile::tempdir().unwrap();
        std_fs::create_dir(target_dir.path().join("release")).unwrap();
        let output = r#"{"reason":"compiler-artifact","package_id":"expected-similar 0.1.0","target":{"kind":["bin"],"crate_types":["bin"],"name":"expected-bin"},"profile":{"test":false,"opt_level":"3","debug_assertions":false},"executable":"/bin/one"}"#;
        let result = select_artifact_from_cargo_output(
            output,
            "expected 0.1.0",
            "expected-bin",
            target_dir.path(),
        );

        assert!(matches!(
            result,
            Err(ManagedRunnerArtifactSelectionError::NoMatchingArtifact { .. })
        ));
    }

    #[test]
    fn select_managed_runner_executable_exact_binary_name_required() {
        let target_dir = tempfile::tempdir().unwrap();
        std_fs::create_dir(target_dir.path().join("release")).unwrap();
        let output = r#"{"reason":"compiler-artifact","package_id":"expected 0.1.0","target":{"kind":["bin"],"crate_types":["bin"],"name":"wrong-bin"},"profile":{"test":false,"opt_level":"3","debug_assertions":false},"executable":"/bin/one"}"#;
        let result = select_artifact_from_cargo_output(
            output,
            "expected 0.1.0",
            "expected-bin",
            target_dir.path(),
        );

        assert!(matches!(
            result,
            Err(ManagedRunnerArtifactSelectionError::NoMatchingArtifact { .. })
        ));
    }

    #[test]
    fn select_managed_runner_executable_rejects_malformed_json_line() {
        let target_dir = tempfile::tempdir().unwrap();
        std_fs::create_dir(target_dir.path().join("release")).unwrap();
        let result = select_artifact_from_cargo_output(
            "{",
            "expected 0.1.0",
            "expected-bin",
            target_dir.path(),
        );

        assert!(matches!(
            result,
            Err(ManagedRunnerArtifactSelectionError::MalformedJsonLine { .. })
        ));
    }

    #[test]
    fn cargo_build_finished_record_is_ignored_before_exact_artifact() {
        let target_dir = tempfile::tempdir().unwrap();
        let release = target_dir.path().join("release");
        std_fs::create_dir(&release).unwrap();
        let executable = release.join(expected_test_binary_name());
        std_fs::write(&executable, b"runtime").unwrap();
        let artifact = serde_json::json!({
            "reason": "compiler-artifact",
            "package_id": "expected 0.1.0",
            "target": { "kind": ["bin"], "crate_types": ["bin"], "name": "expected-bin" },
            "profile": { "test": false },
            "executable": executable,
        });
        let output = format!("{{\"reason\":\"build-finished\",\"success\":true}}\n{artifact}");
        let selected = select_artifact_from_cargo_output(
            &output,
            "expected 0.1.0",
            "expected-bin",
            target_dir.path(),
        )
        .unwrap();
        assert_eq!(selected, executable.canonicalize().unwrap());
    }

    #[test]
    fn debug_path_artifact_is_not_admitted_as_release_runtime() {
        let target_dir = tempfile::tempdir().unwrap();
        std_fs::create_dir(target_dir.path().join("release")).unwrap();
        let debug = target_dir.path().join("debug");
        std_fs::create_dir(&debug).unwrap();
        let executable = debug.join(expected_test_binary_name());
        std_fs::write(&executable, b"runtime").unwrap();
        let output = serde_json::json!({
            "reason": "compiler-artifact",
            "package_id": "expected 0.1.0",
            "target": { "kind": ["bin"], "crate_types": ["bin"], "name": "expected-bin" },
            "profile": { "test": false },
            "executable": executable,
        })
        .to_string();
        assert!(matches!(
            select_artifact_from_cargo_output(
                &output,
                "expected 0.1.0",
                "expected-bin",
                target_dir.path(),
            ),
            Err(ManagedRunnerArtifactSelectionError::ExecutableOutsideTarget { .. })
        ));
    }

    fn expected_test_binary_name() -> String {
        if cfg!(windows) { "expected-bin.exe".to_owned() } else { "expected-bin".to_owned() }
    }

    fn exact_artifact_record(
        executable: Option<&Path>,
        kind: &[&str],
        crate_types: &[&str],
        test: bool,
    ) -> String {
        serde_json::json!({
            "reason": "compiler-artifact",
            "package_id": "expected 0.1.0",
            "target": { "kind": kind, "crate_types": crate_types, "name": "expected-bin" },
            "profile": { "test": test, "opt_level": "z", "debug_assertions": true },
            "executable": executable,
        }).to_string()
    }

    #[test]
    fn non_bin_kind_is_not_selected() {
        let target = tempfile::tempdir().unwrap();
        let release = target.path().join("release");
        std_fs::create_dir(&release).unwrap();
        let executable = release.join(expected_test_binary_name());
        std_fs::write(&executable, b"runtime").unwrap();
        let result = select_artifact_from_cargo_output(
            &exact_artifact_record(Some(&executable), &["lib"], &["bin"], false),
            "expected 0.1.0", "expected-bin", target.path());
        assert!(matches!(result, Err(ManagedRunnerArtifactSelectionError::NoMatchingArtifact { .. })));
    }

    #[test]
    fn non_bin_crate_type_is_not_selected() {
        let target = tempfile::tempdir().unwrap();
        let release = target.path().join("release");
        std_fs::create_dir(&release).unwrap();
        let executable = release.join(expected_test_binary_name());
        std_fs::write(&executable, b"runtime").unwrap();
        let result = select_artifact_from_cargo_output(
            &exact_artifact_record(Some(&executable), &["bin"], &["rlib"], false),
            "expected 0.1.0", "expected-bin", target.path());
        assert!(matches!(result, Err(ManagedRunnerArtifactSelectionError::NoMatchingArtifact { .. })));
    }

    #[test]
    fn test_profile_artifact_is_not_selected() {
        let target = tempfile::tempdir().unwrap();
        let release = target.path().join("release");
        std_fs::create_dir(&release).unwrap();
        let executable = release.join(expected_test_binary_name());
        std_fs::write(&executable, b"runtime").unwrap();
        let result = select_artifact_from_cargo_output(
            &exact_artifact_record(Some(&executable), &["bin"], &["bin"], true),
            "expected 0.1.0", "expected-bin", target.path());
        assert!(matches!(result, Err(ManagedRunnerArtifactSelectionError::NoMatchingArtifact { .. })));
    }

    #[test]
    fn missing_executable_field_is_typed() {
        let target = tempfile::tempdir().unwrap();
        std_fs::create_dir(target.path().join("release")).unwrap();
        let result = select_artifact_from_cargo_output(
            &exact_artifact_record(None, &["bin"], &["bin"], false),
            "expected 0.1.0", "expected-bin", target.path());
        assert!(matches!(result, Err(ManagedRunnerArtifactSelectionError::MissingExecutablePath { .. })));
    }

    #[test]
    fn nonexistent_executable_is_typed_as_unavailable() {
        let target = tempfile::tempdir().unwrap();
        let release = target.path().join("release");
        std_fs::create_dir(&release).unwrap();
        let executable = release.join(expected_test_binary_name());
        let result = select_artifact_from_cargo_output(
            &exact_artifact_record(Some(&executable), &["bin"], &["bin"], false),
            "expected 0.1.0", "expected-bin", target.path());
        assert!(matches!(result, Err(ManagedRunnerArtifactSelectionError::ExecutableUnavailable { .. })));
    }

    #[test]
    fn executable_outside_isolated_target_is_rejected() {
        let target = tempfile::tempdir().unwrap();
        std_fs::create_dir(target.path().join("release")).unwrap();
        let outside = tempfile::tempdir().unwrap();
        let executable = outside.path().join(expected_test_binary_name());
        std_fs::write(&executable, b"runtime").unwrap();
        let result = select_artifact_from_cargo_output(
            &exact_artifact_record(Some(&executable), &["bin"], &["bin"], false),
            "expected 0.1.0", "expected-bin", target.path());
        assert!(matches!(result, Err(ManagedRunnerArtifactSelectionError::ExecutableOutsideTarget { .. })));
    }

    #[cfg(unix)]
    #[test]
    fn executable_symlink_escape_from_isolated_target_is_rejected() {
        use std::os::unix::fs::symlink;
        let target = tempfile::tempdir().unwrap();
        let release = target.path().join("release");
        std_fs::create_dir(&release).unwrap();
        let outside = tempfile::NamedTempFile::new().unwrap();
        let executable = release.join(expected_test_binary_name());
        symlink(outside.path(), &executable).unwrap();
        let result = select_artifact_from_cargo_output(
            &exact_artifact_record(Some(&executable), &["bin"], &["bin"], false),
            "expected 0.1.0", "expected-bin", target.path());
        assert!(matches!(result, Err(ManagedRunnerArtifactSelectionError::ExecutableOutsideTarget { .. })));
    }

    #[test]
    fn owned_runtime_identity_http_acquisition_has_correct_fields() {
        let identity = OwnedRuntimeIdentity::http_acquisition("test-source", 1);

        assert_eq!(identity.source_name(), "test-source");
        assert_eq!(identity.protocol(), RuntimeProtocol::Http);
        assert_eq!(identity.operation(), RuntimeOperation::Acquisition);
        assert_eq!(identity.source_contract_version(), 1);
    }

    #[test]
    fn owned_runtime_identity_does_not_require_static_lifetime() {
        let source_name = String::from("dynamic-source");
        let identity = OwnedRuntimeIdentity::http_acquisition(source_name.as_str(), 1);

        assert_eq!(identity.source_name(), "dynamic-source");
    }

    #[test]
    fn managed_source_build_error_displays_without_panic() {
        let validation_errors = vec![
            ManagedWorkspaceValidationError::MissingManifest("missing manifest".to_owned()),
            ManagedWorkspaceValidationError::ManifestParseFailed("bad manifest".to_owned()),
            ManagedWorkspaceValidationError::InvalidMembers {
                expected: vec!["a".to_owned()],
                found: vec!["b".to_owned()],
            },
            ManagedWorkspaceValidationError::MissingImplementation("get-raw-data".to_owned()),
            ManagedWorkspaceValidationError::MissingRunner("get-raw-data".to_owned()),
            ManagedWorkspaceValidationError::MissingLibrarySource("get-raw-data".to_owned()),
            ManagedWorkspaceValidationError::MissingRunnerSource("get-raw-data".to_owned()),
            ManagedWorkspaceValidationError::ImplNameMismatch {
                expected: "expected".to_owned(),
                found: "found".to_owned(),
            },
            ManagedWorkspaceValidationError::RunnerNameMismatch {
                expected: "expected".to_owned(),
                found: "found".to_owned(),
            },
            ManagedWorkspaceValidationError::BinaryNameMismatch {
                expected: "expected".to_owned(),
                found: "found".to_owned(),
            },
            ManagedWorkspaceValidationError::InvalidRunnerTemplate("bad template".to_owned()),
            ManagedWorkspaceValidationError::LegacyLayout("legacy".to_owned()),
            ManagedWorkspaceValidationError::ExtraWorkspaceMembers(vec!["extra".to_owned()]),
        ];
        let metadata_errors = vec![
            ManagedWorkspaceMetadataError::OutputInvalid("bad output".to_owned()),
            ManagedWorkspaceMetadataError::PackageNotFound {
                name: "pkg".to_owned(),
            },
        ];
        let artifact_errors = vec![
            ManagedRunnerArtifactSelectionError::MetadataOutput("bad output".to_owned()),
            ManagedRunnerArtifactSelectionError::PackageNotFound {
                name: "pkg".to_owned(),
            },
            ManagedRunnerArtifactSelectionError::NoMatchingArtifact {
                package_id: "pkg-id".to_owned(),
                binary_name: "bin".to_owned(),
            },
            ManagedRunnerArtifactSelectionError::MultipleMatchingArtifacts {
                package_id: "pkg-id".to_owned(),
                binary_name: "bin".to_owned(),
            },
            ManagedRunnerArtifactSelectionError::MissingExecutablePath {
                package_id: "pkg-id".to_owned(),
                binary_name: "bin".to_owned(),
            },
        ];
        let build_errors = vec![
            ManagedRunnerBuildError::ArtifactSelection(
                ManagedRunnerArtifactSelectionError::NoMatchingArtifact {
                    package_id: "pkg-id".to_owned(),
                    binary_name: "bin".to_owned(),
                },
            ),
            ManagedRunnerBuildError::ExecutableNotFile(PathBuf::from("not-a-file")),
        ];
        let source_errors = vec![
            ManagedSourceBuildError::WorkspaceValidation(
                ManagedWorkspaceValidationError::MissingManifest("missing manifest".to_owned()),
            ),
            ManagedSourceBuildError::Metadata(ManagedWorkspaceMetadataError::OutputInvalid(
                "bad metadata".to_owned(),
            )),
            ManagedSourceBuildError::AcquisitionVerification(
                crate::build::HttpRuntimeVerificationError::InitialHash(
                    crate::build::RuntimeArtifactHashError::MissingCandidate {
                        path: PathBuf::from("missing-http"),
                    },
                ),
            ),
            ManagedSourceBuildError::ProcessingVerification(
                crate::build::ProcessingRuntimeVerificationError::InitialHash(
                    crate::build::RuntimeArtifactHashError::MissingCandidate {
                        path: PathBuf::from("missing-processing"),
                    },
                ),
            ),
            ManagedSourceBuildError::AcquisitionStaging(
                crate::build::RuntimeBundleStagingError::InvalidStagingParent {
                    path: PathBuf::from("bad-http-parent"),
                },
            ),
            ManagedSourceBuildError::ProcessingStaging(
                crate::build::ProcessingRuntimeBundleStagingError::InvalidStagingParent {
                    path: PathBuf::from("bad-processing-parent"),
                },
            ),
            ManagedSourceBuildError::Publication(
                crate::publication::RuntimePairPublicationError::InvalidDestinations,
            ),
            ManagedSourceBuildError::MissingLockfile(PathBuf::from("Cargo.lock")),
            ManagedSourceBuildError::LockfileModified(PathBuf::from("Cargo.lock")),
        ];

        for rendered in validation_errors
            .into_iter()
            .map(|error| error.to_string())
            .chain(metadata_errors.into_iter().map(|error| error.to_string()))
            .chain(artifact_errors.into_iter().map(|error| error.to_string()))
            .chain(build_errors.into_iter().map(|error| error.to_string()))
            .chain(source_errors.into_iter().map(|error| error.to_string()))
        {
            assert!(!rendered.is_empty());
        }
    }

    #[test]
    fn workspace_validation_rejects_missing_template_version_marker() {
        let root_dir = unique_test_dir("lexicon-workspace-missing-marker-");
        let workspace = root_dir.path().join("http/get-raw-data");
        write_valid_managed_workspace(&workspace, "example-source", "get-raw-data");
        let runner_main = workspace.join("lexicon-runner/src/main.rs");
        let marker = format!(
            "const LEXICON_MANAGED_RUNNER_TEMPLATE_VERSION: u32 = {};\n\n",
            MANAGED_RUNNER_TEMPLATE_VERSION
        );
        let source = std_fs::read_to_string(&runner_main)
            .unwrap()
            .replace(&marker, "");
        std_fs::write(&runner_main, source).unwrap();

        let result = validate_managed_workspace_layout(
            &workspace,
            "example-source",
            "get-raw-data",
            "example-source-get-raw-data",
            "example-source-get-raw-data-runner",
            "example-source-get-raw-data",
        );

        assert!(matches!(
            result,
            Err(ManagedWorkspaceValidationError::InvalidRunnerTemplate(_))
        ));
    }

    #[test]
    fn workspace_validation_accepts_correct_template_version_marker() {
        let root_dir = unique_test_dir("lexicon-workspace-valid-marker-");
        let workspace = root_dir.path().join("http/get-raw-data");
        write_valid_managed_workspace(&workspace, "example-source", "get-raw-data");

        let result = validate_managed_workspace_layout(
            &workspace,
            "example-source",
            "get-raw-data",
            "example-source-get-raw-data",
            "example-source-get-raw-data-runner",
            "example-source-get-raw-data",
        );

        assert!(result.is_ok(), "result: {result:?}");
    }

    #[test]
    fn workspace_validation_rejects_modified_runner_template_content() {
        let root_dir = unique_test_dir("lexicon-workspace-modified-template-");
        let workspace = root_dir.path().join("http/get-raw-data");
        write_valid_managed_workspace(&workspace, "example-source", "get-raw-data");
        let runner_main = workspace.join("lexicon-runner/src/main.rs");
        let source = std_fs::read_to_string(&runner_main)
            .unwrap()
            .replace("ExitCode::SUCCESS", "ExitCode::from(0)");
        std_fs::write(&runner_main, source).unwrap();

        let result = validate_managed_workspace_layout(
            &workspace,
            "example-source",
            "get-raw-data",
            "example-source-get-raw-data",
            "example-source-get-raw-data-runner",
            "example-source-get-raw-data",
        );

        assert!(matches!(
            result,
            Err(ManagedWorkspaceValidationError::InvalidRunnerTemplate(_))
        ));
    }

    #[test]
    fn workspace_validation_rejects_source_owned_main_entrypoint_file() {
        let root_dir = unique_test_dir("lexicon-workspace-legacy-main-file-");
        let workspace = root_dir.path().join("http/get-raw-data");
        write_valid_managed_workspace(&workspace, "example-source", "get-raw-data");
        std_fs::write(
            workspace.join("get-raw-data-impl/src/main.rs"),
            "fn main() {}\n",
        )
        .unwrap();

        let result = validate_managed_workspace_layout(
            &workspace,
            "example-source",
            "get-raw-data",
            "example-source-get-raw-data",
            "example-source-get-raw-data-runner",
            "example-source-get-raw-data",
        );

        assert!(matches!(
            result,
            Err(ManagedWorkspaceValidationError::LegacyLayout(_))
        ));
    }

    #[test]
    fn workspace_validation_rejects_custom_cargo_release_profile() {
        let root_dir = unique_test_dir("lexicon-workspace-custom-profile-");
        let workspace = root_dir.path().join("http/get-raw-data");
        write_valid_managed_workspace(&workspace, "example-source", "get-raw-data");
        let manifest = workspace.join("Cargo.toml");
        let mut contents = std_fs::read_to_string(&manifest).unwrap();
        contents.push_str("\n[profile.release]\nopt-level = \"z\"\n");
        std_fs::write(&manifest, contents).unwrap();

        let result = validate_managed_workspace_layout(
            &workspace,
            "example-source",
            "get-raw-data",
            "example-source-get-raw-data",
            "example-source-get-raw-data-runner",
            "example-source-get-raw-data",
        );
        assert!(matches!(
            result,
            Err(ManagedWorkspaceValidationError::CustomCargoProfile)
        ));
    }

    #[test]
    fn workspace_validation_rejects_extra_root_manifest_tables() {
        let root_dir = unique_test_dir("lexicon-workspace-extra-root-table-");
        let workspace = root_dir.path().join("http/get-raw-data");
        write_valid_managed_workspace(&workspace, "example-source", "get-raw-data");
        let manifest = workspace.join("Cargo.toml");
        let mut contents = std_fs::read_to_string(&manifest).unwrap();
        contents.push_str("\n[patch.crates-io]\nserde = { path = \"../serde\" }\n");
        std_fs::write(&manifest, contents).unwrap();

        let result = validate_managed_workspace_layout(
            &workspace,
            "example-source",
            "get-raw-data",
            "example-source-get-raw-data",
            "example-source-get-raw-data-runner",
            "example-source-get-raw-data",
        );
        assert!(matches!(
            result,
            Err(ManagedWorkspaceValidationError::ManifestParseFailed(_))
        ));
    }

    #[test]
    fn workspace_validation_rejects_extra_runner_dependencies() {
        let root_dir = unique_test_dir("lexicon-workspace-extra-runner-dependency-");
        let workspace = root_dir.path().join("http/get-raw-data");
        write_valid_managed_workspace(&workspace, "example-source", "get-raw-data");
        let manifest = workspace.join("lexicon-runner/Cargo.toml");
        let mut contents = std_fs::read_to_string(&manifest).unwrap();
        contents.push_str("serde = \"1\"\n");
        std_fs::write(&manifest, contents).unwrap();

        let result = validate_managed_workspace_layout(
            &workspace,
            "example-source",
            "get-raw-data",
            "example-source-get-raw-data",
            "example-source-get-raw-data-runner",
            "example-source-get-raw-data",
        );
        assert!(matches!(
            result,
            Err(ManagedWorkspaceValidationError::ManifestParseFailed(_))
        ));
    }

    #[test]
    fn workspace_metadata_validation_accepts_valid_workspace() {
        let root_dir = unique_test_dir("lexicon-workspace-metadata-valid-");
        let workspace = root_dir.path().join("http/get-raw-data");
        write_valid_managed_workspace(&workspace, "example-source", "get-raw-data");
        let result = validate_managed_workspace_metadata(
            &workspace,
            "get-raw-data",
            "example-source-get-raw-data",
            "example-source-get-raw-data-runner",
            "example-source-get-raw-data",
        );
        assert!(result.is_ok(), "result: {result:?}");
    }

    #[test]
    fn framework_init_returns_typed_result_not_exit() {
        let parent_dir = unique_test_dir("lexicon-fw-init-");
        let parent = parent_dir.path().to_path_buf();

        let result = init(&parent, "my-project");
        assert!(result.is_ok());
        let info = result.unwrap();
        assert_eq!(info.project_directory, parent.join("my-project"));
        assert!(info.project_directory.join("lexicon.toml").is_file());
    }

    #[test]
    fn framework_init_fails_with_error_not_exit_for_bad_name() {
        let parent_dir = unique_test_dir("lexicon-fw-init-bad-");
        let parent = parent_dir.path().to_path_buf();

        let result = init(&parent, "../evil");
        assert!(result.is_err(), "bad project name should return Err");
    }

    #[test]
    fn framework_source_create_fails_with_error_not_exit_for_bad_protocol() {
        let temp_dir = unique_test_dir("lexicon-fw-sc-");
        let temp = temp_dir.path().to_path_buf();
        std_fs::write(
            temp.join("lexicon.toml"),
            "schema_version = 1\n[project]\nname = \"demo\"\n[paths]\nsources_directory = \"sources\"\n",
        )
        .unwrap();

        let result = with_test_cwd(&temp, || source_create("example-source", "browser"));

        assert!(result.is_err(), "unsupported protocol should return Err");
        assert!(matches!(result, Err(SourceCreateError::InvalidProtocol(_))));
    }

    #[test]
    fn finalize_source_staging_cleans_up_tempdir_when_rename_fails() {
        let root_dir = unique_test_dir("lexicon-stage-cleanup-");
        let root = root_dir.path().to_path_buf();
        let sources_dir = root.join("sources");
        let source_dir = sources_dir.join("example-source");
        std_fs::create_dir_all(&sources_dir).unwrap();
        std_fs::write(
            root.join("lexicon.toml"),
            "schema_version = 1\n[project]\nname = \"demo\"\n[paths]\nsources_directory = \"sources\"\n",
        )
        .unwrap();

        let staging = tempfile::Builder::new()
            .prefix("example-source-")
            .tempdir_in(&sources_dir)
            .unwrap();
        let staging_path = staging.path().to_path_buf();
        std_fs::write(staging_path.join("source.toml"), "schema_version = 1\n").unwrap();
        std_fs::create_dir_all(&source_dir).unwrap();
        std_fs::write(source_dir.join("existing.txt"), "preserve-me\n").unwrap();

        let result = finalize_source_staging(staging, &source_dir);

        assert!(
            result.is_err(),
            "rename should fail when the final directory already exists"
        );
        assert!(
            !staging_path.exists(),
            "staging directory must be removed on rename failure"
        );
        assert!(
            source_dir.join("existing.txt").exists(),
            "existing content must remain untouched"
        );
    }

    #[test]
    fn source_publication_parent_sync_failure_rolls_back_final_destination() {
        let root = unique_test_dir("lexicon-stage-sync-rollback-");
        let final_path = root.path().join("example-source");
        let staging = tempfile::Builder::new().prefix("staged-").tempdir_in(root.path()).unwrap();
        std_fs::write(staging.path().join("source.toml"), "schema_version = 2\n").unwrap();
        let calls = std::sync::atomic::AtomicUsize::new(0);
        let result = finalize_source_staging_with_sync(staging, &final_path, |_| {
            if calls.fetch_add(1, std::sync::atomic::Ordering::SeqCst) == 0 {
                Err(std::io::Error::other("injected publication sync failure"))
            } else {
                Ok(())
            }
        });
        assert!(matches!(result, Err(SourcePublicationError::ParentSyncRolledBack(_))));
        assert!(!final_path.exists());
    }

    #[test]
    fn source_publication_reports_ambiguous_when_rollback_parent_sync_fails() {
        let root = unique_test_dir("lexicon-stage-sync-ambiguous-");
        let final_path = root.path().join("example-source");
        let staging = tempfile::Builder::new().prefix("staged-").tempdir_in(root.path()).unwrap();
        std_fs::write(staging.path().join("source.toml"), "schema_version = 2\n").unwrap();
        let result = finalize_source_staging_with_sync(staging, &final_path, |_| {
            Err(std::io::Error::other("injected directory sync failure"))
        });
        assert!(matches!(result, Err(SourcePublicationError::RollbackParentSyncFailed { .. })));
        assert!(!final_path.exists());
    }

    #[test]
    fn build_all_finds_zero_targets_in_empty_sources_directory() {
        let parent_dir = unique_test_dir("lexicon-build-empty-");
        let parent = parent_dir.path().to_path_buf();
        let init_result = init(&parent, "empty-proj").unwrap();

        let outcome = with_test_cwd(&init_result.project_directory, || build_all()).unwrap();
        assert!(outcome.is_success());
        assert_eq!(outcome.succeeded.len(), 0);
        assert_eq!(outcome.failed.len(), 0);
    }

    #[test]
    fn discover_build_targets_finds_valid_source_and_protocol() {
        let parent_dir = unique_test_dir("lexicon-discover-valid-");
        let parent = parent_dir.path().to_path_buf();
        let init_result = init(&parent, "valid-proj").unwrap();

        with_test_cwd(&init_result.project_directory, || {
            source_create("my-source", "http").unwrap();
            let targets = discover_build_targets().unwrap();
            assert_eq!(targets, vec![("my-source".to_string(), "http".to_string())]);
        });
    }

    #[test]
    fn discover_build_targets_sorts_deterministically() {
        let parent_dir = unique_test_dir("lexicon-discover-sort-");
        let parent = parent_dir.path().to_path_buf();
        let init_result = init(&parent, "sort-proj").unwrap();

        with_test_cwd(&init_result.project_directory, || {
            source_create("zebra-source", "http").unwrap();
            source_create("alpha-source", "http").unwrap();
            source_create("beta-source", "http").unwrap();

            let targets = discover_build_targets().unwrap();
            assert_eq!(
                targets,
                vec![
                    ("alpha-source".to_string(), "http".to_string()),
                    ("beta-source".to_string(), "http".to_string()),
                    ("zebra-source".to_string(), "http".to_string()),
                ]
            );
        });
    }

    #[test]
    fn discover_build_targets_rejects_non_directory_in_sources_root() {
        let parent_dir = unique_test_dir("lexicon-discover-nondir-root-");
        let parent = parent_dir.path().to_path_buf();
        let init_result = init(&parent, "nondir-proj").unwrap();

        with_test_cwd(&init_result.project_directory, || {
            source_create("valid-source", "http").unwrap();
            std_fs::write(init_result.project_directory.join("sources/junk.txt"), "junk").unwrap();

            let result = discover_build_targets();
            assert!(matches!(
                result,
                Err(BuildAllError::NonDirectoryInSourcesRoot { .. })
            ));
        });
    }

    #[test]
    fn discover_build_targets_rejects_non_directory_in_source() {
        let parent_dir = unique_test_dir("lexicon-discover-nondir-source-");
        let parent = parent_dir.path().to_path_buf();
        let init_result = init(&parent, "nondir-src-proj").unwrap();

        with_test_cwd(&init_result.project_directory, || {
            source_create("valid-source", "http").unwrap();
            std_fs::write(
                init_result.project_directory.join("sources/valid-source/notes.txt"),
                "notes",
            )
            .unwrap();

            let result = discover_build_targets();
            assert!(matches!(
                result,
                Err(BuildAllError::NonDirectoryInSource { .. })
            ));
        });
    }

    #[test]
    fn discover_build_targets_rejects_unrecognized_protocol_directory() {
        let parent_dir = unique_test_dir("lexicon-discover-unrecog-proto-");
        let parent = parent_dir.path().to_path_buf();
        let init_result = init(&parent, "unrecog-proj").unwrap();

        with_test_cwd(&init_result.project_directory, || {
            source_create("valid-source", "http").unwrap();
            std_fs::create_dir_all(
                init_result.project_directory.join("sources/valid-source/browser"),
            )
            .unwrap();

            let result = discover_build_targets();
            assert!(matches!(
                result,
                Err(BuildAllError::InvalidProtocolIdentity { .. })
            ));
        });
    }

    #[test]
    fn discover_build_targets_rejects_schema_1_source_manifest() {
        let parent_dir = unique_test_dir("lexicon-discover-schema1-");
        let parent = parent_dir.path().to_path_buf();
        let init_result = init(&parent, "schema1-proj").unwrap();

        with_test_cwd(&init_result.project_directory, || {
            source_create("valid-source", "http").unwrap();
            // Overwrite source.toml with schema-1 content
            let manifest_path = init_result
                .project_directory
                .join("sources/valid-source/http/source.toml");
            std_fs::write(
                &manifest_path,
                "schema_version = 1\n[source]\nname = \"valid-source\"\nprotocol = \"http\"\n",
            )
            .unwrap();

            let result = discover_build_targets();
            assert!(matches!(
                result,
                Err(BuildAllError::InvalidSourceManifest {
                    error: SourceManifestError::UnsupportedSchemaVersion { actual: 1 },
                    ..
                })
            ));
        });
    }

    #[test]
    fn discover_build_targets_rejects_source_with_no_protocol_directories() {
        let parent_dir = unique_test_dir("lexicon-discover-no-proto-");
        let parent = parent_dir.path().to_path_buf();
        let init_result = init(&parent, "no-proto-proj").unwrap();

        with_test_cwd(&init_result.project_directory, || {
            std_fs::create_dir_all(init_result.project_directory.join("sources/empty-source")).unwrap();

            let result = discover_build_targets();
            assert!(matches!(
                result,
                Err(BuildAllError::NoRecognizedProtocolDirectories { .. })
            ));
        });
    }

    #[cfg(unix)]
    #[test]
    fn discover_build_targets_rejects_symlinked_source_directory() {
        let parent_dir = unique_test_dir("lexicon-discover-source-link-");
        let init_result = init(parent_dir.path(), "linked-source-proj").unwrap();
        let outside = unique_test_dir("lexicon-discover-source-outside-");
        std::os::unix::fs::symlink(
            outside.path(),
            init_result.project_directory.join("sources/linked-source"),
        )
        .unwrap();

        let result = with_test_cwd(&init_result.project_directory, discover_build_targets);
        assert!(matches!(result, Err(BuildAllError::SymlinkNotPermitted { .. })));
    }

    #[cfg(unix)]
    #[test]
    fn discover_build_targets_rejects_non_unicode_source_identity() {
        use std::os::unix::ffi::OsStringExt;

        let parent_dir = unique_test_dir("lexicon-discover-non-unicode-");
        let init_result = init(parent_dir.path(), "non-unicode-proj").unwrap();
        let invalid = std::ffi::OsString::from_vec(vec![b's', 0xff]);
        std_fs::create_dir(init_result.project_directory.join("sources").join(invalid)).unwrap();

        let result = with_test_cwd(&init_result.project_directory, discover_build_targets);
        assert!(matches!(
            result,
            Err(BuildAllError::InvalidSourceIdentity {
                error: crate::identity::ManagedNameError::NonUnicode,
                ..
            })
        ));
    }
}
