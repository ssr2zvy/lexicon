use sha2::{Digest, Sha256};
use std::env;
use std::ffi::OsStr;
use std::fs;
use std::io::{self, Write};
use std::path::{Component, Path, PathBuf};

const SNAPSHOT_MAGIC: &[u8] = b"LEXICON_CORE_SNAPSHOT_V1\0";
const MAX_SNAPSHOT_BYTES: usize = 64 * 1024 * 1024;
const MAX_SNAPSHOT_FILES: usize = 16_384;
const MAX_PATH_BYTES: usize = 4_096;
const CORE_PACKAGE: &str = "lexicon-core";
const IMPLEMENTATION_PLACEHOLDER: &str = "lexicon-lock-template-implementation";
const RUNNER_PLACEHOLDER: &str = "lexicon-lock-template-runner";

fn main() {
    println!("cargo:rerun-if-changed=../lexicon-core");
    println!("cargo:rerun-if-changed=assets/source-workspace.Cargo.lock.in");
    println!("cargo:rerun-if-env-changed=LEXICON_BUILD_REVISION");

    let manifest_dir = PathBuf::from(
        env::var_os("CARGO_MANIFEST_DIR").expect("Cargo must set CARGO_MANIFEST_DIR"),
    );
    let core_root = manifest_dir.join("../lexicon-core");
    let out_dir = PathBuf::from(env::var_os("OUT_DIR").expect("Cargo must set OUT_DIR"));

    let (package, version) = read_core_package_identity(&core_root)
        .unwrap_or_else(|error| panic!("cannot identify embedded Core source: {error}"));
    assert_eq!(package, CORE_PACKAGE, "embedded package must be `{CORE_PACKAGE}`");

    let archive = encode_core_snapshot(&core_root)
        .unwrap_or_else(|error| panic!("cannot create embedded Core snapshot: {error}"));
    let digest = hex_sha256(&archive);
    let snapshot_path = out_dir.join("lexicon_core_snapshot_v1.bin");
    write_new_file(&snapshot_path, &archive)
        .unwrap_or_else(|error| panic!("cannot publish embedded Core snapshot: {error}"));

    let lock_template = validated_lock_template(&version)
        .unwrap_or_else(|error| panic!("cannot admit embedded source-workspace lockfile: {error}"));
    let lock_digest = hex_sha256(lock_template.as_bytes());
    let lock_template_path = out_dir.join("lexicon_source_workspace_Cargo.lock");
    write_new_file(&lock_template_path, lock_template.as_bytes())
        .unwrap_or_else(|error| panic!("cannot publish embedded lockfile template: {error}"));

    let build_revision = env::var("LEXICON_BUILD_REVISION").unwrap_or_default();
    if !build_revision.is_empty()
        && (build_revision.len() != 40
            || !build_revision.bytes().all(|byte| byte.is_ascii_hexdigit())
            || build_revision.bytes().all(|byte| byte == b'0'))
    {
        panic!("LEXICON_BUILD_REVISION must be empty or a non-zero 40-character hexadecimal commit");
    }

    println!("cargo:rustc-env=LEXICON_EMBEDDED_CORE_PACKAGE={package}");
    println!("cargo:rustc-env=LEXICON_EMBEDDED_CORE_VERSION={version}");
    println!("cargo:rustc-env=LEXICON_EMBEDDED_CORE_SHA256={digest}");
    println!("cargo:rustc-env=LEXICON_EMBEDDED_CORE_LOCK_SHA256={lock_digest}");
    println!("cargo:rustc-env=LEXICON_BUILD_REVISION={build_revision}");
}

fn read_core_package_identity(core_root: &Path) -> Result<(String, String), String> {
    let manifest_path = core_root.join("Cargo.toml");
    let manifest = fs::read_to_string(&manifest_path)
        .map_err(|error| format!("failed to read {}: {error}", manifest_path.display()))?;
    let document: toml::Value = toml::from_str(&manifest)
        .map_err(|error| format!("failed to parse {}: {error}", manifest_path.display()))?;
    let package = document
        .get("package")
        .and_then(|value| value.get("name"))
        .and_then(toml::Value::as_str)
        .ok_or("Core manifest has no package.name")?;
    let version = document
        .get("package")
        .and_then(|value| value.get("version"))
        .and_then(toml::Value::as_str)
        .ok_or("Core manifest has no package.version")?;
    if package.contains(['\n', '\r', '\0']) || version.contains(['\n', '\r', '\0']) {
        return Err("Core package identity contains an unsafe character".to_owned());
    }
    Ok((package.to_owned(), version.to_owned()))
}

fn encode_core_snapshot(core_root: &Path) -> Result<Vec<u8>, String> {
    let mut files = Vec::new();
    collect_snapshot_files(core_root, core_root, &mut files)?;
    files.sort();
    files.dedup();
    if files.is_empty() {
        return Err("Core snapshot is empty".to_owned());
    }
    if files.len() > MAX_SNAPSHOT_FILES {
        return Err("Core snapshot contains too many files".to_owned());
    }
    let mut output = Vec::new();
    output.extend_from_slice(SNAPSHOT_MAGIC);
    output.extend_from_slice(&u32::try_from(files.len()).map_err(|_| "too many Core snapshot files")?.to_be_bytes());
    for relative in files {
        let text = relative.to_str().ok_or_else(|| format!("non-UTF-8 Core path: {}", relative.display()))?.replace('\\', "/");
        if text.is_empty() || text.len() > MAX_PATH_BYTES {
            return Err(format!("Core snapshot path exceeds the supported limit: {text}"));
        }
        let metadata = fs::metadata(core_root.join(&relative))
            .map_err(|error| format!("failed to inspect {}: {error}", relative.display()))?;
        let content_length = usize::try_from(metadata.len())
            .map_err(|_| format!("Core file is too large: {text}"))?;
        let encoded_length = 12usize
            .checked_add(text.len())
            .and_then(|length| length.checked_add(content_length))
            .ok_or_else(|| format!("Core snapshot size overflow at: {text}"))?;
        if output
            .len()
            .checked_add(encoded_length)
            .is_none_or(|length| length > MAX_SNAPSHOT_BYTES)
        {
            return Err("Core snapshot exceeds the supported archive size".to_owned());
        }
        let contents = fs::read(core_root.join(&relative))
            .map_err(|error| format!("failed to read {}: {error}", relative.display()))?;
        if contents.len() != content_length {
            return Err(format!("Core file changed while snapshotting: {text}"));
        }
        output.extend_from_slice(&u32::try_from(text.len()).map_err(|_| format!("Core path is too long: {text}"))?.to_be_bytes());
        output.extend_from_slice(&u64::try_from(contents.len()).map_err(|_| format!("Core file is too large: {text}"))?.to_be_bytes());
        output.extend_from_slice(text.as_bytes());
        output.extend_from_slice(&contents);
    }
    if output.len() > MAX_SNAPSHOT_BYTES {
        return Err("Core snapshot exceeds the supported archive size".to_owned());
    }
    Ok(output)
}

fn collect_snapshot_files(root: &Path, directory: &Path, files: &mut Vec<PathBuf>) -> Result<(), String> {
    let mut entries = fs::read_dir(directory)
        .map_err(|error| format!("failed to read {}: {error}", directory.display()))?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|error| format!("failed to enumerate {}: {error}", directory.display()))?;
    entries.sort_by_key(|entry| entry.file_name());
    for entry in entries {
        let path = entry.path();
        let file_type = entry.file_type().map_err(|error| format!("failed to inspect {}: {error}", path.display()))?;
        if file_type.is_symlink() {
            return Err(format!("symlink is forbidden in embedded Core source: {}", path.display()));
        }
        let relative = path.strip_prefix(root).map_err(|_| format!("Core path escaped snapshot root: {}", path.display()))?;
        validate_relative_path(relative)?;
        if file_type.is_dir() {
            if relative == Path::new("target") || relative == Path::new(".git") {
                return Err(format!("build or repository metadata is forbidden in Core source: {}", path.display()));
            }
            collect_snapshot_files(root, &path, files)?;
        } else if file_type.is_file() {
            if relative == Path::new("Cargo.toml") || relative == Path::new("build.rs") || relative.starts_with("src") {
                files.push(relative.to_path_buf());
            }
        } else {
            return Err(format!("non-regular Core source entry is forbidden: {}", path.display()));
        }
    }
    Ok(())
}

fn validate_relative_path(path: &Path) -> Result<(), String> {
    if path.as_os_str().is_empty() || path.is_absolute() {
        return Err(format!("unsafe Core snapshot path: {}", path.display()));
    }
    for component in path.components() {
        match component {
            Component::Normal(value)
                if value != OsStr::new("")
                    && value != OsStr::new(".")
                    && value != OsStr::new("..")
                    && !value.to_string_lossy().contains([':', '\\']) => {}
            _ => return Err(format!("unsafe Core snapshot path: {}", path.display())),
        }
    }
    Ok(())
}

fn validated_lock_template(version: &str) -> Result<&'static str, String> {
    let lock = include_str!("assets/source-workspace.Cargo.lock.in");
    if !lock.contains(IMPLEMENTATION_PLACEHOLDER) || !lock.contains(RUNNER_PLACEHOLDER) {
        return Err("checked-in lock template omitted managed workspace packages".to_owned());
    }
    let expected_core = format!("name = \"{CORE_PACKAGE}\"\nversion = \"{version}\"");
    if !lock.contains(&expected_core) {
        return Err("checked-in lock template does not match the embedded Core version".to_owned());
    }
    Ok(lock)
}

fn write_new_file(path: &Path, bytes: &[u8]) -> io::Result<()> {
    if path.exists() { fs::remove_file(path)?; }
    let mut file = fs::OpenOptions::new().write(true).create_new(true).open(path)?;
    file.write_all(bytes)?;
    file.sync_all()
}

fn hex_sha256(bytes: &[u8]) -> String {
    let digest = Sha256::digest(bytes);
    let mut output = String::with_capacity(64);
    for byte in digest {
        use std::fmt::Write as _;
        write!(&mut output, "{byte:02x}").expect("writing to String cannot fail");
    }
    output
}
