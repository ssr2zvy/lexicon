# Lexicon Implementation Status

Normative implementation status for Lexicon achieving Contract V1 and
Specification V1 conformance (`workspace/specs/contract.md`,
`workspace/specs/specs.md`). The mechanical conformance matrix lives in
[`workspace/specs/conformance.toml`](conformance.toml). That matrix is the
machine-readable required-test ledger; this document also records non-test,
release, and external-evidence gates that the test-name checker cannot prove.
Neither file alone is a completion claim.

The master milestone remains open until:

1. MZA publishes and pins a Protocol 1 installer API that owns install,
   upgrade, uninstall, command registration, and platform integration
   (`current.md` §3); or
2. the committee explicitly amends `contract.md` to remove that
   requirement.

Until one of those events occurs, the MZA-dependent release rows remain open.
All non-deferred contract/specification matrix rows are now classified as
`implemented, unverified`; `conformance.toml` is authoritative for the exact
status and test mapping. The broader status ledger still marks external CI and
supply-chain evidence partial, and leaves the excluded MZA release work open.
CI-01 defines the native workflow and manifest producer, but the first green
run is still pending.

No row claims `Status: conformant` — that flag requires durable
evidence linked to an exact commit, and per the audit's own §17 wording
"a number in current.md without the attached exact-SHA manifest is not
evidence."

---

## 1. Source contract compile-time guarantees (specs.md §44)

The normative processing scaffold in §39 exports `PROCESSOR`; §44's shorthand
"missing public SOURCE" applies to the public descriptor boundary generally.
The implementation and real two-package tests therefore use acquisition
`SOURCE` and processing `PROCESSOR` consistently.

### specs-44-valid-descriptor-compile-pass

* Contract/spec authority: `workspace/specs/specs.md#44`
* Implementation:
  * `lexicon-core/src/protocols/http/contract.rs:HttpSourceContractV1`
  * `lexicon-core/src/processing/contract.rs:ProcessingSourceContractV1`
* Automated evidence:
  * `core::protocols::http::contract::tests::source_contract_can_be_declared_as_const`
  * `core::processing::contract::tests::descriptor_works_in_a_constant`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-44-private-acquisition-handler

* Contract/spec authority: `workspace/specs/specs.md#44`
* Implementation:
  * `lexicon-core/src/protocols/http/contract.rs`
  * `lexicon-core/tests/ui-pass/private_acquisition_handler.rs`
* Automated evidence:
  * `core::tests::contract_ui::compile_pass_contracts`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-44-private-processing-handlers

* Contract/spec authority: `workspace/specs/specs.md#44`
* Implementation:
  * `lexicon-core/src/processing/contract.rs`
  * `lexicon-core/tests/ui-pass/private_processing_handlers.rs`
* Automated evidence:
  * `core::tests::contract_ui::compile_pass_contracts`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-44-missing-public-source-descriptor

* Contract/spec authority: `workspace/specs/specs.md#44`
* Implementation:
  * `lexicon-core/tests/ui/missing_exported_source_descriptor.rs`
  * `lexicon-core/tests/managed_runner_contract.rs`
* Automated evidence:
  * `managed_runner_contract::acquisition_runner_rejects_missing_exported_source_descriptor`
  * `managed_runner_contract::processing_runner_rejects_missing_exported_processor_descriptor`
  * `managed_runner_contract::acquisition_library_rejects_wrong_handler_signature_before_runner_link`
  * `managed_runner_contract::processing_library_rejects_wrong_handler_signature_before_runner_link`
* Required environment: `linux-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### contract-7-wrong-acquisition-signature-compile-fail

* Contract/spec authority: `workspace/specs/contract.md#7`
* Implementation:
  * `lexicon-core/tests/ui/wrong_argument_type.rs`
  * `lexicon-core/tests/ui/reversed_parameters.rs`
  * `lexicon-core/tests/ui/context_by_value.rs`
  * `lexicon-core/tests/ui/bool_return.rs`
  * `lexicon-core/tests/contract_ui.rs`
* Automated evidence:
  * `core::tests::contract_ui::compile_fail_contracts`
* Required environment: `linux-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### contract-7-unsupported-capability-rejection

* Contract/spec authority: `workspace/specs/contract.md#7`
* Implementation: `lexicon-core/src/runtime/information.rs:validate_capabilities`
* Automated evidence:
  * `build::runtime_probe::tests::missing_required_capabilities_produce_incompatible_error`
  * `build::runtime_verification::tests::build_verification_rejects_descriptor_capability_the_runner_cannot_supply`
  * `protocols::http::runner::tests::missing_capabilities_return_admission_error`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-44-wrong-resume-signature-compile-fail

* Contract/spec authority: `workspace/specs/specs.md#44`
* Implementation: `lexicon-core/tests/ui/invalid_resume_handlers.rs`
* Automated evidence: `core::tests::contract_ui::compile_fail_contracts`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

## 2. Source creation, durability, and validation (specs.md §6, §7, §10)

### specs-7-atomic-source-creation

* Contract/spec authority: `workspace/specs/specs.md#7`
* Implementation:
  * `lexicon-framework/src/lib.rs:generate_source_scaffold`
  * `lexicon-framework/src/fs/durable.rs`
* Automated evidence:
  * `lexicon-framework::lib::tests::finalize_source_staging_cleans_up_tempdir_when_rename_fails`
  * `lexicon-framework::lib::tests::source_publication_parent_sync_failure_rolls_back_final_destination`
  * `lexicon-framework::lib::tests::source_publication_reports_ambiguous_when_rollback_parent_sync_fails`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-6-exact-source-layout

* Contract/spec authority: `workspace/specs/specs.md#6`
* Implementation: `lexicon-framework/src/lib.rs:generate_source_scaffold`
* Automated evidence:
  * `lexicon-framework::lib::tests::source_create_publishes_complete_schema_2_library_and_managed_runner_tree`
  * `cli::cli::mod::tests::cli_source_create_calls_framework_library_directly`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-5-schema-2-manifest

* Contract/spec authority: `workspace/specs/specs.md#5`
* Implementation:
  * `lexicon-framework/src/lib.rs:format_source_toml`
  * `lexicon-framework/src/lib.rs:validate_source_toml_text`
* Automated evidence:
  * `lexicon-framework::lib::tests::generated_source_toml_matches_required_schema_2_contract`
  * `lexicon-framework::lib::tests::schema_1_source_manifest_is_rejected_with_typed_error`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-10-managed-runner-integrity

* Contract/spec authority: `workspace/specs/specs.md#10`
* Implementation:
  * `lexicon-framework/src/lib.rs:validate_managed_workspace_layout`
  * `lexicon-framework/src/lib.rs:validate_managed_workspace_metadata`
* Automated evidence:
  * `lexicon-framework::lib::tests::workspace_validation_accepts_correct_template_version_marker`
  * `lexicon-framework::lib::tests::workspace_validation_rejects_modified_runner_template_content`
  * `lexicon-framework::lib::tests::workspace_validation_rejects_extra_root_manifest_tables`
  * `lexicon-framework::lib::tests::workspace_validation_rejects_extra_runner_dependencies`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-10-source-owned-main-rejection

* Contract/spec authority: `workspace/specs/specs.md#10`
* Implementation: `lexicon-framework/src/lib.rs:validate_managed_workspace_layout`
* Automated evidence:
  * `lexicon-framework::lib::tests::workspace_validation_rejects_source_owned_main_entrypoint_file`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-7-lockfile-requirement

* Contract/spec authority: `workspace/specs/specs.md#7`
* Implementation:
  * `lexicon-framework/src/core_provenance.rs:managed_workspace_lockfile`
  * `lexicon-framework/src/lib.rs:read_lockfile_snapshot`
* Automated evidence:
  * `installed_core_identity::copied_installed_cli_materializes_exact_core_and_both_workspaces_build_locked_offline`
  * `lexicon-framework::core_provenance::tests::lockfile_substitution_does_not_rewrite_inserted_placeholder_text`
* Required environment: `linux-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

## 3. Installed-CLI core identity (specs.md §8)

### specs-8-installed-scaffold-without-checkout

* Contract/spec authority: `workspace/specs/specs.md#8`
* Implementation:
  * `lexicon-framework/build.rs`
  * `lexicon-framework/src/core_provenance.rs:EMBEDDED_CORE_IDENTITY`
  * `lexicon-framework/src/build/core_dependency.rs:admit_managed_core_dependency`
* Automated evidence:
  * `installed_core_identity::copied_installed_cli_materializes_exact_core_and_both_workspaces_build_locked_offline`
  * `installed_core_identity::managed_core_mutation_fails_before_build`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

## 4. Build and publication (specs.md §19, §21)

### specs-19-locked-release-build

* Contract/spec authority: `workspace/specs/specs.md#19`
* Implementation:
  * `lexicon-framework/src/lib.rs:build_managed_runner`
  * `lexicon-framework/src/build/cargo_executor.rs:CargoInvocation::BuildReleaseLocked`
* Automated evidence:
  * `build::cargo_executor::tests::build_translator_requires_release_and_locked`
  * `build::cargo_executor::tests::fake_executor_converts_non_zero_exit_to_typed_error`
  * `build::cargo_executor::tests::fake_executor_treats_abnormal_termination_as_failure`
* Required environment: `linux-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-8-exact-core-dependency-resolution

* Contract/spec authority: `workspace/specs/specs.md#8`
* Implementation:
  * `lexicon-framework/src/build/core_dependency.rs:admit_managed_core_dependency`
  * `lexicon-framework/src/build/core_dependency.rs:verify_lexicon_core_metadata`
* Automated evidence:
  * `installed_core_identity::copied_installed_cli_materializes_exact_core_and_both_workspaces_build_locked_offline`
  * `installed_core_identity::managed_core_mutation_fails_before_build`
  * `build::core_dependency::tests::symlinked_managed_core_root_is_rejected_before_content_admission`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-19-isolated-target-directory

* Contract/spec authority: `workspace/specs/specs.md#19`
* Implementation: `lexicon-framework/src/lib.rs:build_managed_runner_with_executor`
* Automated evidence: `build::cargo_executor::tests::build_translator_requires_release_and_locked`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-20-exact-cargo-artifact-selection

* Contract/spec authority: `workspace/specs/specs.md#20`
* Implementation: `lexicon-framework/src/lib.rs:select_artifact_from_cargo_output`
* Automated evidence:
  * `lexicon-framework::lib::tests::select_managed_runner_executable_rejects_multiple_artifacts`
  * `lexicon-framework::lib::tests::non_bin_kind_is_not_selected`
  * `lexicon-framework::lib::tests::non_bin_crate_type_is_not_selected`
  * `lexicon-framework::lib::tests::test_profile_artifact_is_not_selected`
  * `lexicon-framework::lib::tests::missing_executable_field_is_typed`
  * `lexicon-framework::lib::tests::nonexistent_executable_is_typed_as_unavailable`
  * `lexicon-framework::lib::tests::executable_outside_isolated_target_is_rejected`
  * `lexicon-framework::lib::tests::executable_symlink_escape_from_isolated_target_is_rejected`
  * `lexicon-framework::lib::tests::debug_path_artifact_is_not_admitted_as_release_runtime`
  * `lexicon-framework::lib::tests::workspace_validation_rejects_custom_cargo_release_profile`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-19-acquisition-build-failure-preserves-runtimes

* Contract/spec authority: `workspace/specs/specs.md#19`
* Implementation: `lexicon-framework/src/lib.rs:build_source_with_executor`
* Automated evidence: `lexicon-framework::lib::tests::acquisition_build_failure_prevents_processing_and_preserves_published_pair`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-19-processing-build-failure-preserves-runtimes

* Contract/spec authority: `workspace/specs/specs.md#19`
* Implementation: `lexicon-framework/src/lib.rs:build_source_with_executor`
* Automated evidence: `lexicon-framework::lib::tests::processing_build_failure_discards_staged_acquisition_and_preserves_published_pair`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-22-runtime-probe-mismatch

* Contract/spec authority: `workspace/specs/specs.md#22`
* Implementation: `lexicon-framework/src/build/runtime_probe.rs`
* Automated evidence: `build::runtime_probe::tests::identity_disagreement_produces_incompatible_error`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-22-executable-hash-mismatch

* Contract/spec authority: `workspace/specs/specs.md#22`
* Implementation: `lexicon-framework/src/build/runtime_verification.rs`
* Automated evidence:
  * `build::runtime_verification::tests::artifact_changed_during_probe_returns_changed_error`
  * `build::runtime_verification::tests::final_hash_failure_returns_final_hash`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-21-paired-publication-rollback

* Contract/spec authority: `workspace/specs/specs.md#21`
* Implementation:
  * `lexicon-framework/src/publication/runtime_pair.rs:publish_runtime_pair`
  * `lexicon-framework/src/publication/runtime_pair_transaction.rs:RuntimePairTransaction`
  * `lexicon-framework/src/publication/runtime_bundle_replacement.rs`
  * `lexicon-framework/src/publication/file_system.rs`
  * `lexicon-framework/src/data/runtime.rs:admit_bundle`
* Automated evidence:
  * `lexicon-framework::publication::runtime_pair::tests::publication_fails_when_processing_staging_is_missing_and_cleans_up`
  * `lexicon-framework::publication::runtime_pair::tests::scripted_processing_replace_failure_restores_prior_acquisition_pair`
  * `lexicon-framework::publication::runtime_pair::tests::publication_rejects_runtime_pair_with_different_source_identity`
  * `lexicon-framework::publication::runtime_bundle_replacement::tests::post_install_parent_sync_failure_restores_previous_destination`
  * `lexicon-framework::publication::runtime_pair_transaction::tests::shared_admission_is_rejected_while_publication_is_owned`
  * `lexicon-framework::publication::runtime_pair_transaction::tests::publication_is_rejected_while_shared_admission_is_owned`
  * `lexicon-framework::publication::runtime_pair_transaction::tests::interrupted_recovery_state_is_rejected_by_runtime_admission`
  * `lexicon-framework::publication::runtime_pair_transaction::tests::recovery_rolls_back_a_crash_between_pair_replacements`
  * `lexicon-framework::publication::runtime_pair_transaction::tests::committed_recovery_keeps_the_new_pair_and_removes_backups`
  * `lexicon-framework::publication::runtime_pair_transaction::tests::malformed_state_cannot_escape_the_transaction_root`
  * `lexicon-framework::publication_file_system::production_fs_sync_directory_reports_the_platform_outcome`
  * `lexicon-framework::publication::runtime_pair::tests::committed_cleanup_failure_retains_recoverable_state_for_the_next_publication`
  * `journal_phase_publication_uses_the_injected_file_system`
  * `committed_journal_parent_sync_failure_restores_the_previous_pair`
  * `recovery_retains_unsupported_directory_sync_outcome`
  * `interrupted_recovery_retries_a_temporarily_locked_backup` (Windows)
  * `pair_installed_journal_failure_restores_the_complete_previous_pair`
  * `failed_publication_reports_unsupported_rollback_directory_sync`
  * `production_admit_bundle_holds_publication_guard_until_bundle_drop`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: Native Linux and Windows verification has not yet produced repository-controlled exact-commit evidence.

### specs-21-windows-executable-lock-rollback

* Contract/spec authority: `workspace/specs/specs.md#21`
* Implementation: `lexicon-framework/src/publication/runtime_bundle_replacement.rs`
* Automated evidence:
  * `lexicon-framework::publication::runtime_pair::tests::windows_processing_executable_lock_release_allows_paired_publication`
  * `lexicon-framework::publication::runtime_pair::tests::windows_processing_executable_lock_exhausts_retry_and_rolls_back_acquisition`
* Required environment: `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First native Windows CI run that captures the test result and manifest URL.

## 5. HTTP recording and audit (specs.md §§32–38)

HTTP response truncation and transport failure are recorded with exact diagnostic
partial state. Ordinary `Read` operations returning `ErrorKind::Interrupted` are
retried as transient I/O; they are not mislabeled as operator cancellation.
The specification requires transport-failure and truncated-body evidence; it
does not define a separate response-stream cancellation channel. Ordinary
`Read::Interrupted` is correctly retried and is not mislabeled as operator
cancellation.

### specs-32-terminal-interrupted-attempt-classification

* Contract/spec authority: `workspace/specs/specs.md#32`
* Implementation:
  * `lexicon-core/src/processing/transactions.rs:discover_http_transactions_for_processing`
  * `lexicon-core/src/protocols/http/transaction/mod.rs:IncompleteRecordedHttpAttempt::classify_terminal_interruption`
* Automated evidence: `production_catalog_classifies_abnormal_terminal_partial_as_interrupted`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL. Interruption is derived by composing immutable partial-attempt evidence with a terminal abnormal/stale session; it is not retroactively written into the raw response metadata.

### contract-17-compressed-response-preservation

* Contract/spec authority: `workspace/specs/contract.md#17`
* Implementation: `lexicon-core/src/protocols/http/context.rs:execute`
* Automated evidence:
  * `core::protocols::http::runner::execution_tests::compressed_response_preserves_exact_entity_body_bytes_and_hash`
* Required environment: `linux-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-34-redirect-chain-lineage

* Contract/spec authority: `workspace/specs/specs.md#34`
* Implementation: `lexicon-core/src/protocols/http/context.rs`
* Automated evidence:
  * `core::protocols::http::runner::execution_tests::redirect_chain_persists_each_attempt_with_parent_identity`
  * `core::protocols::http::runner::execution_tests::redirect_failures_are_recorded_and_never_dispatch_past_the_boundary`
  * `core::protocols::http::runner::execution_tests::cross_origin_redirect_strips_secrets_for_ip_literal_hosts`
* Required environment: `linux-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-35-retry-policy-three-attempts

* Contract/spec authority: `workspace/specs/specs.md#35`
* Implementation: `lexicon-core/src/protocols/http/context.rs`
* Automated evidence:
  * `core::protocols::http::runner::execution_tests::retry_policy_persists_exactly_three_distinct_attempts`
  * `core::protocols::http::runner::execution_tests::transient_retry_policy_rejects_non_idempotent_method_before_dispatch`
  * `core::protocols::http::runner::execution_tests::fixed_retry_delay_uses_virtual_sleeper_on_production_execute_path`
  * `core::protocols::http::runner::execution_tests::exponential_retry_delay_caps_without_wall_clock_sleep`
  * `core::protocols::http::runner::execution_tests::positive_retry_after_delta_and_date_override_policy_delay`
  * `core::protocols::http::runner::execution_tests::elapsed_retry_budget_prevents_sleep_and_extra_dispatch`
* Required environment: `linux-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-38-connection-failure-final-metadata

* Contract/spec authority: `workspace/specs/specs.md#38`
* Implementation: `lexicon-core/src/protocols/http/context.rs`
* Automated evidence:
  * `core::protocols::http::runner::execution_tests::connection_failure_persists_finalized_failure_metadata`
* Required environment: `linux-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-38-truncated-body-partial-bytes

* Contract/spec authority: `workspace/specs/specs.md#38`
* Implementation: `lexicon-core/src/protocols/http/transaction/recorder.rs`
* Automated evidence:
  * `core::protocols::http::runner::execution_tests::truncated_body_preserves_partial_bytes_and_incomplete_marker`
* Required environment: `linux-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-37-mandatory-explicit-redaction

* Contract/spec authority: `workspace/specs/specs.md#37`
* Implementation:
  * `lexicon-core/src/protocols/http/sensitivity.rs`
  * `lexicon-core/src/protocols/http/transaction/recorder.rs`
  * `lexicon-core/src/protocols/http/transaction/metadata.rs`
* Automated evidence:
  * `core::protocols::http::runner::execution_tests::all_mandatory_and_explicit_headers_are_structurally_redacted`
  * `core::protocols::http::runner::execution_tests::sensitive_query_never_appears_in_any_durable_or_diagnostic_text`
* Required environment: `linux-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-34-cross-origin-strip-secrets

* Contract/spec authority: `workspace/specs/specs.md#34`
* Implementation: `lexicon-core/src/protocols/http/context.rs:same_origin`
* Automated evidence:
  * `core::protocols::http::runner::execution_tests::cross_origin_redirect_strips_secrets_for_ip_literal_hosts`
* Required environment: `linux-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### contract-16-record-before-return

* Contract/spec authority: `workspace/specs/contract.md#16`
* Implementation: `lexicon-core/src/protocols/http/context.rs:execute`
* Automated evidence:
  * `core::protocols::http::durability_tests::request_tree_is_durable_and_visible_before_network_dispatch`
  * `core::protocols::http::durability_tests::failure_after_raw_root_sync_prevents_dispatch_and_leaves_diagnostic_partial`
* Required environment: `linux-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

## 6. Checkpoints (specs.md §17)

### specs-17-checkpoint-backs-completed-transaction

* Contract/spec authority: `workspace/specs/specs.md#17`
* Implementation:
  * `lexicon-core/src/protocols/http/checkpoint/model.rs`
  * `lexicon-core/src/protocols/http/context.rs:commit_checkpoint`
  * `lexicon-core/src/protocols/http/context.rs:has_checkpoint`
* Automated evidence:
  * `checkpoint_decoder_rejects_unknown_fields_wrong_schema_and_filename_digest`
  * `checkpoint_no_replace_publication_preserves_first_receipt`
  * `checkpoint_commit_rejects_key_without_durable_transaction`
  * `checkpoint_lookup_fails_closed_when_backing_transaction_is_missing`
  * `checkpoint_lookup_rejects_malformed_foreign_mismatched_and_replayed_receipts`
  * `checkpoint_publication_faults_distinguish_uncommitted_from_partial_commit`
  * `checkpoint_crash_then_fresh_resume_uses_receipt_without_repeating_http`
  * `crash_after_response_before_checkpoint_repeats_keyed_request`
  * `background_managed_runtime_uses_the_same_checkpoint_commit_and_resume_boundary`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: Native Linux and Windows execution has not yet produced repository-controlled durable evidence. The ignored subprocess entrypoints in `checkpoint_process_recovery.rs` are harness helpers and are not mapped as passing evidence.

## 7. Processing (specs.md §39)

### specs-39-raw-transaction-enumeration

* Contract/spec authority: `workspace/specs/specs.md#39`
* Implementation: `lexicon-core/src/processing/transactions.rs`
* Automated evidence:
  * `production_catalog_admits_finalized_transaction_and_binds_session_provenance`
  * `production_catalog_rejects_foreign_project_provenance`
  * `production_catalog_rejects_foreign_runtime_source`
  * `production_catalog_rejects_runtime_operation_mismatch`
  * `production_catalog_rejects_session_operation_mismatch`
  * `production_catalog_rejects_unsupported_acquisition_runtime_contract_version`
  * `production_catalog_rejects_duplicate_transaction_identity`
  * `production_catalog_rejects_malformed_finalized_metadata_without_mutation`
  * `production_discovery_rejects_foreign_raw_file_without_mutating_it`
  * `production_discovery_rejects_malformed_partial_directory_without_mutating_it`
  * `production_discovery_rejects_raw_entry_symlink_without_following_it` (Unix)
  * `production_discovery_rejects_windows_reparse_directory_without_following_it` (Windows)
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: Native Linux and Windows verification has not yet produced repository-controlled durable evidence.

### specs-39-incomplete-transaction-handling

* Contract/spec authority: `workspace/specs/specs.md#39`
* Implementation: `lexicon-core/src/processing/transactions.rs`
* Automated evidence:
  * `production_discovery_excludes_well_formed_partial_directory_without_mutating_it`
  * `production_catalog_rejects_finalized_directory_with_incomplete_response`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: Native verification has not yet produced repository-controlled evidence.

### specs-39-staged-database-publication

* Contract/spec authority: `workspace/specs/specs.md#39`
* Implementation:
  * `lexicon-core/src/processing/contract.rs`
  * `lexicon-core/src/processing/context.rs`
  * `lexicon-core/src/processing/publication.rs`
  * `lexicon-core/src/processing/runner.rs`
  * `lexicon-framework/src/lib.rs:format_processing_implementation_library`
* Automated evidence:
  * `successful_processing_handler_publishes_its_real_sqlite_schema_and_rows`
  * `normative_section_39_source_api_compiles_and_requests_managed_publication`
  * `normative_processing_api_compiles_across_implementation_runner_boundary`
  * `source_create_publishes_complete_schema_2_library_and_managed_runner_tree`
  * `handler_success_without_publish_request_is_typed_failure_and_never_installs_canonical`
  * `background_success_uses_normative_api_and_publishes_real_sqlite`
  * `successful_publication_replaces_canonical_with_committed_staging_database`
  * `preinstallation_fault_preserves_exact_prior_canonical_bytes`
  * `postinstall_fault_returns_success_warning_and_keeps_new_database`
  * `postcommit_directory_sync_warning_retains_recoverable_state`
  * `postcommit_backup_cleanup_failure_is_success_and_recovers_cleanup`
  * `postcommit_state_cleanup_failure_is_success_and_recovers_cleanup`
  * `postcommit_cleanup_sync_failure_is_success_and_keeps_new_database`
  * `real_subprocess_crash_before_install_preserves_prior_and_after_install_rolls_forward`
  * `bounded_state_temporary_is_removed_durably_before_new_allocation`
  * `windows_prepare_commit_and_write_through_replace_publishes_real_database` (Windows)
  * `processing_handler_panic_is_caught_failed_and_never_publishes_canonical_database`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: Native Linux and Windows verification has not yet produced repository-controlled exact-commit evidence. Atomic canonical replacement is the commit point: pre-replacement errors preserve the prior database, while post-replacement durability or cleanup diagnostics are typed success warnings and retain recovery state where needed.

### specs-39-failed-processing-preserves-prior-output

* Contract/spec authority: `workspace/specs/specs.md#39`
* Implementation:
  * `lexicon-core/src/processing/publication.rs`
  * `lexicon-core/src/processing/runner.rs`
* Automated evidence:
  * `source_error_after_real_sqlite_write_preserves_prior_canonical_bytes_exactly`
  * `background_source_error_preserves_prior_canonical_bytes_and_fails_session`
  * `background_panic_preserves_prior_canonical_bytes_and_fails_session`
  * `handler_failure_abandons_staging_and_preserves_canonical_bytes`
  * `preinstallation_fault_preserves_exact_prior_canonical_bytes`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: Native Linux and Windows verification has not yet produced repository-controlled exact-commit evidence. A replacement that has already committed is intentionally reported as success with warnings rather than mislabeled as failed processing.

## 8. Foreground supervision and cancellation (specs.md §29, contract.md §20)

### specs-29-foreground-interruption

* Contract/spec authority: `workspace/specs/specs.md#29`
* Implementation:
  * `lexicon-framework/src/process/mod.rs:wait_with_cancellation`
  * `lexicon-framework/src/process/cancellation.rs:CancellationState`
  * `lexicon-cli/tests/foreground_cancellation.rs:UncoopFakeChild`
  * `lexicon-cli/tests/foreground_cancellation.rs:FailingTermChild`
* Automated evidence:
  * `foreground_cancellation::completed_outcome_when_child_exits_before_any_cancellation`
  * `foreground_cancellation::graceful_cancellation_path_uses_recorded_kind`
  * `foreground_cancellation::termination_kind_maps_to_documented_cancel_outcome`
  * `foreground_cancellation::shell_exit_codes_collapses_graceful_and_forceful_to_same_shell_code`
  * `foreground_cancellation::cancellation_records_graceful_failure_code`
  * `foreground_cancellation::cancellation_records_forced_failure_code`
  * `lexicon-framework::data::foreground::tests::acquisition_cancellation_persists_failure_and_root_summary`
  * `lexicon-framework::data::foreground::tests::processing_cancellation_persists_failure_and_root_summary`
  * `foreground_cancellation::wait_or_kill_error_never_reports_false_success`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### contract-20-stale-lease-recovery

* Contract/spec authority: `workspace/specs/contract.md#20`
* Implementation:
  * `lexicon-framework/src/data/session.rs`
  * `lexicon-core/src/session/store.rs`
* Automated evidence:
  * `launch_construction_failure_is_terminal_before_lease_release`
  * `missing_root_summary_uses_detailed_history_and_reconciles_stale_session`
  * `expired_reservation_revokes_under_lock_and_permits_stale_recovery`
  * `owned_proof_requires_the_exact_live_operator_lease_and_recovers_after_death`
  * `ordinary_stale_reconciliation_revokes_dead_operator_authority`
* Required environment: `linux-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-26-abandon-policy

* Contract/spec authority: `workspace/specs/specs.md#26`
* Implementation: `lexicon-framework/src/data/session.rs`
* Automated evidence:
  * `acquisition_abandon_flag_abandons_failed_session_before_new_run`
  * `processing_abandon_flag_abandons_failed_session_before_new_run`
  * `acquisition_failure_without_resume_or_abandon_remains_failed`
  * `acquisition_failure_with_resume_handler_prepares_resume_without_abandoning`
  * `processing_failure_without_abandon_remains_failed`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-23-non-utf8-unix-arg-preservation

* Contract/spec authority: `workspace/specs/specs.md#23`
* Implementation:
  * `lexicon-core/src/runtime/invocation_transport.rs`
* Automated evidence:
  * `non_utf8_unix_source_argument_is_preserved_byte_for_byte`
* Required environment: `linux-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-23-windows-unicode-arg-preservation

* Contract/spec authority: `workspace/specs/specs.md#23`
* Implementation:
  * `lexicon-core/src/runtime/invocation_transport.rs`
* Automated evidence:
  * `source_argument_fidelity_is_preserved_across_dispatch`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

## 9. Background handoff and operator host (specs.md §30, contract.md §30)

### specs-30-background-operator-host-handoff

* Contract/spec authority: `workspace/specs/specs.md#30`
* Implementation:
  * `lexicon-framework/src/data/background.rs`
  * `lexicon-core/src/session/handoff.rs`
* Automated evidence:
  * `real_background_acquisition_reexecutes_operator_and_publishes_owned_evidence`
  * `real_background_processing_uses_the_same_owned_handoff_protocol`
  * `real_operator_host_remains_ready_until_the_initiator_releases_lease`
  * `reserved_and_ready_are_deterministic_contention_barriers`
  * `authenticated_ready_fence_prevents_late_claim_and_replay`
  * `malformed_final_authority_document_fails_closed`
  * `incomplete_unique_staged_sibling_is_ignored_until_final_publication`
  * `expired_reservation_is_revoked_before_ordinary_acquisition`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-30-operator-host-terminal-reconciliation

* Contract/spec authority: `workspace/specs/specs.md#30`
* Implementation: `lexicon-framework/src/data/background.rs`
* Automated evidence:
  * `real_background_acquisition_reexecutes_operator_and_publishes_owned_evidence`
  * `real_background_processing_uses_the_same_owned_handoff_protocol`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### current-15-cli-installed-core-identity

* Contract/spec authority: `current.md#15`
* Implementation:
  * `lexicon-cli/tests/installed_core_identity.rs`
  * `lexicon-framework/build.rs`
  * `lexicon-framework/src/core_provenance.rs:EMBEDDED_CORE_IDENTITY`
* Automated evidence:
  * `copied_installed_cli_materializes_exact_core_and_both_workspaces_build_locked_offline`
  * `managed_core_mutation_fails_before_build`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### current-15-cli-background-handoff

* Contract/spec authority: `current.md#15`
* Implementation:
  * `lexicon-cli/tests/background_handoff.rs`
  * `lexicon-framework/src/data/background.rs`
  * `lexicon-framework/src/supervision/mod.rs:OperatorHostInvocationV1`
  * `lexicon-core/src/session/handoff.rs`
* Automated evidence:
  * `reserved_invocation_round_trips_without_serializing_private_token`
  * `decoder_rejects_unknown_operation`
  * `hidden_operator_host_requires_literal_boundary_and_valid_reference`
  * `hidden_operator_host_rejects_missing_and_malformed_private_capability`
  * `real_background_acquisition_reexecutes_operator_and_publishes_owned_evidence`
  * `real_background_processing_uses_the_same_owned_handoff_protocol`
  * `reserved_and_ready_are_deterministic_contention_barriers`
  * `authenticated_ready_fence_prevents_late_claim_and_replay`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### current-15-cli-foreground-cancellation

* Contract/spec authority: `current.md#15`
* Implementation:
  * `lexicon-cli/tests/foreground_cancellation.rs`
  * `lexicon-framework/src/process/mod.rs:wait_with_cancellation`
  * `lexicon-framework/src/process/cancellation.rs:CancellationState`
* Automated evidence:
  * `completed_outcome_when_child_exits_before_any_cancellation`
  * `graceful_cancellation_path_uses_recorded_kind`
  * `termination_kind_maps_to_documented_cancel_outcome`
  * `shell_exit_codes_collapses_graceful_and_forceful_to_same_shell_code`
  * `cancellation_records_graceful_failure_code`
  * `cancellation_records_forced_failure_code`
  * `wait_or_kill_error_never_reports_false_success`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

## 10. Sessions and supervision end-to-end (specs.md §30, contract.md §20)

### contract-20-ordinary-source-error

* Contract/spec authority: `workspace/specs/contract.md#20`
* Implementation:
  * `lexicon-framework/src/data/foreground.rs`
  * `lexicon-core/src/protocols/http/runner.rs`
  * `lexicon-core/src/processing/runner.rs`
* Automated evidence:
  * `session_transitions_to_failed_after_source_authored_error`
  * `source_error_after_real_sqlite_write_preserves_prior_canonical_bytes_exactly`
* Required environment: `linux-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-28-durable-session-publication

* Contract/spec authority: `workspace/specs/specs.md#28`
* Implementation:
  * `lexicon-core/src/session/store.rs:SessionStore::create_prepared_while_selected`
  * `lexicon-core/src/session/store.rs:SessionStore::cleanup_unpublished_session_directory`
* Automated evidence:
  * `prepared_creation_publishes_detailed_record_before_root_summary`
  * `unpublished_session_cleanup_prevents_history_poisoning`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### specs-27-session-transition-table

* Contract/spec authority: `workspace/specs/specs.md#27`
* Implementation:
  * `lexicon-core/src/session/transition.rs:validate_transition`
  * `lexicon-core/src/session/store.rs:SessionStore::transition_verified`
  * `lexicon-core/src/session/binding.rs:RunningRuntimeSession`
  * `lexicon-core/src/processing/runner.rs:run_processing_runtime_invocation`
  * `lexicon-framework/src/session/coordinator.rs`
  * `lexicon-framework/src/data/foreground.rs:fail_prepared_execution`
* Automated evidence:
  * `specification_27_transition_table_is_exact`
  * `running_session_cannot_transition_directly_to_abandoned`
  * `prepared_creation_publishes_detailed_record_before_root_summary`
  * `session_transitions_to_succeeded_after_successful_handler`
  * `session_transitions_to_failed_after_source_authored_error`
  * `session_transitions_to_failed_after_source_authored_failure`
  * `launch_construction_failure_is_terminal_before_lease_release`
  * `nonzero_child_without_terminal_record_is_reconciled_to_failed`
  * `acquisition_abandon_flag_abandons_failed_session_before_new_run`
  * `processing_abandon_flag_abandons_failed_session_before_new_run`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: Native Linux and Windows verification has not yet produced repository-controlled exact-commit evidence.

### contract-20-source-panic

* Contract/spec authority: `workspace/specs/contract.md#20`
* Implementation:
  * `lexicon-core/src/protocols/http/runner.rs`
  * `lexicon-core/src/processing/runner.rs`
* Automated evidence:
  * `handler_panic_is_caught_reconciled_and_rolls_back`
  * `processing_handler_panic_is_caught_failed_and_never_publishes_canonical_database`
  * `background_panic_preserves_prior_canonical_bytes_and_fails_session`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

### contract-20-abnormal-child-exit

* Contract/spec authority: `workspace/specs/contract.md#20`
* Implementation:
  * `lexicon-framework/src/data/foreground.rs:wait_and_reconcile`
  * `lexicon-framework/src/data/session.rs:persist_abnormal_termination`
* Automated evidence:
  * `nonzero_child_without_terminal_record_is_reconciled_to_failed`
  * `zero_child_without_terminal_record_is_never_reported_as_success`
  * `real_nonzero_child_exit_is_reaped_and_reconciled_to_failed`
  * `wait_or_kill_error_never_reports_false_success`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First native Linux and Windows CI runs that capture the real process-tree child exit and manifest URLs.

## 11. Environment handling for retries and probes (specs.md §44)

### specs-44-no-false-success-on-test-skips

* Contract/spec authority: `workspace/specs/specs.md#44`
* Implementation:
  * `lexicon-framework/src/build/runtime_probe.rs`
  * `lexicon-framework/src/build/runtime_staging.rs`
  * `lexicon-framework/src/lib.rs`
* Automated evidence:
  * `executable_busy_retry_exhaustion_returns_the_original_error_kind`
  * `executable_busy_retry_stops_immediately_after_success`
  * `executable_busy_retry_never_retries_a_different_spawn_error`
  * `staged_temp_layout_round_trip_blob_under_windows_runner`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First CI run that captures the manifest URL.

## 12. CI durable evidence (current.md §13/§14)

### ci-01-conformance-workflow

* Contract/spec authority: `current.md#13`
* Implementation:
  * `.github/workflows/conformance.yml`
  * `automation/verification/conformance.py`
  * `rust-toolchain.toml`
* Repository evidence: the Linux job and final matrix check execute Cargo only inside the digest-pinned test container with read-only source and external target/Cargo-home mounts; Windows is the explicit native exception. Both platform jobs emit authenticated command manifests, the final job merges cfg-gated test indexes, and every action is pinned by full commit SHA.
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: Obtain the first green exact-commit run and publish its workflow and manifest URLs.

### ci-02-verification-manifest

* Contract/spec authority: `current.md#14`
* Implementation:
  * `verification/README.md`
  * `verification/verification-manifest.json`
  * `automation/verification/conformance.py`
  * `automation/verification/test_conformance.py`
* Repository evidence: the producer validates native platform identity and exact toolchain/commit cleanliness before and after command execution. The final validator binds both platform manifests to the workflow SHA, exact commands, repository and native architecture, recomputed log hashes, the exact artifact set, zero skipped/failed/required-ignored tests, and the merged native test index. Deterministic Python tests reject hash tampering, cross-commit evidence, unbound artifacts, and skipped outer workflows. The checked-in manifest remains an explicitly non-evidentiary placeholder.
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `partial`
* Open gap: Run the workflow and retain its per-platform manifests and raw logs; do not replace the checked-in placeholder with unaudited local output.

## 13. Supply chain policy (current.md §12)

### supply-01-release-policy

* Contract/spec authority: `current.md#12`
* Implementation:
  * `workspace/specs/release-policy.md`
  * `verification/dependencies/cargo-metadata.json`
  * `verification/dependencies/cargo-tree.txt`
  * `verification/dependencies/external-dependencies.json`
  * `verification/dependencies/build-scripts.json`
  * `verification/dependencies/proc-macros.json`
  * `verification/dependencies/licenses.json`
  * `verification/dependencies/native-tools.json`
  * `verification/dependencies/advisories.json`
  * `verification/dependencies/inventory-manifest.json`
  * `verification/sbom.cdx.json`
  * `automation/supply-chain/README.md`
  * `automation/supply-chain/produce_inventory.py`
  * `automation/supply-chain/offline_build.sh`
  * `automation/supply-chain/test_produce_inventory.py`
* Repository evidence: the producer forces offline metadata through the supplied vendor root, checks every external package path and `.cargo-checksum.json` file set against `Cargo.lock`, hashes complete package source trees, scans every Rust source in build-script/procedural-macro packages, and binds per-target human approval—including purpose, reviewer, and UTC time—to the complete package digest. The offline driver validates absolute normalized boundaries, refuses any writable source/vendor path, requires the outer rootless/read-only/networkless/capability/no-new-privileges controls, clears inherited environment state, and exposes only separate work directories. Deterministic Python tests cover auxiliary-module digest changes, symlink rejection, stale/incomplete review rejection, vendored checksum mismatch, undeclared vendored files, and vendor-boundary escape. Checked-in reports remain placeholders.
* Required environment: `linux-x86_64` (offline)
* Durable evidence: `none`
* Status: `partial`
* Open gap: Vendor the locked graph, run the producer and hardened builder in a real rootless `--network none` environment, complete human review, and retain the nonempty inventory/SBOM hashes.

## 14. Windows runtime replacement (current.md §15)

### current-15-windows-runtime-replacement

* Contract/spec authority: `current.md#15`
* Implementation:
  * `lexicon-framework/tests/windows_runtime_replacement.rs`
  * `lexicon-framework/src/publication/runtime_pair.rs:publish_runtime_pair`
  * `lexicon-framework/src/publication/runtime_bundle_replacement.rs`
  * `lexicon-framework/src/publication/file_system.rs`
* Automated evidence:
  * `published_runtime_pair_exposes_documented_accessors`
  * `staged_temp_layout_round_trip_blob_under_windows_runner`
  * `windows_processing_executable_lock_release_allows_paired_publication`
  * `windows_processing_executable_lock_exhausts_retry_and_rolls_back_acquisition`
  * `publication_primitive_reachable_from_cross_platform_integration_target`
* Required environment: `linux-x86_64` (compile-pass only), `windows-x86_64` (real evidence)
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: First native Windows CI run that captures the test result and manifest URL.

## 15. MZA release construction (current.md §11) — blocked

### mza-01-pin-upstream-source

* Contract/spec authority: `current.md#11`
* Existing preparation: `automation/build_bundle_mza/mza_artifacts.toml` describes the intended artifact and bundle labels, but no accepted MZA source is pinned.
* Automated evidence: none.
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `not implemented`
* Open gap: MZA does not publish the required Protocol 1 installer API, and this repository has neither `.gitmodules` nor a pinned `automation/build_bundle_mza/mza/` source tree. The exogenous API blocker is recorded in `current.md` §3.

### mza-02-real-installer-entrypoint

* Contract/spec authority: `current.md#11`
* Implementation:
  * `lexicon-bundle/build.rs` (Protocol 1 input parser and standalone empty-adapter path only)
  * `lexicon-bundle/src/main.rs` (`MzaBundleInput` include boundary plus the still-obsolete local installer)
  * `lexicon-bundle/Cargo.toml`
* Automated evidence: none; no Rust command or MZA integration run is attached.
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `not implemented`
* Open gap: Replace the local installer with the exact accepted upstream installer types and entrypoint after `mza-01`; prove a nonempty `lexicon_cli` archive through an integration build.

### release-01-locked-noninteractive-build

* Contract/spec authority: `current.md#11`
* Implementation: none; `automation/build_bundle_mza/build_release.sh` is absent.
* Automated evidence: none.
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `not implemented`
* Open gap: Pin the accepted MZA source, then add the locked, noninteractive release script and its native-platform evidence.

### release-02-obsolete-orchestration-deleted

* Contract/spec authority: `current.md#11`
* Current repository state:
  * `automation/build_bundle_install/` is still present.
  * `lexicon-install.toml` and the Lexicon-owned installer modules are still present.
  * The container and README paths have not been retargeted to an MZA-owned release script.
  * `.cargo/config.toml` and an offline `vendored-sources` replacement are absent.
  * The root `Cargo.lock` is the workspace lockfile.
* Repository evidence: the materialized tree directly shows the remaining legacy paths and absent replacement paths.
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `not implemented`
* Open gap: Perform the cleanup only with the accepted MZA replacement in the same change; then verify the locked offline release path.

## 16. Master completion criteria (current.md §18) — blocked

### final-18-conformance

* Contract/spec authority: `current.md#18`
* Implementation: this status document and `workspace/specs/conformance.toml`.
* Planned automated evidence: once implemented, `.github/workflows/conformance.yml` must run the `conformance-final` gate.
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `not implemented`
* Open gap: Items 1..29 of §18 remain until every prerequisite passes — including Gate 6 (MZA upstream API) and durable green CI evidence.

---

## 17. Constrained operator diagnostics and milestones (contract.md §20A, specs.md §43A)

### contract-20a-terminal-diagnostic-funnel

* Contract/spec authority: `workspace/specs/contract.md#20a`, `workspace/specs/specs.md#43a`
* Implementation:
  * `lexicon-core/src/diagnostic.rs`
  * `lexicon-cli/src/cli/mod.rs:run_native`
  * `lexicon-framework/src/data/error.rs:ReportableDiagnostic for ForegroundDataExecutionError`
  * `lexicon-framework/src/data/session.rs:project_session_coordination_error`
  * `lexicon-framework/src/data/foreground.rs`
  * `lexicon-framework/src/data/background.rs`
  * `lexicon-framework/src/session/error.rs:SessionCoordinationError::SessionBound`
  * `lexicon-framework/src/session/coordinator.rs:project_session_store_error`
  * `lexicon-framework/src/lib.rs:ReportableDiagnostic implementations`
  * `lexicon-core/src/protocols/http/runner.rs`
  * `lexicon-core/src/processing/runner.rs`
  * `lexicon-core/src/session/error.rs:SessionStoreError::committed_session_failure`
  * `lexicon-core/src/session/store.rs`
* Automated evidence:
  * `core::diagnostic::tests::stable_code_registry_is_unique_and_well_formed`
  * `core::diagnostic::tests::every_session_code_has_a_safe_summary`
  * `core::diagnostic::tests::renderer_has_one_stable_coded_line`
  * `core::diagnostic::tests::compound_renderer_preserves_primary_and_marks_secondary_as_warning`
  * `cli::cli::tests::terminal_renderer_uses_stable_code_and_omits_raw_error_text`
  * `cli::cli::tests::durable_session_code_is_the_terminal_cli_code`
  * `cli::cli::tests::validated_session_wrapper_is_retained_in_the_terminal_report`
  * `cli::cli::tests::authoritative_session_code_is_not_duplicated_as_a_warning`
  * `cli::cli::tests::authoritative_session_code_keeps_distinct_handoff_context_subordinate`
  * `cli::cli::tests::cancellation_keeps_durable_session_code_and_signal_exit_class`
  * `cli::cli::tests::aggregate_build_failure_uses_coded_safe_subordinate_details`
  * `core::protocols::http::runner::tests::ordinary_managed_http_failure_does_not_duplicate_parent_terminal_output`
  * `core::processing::runner::tests::ordinary_managed_processing_failure_does_not_duplicate_parent_terminal_output`
  * `framework::session::coordinator::tests::launch_construction_failure_is_terminal_before_lease_release`
  * `core::session::store::history_tests::creation_summary_failure_retains_committed_session_identity_and_code`
  * `framework::data::foreground::tests::nonzero_child_without_terminal_record_is_reconciled_to_failed`
  * `framework::data::foreground::tests::real_nonzero_child_exit_is_reaped_and_reconciled_to_failed`
  * `framework::publication::runtime_pair::tests::committed_cleanup_failure_retains_recoverable_state_for_the_next_publication`
  * `core::processing::publication::tests::postinstall_fault_returns_success_warning_and_keeps_new_database`
  * `diagnostic_contract::invalid_usage_has_one_coded_status_two_outcome`
  * `diagnostic_contract::project_initialization_failure_omits_rejected_raw_name`
  * `diagnostic_contract::commands_do_not_create_a_general_lexicon_log`
  * `cli::cli::tests::completed_supervision_uses_coarse_shell_statuses`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: Cargo formatting, check, complete tests, and native platform evidence have not yet run for this extracted artifact. Until they do, this row is an implementation claim only, not conformance evidence.

### specs-43a-managed-panic-output-policy

* Contract/spec authority: `workspace/specs/specs.md#43a`
* Implementation:
  * `lexicon-core/src/diagnostic.rs:install_managed_runtime_panic_sanitizer`
  * `lexicon-core/src/protocols/http/runner.rs:run_http_source`
  * `lexicon-core/src/processing/runner.rs:run_processing_source`
* Automated evidence:
  * `core::diagnostic::tests::managed_runtime_panic_hook_suppresses_payload_in_subprocess`
  * `core::protocols::http::runner::tests::ordinary_managed_http_failure_does_not_duplicate_parent_terminal_output`
  * `core::processing::runner::tests::ordinary_managed_processing_failure_does_not_duplicate_parent_terminal_output`
  * `core::protocols::http::runner::execution_tests::handler_panic_is_caught_reconciled_and_rolls_back`
  * `core::processing::runner::execution_tests::processing_handler_panic_is_caught_failed_and_never_publishes_canonical_database`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: The subprocess disclosure tests and managed-runner suites require an actual Cargo run on both supported native platforms.

### contract-22-diagnostic-registry-version

* Contract/spec authority: `workspace/specs/contract.md#22`, `workspace/specs/specs.md#43a`
* Implementation:
  * `lexicon-core/src/diagnostic.rs:DIAGNOSTIC_CODE_REGISTRY_VERSION`
  * `lexicon-core/src/diagnostic.rs:codes`
* Automated evidence:
  * `core::diagnostic::tests::stable_code_registry_is_unique_and_well_formed`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: Cargo and native platform evidence have not run for this extracted artifact.

### specs-43a-sparse-success-milestones

* Contract/spec authority: `workspace/specs/specs.md#43a`
* Implementation:
  * `lexicon-core/src/diagnostic.rs:write_milestone`
  * `lexicon-cli/src/cli/mod.rs:dispatch`
* Automated evidence:
  * `diagnostic_contract::successful_init_emits_one_project_milestone`
  * `diagnostic_contract::successful_milestone_cannot_be_extended_by_a_newline_in_the_parent_path`
  * `diagnostic_contract::help_and_version_remain_successful_display_outcomes`
* Required environment: `linux-x86_64`, `windows-x86_64`
* Durable evidence: `none`
* Status: `implemented, unverified`
* Open gap: Full CLI integration verification has not yet run in this environment.

## Explicitly Deferred Items (per `current.md` §16)

These are deferred by contract, not by stagnation:

1. `specs-46-core-owned-task-queue`: deferred per `workspace/specs/specs.md#46`
   in favor of the source-owned SQLite model.
2. `specs-2-protocols-beyond-http`: deferred per `workspace/specs/specs.md#2`;
   HTTP is the initial supported protocol.
3. `specs-40-project-wide-publication-transaction`: deferred per
   `workspace/specs/specs.md#40`; per-pair runtime publication is
   completed and tested, but a project-wide transaction across every
   source/protocol pairing is out of scope for Contract V1.

No row above claims `Status: conformant`. Conformant status requires
durable evidence tied to an exact commit, and per `current.md` §17
"a number in current.md without the attached exact-SHA manifest is not
evidence." A row reaches `conformant` only after `.github/workflows/conformance.yml`
publishes a green manifest URL and that URL replaces `durable_evidence = none`
in this same commit.
