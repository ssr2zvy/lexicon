use std::env;

mod cli;
mod envpath;
mod install;
mod model;
mod pathutil;

// Protocol-agnostic part of cargo-bundler-v0.1.0: build.rs consumes the
// MZA_BUNDLE_INPUTS TOML path and copies admitted archives into OUT_DIR.
pub struct MzaBundleInput {
    pub label: &'static str,
    pub archive: &'static [u8],
}

include!(concat!(env!("OUT_DIR"), "/mza_bundle_inputs.rs"));
include!(concat!(env!("OUT_DIR"), "/lexicon_install_layout.rs"));

const MARKER: &str = "# Added by the lexicon installer";

fn main() {
    let args: Vec<String> = env::args().skip(1).collect();
    std::process::exit(cli::dispatch(&args));
}
