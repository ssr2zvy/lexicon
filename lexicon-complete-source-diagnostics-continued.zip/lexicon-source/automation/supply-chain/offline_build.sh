#!/usr/bin/env bash
# Fail-closed driver for a network-isolated, vendored Lexicon build.
set -euo pipefail

repo_root="${LEXICON_OFFLINE_REPOSITORY:-/lexicon/source}"
vendor_root="${LEXICON_OFFLINE_VENDOR_DIR:-/lexicon/vendor}"
target_root="${LEXICON_OFFLINE_TARGET_DIR:-/lexicon/work/target}"
cargo_home="${LEXICON_OFFLINE_CARGO_HOME:-/lexicon/work/cargo-home}"
temporary_root="${LEXICON_OFFLINE_TMP_DIR:-/lexicon/work/tmp}"

fail() {
    printf 'offline build refused: %s\n' "$1" >&2
    exit 2
}

validate_path() {
    local path_name="$1"
    local path_value="$2"
    case "$path_value" in
        /*) ;;
        *) fail "$path_name must be an absolute path" ;;
    esac
    case "$path_value" in
        *[!A-Za-z0-9_./-]*) fail "$path_name contains unsupported characters" ;;
    esac
}

is_within() {
    local candidate="$1"
    local boundary="$2"
    [ "$candidate" = "$boundary" ] || [ "${candidate#"$boundary"/}" != "$candidate" ]
}

validate_path LEXICON_OFFLINE_REPOSITORY "$repo_root"
validate_path LEXICON_OFFLINE_VENDOR_DIR "$vendor_root"
validate_path LEXICON_OFFLINE_TARGET_DIR "$target_root"
validate_path LEXICON_OFFLINE_CARGO_HOME "$cargo_home"
validate_path LEXICON_OFFLINE_TMP_DIR "$temporary_root"

repo_root="$(realpath -e "$repo_root")" || fail 'repository path cannot be resolved'
vendor_root="$(realpath -e "$vendor_root")" || fail 'vendor path cannot be resolved'
target_root="$(realpath -m "$target_root")" || fail 'target path cannot be normalized'
cargo_home="$(realpath -m "$cargo_home")" || fail 'Cargo home path cannot be normalized'
temporary_root="$(realpath -m "$temporary_root")" || fail 'temporary path cannot be normalized'

[ "${LEXICON_NETWORK_ISOLATION:-}" = "confirmed" ] || \
    fail 'LEXICON_NETWORK_ISOLATION=confirmed is required from the outer --network none runner'
[ "${LEXICON_READ_ONLY_ROOT:-}" = "confirmed" ] || \
    fail 'LEXICON_READ_ONLY_ROOT=confirmed is required from the outer --read-only runner'
[ "${LEXICON_ROOTLESS_USER_NAMESPACE:-}" = "confirmed" ] || \
    fail 'LEXICON_ROOTLESS_USER_NAMESPACE=confirmed is required from the outer rootless runner'
[ "${LEXICON_CAPABILITIES_DROPPED:-}" = "confirmed" ] || \
    fail 'LEXICON_CAPABILITIES_DROPPED=confirmed is required from the outer --cap-drop all runner'
[ "${LEXICON_NO_NEW_PRIVILEGES:-}" = "confirmed" ] || \
    fail 'LEXICON_NO_NEW_PRIVILEGES=confirmed is required from the outer no-new-privileges runner'
[ -f "$repo_root/Cargo.toml" ] || fail 'repository Cargo.toml is missing'
[ -f "$repo_root/Cargo.lock" ] || fail 'repository Cargo.lock is missing'
[ -d "$vendor_root" ] || fail 'vendored Cargo source directory is missing'
[ -n "$(find "$vendor_root" -mindepth 2 -name .cargo-checksum.json -type f -print -quit)" ] || \
    fail 'vendored Cargo source directory contains no Cargo checksums'
[ -z "$(find "$repo_root" -xdev -writable -print -quit)" ] || \
    fail 'every project source path must be mounted read-only'
[ -z "$(find "$vendor_root" -xdev -writable -print -quit)" ] || \
    fail 'every vendored source path must be mounted read-only'

for writable_root in "$target_root" "$cargo_home" "$temporary_root"; do
    is_within "$writable_root" "$repo_root" && fail 'writable work paths must be outside project source'
    is_within "$writable_root" "$vendor_root" && fail 'writable work paths must be outside vendored source'
done

for variable in SSH_AUTH_SOCK DOCKER_HOST CONTAINER_HOST AWS_ACCESS_KEY_ID \
    AWS_SECRET_ACCESS_KEY GITHUB_TOKEN CARGO_REGISTRY_TOKEN; do
    [ -z "${!variable:-}" ] || fail "$variable must not enter the builder"
done
[ ! -S /var/run/docker.sock ] || fail 'Docker socket is mounted'
[ ! -S /run/podman/podman.sock ] || fail 'Podman socket is mounted'

mkdir -p "$target_root" "$cargo_home" "$temporary_root"
config="$cargo_home/config.toml"
printf '%s\n' \
    '[source.crates-io]' \
    'replace-with = "vendored-sources"' \
    '[source.vendored-sources]' \
    "directory = \"$vendor_root\"" \
    '[net]' \
    'offline = true' > "$config"

cargo_executable="$(command -v cargo)"
[ -n "$cargo_executable" ] || fail 'cargo is absent from the pinned builder image'
cargo_executable="$(realpath -e "$cargo_executable")"
[ ! -w "$cargo_executable" ] || fail 'cargo executable must come from the read-only builder image'
tool_directory="$(dirname "$cargo_executable")"

env -i \
    "PATH=$tool_directory:/usr/local/bin:/usr/bin:/bin" \
    "CARGO_HOME=$cargo_home" \
    CARGO_NET_OFFLINE=true \
    CARGO_INCREMENTAL=0 \
    "CARGO_TARGET_DIR=$target_root" \
    "TMPDIR=$temporary_root" \
    "$cargo_executable" build \
    --manifest-path "$repo_root/Cargo.toml" \
    --workspace \
    --release \
    --locked \
    --offline \
    --frozen \
    --target-dir "$target_root"
