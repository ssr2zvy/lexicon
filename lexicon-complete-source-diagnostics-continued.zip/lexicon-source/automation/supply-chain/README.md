# Supply-chain inventory and isolated build

These tools produce review inputs; they do not decide that dependency code is
benign. Build scripts and procedural macros execute native code during a Cargo
build, so approval remains a human security decision tied to exact bytes.

## Preparation

In a separate network-enabled preparation environment, resolve the locked
graph and create a content-addressed vendor snapshot:

```bash
cargo vendor --locked vendor
```

Hash and retain that snapshot before moving it into the offline review/build
environment. Do not perform dependency resolution in the isolated builder.

## Inventory

Run the inventory only against the reviewed vendor snapshot:

```bash
python automation/supply-chain/produce_inventory.py \
  --vendor-root /absolute/path/to/vendor \
  --output-dir verification/dependencies
```

The producer:

- forces Cargo metadata and tree resolution through the supplied vendor root;
- rejects external package paths outside that root;
- validates every vendored file against `.cargo-checksum.json` and the
  `Cargo.lock` package checksum;
- hashes the complete package source tree, not only `build.rs` or the
  procedural-macro entrypoint;
- conservatively scans every Rust source file in each relevant package for
  filesystem, environment, network, subprocess, native-link, and literal-tool
  signals;
- lists the exact sources scanned and gives every executable target a stable
  review key;
- never converts static signal absence into an approval.

Static signals are leads for review, not a maliciousness detector. Reviewers
must inspect dynamic command construction, included/generated source,
transitive build dependencies, unsafe code, native libraries, and behavior not
recognized by the literal scanner.

## Review file

Review input is a JSON object keyed by the emitted `review_key`:

```json
{
  "registry+https://github.com/rust-lang/crates.io-index#example@1.2.3::custom-build::build-script-build": {
    "package_source_sha256": "<64 lowercase hex characters>",
    "status": "approved",
    "purpose": "Generate the platform bindings required by example",
    "reviewer": "<reviewer identity>",
    "reviewed_at": "2026-01-01T00:00:00Z"
  }
}
```

Use the review file on a second inventory pass:

```bash
python automation/supply-chain/produce_inventory.py \
  --vendor-root /absolute/path/to/vendor \
  --review-file /absolute/path/to/reviews.json \
  --output-dir verification/dependencies
```

Changing any package source file invalidates every approval for executable
targets in that package. Missing purpose, reviewer, UTC timestamp, recognized
status, or exact package digest fails closed.

## Isolated build

`offline_build.sh` is the inner builder. An outer rootless container/VM must
actually enforce network isolation, a read-only root filesystem, read-only
source/vendor mounts, dropped capabilities, and no-new-privileges. The inner
script requires explicit acknowledgements of those boundaries, verifies all
source and vendor paths are non-writable, clears the inherited environment,
and gives Cargo only separate target, Cargo-home, and temporary directories.

The container remains useful: it limits what malicious build-time code can
reach or persist. It does not make that code trustworthy, prove the resulting
binary benign, or replace source review, quarantine, native testing, malware
scanning, reproducibility comparison, and provenance verification.
