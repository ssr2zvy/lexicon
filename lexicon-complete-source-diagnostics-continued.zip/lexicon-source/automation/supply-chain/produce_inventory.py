#!/usr/bin/env python3
"""Inventory dependency code that can execute while Lexicon is built.

This tool classifies build scripts and procedural macros; it never labels code
benign or malicious automatically. Review status is accepted only from an
explicit reviewer file keyed by package identity and source hash.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import pathlib
import re
import stat
import subprocess
import tempfile
import tomllib
import uuid
from typing import Any


ROOT = pathlib.Path(__file__).resolve().parents[2]
EXCLUDED_SOURCE_COMPONENTS = {".git"}
INVENTORY_OUTPUT_FILES = {
    "advisories.json",
    "build-scripts.json",
    "cargo-metadata.json",
    "cargo-tree.txt",
    "external-dependencies.json",
    "inventory-manifest.json",
    "licenses.json",
    "native-tools.json",
    "proc-macros.json",
}


def sha256_file(path: pathlib.Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def package_source_files(package_root: pathlib.Path) -> list[pathlib.Path]:
    files = []
    for path in package_root.rglob("*"):
        relative = path.relative_to(package_root)
        if any(component in EXCLUDED_SOURCE_COMPONENTS for component in relative.parts):
            continue
        if path.is_symlink():
            raise RuntimeError(f"package source contains a symbolic link: {path}")
        if path.is_file():
            files.append(path)
    return sorted(files, key=lambda path: os.fsencode(path.relative_to(package_root)))


def source_tree_sha256(
    package_root: pathlib.Path, files: list[pathlib.Path] | None = None
) -> str:
    files = package_source_files(package_root) if files is None else files
    digest = hashlib.sha256()
    for path in files:
        relative = os.fsencode(path.relative_to(package_root))
        digest.update(len(relative).to_bytes(8, "big"))
        digest.update(relative)
        metadata = path.stat()
        mode = stat.S_IMODE(metadata.st_mode)
        digest.update(mode.to_bytes(4, "big"))
        size = metadata.st_size
        digest.update(size.to_bytes(8, "big"))
        with path.open("rb") as handle:
            for chunk in iter(lambda: handle.read(1024 * 1024), b""):
                digest.update(chunk)
    return digest.hexdigest()


def run(argv: list[str], env: dict[str, str] | None = None) -> bytes:
    completed = subprocess.run(
        argv, cwd=ROOT, env=env, check=False, capture_output=True
    )
    if completed.returncode != 0:
        raise RuntimeError(
            f"command failed ({completed.returncode}): {argv!r}\n"
            + completed.stderr.decode("utf-8", "replace")
        )
    return completed.stdout


def load_lock_checksums() -> dict[tuple[str, str, str], str]:
    with (ROOT / "Cargo.lock").open("rb") as handle:
        lock = tomllib.load(handle)
    checksums = {}
    for package in lock.get("package", []):
        source = package.get("source", "workspace")
        checksums[(package["name"], package["version"], source)] = package.get(
            "checksum", ""
        )
    return checksums


def require_source_boundary(
    package: dict[str, Any], package_root: pathlib.Path, vendor_root: pathlib.Path
) -> None:
    package_root = package_root.resolve()
    boundary = vendor_root if package.get("source") else ROOT
    try:
        package_root.relative_to(boundary.resolve())
    except ValueError as error:
        kind = "external vendored" if package.get("source") else "workspace/path"
        raise RuntimeError(
            f"{kind} package source escapes its approved boundary: {package_root}"
        ) from error


def verify_vendored_checksum(
    package_root: pathlib.Path, expected_package_checksum: str
) -> None:
    checksum_path = package_root / ".cargo-checksum.json"
    if checksum_path.is_symlink() or not checksum_path.is_file():
        raise RuntimeError(f"vendored package is missing .cargo-checksum.json: {package_root}")
    try:
        document = json.loads(checksum_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise RuntimeError(f"vendored checksum document is malformed: {checksum_path}") from error
    if not isinstance(document, dict) or not isinstance(document.get("files"), dict):
        raise RuntimeError(f"vendored checksum document has the wrong shape: {checksum_path}")
    recorded_package_checksum = document.get("package") or ""
    if expected_package_checksum and recorded_package_checksum != expected_package_checksum:
        raise RuntimeError(f"vendored package checksum disagrees with Cargo.lock: {package_root}")

    declared = set()
    for relative_text, expected_digest in document["files"].items():
        if (
            not isinstance(relative_text, str)
            or not isinstance(expected_digest, str)
            or not re.fullmatch(r"[0-9a-f]{64}", expected_digest)
        ):
            raise RuntimeError(f"vendored file checksum entry is malformed: {checksum_path}")
        relative = pathlib.PurePosixPath(relative_text)
        if relative.is_absolute() or ".." in relative.parts or not relative.parts:
            raise RuntimeError(f"vendored checksum path escapes its package: {relative_text}")
        path = package_root.joinpath(*relative.parts)
        if path.is_symlink() or not path.is_file() or sha256_file(path) != expected_digest:
            raise RuntimeError(f"vendored file checksum mismatch: {path}")
        declared.add(path.relative_to(package_root).as_posix())

    actual = set()
    for path in package_root.rglob("*"):
        if path.is_symlink():
            raise RuntimeError(f"vendored package contains a symbolic link: {path}")
        if path.is_file() and path.name != ".cargo-checksum.json":
            actual.add(path.relative_to(package_root).as_posix())
    if actual != declared:
        missing = sorted(declared - actual)
        unbound = sorted(actual - declared)
        raise RuntimeError(
            f"vendored package file set disagrees with checksums at {package_root}; "
            f"missing={missing!r}, unbound={unbound!r}"
        )


def signals(source: str) -> dict[str, Any]:
    patterns = {
        "network": r"TcpStream|UdpSocket|http://|https://|reqwest|ureq|curl|wget",
        "subprocess": r"(?:std::)?process::Command|Command::new",
        "environment": r"env::(?:var|var_os)|std::env",
        "filesystem": r"std::fs|fs::(?:read|write|copy|remove|rename|create)",
        "native_link": r"cargo:rustc-link-(?:lib|search|arg)",
    }
    found = {
        name: sorted(set(re.findall(pattern, source, flags=re.IGNORECASE)))
        for name, pattern in patterns.items()
    }
    tools = sorted(
        set(
            match.group(1)
            for match in re.finditer(
                r"Command::new\s*\(\s*[rb#]*\"([^\"]+)\"", source
            )
        )
    )
    return {"signals": found, "literal_invoked_tools": tools}


def review_for(
    reviews: dict[str, Any], review_key: str, package_source_sha256: str
) -> dict[str, str]:
    review = reviews.get(review_key)
    if review is None:
        return {
            "status": "unreviewed",
            "purpose": "",
            "reviewer": "",
            "reviewed_at": "",
        }
    if not isinstance(review, dict):
        raise RuntimeError(f"review entry must be an object: {review_key}")
    if review.get("package_source_sha256") != package_source_sha256:
        return {
            "status": "unreviewed",
            "purpose": "",
            "reviewer": "",
            "reviewed_at": "",
        }
    status = review.get("status")
    if status not in {"approved", "rejected"}:
        raise RuntimeError(f"review entry has an invalid status: {review_key}")
    purpose = review.get("purpose")
    reviewer = review.get("reviewer")
    reviewed_at = review.get("reviewed_at")
    if not all(isinstance(value, str) and value.strip() for value in (purpose, reviewer, reviewed_at)):
        raise RuntimeError(f"review entry is missing purpose/reviewer/time: {review_key}")
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z", reviewed_at):
        raise RuntimeError(f"review entry has a non-RFC3339 UTC timestamp: {review_key}")
    return {
        "status": status,
        "purpose": purpose,
        "reviewer": reviewer,
        "reviewed_at": reviewed_at,
    }


def target_review_key(package_id: str, category: str, target: str) -> str:
    return f"{package_id}::{category}::{target}"


def package_base(
    package: dict[str, Any],
    checksums: dict[tuple[str, str, str], str],
    package_source_sha256: str,
) -> dict[str, Any]:
    source = package.get("source") or "workspace"
    return {
        "id": package["id"],
        "name": package["name"],
        "version": package["version"],
        "source": source,
        "checksum": checksums.get((package["name"], package["version"], source), ""),
        "package_source_sha256": package_source_sha256,
        "manifest_path": package["manifest_path"],
    }


def write_json(path: pathlib.Path, value: Any) -> None:
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def produce(
    output_dir: pathlib.Path,
    review_path: pathlib.Path | None,
    vendor_root: pathlib.Path,
) -> None:
    vendor_root = vendor_root.resolve(strict=True)
    if not vendor_root.is_dir():
        raise RuntimeError(f"vendor root is not a directory: {vendor_root}")
    if output_dir.is_symlink():
        raise RuntimeError("inventory output directory must not be a symbolic link")
    output_dir.mkdir(parents=True, exist_ok=True)
    unexpected_outputs = {
        path.name for path in output_dir.iterdir()
    } - INVENTORY_OUTPUT_FILES
    if unexpected_outputs:
        raise RuntimeError(
            f"inventory output directory contains unexpected entries: {sorted(unexpected_outputs)!r}"
        )
    if any(path.is_symlink() or not path.is_file() for path in output_dir.iterdir()):
        raise RuntimeError("inventory output directory contains a non-regular entry")
    sbom_path = output_dir.parent / "sbom.cdx.json"
    if sbom_path.is_symlink():
        raise RuntimeError("SBOM destination must not be a symbolic link")
    with tempfile.TemporaryDirectory(prefix="lexicon-inventory-cargo-home-") as cargo_home:
        cargo_home_path = pathlib.Path(cargo_home)
        (cargo_home_path / "config.toml").write_text(
            "[source.crates-io]\n"
            'replace-with = "vendored-sources"\n'
            "[source.vendored-sources]\n"
            f"directory = {json.dumps(str(vendor_root))}\n"
            "[net]\n"
            "offline = true\n",
            encoding="utf-8",
        )
        cargo_environment = os.environ.copy()
        cargo_environment["CARGO_HOME"] = str(cargo_home_path)
        cargo_environment["CARGO_NET_OFFLINE"] = "true"
        metadata_bytes = run(
            ["cargo", "metadata", "--locked", "--offline", "--format-version", "1"],
            cargo_environment,
        )
        tree = run(
            [
                "cargo", "tree", "--workspace", "--locked", "--offline",
                "--edges", "normal,build,dev",
            ],
            cargo_environment,
        )
    metadata = json.loads(metadata_bytes)
    (output_dir / "cargo-metadata.json").write_bytes(metadata_bytes + b"\n")
    (output_dir / "cargo-tree.txt").write_bytes(tree)

    reviews: dict[str, Any] = {}
    if review_path is not None:
        reviews = json.loads(review_path.read_text(encoding="utf-8"))
    checksums = load_lock_checksums()
    build_scripts = []
    proc_macros = []
    packages = []
    package_bases: dict[str, dict[str, Any]] = {}

    for package in metadata["packages"]:
        package_root = pathlib.Path(package["manifest_path"]).parent
        require_source_boundary(package, package_root, vendor_root)
        source = package.get("source") or "workspace"
        expected_checksum = checksums.get(
            (package["name"], package["version"], source), ""
        )
        if package.get("source"):
            verify_vendored_checksum(package_root, expected_checksum)
        source_files = package_source_files(package_root)
        package_digest = source_tree_sha256(package_root, source_files)
        base = package_base(package, checksums, package_digest)
        package_bases[package["id"]] = base
        packages.append(base)
        rust_sources = [path for path in source_files if path.suffix == ".rs"]
        package_rust_text = "\n".join(
            path.read_text(encoding="utf-8", errors="replace") for path in rust_sources
        )
        scanned_rust_sources = [
            str(path.relative_to(package_root)) for path in rust_sources
        ]
        for target in package.get("targets", []):
            kinds = set(target.get("kind", []))
            if "custom-build" in kinds:
                source_path = pathlib.Path(target["src_path"])
                source_hash = sha256_file(source_path)
                review_key = target_review_key(
                    package["id"], "custom-build", target["name"]
                )
                build_scripts.append(
                    {
                        **base,
                        "target": target["name"],
                        "source_path": str(source_path.relative_to(package_root)),
                        "source_sha256": source_hash,
                        "review_key": review_key,
                        "scanned_rust_sources": scanned_rust_sources,
                        **signals(package_rust_text),
                        "review": review_for(reviews, review_key, package_digest),
                    }
                )
            if "proc-macro" in kinds:
                source_path = pathlib.Path(target["src_path"])
                source_hash = sha256_file(source_path)
                review_key = target_review_key(
                    package["id"], "proc-macro", target["name"]
                )
                proc_macros.append(
                    {
                        **base,
                        "target": target["name"],
                        "source_path": str(source_path.relative_to(package_root)),
                        "source_sha256": source_hash,
                        "review_key": review_key,
                        "scanned_rust_sources": scanned_rust_sources,
                        **signals(package_rust_text),
                        "review": review_for(reviews, review_key, package_digest),
                    }
                )

    licenses = [
        {
            **package_bases[package["id"]],
            "license": package.get("license"),
            "license_file": package.get("license_file"),
        }
        for package in metadata["packages"]
    ]
    components = [
        {
            "type": "library",
            "name": package["name"],
            "version": package["version"],
            "bom-ref": package["id"],
            "purl": f"pkg:cargo/{package['name']}@{package['version']}",
            "hashes": [
                {
                    "alg": "SHA-256",
                    "content": package["checksum"] or package["package_source_sha256"],
                }
            ],
        }
        for package in packages
    ]

    write_json(
        output_dir / "external-dependencies.json",
        {"schema_version": 1, "status": "generated", "items": packages},
    )
    write_json(
        output_dir / "build-scripts.json",
        {"schema_version": 1, "status": "generated", "items": build_scripts},
    )
    write_json(
        output_dir / "proc-macros.json",
        {"schema_version": 1, "status": "generated", "items": proc_macros},
    )
    write_json(
        output_dir / "licenses.json",
        {"schema_version": 1, "status": "generated", "items": licenses},
    )
    write_json(
        output_dir / "native-tools.json",
        {
            "schema_version": 1,
            "status": "generated",
            "literal_tools": sorted(
                {tool for entry in build_scripts for tool in entry["literal_invoked_tools"]}
            ),
            "note": "Literal static extraction only; dynamic tool names require manual review.",
        },
    )
    write_json(
        output_dir / "advisories.json",
        {
            "schema_version": 1,
            "status": "unassessed",
            "reason": "No pinned advisory database/report was supplied to this offline producer.",
            "advisories": [],
        },
    )
    write_json(
        output_dir.parent / "sbom.cdx.json",
        {
            "bomFormat": "CycloneDX",
            "specVersion": "1.5",
            "serialNumber": "urn:uuid:"
            + str(
                uuid.uuid5(
                    uuid.NAMESPACE_URL,
                    "\n".join(
                        f"{package['id']}:{package['package_source_sha256']}"
                        for package in packages
                    ),
                )
            ),
            "version": 1,
            "metadata": {"component": {"type": "application", "name": "lexicon"}},
            "components": components,
        },
    )

    generated = sorted(
        path
        for path in output_dir.iterdir()
        if path.is_file() and path.name != "inventory-manifest.json"
    )
    manifest = {
        "schema_version": 1,
        "status": "generated",
        "build_script_count": len(build_scripts),
        "proc_macro_count": len(proc_macros),
        "package_count": len(packages),
        "all_build_scripts_reviewed": all(
            entry["review"]["status"] == "approved" for entry in build_scripts
        ),
        "all_proc_macros_reviewed": all(
            entry["review"]["status"] == "approved" for entry in proc_macros
        ),
        "files": [
            {"path": path.name, "sha256": sha256_file(path)} for path in generated
        ],
        "sbom": {"path": "../sbom.cdx.json", "sha256": sha256_file(sbom_path)},
    }
    write_json(output_dir / "inventory-manifest.json", manifest)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output-dir",
        type=pathlib.Path,
        default=ROOT / "verification" / "dependencies",
    )
    parser.add_argument("--review-file", type=pathlib.Path)
    parser.add_argument(
        "--vendor-root",
        type=pathlib.Path,
        default=ROOT / "vendor",
    )
    args = parser.parse_args()
    try:
        produce(args.output_dir.resolve(), args.review_file, args.vendor_root)
    except (OSError, RuntimeError, subprocess.SubprocessError, json.JSONDecodeError) as error:
        print(f"supply inventory failed: {error}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
