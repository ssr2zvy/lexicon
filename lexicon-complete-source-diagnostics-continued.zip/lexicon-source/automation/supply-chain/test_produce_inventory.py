from __future__ import annotations

import importlib.util
import hashlib
import json
import pathlib
import tempfile
import unittest


MODULE_PATH = pathlib.Path(__file__).with_name("produce_inventory.py")
SPEC = importlib.util.spec_from_file_location("lexicon_supply_inventory", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
inventory = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(inventory)


class PackageSourceInventoryTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = pathlib.Path(self.temporary.name)
        (self.root / "src").mkdir()
        (self.root / "Cargo.toml").write_text("[package]\nname='fixture'\n", encoding="utf-8")
        (self.root / "build.rs").write_text("mod helper;\nfn main() {}\n", encoding="utf-8")
        (self.root / "helper.rs").write_text("pub fn helper() {}\n", encoding="utf-8")
        (self.root / "src" / "lib.rs").write_text("pub fn library() {}\n", encoding="utf-8")

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def test_auxiliary_build_script_module_changes_package_digest(self) -> None:
        before = inventory.source_tree_sha256(self.root)
        (self.root / "helper.rs").write_text(
            'pub fn helper() { std::process::Command::new("curl"); }\n',
            encoding="utf-8",
        )
        after = inventory.source_tree_sha256(self.root)
        self.assertNotEqual(before, after)

    def test_executable_mode_changes_package_digest(self) -> None:
        helper = self.root / "helper.rs"
        before = inventory.source_tree_sha256(self.root)
        original_mode = helper.stat().st_mode
        helper.chmod(original_mode | 0o111)
        if helper.stat().st_mode == original_mode:
            self.skipTest("host filesystem does not expose executable mode changes")
        self.assertNotEqual(inventory.source_tree_sha256(self.root), before)

    def test_git_metadata_is_excluded_but_package_target_files_are_bound(self) -> None:
        before = inventory.source_tree_sha256(self.root)
        (self.root / ".git").mkdir()
        (self.root / ".git" / "index").write_text("ignored", encoding="utf-8")
        self.assertEqual(inventory.source_tree_sha256(self.root), before)
        (self.root / "target").mkdir()
        (self.root / "target" / "payload").write_text("bound", encoding="utf-8")
        self.assertNotEqual(inventory.source_tree_sha256(self.root), before)

    def test_package_source_symlink_is_rejected(self) -> None:
        if not hasattr(pathlib.Path, "symlink_to"):
            self.skipTest("symlinks unavailable")
        link = self.root / "linked.rs"
        try:
            link.symlink_to(self.root / "helper.rs")
        except OSError as error:
            self.skipTest(f"symlink creation unavailable: {error}")
        with self.assertRaisesRegex(RuntimeError, "symbolic link"):
            inventory.source_tree_sha256(self.root)

    def test_review_is_bound_to_complete_package_digest(self) -> None:
        key = "fixture 1.0.0::custom-build::build-script-build"
        reviews = {
            key: {
                "package_source_sha256": "a" * 64,
                "status": "approved",
                "purpose": "generate fixture bindings",
                "reviewer": "reviewer",
                "reviewed_at": "2026-01-01T00:00:00Z",
            }
        }
        approved = inventory.review_for(reviews, key, "a" * 64)
        stale = inventory.review_for(reviews, key, "b" * 64)
        self.assertEqual(approved["status"], "approved")
        self.assertEqual(stale["status"], "unreviewed")

    def test_approval_without_purpose_is_rejected(self) -> None:
        key = "fixture 1.0.0::proc-macro::fixture"
        reviews = {
            key: {
                "package_source_sha256": "a" * 64,
                "status": "approved",
                "purpose": "",
                "reviewer": "reviewer",
                "reviewed_at": "2026-01-01T00:00:00Z",
            }
        }
        with self.assertRaisesRegex(RuntimeError, "missing purpose"):
            inventory.review_for(reviews, key, "a" * 64)

    def test_package_wide_signal_scan_finds_auxiliary_tool_invocation(self) -> None:
        (self.root / "helper.rs").write_text(
            'pub fn helper() { std::process::Command::new("curl"); }\n',
            encoding="utf-8",
        )
        text = "\n".join(
            path.read_text(encoding="utf-8")
            for path in inventory.package_source_files(self.root)
            if path.suffix == ".rs"
        )
        report = inventory.signals(text)
        self.assertIn("curl", report["literal_invoked_tools"])

    def write_checksum_document(self, package_checksum: str = "c" * 64) -> None:
        files = {}
        for path in inventory.package_source_files(self.root):
            if path.name == ".cargo-checksum.json":
                continue
            files[path.relative_to(self.root).as_posix()] = hashlib.sha256(
                path.read_bytes()
            ).hexdigest()
        (self.root / ".cargo-checksum.json").write_text(
            json.dumps({"files": files, "package": package_checksum}),
            encoding="utf-8",
        )

    def test_vendored_checksum_binds_every_package_file(self) -> None:
        self.write_checksum_document()
        inventory.verify_vendored_checksum(self.root, "c" * 64)
        (self.root / "helper.rs").write_text("changed\n", encoding="utf-8")
        with self.assertRaisesRegex(RuntimeError, "checksum mismatch"):
            inventory.verify_vendored_checksum(self.root, "c" * 64)

    def test_unbound_vendored_file_is_rejected(self) -> None:
        self.write_checksum_document()
        (self.root / "undeclared.rs").write_text("undeclared\n", encoding="utf-8")
        with self.assertRaisesRegex(RuntimeError, "file set disagrees"):
            inventory.verify_vendored_checksum(self.root, "c" * 64)

    def test_external_package_must_resolve_under_vendor_root(self) -> None:
        vendor = self.root / "vendor"
        package = vendor / "fixture-1.0.0"
        package.mkdir(parents=True)
        inventory.require_source_boundary(
            {"source": "registry+https://github.com/rust-lang/crates.io-index"},
            package,
            vendor,
        )
        with self.assertRaisesRegex(RuntimeError, "escapes"):
            inventory.require_source_boundary(
                {"source": "registry+https://github.com/rust-lang/crates.io-index"},
                self.root / "outside",
                vendor,
            )


if __name__ == "__main__":
    unittest.main()
