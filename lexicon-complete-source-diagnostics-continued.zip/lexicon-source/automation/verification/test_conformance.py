from __future__ import annotations

import importlib.util
import json
import pathlib
import tempfile
import unittest


MODULE_PATH = pathlib.Path(__file__).with_name("conformance.py")
SPEC = importlib.util.spec_from_file_location("lexicon_conformance_evidence", MODULE_PATH)
assert SPEC is not None and SPEC.loader is not None
conformance = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(conformance)

COMMIT = "0123456789abcdef0123456789abcdef01234567"
PLATFORM = "linux-x86_64"


class NativeEvidenceValidationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = pathlib.Path(self.temporary.name)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def write_evidence(self) -> pathlib.Path:
        directory = self.root / PLATFORM
        directory.mkdir()
        commands = []
        artifacts = ["verification-manifest.json"]
        for index, argv in enumerate(conformance.EXPECTED_COMMANDS, start=1):
            stdout_name = f"{index:02d}.stdout.log"
            stderr_name = f"{index:02d}.stderr.log"
            if argv == ["rustc", "-V"]:
                stdout = b"rustc 1.98.0 (test 2026-01-01)\n"
            elif argv == ["cargo", "-V"]:
                stdout = b"cargo 1.98.0 (test 2026-01-01)\n"
            elif "--list" in argv and "--ignored" not in argv:
                stdout = b"evidence_test: test\n"
            else:
                stdout = b""
            stderr = b""
            (directory / stdout_name).write_bytes(stdout)
            (directory / stderr_name).write_bytes(stderr)
            artifacts.extend([stdout_name, stderr_name])
            commands.append(
                {
                    "argv": argv,
                    "exit_code": 0,
                    "started_at": "2026-01-01T00:00:00Z",
                    "finished_at": "2026-01-01T00:00:01Z",
                    "stdout_sha256": conformance.sha256(stdout),
                    "stderr_sha256": conformance.sha256(stderr),
                    "stdout_path": stdout_name,
                    "stderr_path": stderr_name,
                }
            )
        document = {
            "schema_version": 1,
            "result": "passed",
            "failure": "",
            "repository": conformance.EXPECTED_REPOSITORY,
            "commit": COMMIT,
            "dirty": False,
            "os": PLATFORM,
            "architecture": "x86_64",
            "rustc": "rustc 1.98.0 (test 2026-01-01)",
            "cargo": "cargo 1.98.0 (test 2026-01-01)",
            "mza_commit": "",
            "commands": commands,
            "tests": {
                "passed": 1,
                "failed": 0,
                "ignored": 0,
                "ignored_required": 0,
                "outer_workflow_skipped": 0,
            },
            "artifacts": artifacts,
        }
        manifest = directory / "verification-manifest.json"
        manifest.write_text(json.dumps(document), encoding="utf-8")
        return manifest

    def validate(self) -> int:
        return conformance.validate_set(
            self.root,
            [PLATFORM],
            self.root / "merged-tests.txt",
            COMMIT,
        )

    def test_authentic_exact_commit_evidence_is_accepted(self) -> None:
        self.write_evidence()
        self.assertEqual(self.validate(), 0)
        self.assertEqual(
            (self.root / "merged-tests.txt").read_text(encoding="utf-8"),
            "evidence_test: test\n",
        )

    def test_stream_hash_mismatch_is_rejected(self) -> None:
        manifest = self.write_evidence()
        document = json.loads(manifest.read_text(encoding="utf-8"))
        stream = manifest.parent / document["commands"][0]["stdout_path"]
        stream.write_bytes(b"tampered\n")
        with self.assertRaisesRegex(RuntimeError, "stream hash mismatch"):
            self.validate()

    def test_manifest_commit_must_match_workflow_commit(self) -> None:
        self.write_evidence()
        with self.assertRaisesRegex(RuntimeError, "does not match"):
            conformance.validate_set(
                self.root,
                [PLATFORM],
                None,
                "fedcba9876543210fedcba9876543210fedcba98",
            )

    def test_extra_unbound_artifact_is_rejected(self) -> None:
        manifest = self.write_evidence()
        (manifest.parent / "unbound.log").write_text("unbound", encoding="utf-8")
        with self.assertRaisesRegex(RuntimeError, "artifact set"):
            self.validate()

    def test_skipped_outer_workflow_is_rejected(self) -> None:
        manifest = self.write_evidence()
        document = json.loads(manifest.read_text(encoding="utf-8"))
        document["tests"]["outer_workflow_skipped"] = 1
        manifest.write_text(json.dumps(document), encoding="utf-8")
        with self.assertRaisesRegex(RuntimeError, "failures or ignored required tests"):
            self.validate()

    def test_windows_style_absolute_artifact_path_is_rejected_by_linux_validator(self) -> None:
        manifest = self.write_evidence()
        document = json.loads(manifest.read_text(encoding="utf-8"))
        document["artifacts"][1] = r"C:\evidence.log"
        manifest.write_text(json.dumps(document), encoding="utf-8")
        with self.assertRaisesRegex(RuntimeError, "unsafe artifact path"):
            self.validate()

    def test_backwards_command_timestamps_are_rejected(self) -> None:
        manifest = self.write_evidence()
        document = json.loads(manifest.read_text(encoding="utf-8"))
        document["commands"][0]["started_at"] = "2026-01-01T00:00:02Z"
        document["commands"][0]["finished_at"] = "2026-01-01T00:00:01Z"
        manifest.write_text(json.dumps(document), encoding="utf-8")
        with self.assertRaisesRegex(RuntimeError, "timestamps run backwards"):
            self.validate()


if __name__ == "__main__":
    unittest.main()
