#!/usr/bin/env python3
"""Run Lexicon's native conformance gate and emit exact-commit evidence."""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import pathlib
import platform as host_platform
import re
import subprocess
import sys
import tomllib
from typing import Any


ROOT = pathlib.Path(__file__).resolve().parents[2]
EXPECTED_REPOSITORY = "https://github.com/ssr2zvy/lexicon"
EXPECTED_TOOLCHAIN = "1.98.0"
EXPECTED_COMMANDS = [
    ["rustc", "-V"],
    ["cargo", "-V"],
    ["cargo", "check", "--workspace", "--locked"],
    ["cargo", "test", "--workspace", "--locked", "--", "--list"],
    [
        "cargo",
        "test",
        "--workspace",
        "--locked",
        "--",
        "--ignored",
        "--list",
    ],
    ["cargo", "test", "--workspace", "--locked", "--quiet"],
]
TEST_SUMMARY = re.compile(
    rb"test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; "
    rb"(\d+) ignored;"
)


def timestamp() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def safe_artifact_name(value: Any) -> bool:
    return (
        isinstance(value, str)
        and value not in {".", ".."}
        and re.fullmatch(r"[A-Za-z0-9_.-]+", value) is not None
    )


def parse_manifest_timestamp(value: Any) -> dt.datetime:
    if not isinstance(value, str) or not value.endswith("Z"):
        raise RuntimeError("manifest timestamp is not RFC3339 UTC")
    try:
        parsed = dt.datetime.fromisoformat(value[:-1] + "+00:00")
    except ValueError as error:
        raise RuntimeError("manifest timestamp is not RFC3339 UTC") from error
    if parsed.utcoffset() != dt.timedelta(0):
        raise RuntimeError("manifest timestamp is not UTC")
    return parsed


def git(*args: str) -> str:
    completed = subprocess.run(
        ["git", *args], cwd=ROOT, check=True, capture_output=True, text=True
    )
    return completed.stdout.strip()


def safe_name(index: int, argv: list[str]) -> str:
    stem = "-".join(re.sub(r"[^A-Za-z0-9_.-]+", "-", item) for item in argv[:3])
    return f"{index:02d}-{stem[:80]}"


def run_command(
    argv: list[str], output_dir: pathlib.Path, index: int, extra_env: dict[str, str] | None = None
) -> tuple[dict[str, Any], bytes, bytes]:
    started = timestamp()
    env = os.environ.copy()
    if extra_env:
        env.update(extra_env)
    completed = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True, check=False)
    finished = timestamp()

    stem = safe_name(index, argv)
    stdout_path = output_dir / f"{stem}.stdout.log"
    stderr_path = output_dir / f"{stem}.stderr.log"
    stdout_path.write_bytes(completed.stdout)
    stderr_path.write_bytes(completed.stderr)
    sys.stdout.buffer.write(completed.stdout)
    sys.stderr.buffer.write(completed.stderr)

    record = {
        "argv": argv,
        "exit_code": completed.returncode,
        "started_at": started,
        "finished_at": finished,
        "stdout_sha256": sha256(completed.stdout),
        "stderr_sha256": sha256(completed.stderr),
        "stdout_path": stdout_path.name,
        "stderr_path": stderr_path.name,
    }
    return record, completed.stdout, completed.stderr


def native_architecture() -> str:
    machine = host_platform.machine().lower()
    aliases = {"amd64": "x86_64", "x64": "x86_64", "arm64": "aarch64"}
    return aliases.get(machine, machine)


def expected_native_platform() -> str:
    operating_system = {
        "linux": "linux",
        "win32": "windows",
    }.get(sys.platform)
    if operating_system is None:
        raise RuntimeError(f"unsupported native evidence host: {sys.platform}")
    return f"{operating_system}-{native_architecture()}"


def validate_requested_platform(platform_name: str) -> None:
    expected = expected_native_platform()
    if platform_name != expected:
        raise RuntimeError(
            f"requested evidence platform {platform_name!r} does not match native host {expected!r}"
        )


def parse_test_totals(stdout: bytes, stderr: bytes) -> dict[str, int]:
    summaries = TEST_SUMMARY.findall(stdout + b"\n" + stderr)
    if not summaries:
        raise RuntimeError("cargo test emitted no libtest summary")
    totals = [sum(int(row[column]) for row in summaries) for column in range(3)]
    return {
        "passed": totals[0],
        "failed": totals[1],
        "ignored": totals[2],
        "ignored_required": 0,
        "outer_workflow_skipped": 0,
    }


def listed_tests(output: bytes) -> set[str]:
    names = set()
    for raw_line in output.decode("utf-8", "replace").splitlines():
        line = raw_line.strip()
        if line.endswith(": test"):
            names.add(line.removesuffix(": test"))
    return names


def required_tests() -> set[str]:
    matrix_path = ROOT / "workspace" / "specs" / "conformance.toml"
    with matrix_path.open("rb") as handle:
        matrix = tomllib.load(handle)
    return {
        name
        for requirement in matrix.get("requirement", [])
        for name in requirement.get("tests", [])
    }


def is_required_test(name: str, required: set[str]) -> bool:
    short = name.rsplit("::", 1)[-1]
    return name in required or short in required


def write_manifest(output_dir: pathlib.Path, manifest: dict[str, Any]) -> None:
    path = output_dir / "verification-manifest.json"
    path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def produce(platform_name: str, output_dir: pathlib.Path) -> int:
    validate_requested_platform(platform_name)
    commit = git("rev-parse", "HEAD")
    dirty_before = bool(git("status", "--porcelain=v1", "--untracked-files=all"))
    if output_dir.is_symlink():
        raise RuntimeError("evidence output directory must not be a symbolic link")
    if output_dir.exists():
        if not output_dir.is_dir() or any(output_dir.iterdir()):
            raise RuntimeError("evidence output directory must be a new or empty directory")
    else:
        output_dir.mkdir(parents=True)

    commands: list[dict[str, Any]] = []
    rustc_text = ""
    cargo_text = ""
    tests = {
        "passed": 0,
        "failed": 0,
        "ignored": 0,
        "ignored_required": 0,
        "outer_workflow_skipped": 0,
    }
    result = "passed"
    failure = ""

    command_specs: list[tuple[list[str], dict[str, str] | None]] = [
        (["rustc", "-V"], None),
        (["cargo", "-V"], None),
        (["cargo", "check", "--workspace", "--locked"], None),
        (["cargo", "test", "--workspace", "--locked", "--", "--list"], None),
        (["cargo", "test", "--workspace", "--locked", "--", "--ignored", "--list"], None),
    ]

    final_test_streams: tuple[bytes, bytes] | None = None
    ignored_test_list: set[str] = set()
    for argv, env in command_specs:
        record, stdout, stderr = run_command(argv, output_dir, len(commands) + 1, env)
        commands.append(record)
        if argv[0] == "rustc":
            rustc_text = stdout.decode("utf-8", "replace").strip()
        elif argv[:2] == ["cargo", "-V"]:
            cargo_text = stdout.decode("utf-8", "replace").strip()
        elif "--ignored" in argv and "--list" in argv:
            ignored_test_list = listed_tests(stdout)
        if record["exit_code"] != 0:
            result = "failed"
            failure = f"command failed: {argv!r}"
            break

    if result == "passed":
        argv = ["cargo", "test", "--workspace", "--locked", "--quiet"]
        record, stdout, stderr = run_command(argv, output_dir, len(commands) + 1)
        commands.append(record)
        final_test_streams = (stdout, stderr)
        if record["exit_code"] != 0:
            result = "failed"
            failure = "workspace test command failed"

    dirty_after = bool(git("status", "--porcelain=v1", "--untracked-files=all"))
    dirty = dirty_before or dirty_after
    if result == "passed":
        if not rustc_text.startswith(f"rustc {EXPECTED_TOOLCHAIN} ") or not cargo_text.startswith(
            f"cargo {EXPECTED_TOOLCHAIN} "
        ):
            result = "failed"
            failure = f"runner did not use the exact Rust {EXPECTED_TOOLCHAIN} toolchain"
        elif dirty:
            result = "failed"
            failure = "checkout was dirty before or after evidence generation"
        elif not re.fullmatch(r"[0-9a-f]{40}", commit):
            result = "failed"
            failure = "git did not return an exact 40-character commit"

    if final_test_streams is not None:
        try:
            tests = parse_test_totals(*final_test_streams)
        except RuntimeError as error:
            result = "failed"
            failure = str(error)
        required = required_tests()
        tests["ignored"] = len(ignored_test_list)
        tests["ignored_required"] = sum(
            1 for name in ignored_test_list if is_required_test(name, required)
        )
        if tests["failed"] or tests["ignored_required"]:
            result = "failed"
            failure = "workspace test summary contains failures or an ignored required test"

    artifacts = ["verification-manifest.json"]
    for command in commands:
        artifacts.extend([command["stdout_path"], command["stderr_path"]])
    manifest = {
        "schema_version": 1,
        "result": result,
        "failure": failure,
        "repository": EXPECTED_REPOSITORY,
        "commit": commit,
        "dirty": dirty,
        "os": platform_name,
        "architecture": native_architecture(),
        "rustc": rustc_text,
        "cargo": cargo_text,
        "mza_commit": "",
        "commands": commands,
        "tests": tests,
        "artifacts": artifacts,
    }
    write_manifest(output_dir, manifest)
    if result != "passed":
        print(f"conformance evidence failed: {failure}", file=sys.stderr)
        return 1
    return 0


def validate_set(
    root: pathlib.Path,
    expected: list[str],
    merged_test_list: pathlib.Path | None,
    expected_commit: str,
) -> int:
    if not re.fullmatch(r"[0-9a-f]{40}", expected_commit):
        raise RuntimeError("--expected-commit must be one lowercase 40-character Git SHA")
    manifests = sorted(root.rglob("verification-manifest.json"))
    documents = [json.loads(path.read_text(encoding="utf-8")) for path in manifests]
    if any(not isinstance(document, dict) for document in documents):
        raise RuntimeError("native evidence manifest must be a JSON object")
    platform_values = [document.get("os") for document in documents]
    if any(not isinstance(value, str) for value in platform_values):
        raise RuntimeError("native evidence manifest has an invalid platform identity")
    by_platform = {document.get("os"): document for document in documents}
    if set(by_platform) != set(expected) or len(documents) != len(expected):
        raise RuntimeError(f"expected exactly {expected!r}; found {sorted(by_platform)!r}")
    commits = set()
    for path, document in zip(manifests, documents):
        platform_name = document.get("os")
        if document.get("schema_version") != 1 or document.get("result") != "passed":
            raise RuntimeError(f"{platform_name} did not publish passing schema-v1 evidence")
        if document.get("failure") != "":
            raise RuntimeError(f"{platform_name} passing evidence contains a failure diagnostic")
        if document.get("repository") != EXPECTED_REPOSITORY:
            raise RuntimeError(f"{platform_name} evidence names the wrong repository")
        if document.get("dirty") is not False:
            raise RuntimeError(f"{platform_name} evidence came from a dirty checkout")
        if document.get("commit") != expected_commit:
            raise RuntimeError(
                f"{platform_name} evidence commit {document.get('commit')!r} does not match {expected_commit}"
            )
        expected_architecture = platform_name.rsplit("-", 1)[-1]
        if document.get("architecture") != expected_architecture:
            raise RuntimeError(f"{platform_name} evidence has the wrong native architecture")
        if not str(document.get("rustc", "")).startswith(
            f"rustc {EXPECTED_TOOLCHAIN} "
        ) or not str(document.get("cargo", "")).startswith(
            f"cargo {EXPECTED_TOOLCHAIN} "
        ):
            raise RuntimeError(f"{platform_name} evidence used the wrong Rust toolchain")
        tests = document.get("tests", {})
        if not isinstance(tests, dict):
            raise RuntimeError(f"{platform_name} evidence contains invalid test totals")
        numeric_test_fields = (
            "passed",
            "failed",
            "ignored",
            "ignored_required",
            "outer_workflow_skipped",
        )
        if any(
            type(tests.get(field)) is not int or tests[field] < 0
            for field in numeric_test_fields
        ):
            raise RuntimeError(f"{platform_name} evidence contains invalid test totals")
        if tests["passed"] == 0:
            raise RuntimeError(f"{platform_name} evidence contains no passing tests")
        if (
            tests["failed"] != 0
            or tests["ignored_required"] != 0
            or tests["outer_workflow_skipped"] != 0
        ):
            raise RuntimeError(f"{platform_name} evidence contains failures or ignored required tests")
        commands = document.get("commands")
        if (
            not isinstance(commands, list)
            or any(not isinstance(command, dict) for command in commands)
            or [command.get("argv") for command in commands] != EXPECTED_COMMANDS
        ):
            raise RuntimeError(f"{platform_name} evidence does not contain the exact command sequence")
        if any(type(command.get("exit_code")) is not int or command["exit_code"] != 0 for command in commands):
            raise RuntimeError(f"{platform_name} evidence contains a missing or failed command")
        for command in commands:
            started = parse_manifest_timestamp(command.get("started_at"))
            finished = parse_manifest_timestamp(command.get("finished_at"))
            if finished < started:
                raise RuntimeError(f"{platform_name} evidence command timestamps run backwards")
        declared_artifacts = document.get("artifacts")
        if (
            not isinstance(declared_artifacts, list)
            or any(
                not safe_artifact_name(name)
                for name in declared_artifacts
            )
            or len(set(declared_artifacts)) != len(declared_artifacts)
        ):
            raise RuntimeError(f"{platform_name} evidence contains an unsafe artifact path")
        actual_candidates = list(path.parent.iterdir())
        if any(candidate.is_symlink() or not candidate.is_file() for candidate in actual_candidates):
            raise RuntimeError(f"{platform_name} evidence contains a non-regular artifact")
        actual_artifacts = {candidate.name for candidate in actual_candidates}
        if set(declared_artifacts) != actual_artifacts:
            raise RuntimeError(f"{platform_name} evidence artifact set does not match its manifest")
        stream_artifacts = []
        for command in commands:
            for stream in ("stdout", "stderr"):
                relative = command.get(f"{stream}_path")
                digest = command.get(f"{stream}_sha256")
                if (
                    not safe_artifact_name(relative)
                    or not isinstance(digest, str)
                    or not re.fullmatch(r"[0-9a-f]{64}", digest)
                ):
                    raise RuntimeError(f"{platform_name} evidence contains malformed stream metadata")
                stream_artifacts.append(relative)
                stream_path = path.parent / relative
                if (
                    stream_path.is_symlink()
                    or not stream_path.is_file()
                    or sha256(stream_path.read_bytes()) != digest
                ):
                    raise RuntimeError(f"{platform_name} evidence stream hash mismatch: {relative}")
        if (
            len(set(stream_artifacts)) != len(stream_artifacts)
            or set(stream_artifacts) != set(declared_artifacts) - {"verification-manifest.json"}
        ):
            raise RuntimeError(f"{platform_name} evidence contains an unbound or reused stream artifact")
        commits.add(document.get("commit"))
    if len(commits) != 1:
        raise RuntimeError(f"native evidence does not describe one exact commit: {commits!r}")
    if merged_test_list is not None:
        merged: set[str] = set()
        for path, document in zip(manifests, documents):
            for command in document["commands"]:
                argv = command.get("argv", [])
                if (
                    argv[:3] == ["cargo", "test", "--workspace"]
                    and "--list" in argv
                    and "--ignored" not in argv
                ):
                    merged.update(
                        listed_tests((path.parent / command["stdout_path"]).read_bytes())
                    )
        if not merged:
            raise RuntimeError("native evidence contains no test-list output")
        merged_test_list.parent.mkdir(parents=True, exist_ok=True)
        merged_test_list.write_text(
            "".join(f"{name}: test\n" for name in sorted(merged)), encoding="utf-8"
        )
    print(f"validated native conformance evidence for {sorted(by_platform)} at {commits.pop()}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--platform")
    parser.add_argument("--output-dir", type=pathlib.Path)
    parser.add_argument("--validate-set", type=pathlib.Path)
    parser.add_argument("--merged-test-list", type=pathlib.Path)
    parser.add_argument("--expected-commit")
    parser.add_argument("expected_platforms", nargs="*")
    args = parser.parse_args()
    try:
        if args.validate_set:
            if not args.expected_commit:
                parser.error("--expected-commit is required in validation mode")
            return validate_set(
                args.validate_set,
                args.expected_platforms,
                args.merged_test_list,
                args.expected_commit,
            )
        if not args.platform or not args.output_dir:
            parser.error("--platform and --output-dir are required in producer mode")
        return produce(args.platform, args.output_dir)
    except (OSError, RuntimeError, subprocess.SubprocessError, json.JSONDecodeError) as error:
        print(f"conformance evidence error: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
