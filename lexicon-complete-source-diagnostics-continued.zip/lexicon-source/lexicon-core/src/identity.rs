use std::ffi::OsStr;
use std::fmt;
use std::str::FromStr;

pub const MAX_MANAGED_NAME_BYTES: usize = 63;

pub const RESERVED_NAMES: &[&str] = &[
    "lexicon", "http", "data", "state", "runtime", "sessions", "get-raw-data",
    "process-data", "con", "prn", "aux", "nul", "com1", "com2", "com3", "com4",
    "com5", "com6", "com7", "com8", "com9", "lpt1", "lpt2", "lpt3", "lpt4",
    "lpt5", "lpt6", "lpt7", "lpt8", "lpt9",
];

#[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
pub struct ManagedName(String);

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ManagedNameError {
    NonUnicode,
    Empty,
    TooLong,
    InvalidGrammar,
    Reserved,
}

impl ManagedName {
    pub fn parse(value: &str) -> Result<Self, ManagedNameError> {
        if value.is_empty() {
            return Err(ManagedNameError::Empty);
        }
        if value.len() > MAX_MANAGED_NAME_BYTES {
            return Err(ManagedNameError::TooLong);
        }
        let bytes = value.as_bytes();
        let edge_ok = |byte: u8| byte.is_ascii_lowercase() || byte.is_ascii_digit();
        if !edge_ok(bytes[0]) || !edge_ok(bytes[bytes.len() - 1]) {
            return Err(ManagedNameError::InvalidGrammar);
        }
        if !bytes.iter().all(|byte| edge_ok(*byte) || *byte == b'-') {
            return Err(ManagedNameError::InvalidGrammar);
        }
        if RESERVED_NAMES.contains(&value) {
            return Err(ManagedNameError::Reserved);
        }
        Ok(Self(value.to_owned()))
    }

    pub fn parse_os(value: &OsStr) -> Result<Self, ManagedNameError> {
        Self::parse(value.to_str().ok_or(ManagedNameError::NonUnicode)?)
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }

    pub fn into_string(self) -> String {
        self.0
    }
}

impl fmt::Display for ManagedName {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(self.as_str())
    }
}

impl fmt::Display for ManagedNameError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(match self {
            Self::NonUnicode => "managed names must be exact Unicode strings",
            Self::Empty => "managed names must not be empty",
            Self::TooLong => "managed name exceeds the 63-byte limit",
            Self::InvalidGrammar => {
                "managed names must contain lowercase ASCII letters, digits, and interior hyphens"
            }
            Self::Reserved => "managed name is reserved by Lexicon or the operating system",
        })
    }
}

impl std::error::Error for ManagedNameError {}

impl FromStr for ManagedName {
    type Err = ManagedNameError;

    fn from_str(value: &str) -> Result<Self, Self::Err> {
        Self::parse(value)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn grammar_is_bounded_exact_and_reserved() {
        assert!(ManagedName::parse("a").is_ok());
        assert!(ManagedName::parse("example-source-9").is_ok());
        for rejected in ["", "A", "a_1", "-a", "a-", ".", "..", "http", "nul"] {
            assert!(ManagedName::parse(rejected).is_err(), "accepted {rejected:?}");
        }
        assert!(ManagedName::parse(&"a".repeat(MAX_MANAGED_NAME_BYTES)).is_ok());
        assert_eq!(
            ManagedName::parse(&"a".repeat(MAX_MANAGED_NAME_BYTES + 1)),
            Err(ManagedNameError::TooLong)
        );
    }
}
