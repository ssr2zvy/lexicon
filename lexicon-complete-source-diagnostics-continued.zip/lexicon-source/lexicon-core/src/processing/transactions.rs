use std::collections::{HashMap, HashSet};
use std::fmt;
use std::path::{Path, PathBuf};

use crate::protocols::http::transaction::error::HttpManagedPathValidationMode;
use crate::protocols::http::transaction::error::validate_managed_path;
use crate::protocols::http::transaction::metadata::{
    HttpTransactionAdmissionError, admit_incomplete_attempt_from_disk,
    admit_transaction_from_disk, incomplete_attempt_session_from_disk,
};
use crate::protocols::http::transaction::recorder::{
    StagingDirectoryNameClass, classify_staging_transaction_directory_name,
};
use crate::protocols::http::transaction::{
    IncompleteRecordedHttpAttempt, RecordedTransaction,
};
use crate::runtime::{OwnedRuntimeIdentity, RuntimeOperation, RuntimeProtocol};
use crate::session::{
    ProjectIdentity, SessionFailureKind, SessionIdentity, SessionOperation, SessionOperationRoot,
    SessionRecordV1,
    SessionLeaseState, SessionState,
    SessionStore, SessionStoreError, SessionTimestamp,
};

/// Directory name of the acquisition operation root beneath the protocol root.
const ACQUISITION_OPERATION_DIRECTORY: &str = "get-raw-data";

#[derive(Debug, Clone)]
pub struct ProcessingHttpTransaction {
    project: ProjectIdentity,
    acquisition_runtime: OwnedRuntimeIdentity,
    acquisition_session: SessionIdentity,
    acquisition_session_state: SessionState,
    transaction: RecordedTransaction,
}

impl ProcessingHttpTransaction {
    pub fn project(&self) -> &ProjectIdentity {
        &self.project
    }
    pub fn acquisition_runtime(&self) -> &OwnedRuntimeIdentity {
        &self.acquisition_runtime
    }
    pub fn acquisition_session(&self) -> &SessionIdentity {
        &self.acquisition_session
    }
    pub fn acquisition_session_state(&self) -> SessionState {
        self.acquisition_session_state
    }
    pub fn transaction(&self) -> &RecordedTransaction {
        &self.transaction
    }
}

#[derive(Debug, Clone)]
pub struct ProcessingIncompleteHttpAttempt {
    project: ProjectIdentity,
    acquisition_runtime: OwnedRuntimeIdentity,
    acquisition_session: SessionIdentity,
    acquisition_session_state: SessionState,
    attempt: IncompleteRecordedHttpAttempt,
}

impl ProcessingIncompleteHttpAttempt {
    pub fn project(&self) -> &ProjectIdentity { &self.project }
    pub fn acquisition_runtime(&self) -> &OwnedRuntimeIdentity {
        &self.acquisition_runtime
    }
    pub fn acquisition_session(&self) -> &SessionIdentity { &self.acquisition_session }
    pub fn acquisition_session_state(&self) -> SessionState {
        self.acquisition_session_state
    }
    pub fn attempt(&self) -> &IncompleteRecordedHttpAttempt { &self.attempt }
}

#[derive(Debug, Clone, Copy)]
pub enum ProcessingHttpRawEntry<'a> {
    Complete(&'a ProcessingHttpTransaction),
    Incomplete(&'a ProcessingIncompleteHttpAttempt),
}

#[derive(Debug, Clone)]
pub struct ProcessingHttpTransactionCatalog {
    transactions: Vec<ProcessingHttpTransaction>,
    incomplete_attempts: Vec<ProcessingIncompleteHttpAttempt>,
}

impl ProcessingHttpTransactionCatalog {
    pub(crate) fn new(transactions: Vec<ProcessingHttpTransaction>) -> Self {
        Self { transactions, incomplete_attempts: Vec::new() }
    }

    pub(crate) fn with_incomplete(
        transactions: Vec<ProcessingHttpTransaction>,
        incomplete_attempts: Vec<ProcessingIncompleteHttpAttempt>,
    ) -> Self {
        Self { transactions, incomplete_attempts }
    }

    pub fn as_slice(&self) -> &[ProcessingHttpTransaction] {
        &self.transactions
    }

    pub fn iter(&self) -> impl ExactSizeIterator<Item = &ProcessingHttpTransaction> {
        self.transactions.iter()
    }

    /// Strictly admitted terminal-session attempts that did not reach atomic
    /// transaction publication. Running-session partials are never included.
    pub fn incomplete_attempts(
        &self,
    ) -> impl ExactSizeIterator<Item = &ProcessingIncompleteHttpAttempt> {
        self.incomplete_attempts.iter()
    }

    /// Enumerate both complete and incomplete raw evidence, preserving the
    /// distinction in the item type.
    pub fn entries(&self) -> impl Iterator<Item = ProcessingHttpRawEntry<'_>> {
        self.transactions
            .iter()
            .map(ProcessingHttpRawEntry::Complete)
            .chain(
                self.incomplete_attempts
                    .iter()
                    .map(ProcessingHttpRawEntry::Incomplete),
            )
    }

    /// Number of complete transactions exposed by [`Self::iter`] and
    /// [`Self::as_slice`]. Use [`Self::entry_len`] for all raw evidence.
    pub fn len(&self) -> usize { self.transactions.len() }

    /// Whether the complete-transaction view is empty.
    pub fn is_empty(&self) -> bool { self.transactions.is_empty() }

    pub fn entries_is_empty(&self) -> bool {
        self.transactions.is_empty() && self.incomplete_attempts.is_empty()
    }


    pub fn incomplete_len(&self) -> usize { self.incomplete_attempts.len() }

    pub fn complete_len(&self) -> usize { self.transactions.len() }

    pub fn entry_len(&self) -> usize {
        self.transactions.len() + self.incomplete_attempts.len()
    }
}

#[derive(Debug)]
pub enum ProcessingTransactionDiscoveryError {
    RuntimeProtocolMismatch,
    RuntimeOperationMismatch,
    ManagedPath(crate::protocols::http::transaction::error::HttpManagedPathError),
    /// The supplied raw root is not exactly `protocol_root/data/raw`.
    RawRootDisagreement { expected: PathBuf, actual: PathBuf },
    /// `protocol_root/get-raw-data` is not a managed existing directory.
    AcquisitionRootInvalid {
        acquisition_root: PathBuf,
        source: crate::protocols::http::transaction::error::HttpManagedPathError,
    },
    RawRootEnumeration(std::io::Error),
    RawEntryMetadata(std::io::Error),
    RawEntrySymlink {
        entry_path: PathBuf,
    },
    RawEntryUnexpectedFile {
        entry_path: PathBuf,
    },
    RawEntryUnsupportedType {
        entry_path: PathBuf,
    },
    RawEntryNameInvalid {
        entry_path: PathBuf,
    },
    /// A directory carries the Core staging prefix but violates the staging grammar.
    RawEntryMalformedPartialDirectory {
        entry_path: PathBuf,
    },
    RawEntryUnrecognizedDirectory {
        entry_path: PathBuf,
    },
    TransactionAdmission {
        entry_path: PathBuf,
        source: HttpTransactionAdmissionError,
    },
    DuplicateTransactionIdentity {
        transaction_identity: String,
    },
    AcquisitionStoreOpen(SessionStoreError),
    AcquisitionSessionLoad {
        acquisition_session: SessionIdentity,
        source: SessionStoreError,
    },
    AcquisitionSessionLeaseInspection {
        acquisition_session: SessionIdentity,
        source: crate::session::SessionLeaseError,
    },
    StaleRunningAcquisitionSession {
        acquisition_session: SessionIdentity,
    },
    /// The typed provenance cache lost a record it had just admitted.
    ProvenanceCacheInvariant {
        acquisition_session: SessionIdentity,
    },
    Provenance(ProcessingTransactionProvenanceError),
}

impl ProcessingTransactionDiscoveryError {
    /// Whether this discovery failure was caused by transaction provenance.
    ///
    /// Used to select the stable session failure code without matching on Display.
    pub fn is_provenance_failure(&self) -> bool {
        matches!(self, Self::Provenance(_))
    }

    /// The retained provenance failure, when present.
    pub fn provenance_error(&self) -> Option<&ProcessingTransactionProvenanceError> {
        match self {
            Self::Provenance(error) => Some(error),
            _ => None,
        }
    }

    /// The raw entry path involved, when this failure names one.
    pub fn entry_path(&self) -> Option<&Path> {
        match self {
            Self::RawEntrySymlink { entry_path }
            | Self::RawEntryUnexpectedFile { entry_path }
            | Self::RawEntryUnsupportedType { entry_path }
            | Self::RawEntryNameInvalid { entry_path }
            | Self::RawEntryMalformedPartialDirectory { entry_path }
            | Self::RawEntryUnrecognizedDirectory { entry_path }
            | Self::TransactionAdmission { entry_path, .. } => Some(entry_path.as_path()),
            _ => None,
        }
    }
}

impl fmt::Display for ProcessingTransactionDiscoveryError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::RuntimeProtocolMismatch => formatter
                .write_str("processing transaction discovery requires HTTP runtime protocol"),
            Self::RuntimeOperationMismatch => formatter.write_str(
                "processing transaction discovery requires processing runtime operation",
            ),
            Self::ManagedPath(_) => {
                formatter.write_str("processing transaction discovery path validation failed")
            }
            Self::RawRootDisagreement { .. } => formatter.write_str(
                "processing transaction discovery raw root does not match the protocol layout",
            ),
            Self::AcquisitionRootInvalid { .. } => formatter.write_str(
                "processing transaction discovery acquisition root is not a managed directory",
            ),
            Self::RawRootEnumeration(_) => {
                formatter.write_str("processing transaction discovery failed to enumerate raw root")
            }
            Self::RawEntryMetadata(_) => formatter
                .write_str("processing transaction discovery failed to inspect a raw entry"),
            Self::RawEntrySymlink { .. } => {
                formatter.write_str("processing transaction discovery rejected a raw-entry symlink")
            }
            Self::RawEntryUnexpectedFile { .. } => formatter.write_str(
                "processing transaction discovery rejected an unexpected raw file entry",
            ),
            Self::RawEntryUnsupportedType { .. } => formatter.write_str(
                "processing transaction discovery rejected an unsupported raw entry type",
            ),
            Self::RawEntryNameInvalid { .. } => formatter.write_str(
                "processing transaction discovery rejected an invalid raw directory name",
            ),
            Self::RawEntryMalformedPartialDirectory { .. } => formatter.write_str(
                "processing transaction discovery rejected a malformed partial raw directory",
            ),
            Self::RawEntryUnrecognizedDirectory { .. } => formatter.write_str(
                "processing transaction discovery rejected an unrecognized raw directory",
            ),
            Self::TransactionAdmission { .. } => formatter.write_str(
                "processing transaction discovery could not admit a finalized transaction",
            ),
            Self::DuplicateTransactionIdentity { .. } => formatter
                .write_str("processing transaction discovery rejected duplicate transaction identity"),
            Self::AcquisitionStoreOpen(_) => formatter.write_str(
                "processing transaction discovery failed to open acquisition session store",
            ),
            Self::AcquisitionSessionLoad { .. } => formatter.write_str(
                "processing transaction discovery failed to load acquisition session provenance",
            ),
            Self::AcquisitionSessionLeaseInspection { .. } => formatter.write_str(
                "processing transaction discovery failed to inspect acquisition session ownership",
            ),
            Self::StaleRunningAcquisitionSession { .. } => formatter.write_str(
                "processing transaction discovery found an unreconciled running acquisition session",
            ),
            Self::ProvenanceCacheInvariant { .. } => formatter.write_str(
                "processing transaction discovery lost an admitted acquisition session record",
            ),
            Self::Provenance(_) => {
                formatter.write_str("processing transaction discovery rejected transaction provenance")
            }
        }
    }
}

impl std::error::Error for ProcessingTransactionDiscoveryError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::ManagedPath(error) => Some(error),
            Self::AcquisitionRootInvalid { source, .. } => Some(source),
            Self::RawRootEnumeration(error) => Some(error),
            Self::RawEntryMetadata(error) => Some(error),
            Self::TransactionAdmission { source, .. } => Some(source),
            Self::AcquisitionStoreOpen(error) => Some(error),
            Self::AcquisitionSessionLoad { source, .. } => Some(source),
            Self::AcquisitionSessionLeaseInspection { source, .. } => Some(source),
            Self::Provenance(error) => Some(error),
            _ => None,
        }
    }
}

#[derive(Debug)]
pub enum ProcessingTransactionProvenanceError {
    ProjectMismatch {
        acquisition_session: SessionIdentity,
    },
    SessionIdentityMismatch {
        acquisition_session: SessionIdentity,
    },
    RuntimeProtocolMismatch {
        acquisition_session: SessionIdentity,
    },
    RuntimeOperationMismatch {
        acquisition_session: SessionIdentity,
    },
    SessionOperationMismatch {
        acquisition_session: SessionIdentity,
    },
    RuntimeSourceMismatch {
        acquisition_session: SessionIdentity,
    },
    RuntimeContractVersionMismatch {
        acquisition_session: SessionIdentity,
        found: u32,
    },
    SessionNotExecutable {
        acquisition_session: SessionIdentity,
        state: SessionState,
    },
    MissingStartedAt {
        acquisition_session: SessionIdentity,
    },
    TimestampOutOfBounds {
        acquisition_session: SessionIdentity,
        transaction_identity: String,
    },
}

impl ProcessingTransactionProvenanceError {
    /// The acquisition session this provenance failure concerns.
    pub fn acquisition_session(&self) -> &SessionIdentity {
        match self {
            Self::ProjectMismatch {
                acquisition_session,
            }
            | Self::SessionIdentityMismatch {
                acquisition_session,
            }
            | Self::RuntimeProtocolMismatch {
                acquisition_session,
            }
            | Self::RuntimeOperationMismatch {
                acquisition_session,
            }
            | Self::SessionOperationMismatch {
                acquisition_session,
            }
            | Self::RuntimeSourceMismatch {
                acquisition_session,
            }
            | Self::RuntimeContractVersionMismatch {
                acquisition_session, ..
            }
            | Self::SessionNotExecutable {
                acquisition_session, ..
            }
            | Self::MissingStartedAt {
                acquisition_session,
            }
            | Self::TimestampOutOfBounds {
                acquisition_session, ..
            } => acquisition_session,
        }
    }
}

impl fmt::Display for ProcessingTransactionProvenanceError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::ProjectMismatch { .. } => {
                formatter.write_str("acquisition session project does not match processing project")
            }
            Self::SessionIdentityMismatch { .. } => formatter.write_str(
                "transaction session identity does not match durable acquisition session identity",
            ),
            Self::RuntimeProtocolMismatch { .. } => {
                formatter.write_str("acquisition session runtime protocol is not HTTP")
            }
            Self::RuntimeOperationMismatch { .. } => {
                formatter.write_str("acquisition session runtime operation is not acquisition")
            }
            Self::SessionOperationMismatch { .. } => {
                formatter.write_str("acquisition session operation is not acquisition")
            }
            Self::RuntimeSourceMismatch { .. } => formatter.write_str(
                "acquisition session runtime source does not match processing runtime source",
            ),
            Self::RuntimeContractVersionMismatch { .. } => formatter.write_str(
                "acquisition session runtime contract version is not supported by this processing catalog",
            ),
            Self::SessionNotExecutable { .. } => {
                formatter.write_str("acquisition session state cannot prove execution")
            }
            Self::MissingStartedAt { .. } => formatter
                .write_str("acquisition session record does not contain execution start timestamp"),
            Self::TimestampOutOfBounds { .. } => formatter.write_str(
                "transaction timestamps fall outside acquisition session temporal bounds",
            ),
        }
    }
}

impl std::error::Error for ProcessingTransactionProvenanceError {}

/// Discover, admit, and validate complete and incomplete raw HTTP evidence.
///
/// Sequence:
/// 1. Validate the processing runtime protocol and operation.
/// 2. Require `raw_root == protocol_root/data/raw` exactly.
/// 3. Enumerate raw entries and strictly classify each directory name.
/// 4. Admit finalized transactions and attributable partial attempts from disk.
/// 5. Require `acquisition_root == protocol_root/get-raw-data` exactly and open it.
/// 6. Admit each acquisition session record once, cached by typed session identity.
/// 7. Validate **every** transaction against its durable session record.
/// 8. Build the deterministic catalog and reject duplicate identities.
///
/// This function never mutates acquisition raw data. A partial is source-visible
/// only after its acquisition session is terminal; mutable running-session partials
/// and pre-metadata allocations are retained on disk but omitted from the snapshot.
pub(crate) fn discover_http_transactions_for_processing(
    project: &ProjectIdentity,
    processing_runtime: &OwnedRuntimeIdentity,
    protocol_root: &Path,
    raw_root: &Path,
) -> Result<ProcessingHttpTransactionCatalog, ProcessingTransactionDiscoveryError> {
    if processing_runtime.protocol() != RuntimeProtocol::Http {
        return Err(ProcessingTransactionDiscoveryError::RuntimeProtocolMismatch);
    }

    if processing_runtime.operation() != RuntimeOperation::Processing {
        return Err(ProcessingTransactionDiscoveryError::RuntimeOperationMismatch);
    }

    validate_managed_path(
        protocol_root,
        protocol_root,
        HttpManagedPathValidationMode::ExistingDirectory,
    )
    .map_err(ProcessingTransactionDiscoveryError::ManagedPath)?;

    // Discovery establishes its own raw-root invariant rather than trusting the caller.
    let expected_raw_root = protocol_root.join("data").join("raw");
    if raw_root != expected_raw_root {
        return Err(ProcessingTransactionDiscoveryError::RawRootDisagreement {
            expected: expected_raw_root,
            actual: raw_root.to_path_buf(),
        });
    }

    validate_managed_path(
        protocol_root,
        raw_root,
        HttpManagedPathValidationMode::ExistingDirectory,
    )
    .map_err(ProcessingTransactionDiscoveryError::ManagedPath)?;

    let evidence_candidates = enumerate_raw_evidence(raw_root)?;

    let acquisition_store = open_acquisition_session_store(protocol_root)?;

    let mut acquisition_records: HashMap<SessionIdentity, SessionRecordV1> = HashMap::new();
    let mut discovered = Vec::new();
    let mut incomplete_attempts = Vec::new();

    for candidate in evidence_candidates {
        match candidate {
            RawEvidenceCandidate::Complete(path) => {
                let transaction = admit_transaction_from_disk(raw_root, &path).map_err(|source| {
                    ProcessingTransactionDiscoveryError::TransactionAdmission {
                        entry_path: path,
                        source,
                    }
                })?;
                let acquisition_session = transaction.session().clone();
                ensure_acquisition_record(
                    &mut acquisition_records,
                    &acquisition_store,
                    &acquisition_session,
                    project,
                    processing_runtime,
                )?;
                let Some(record) = acquisition_records.get(&acquisition_session) else {
                    return Err(
                        ProcessingTransactionDiscoveryError::ProvenanceCacheInvariant {
                            acquisition_session,
                        },
                    );
                };
                // Transaction-to-session provenance runs for every complete
                // transaction; cache presence never bypasses this check.
                validate_transaction_against_session(record, &transaction)
                    .map_err(ProcessingTransactionDiscoveryError::Provenance)?;
                discovered.push(ProcessingHttpTransaction {
                    project: project.clone(),
                    acquisition_runtime: record.runtime().clone(),
                    acquisition_session,
                    acquisition_session_state: record.state(),
                    transaction,
                });
            }
            RawEvidenceCandidate::Incomplete(path) => {
                let Some(acquisition_session) = incomplete_attempt_session_from_disk(
                    raw_root,
                    &path,
                )
                .map_err(|source| ProcessingTransactionDiscoveryError::TransactionAdmission {
                    entry_path: path.clone(),
                    source,
                })? else {
                    continue;
                };
                ensure_acquisition_record(
                    &mut acquisition_records,
                    &acquisition_store,
                    &acquisition_session,
                    project,
                    processing_runtime,
                )?;
                let Some(record) = acquisition_records.get(&acquisition_session) else {
                    return Err(
                        ProcessingTransactionDiscoveryError::ProvenanceCacheInvariant {
                            acquisition_session,
                        },
                    );
                };
                match record.state() {
                    SessionState::Prepared => {
                        return Err(ProcessingTransactionDiscoveryError::Provenance(
                            ProcessingTransactionProvenanceError::SessionNotExecutable {
                                acquisition_session,
                                state: SessionState::Prepared,
                            },
                        ));
                    }
                    SessionState::Running => {
                        match acquisition_store
                            .inspect_lease_state(&acquisition_session)
                            .map_err(|source| {
                                ProcessingTransactionDiscoveryError::AcquisitionSessionLeaseInspection {
                                    acquisition_session: acquisition_session.clone(),
                                    source,
                                }
                            })?
                        {
                            // Only a physically owned lease proves that the
                            // recorder may still mutate this staging directory.
                            SessionLeaseState::Owned => continue,
                            SessionLeaseState::Available => {
                                return Err(
                                    ProcessingTransactionDiscoveryError::StaleRunningAcquisitionSession {
                                        acquisition_session,
                                    },
                                );
                            }
                        }
                    }
                    SessionState::Succeeded | SessionState::Failed | SessionState::Abandoned => {}
                }
                let Some(mut attempt) = admit_incomplete_attempt_from_disk(raw_root, &path)
                    .map_err(|source| {
                        ProcessingTransactionDiscoveryError::TransactionAdmission {
                            entry_path: path,
                            source,
                        }
                    })?
                else {
                    continue;
                };
                if matches!(
                    record.failure().map(|failure| failure.kind()),
                    Some(
                        SessionFailureKind::AbnormalTermination
                            | SessionFailureKind::StaleOwnership
                    )
                ) {
                    let terminal_at = record
                        .finished_at()
                        .unwrap_or_else(|| record.updated_at())
                        .nanos_since_epoch();
                    attempt.classify_terminal_interruption(terminal_at);
                }
                validate_incomplete_attempt_against_session(record, &attempt)
                    .map_err(ProcessingTransactionDiscoveryError::Provenance)?;
                incomplete_attempts.push(ProcessingIncompleteHttpAttempt {
                    project: project.clone(),
                    acquisition_runtime: record.runtime().clone(),
                    acquisition_session,
                    acquisition_session_state: record.state(),
                    attempt,
                });
            }
        }
    }

    discovered.sort_by(|left, right| {
        (
            left.transaction.created_at_unix_nanos(),
            left.transaction.identity().id(),
        )
            .cmp(&(
                right.transaction.created_at_unix_nanos(),
                right.transaction.identity().id(),
            ))
    });

    incomplete_attempts.sort_by(|left, right| {
        (
            left.attempt.created_at_unix_nanos(),
            left.attempt.identity().id(),
        )
            .cmp(&(
                right.attempt.created_at_unix_nanos(),
                right.attempt.identity().id(),
            ))
    });

    let mut seen = HashSet::new();
    for transaction in &discovered {
        let inserted = seen.insert(transaction.transaction.identity().id().to_string());
        if !inserted {
            return Err(
                ProcessingTransactionDiscoveryError::DuplicateTransactionIdentity {
                    transaction_identity: transaction.transaction.identity().id().to_string(),
                },
            );
        }
    }

    for attempt in &incomplete_attempts {
        let inserted = seen.insert(attempt.attempt.identity().id().to_string());
        if !inserted {
            return Err(
                ProcessingTransactionDiscoveryError::DuplicateTransactionIdentity {
                    transaction_identity: attempt.attempt.identity().id().to_string(),
                },
            );
        }
    }

    Ok(ProcessingHttpTransactionCatalog::with_incomplete(
        discovered,
        incomplete_attempts,
    ))
}

fn ensure_acquisition_record(
    records: &mut HashMap<SessionIdentity, SessionRecordV1>,
    store: &SessionStore,
    acquisition_session: &SessionIdentity,
    project: &ProjectIdentity,
    processing_runtime: &OwnedRuntimeIdentity,
) -> Result<(), ProcessingTransactionDiscoveryError> {
    if records.contains_key(acquisition_session) {
        return Ok(());
    }
    let record = store.load(acquisition_session).map_err(|source| {
        ProcessingTransactionDiscoveryError::AcquisitionSessionLoad {
            acquisition_session: acquisition_session.clone(),
            source,
        }
    })?;
    validate_session_record(project, processing_runtime, &record)
        .map_err(ProcessingTransactionDiscoveryError::Provenance)?;
    records.insert(acquisition_session.clone(), record);
    Ok(())
}

enum RawEvidenceCandidate {
    Complete(PathBuf),
    Incomplete(PathBuf),
}

/// Enumerate the raw root and strictly admit every attributable evidence entry.
fn enumerate_raw_evidence(
    raw_root: &Path,
) -> Result<Vec<RawEvidenceCandidate>, ProcessingTransactionDiscoveryError> {
    let entries = std::fs::read_dir(raw_root)
        .map_err(ProcessingTransactionDiscoveryError::RawRootEnumeration)?;

    let mut admitted_evidence = Vec::new();
    for entry in entries {
        let entry = entry.map_err(ProcessingTransactionDiscoveryError::RawRootEnumeration)?;
        let path = entry.path();
        let file_type = entry
            .file_type()
            .map_err(ProcessingTransactionDiscoveryError::RawEntryMetadata)?;

        if raw_entry_is_link_or_reparse(&path, &file_type)
            .map_err(ProcessingTransactionDiscoveryError::RawEntryMetadata)?
        {
            return Err(ProcessingTransactionDiscoveryError::RawEntrySymlink { entry_path: path });
        }

        if file_type.is_file() {
            return Err(ProcessingTransactionDiscoveryError::RawEntryUnexpectedFile {
                entry_path: path,
            });
        }

        if !file_type.is_dir() {
            return Err(ProcessingTransactionDiscoveryError::RawEntryUnsupportedType {
                entry_path: path,
            });
        }

        match classify_raw_directory_name(&entry.file_name()) {
            RawDirectoryClass::RecognizedPartial => {
                admitted_evidence.push(RawEvidenceCandidate::Incomplete(path));
            }
            RawDirectoryClass::MalformedPartial => {
                return Err(
                    ProcessingTransactionDiscoveryError::RawEntryMalformedPartialDirectory {
                        entry_path: path,
                    },
                );
            }
            RawDirectoryClass::FinalizedCandidate => {
                admitted_evidence.push(RawEvidenceCandidate::Complete(path));
            }
            RawDirectoryClass::Unrecognized => {
                return Err(
                    ProcessingTransactionDiscoveryError::RawEntryUnrecognizedDirectory {
                        entry_path: path,
                    },
                );
            }
            RawDirectoryClass::InvalidName => {
                return Err(ProcessingTransactionDiscoveryError::RawEntryNameInvalid {
                    entry_path: path,
                });
            }
        }
    }

    Ok(admitted_evidence)
}

#[cfg(not(windows))]
fn raw_entry_is_link_or_reparse(
    _path: &Path,
    file_type: &std::fs::FileType,
) -> std::io::Result<bool> {
    Ok(file_type.is_symlink())
}

#[cfg(windows)]
fn raw_entry_is_link_or_reparse(
    path: &Path,
    file_type: &std::fs::FileType,
) -> std::io::Result<bool> {
    use std::os::windows::fs::MetadataExt;
    const FILE_ATTRIBUTE_REPARSE_POINT: u32 = 0x0000_0400;
    let metadata = std::fs::symlink_metadata(path)?;
    Ok(file_type.is_symlink()
        || metadata.file_attributes() & FILE_ATTRIBUTE_REPARSE_POINT != 0)
}

/// Require the exact acquisition operation root and open its managed session store.
fn open_acquisition_session_store(
    protocol_root: &Path,
) -> Result<SessionStore, ProcessingTransactionDiscoveryError> {
    let expected_acquisition_root = protocol_root.join(ACQUISITION_OPERATION_DIRECTORY);

    validate_managed_path(
        protocol_root,
        &expected_acquisition_root,
        HttpManagedPathValidationMode::ExistingDirectory,
    )
    .map_err(
        |source| ProcessingTransactionDiscoveryError::AcquisitionRootInvalid {
            acquisition_root: expected_acquisition_root.clone(),
            source,
        },
    )?;

    let acquisition_operation_root = SessionOperationRoot::new(expected_acquisition_root)
        .map_err(ProcessingTransactionDiscoveryError::AcquisitionStoreOpen)?;
    SessionStore::open(acquisition_operation_root)
        .map_err(ProcessingTransactionDiscoveryError::AcquisitionStoreOpen)
}

enum RawDirectoryClass {
    /// A well-formed Core staging directory; ignore it and never delete it.
    RecognizedPartial,
    /// Carries the staging prefix but violates the recorder grammar.
    MalformedPartial,
    FinalizedCandidate,
    Unrecognized,
    InvalidName,
}

/// Classify a raw-root directory name using the authoritative Core grammars.
///
/// The staging grammar belongs to the HTTP transaction recorder and the finalized
/// grammar belongs to transaction admission; neither is re-derived here.
fn classify_raw_directory_name(name: &std::ffi::OsStr) -> RawDirectoryClass {
    let Some(name) = name.to_str() else {
        return RawDirectoryClass::InvalidName;
    };

    match classify_staging_transaction_directory_name(name) {
        StagingDirectoryNameClass::Valid { .. } => return RawDirectoryClass::RecognizedPartial,
        StagingDirectoryNameClass::Malformed => return RawDirectoryClass::MalformedPartial,
        StagingDirectoryNameClass::NotStaging => {}
    }

    if crate::protocols::http::transaction::metadata::parse_transaction_directory_name(name).is_ok()
    {
        return RawDirectoryClass::FinalizedCandidate;
    }

    RawDirectoryClass::Unrecognized
}

/// Validate the session-level invariants of a durable acquisition session record.
///
/// These properties depend only on the record, so they may be proven once per session
/// identity and cached.
fn validate_session_record(
    processing_project: &ProjectIdentity,
    processing_runtime: &OwnedRuntimeIdentity,
    acquisition_record: &SessionRecordV1,
) -> Result<(), ProcessingTransactionProvenanceError> {
    if acquisition_record.project() != processing_project {
        return Err(ProcessingTransactionProvenanceError::ProjectMismatch {
            acquisition_session: acquisition_record.session().clone(),
        });
    }

    if acquisition_record.runtime().protocol() != RuntimeProtocol::Http {
        return Err(
            ProcessingTransactionProvenanceError::RuntimeProtocolMismatch {
                acquisition_session: acquisition_record.session().clone(),
            },
        );
    }

    if acquisition_record.runtime().operation() != RuntimeOperation::Acquisition {
        return Err(
            ProcessingTransactionProvenanceError::RuntimeOperationMismatch {
                acquisition_session: acquisition_record.session().clone(),
            },
        );
    }

    if acquisition_record.operation() != SessionOperation::Acquisition {
        return Err(ProcessingTransactionProvenanceError::SessionOperationMismatch {
            acquisition_session: acquisition_record.session().clone(),
        });
    }

    if acquisition_record.runtime().source_name() != processing_runtime.source_name() {
        return Err(ProcessingTransactionProvenanceError::RuntimeSourceMismatch {
            acquisition_session: acquisition_record.session().clone(),
        });
    }

    if acquisition_record.runtime().source_contract_version()
        != crate::protocols::http::HTTP_SOURCE_CONTRACT_VERSION
    {
        return Err(ProcessingTransactionProvenanceError::RuntimeContractVersionMismatch {
            acquisition_session: acquisition_record.session().clone(),
            found: acquisition_record.runtime().source_contract_version(),
        });
    }

    if matches!(acquisition_record.state(), SessionState::Prepared) {
        return Err(ProcessingTransactionProvenanceError::SessionNotExecutable {
            acquisition_session: acquisition_record.session().clone(),
            state: acquisition_record.state(),
        });
    }

    if acquisition_record.started_at().is_none() {
        return Err(ProcessingTransactionProvenanceError::MissingStartedAt {
            acquisition_session: acquisition_record.session().clone(),
        });
    }

    Ok(())
}

/// Validate one transaction against its durable acquisition session record.
///
/// This runs for every transaction, including transactions whose session record was
/// already admitted and cached.
fn validate_transaction_against_session(
    acquisition_record: &SessionRecordV1,
    transaction: &RecordedTransaction,
) -> Result<(), ProcessingTransactionProvenanceError> {
    if acquisition_record.session() != transaction.session() {
        return Err(
            ProcessingTransactionProvenanceError::SessionIdentityMismatch {
                acquisition_session: acquisition_record.session().clone(),
            },
        );
    }

    let Some(started_at) = acquisition_record.started_at() else {
        return Err(ProcessingTransactionProvenanceError::MissingStartedAt {
            acquisition_session: acquisition_record.session().clone(),
        });
    };

    let transaction_created =
        SessionTimestamp::from_nanos_since_epoch(transaction.created_at_unix_nanos());
    let transaction_completed =
        SessionTimestamp::from_nanos_since_epoch(transaction.completed_at_unix_nanos());

    if transaction_completed < transaction_created
        || transaction_created < acquisition_record.created_at()
        || transaction_created < started_at
    {
        return Err(ProcessingTransactionProvenanceError::TimestampOutOfBounds {
            acquisition_session: acquisition_record.session().clone(),
            transaction_identity: transaction.identity().id().to_string(),
        });
    }

    if let Some(finished_at) = acquisition_record.finished_at() {
        if transaction_completed > finished_at {
            return Err(ProcessingTransactionProvenanceError::TimestampOutOfBounds {
                acquisition_session: acquisition_record.session().clone(),
                transaction_identity: transaction.identity().id().to_string(),
            });
        }
    }

    Ok(())
}

/// Validate one admitted partial attempt against its terminal acquisition
/// session. The observed timestamp is the last phase Core could prove durable;
/// it must remain within the same session bounds as a finalized transaction.
fn validate_incomplete_attempt_against_session(
    acquisition_record: &SessionRecordV1,
    attempt: &IncompleteRecordedHttpAttempt,
) -> Result<(), ProcessingTransactionProvenanceError> {
    if acquisition_record.session() != attempt.session() {
        return Err(
            ProcessingTransactionProvenanceError::SessionIdentityMismatch {
                acquisition_session: acquisition_record.session().clone(),
            },
        );
    }

    let Some(started_at) = acquisition_record.started_at() else {
        return Err(ProcessingTransactionProvenanceError::MissingStartedAt {
            acquisition_session: acquisition_record.session().clone(),
        });
    };
    let created = SessionTimestamp::from_nanos_since_epoch(
        attempt.created_at_unix_nanos(),
    );
    let observed = SessionTimestamp::from_nanos_since_epoch(
        attempt.observed_at_unix_nanos(),
    );
    if observed < created
        || created < acquisition_record.created_at()
        || created < started_at
        || acquisition_record
            .finished_at()
            .is_some_and(|finished| observed > finished)
    {
        return Err(ProcessingTransactionProvenanceError::TimestampOutOfBounds {
            acquisition_session: acquisition_record.session().clone(),
            transaction_identity: attempt.identity().id().to_string(),
        });
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    const TX_A: &str = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa";
    const TX_B: &str = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
    const TX_DUPLICATE: &str = "cccccccccccccccccccccccccccccccc";

    fn now_nanos() -> u64 {
        std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos() as u64
    }

    fn write_finalized_transaction(raw: &Path, session: &SessionIdentity, timestamp: u64, id: &str) {
        use crate::protocols::http::transaction::metadata::{
            HTTP_TRANSACTION_SCHEMA_VERSION, RequestAttemptState, RequestMetadataDocument,
            ResponseMetadataDocument, ResponseOutcomeDocument,
        };
        let directory = raw.join(format!("{timestamp}-{id}"));
        std::fs::create_dir_all(directory.join("request")).unwrap();
        std::fs::create_dir_all(directory.join("response")).unwrap();
        let request = RequestMetadataDocument {
            schema_version: HTTP_TRANSACTION_SCHEMA_VERSION,
            transaction_id: id.to_string(), session_id: session.id().to_string(),
            physical_attempt_index: 1, redirect_index: 0, retry_index: 0,
            parent_transaction_id: None, logical_request_key: None,
            method: "GET".to_string(), url: "https://example.invalid/data".to_string(),
            headers: Vec::new(), has_body: false, body_length: 0, body_sha256: None,
            created_at_unix_nanos: timestamp,
            attempt_state: RequestAttemptState::DispatchStarted,
            dispatch_started_at_unix_nanos: Some(timestamp.saturating_add(1)),
        };
        let response = ResponseMetadataDocument {
            schema_version: HTTP_TRANSACTION_SCHEMA_VERSION,
            transaction_id: id.to_string(),
            outcome: ResponseOutcomeDocument::Response {
                status: 200, http_version: None, headers: Vec::new(), body_length: 0,
                body_sha256: "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855".to_string(),
                completed_at_unix_nanos: timestamp.saturating_add(2),
            },
        };
        std::fs::write(directory.join("request/metadata.json"), serde_json::to_vec(&request).unwrap()).unwrap();
        std::fs::write(directory.join("response/metadata.json"), serde_json::to_vec(&response).unwrap()).unwrap();
        std::fs::write(directory.join("response/body"), []).unwrap();
    }

    fn write_incomplete_response_attempt(
        raw: &Path,
        session: &SessionIdentity,
        timestamp: u64,
        id: &str,
    ) {
        use crate::protocols::http::transaction::metadata::{
            HTTP_TRANSACTION_SCHEMA_VERSION, RequestAttemptState, RequestMetadataDocument,
            ResponseMetadataDocument, ResponseOutcomeDocument,
        };
        let directory = raw.join(format!(".partial-{timestamp}-{id}"));
        std::fs::create_dir_all(directory.join("request")).unwrap();
        std::fs::create_dir_all(directory.join("response")).unwrap();
        let request = RequestMetadataDocument {
            schema_version: HTTP_TRANSACTION_SCHEMA_VERSION,
            transaction_id: id.to_string(),
            session_id: session.id().to_string(),
            physical_attempt_index: 1,
            redirect_index: 0,
            retry_index: 0,
            parent_transaction_id: None,
            logical_request_key: Some("work/incomplete".to_string()),
            method: "GET".to_string(),
            url: "https://example.invalid/incomplete".to_string(),
            headers: Vec::new(),
            has_body: false,
            body_length: 0,
            body_sha256: None,
            created_at_unix_nanos: timestamp,
            attempt_state: RequestAttemptState::DispatchStarted,
            dispatch_started_at_unix_nanos: Some(timestamp.saturating_add(1)),
        };
        let response = ResponseMetadataDocument {
            schema_version: HTTP_TRANSACTION_SCHEMA_VERSION,
            transaction_id: id.to_string(),
            outcome: ResponseOutcomeDocument::IncompleteResponse {
                status: 200,
                http_version: None,
                headers: Vec::new(),
                failure_class: "io".to_string(),
                body_bytes_recorded: 0,
                partial_body_sha256: None,
                failed_at_unix_nanos: timestamp.saturating_add(2),
            },
        };
        std::fs::write(
            directory.join("request/metadata.json"),
            serde_json::to_vec(&request).unwrap(),
        )
        .unwrap();
        std::fs::write(
            directory.join("response/metadata.json"),
            serde_json::to_vec(&response).unwrap(),
        )
        .unwrap();
        std::fs::write(directory.join("response/body"), []).unwrap();
    }

    fn write_response_headers_attempt(
        raw: &Path,
        session: &SessionIdentity,
        timestamp: u64,
        id: &str,
    ) {
        use crate::protocols::http::transaction::metadata::{
            HTTP_TRANSACTION_SCHEMA_VERSION, RequestAttemptState, RequestMetadataDocument,
            ResponseMetadataDocument, ResponseOutcomeDocument,
        };
        let directory = raw.join(format!(".partial-{timestamp}-{id}"));
        std::fs::create_dir_all(directory.join("request")).unwrap();
        std::fs::create_dir_all(directory.join("response")).unwrap();
        let request = RequestMetadataDocument {
            schema_version: HTTP_TRANSACTION_SCHEMA_VERSION,
            transaction_id: id.to_string(),
            session_id: session.id().to_string(),
            physical_attempt_index: 1,
            redirect_index: 0,
            retry_index: 0,
            parent_transaction_id: None,
            logical_request_key: Some("work/interrupted".to_string()),
            method: "GET".to_string(),
            url: "https://example.invalid/interrupted".to_string(),
            headers: Vec::new(),
            has_body: false,
            body_length: 0,
            body_sha256: None,
            created_at_unix_nanos: timestamp,
            attempt_state: RequestAttemptState::DispatchStarted,
            dispatch_started_at_unix_nanos: Some(timestamp.saturating_add(1)),
        };
        let response = ResponseMetadataDocument {
            schema_version: HTTP_TRANSACTION_SCHEMA_VERSION,
            transaction_id: id.to_string(),
            outcome: ResponseOutcomeDocument::ResponseHeadersReceived {
                status: 200,
                http_version: None,
                headers: Vec::new(),
                received_at_unix_nanos: timestamp.saturating_add(2),
            },
        };
        std::fs::write(
            directory.join("request/metadata.json"),
            serde_json::to_vec(&request).unwrap(),
        )
        .unwrap();
        std::fs::write(
            directory.join("response/metadata.json"),
            serde_json::to_vec(&response).unwrap(),
        )
        .unwrap();
    }

    fn acquisition_session(
        protocol_root: &Path,
        project: &str,
        contract_version: u32,
    ) -> (SessionStore, crate::session::PreparedSession, SessionRecordV1) {
        session_with_identity(
            protocol_root,
            project,
            OwnedRuntimeIdentity::http_acquisition("example-source", contract_version),
            crate::session::SessionOperation::Acquisition,
        )
    }

    fn session_with_identity(
        protocol_root: &Path,
        project: &str,
        runtime: OwnedRuntimeIdentity,
        operation: crate::session::SessionOperation,
    ) -> (SessionStore, crate::session::PreparedSession, SessionRecordV1) {
        let store = SessionStore::open(SessionOperationRoot::new(protocol_root.join("get-raw-data")).unwrap()).unwrap();
        let prepared = store.create_prepared(crate::session::NewSessionRecord {
            project: ProjectIdentity::new(project).unwrap(),
            runtime,
            operation,
            execution_mode: crate::runtime::RuntimeExecutionMode::Run,
            supervision_mode: crate::runtime::RuntimeSupervisionMode::Foreground,
        }).unwrap();
        let running = store.transition_as_lease_owner(
            prepared.record().session(), prepared.lease(), prepared.record().revision(),
            crate::session::SessionTransition::ToRunning,
        ).unwrap();
        (store, prepared, running)
    }

    #[test]
    fn raw_directory_classifier_accepts_known_partial_and_finalized_shapes() {
        let valid_partial = std::ffi::OsString::from(format!(".partial-1700000000-{TX_A}"));
        match classify_raw_directory_name(&valid_partial) {
            RawDirectoryClass::RecognizedPartial => {}
            other => panic!("expected RecognizedPartial, got {other:?}"),
        }

        let malformed = std::ffi::OsString::from(".partial-abc");
        match classify_raw_directory_name(&malformed) {
            RawDirectoryClass::MalformedPartial => {}
            other => panic!("expected MalformedPartial, got {other:?}"),
        }

        let finalized = std::ffi::OsString::from(format!("1700000000-{TX_A}"));
        match classify_raw_directory_name(&finalized) {
            RawDirectoryClass::FinalizedCandidate => {}
            other => panic!("expected FinalizedCandidate, got {other:?}"),
        }

        let unrecognized = std::ffi::OsString::from("scratch");
        match classify_raw_directory_name(&unrecognized) {
            RawDirectoryClass::Unrecognized => {}
            other => panic!("expected Unrecognized, got {other:?}"),
        }
    }

    #[test]
    fn discovery_error_is_provenance_failure_for_provenance_variants_only() {
        let prov = ProcessingTransactionDiscoveryError::Provenance(
            ProcessingTransactionProvenanceError::RuntimeContractVersionMismatch {
                acquisition_session: SessionIdentity::new("session-test").unwrap(),
                found: 99,
            },
        );
        assert!(prov.is_provenance_failure());
        assert!(prov.entry_path().is_none());

        let not_prov = ProcessingTransactionDiscoveryError::RuntimeProtocolMismatch;
        assert!(!not_prov.is_provenance_failure());
        assert!(not_prov.provenance_error().is_none());

        let symlink = ProcessingTransactionDiscoveryError::RawEntrySymlink {
            entry_path: PathBuf::from("/tmp/raw/symlink"),
        };
        assert!(!symlink.is_provenance_failure());
        assert_eq!(
            symlink.entry_path(),
            Some(std::path::Path::new("/tmp/raw/symlink"))
        );
    }

    #[test]
    fn catalog_iteration_is_total_and_order_preserving() {
        use std::path::PathBuf;

        let runtime = OwnedRuntimeIdentity::http_acquisition("proc-cat-source", 1);
        let make = |suffix: &str| -> ProcessingHttpTransaction {
            use crate::protocols::http::transaction::{
                HttpAttemptIdentity, HttpRecordedOutcome, HttpTransactionIdentity, RecordedHeader,
                RecordedHeaderCollection, RecordedHttpRequest, RecordedHttpResponse,
                RecordedTransaction,
            };
            use crate::session::{ProjectIdentity, SessionIdentity, SessionState};
            let project = ProjectIdentity::new("proc-cat-project").unwrap();
            let session = SessionIdentity::new(format!("proc-cat-{suffix}")).unwrap();
            let identity =
                HttpTransactionIdentity::new().expect("transaction identity");
            let attempt = HttpAttemptIdentity::new(1, 0, 0).expect("attempt");
            let tx = RecordedTransaction::new(
                identity,
                attempt,
                None,
                None,
                session.clone(),
                1_700_000_000,
                PathBuf::from(format!("/tmp/raw/{suffix}")),
                RecordedHttpRequest::new(None, 0, None),
                RecordedHttpResponse::new(
                    Some(200),
                    RecordedHeaderCollection::new(Vec::<RecordedHeader>::new()),
                    PathBuf::from(format!("/tmp/raw/{suffix}/body")),
                    0,
                    None,
                    1_700_000_000,
                    HttpRecordedOutcome::Response,
                ),
            );
            ProcessingHttpTransaction {
                project,
                acquisition_runtime: runtime.clone(),
                acquisition_session: session,
                acquisition_session_state: SessionState::Succeeded,
                transaction: tx,
            }
        };

        let items = vec![make("a"), make("b"), make("c")];
        let catalog = ProcessingHttpTransactionCatalog::new(items.clone());
        assert_eq!(catalog.len(), 3);
        assert!(!catalog.is_empty());
        assert_eq!(catalog.as_slice().len(), 3);
        let collected: Vec<&ProcessingHttpTransaction> = catalog.iter().collect();
        assert_eq!(collected.len(), 3);
    }

    #[test]
    fn production_discovery_excludes_well_formed_partial_directory_without_mutating_it() {
        let root = tempfile::tempdir().unwrap();
        let protocol_root = root.path().join("project/sources/example-source/http");
        let raw_root = protocol_root.join("data/raw");
        let partial = raw_root.join(format!(".partial-1700000000-{TX_A}"));
        std::fs::create_dir_all(&partial).unwrap();
        std::fs::write(partial.join("forensic-marker"), b"retain exactly").unwrap();
        std::fs::create_dir_all(protocol_root.join("get-raw-data")).unwrap();
        let before = std::fs::read(partial.join("forensic-marker")).unwrap();

        let catalog = discover_http_transactions_for_processing(
            &ProjectIdentity::new("example-project").unwrap(),
            &OwnedRuntimeIdentity::http_processing("example-source", 1),
            &protocol_root,
            &raw_root,
        ).unwrap();

        assert!(catalog.is_empty());
        assert_eq!(std::fs::read(partial.join("forensic-marker")).unwrap(), before);
        assert!(partial.is_dir());
    }

    #[test]
    fn production_catalog_exposes_validated_terminal_incomplete_attempt() {
        let root = tempfile::tempdir().unwrap();
        let protocol_root = root.path().join("project/sources/example-source/http");
        let raw_root = protocol_root.join("data/raw");
        std::fs::create_dir_all(&raw_root).unwrap();
        let (store, prepared, running) = acquisition_session(
            &protocol_root,
            "example-project",
            crate::protocols::http::HTTP_SOURCE_CONTRACT_VERSION,
        );
        let timestamp = now_nanos();
        write_incomplete_response_attempt(
            &raw_root,
            running.session(),
            timestamp,
            TX_A,
        );
        store
            .transition_as_lease_owner(
                running.session(),
                prepared.lease(),
                running.revision(),
                crate::session::SessionTransition::ToFailed {
                    failure: crate::session::SafeSessionFailure::source_failure(),
                },
            )
            .unwrap();

        let catalog = discover_http_transactions_for_processing(
            &ProjectIdentity::new("example-project").unwrap(),
            &OwnedRuntimeIdentity::http_processing("example-source", 1),
            &protocol_root,
            &raw_root,
        )
        .unwrap();

        assert_eq!(catalog.len(), 0);
        assert!(catalog.is_empty());
        assert_eq!(catalog.complete_len(), 0);
        assert_eq!(catalog.incomplete_len(), 1);
        assert_eq!(catalog.entry_len(), 1);
        assert!(!catalog.entries_is_empty());
        assert!(matches!(
            catalog.incomplete_attempts().next().unwrap().attempt().phase(),
            crate::protocols::http::transaction::IncompleteHttpAttemptPhase::ResponseBodyIncomplete
        ));
    }

    #[test]
    fn production_catalog_classifies_abnormal_terminal_partial_as_interrupted() {
        let root = tempfile::tempdir().unwrap();
        let protocol_root = root.path().join("project/sources/example-source/http");
        let raw_root = protocol_root.join("data/raw");
        std::fs::create_dir_all(&raw_root).unwrap();
        let (store, prepared, running) = acquisition_session(
            &protocol_root,
            "example-project",
            crate::protocols::http::HTTP_SOURCE_CONTRACT_VERSION,
        );
        write_response_headers_attempt(
            &raw_root,
            running.session(),
            now_nanos(),
            TX_A,
        );
        store
            .transition_as_lease_owner(
                running.session(),
                prepared.lease(),
                running.revision(),
                crate::session::SessionTransition::ToFailed {
                    failure: crate::session::SafeSessionFailure::new(
                        crate::session::SessionFailureKind::AbnormalTermination,
                        crate::session::SessionFailureCode::AbnormalTermination,
                        Some("test child terminated".to_owned()),
                    ),
                },
            )
            .unwrap();

        let catalog = discover_http_transactions_for_processing(
            &ProjectIdentity::new("example-project").unwrap(),
            &OwnedRuntimeIdentity::http_processing("example-source", 1),
            &protocol_root,
            &raw_root,
        )
        .unwrap();

        assert_eq!(catalog.complete_len(), 0);
        assert_eq!(catalog.incomplete_len(), 1);
        assert!(matches!(
            catalog.incomplete_attempts().next().unwrap().attempt().phase(),
            crate::protocols::http::transaction::IncompleteHttpAttemptPhase::Interrupted
        ));
    }

    #[test]
    fn production_catalog_omits_mutable_running_session_partial() {
        let root = tempfile::tempdir().unwrap();
        let protocol_root = root.path().join("project/sources/example-source/http");
        let raw_root = protocol_root.join("data/raw");
        std::fs::create_dir_all(&raw_root).unwrap();
        let (_store, _prepared, running) = acquisition_session(
            &protocol_root,
            "example-project",
            crate::protocols::http::HTTP_SOURCE_CONTRACT_VERSION,
        );
        let timestamp = now_nanos();
        write_incomplete_response_attempt(
            &raw_root,
            running.session(),
            timestamp,
            TX_B,
        );

        let catalog = discover_http_transactions_for_processing(
            &ProjectIdentity::new("example-project").unwrap(),
            &OwnedRuntimeIdentity::http_processing("example-source", 1),
            &protocol_root,
            &raw_root,
        )
        .unwrap();
        assert!(catalog.is_empty());
    }

    #[test]
    fn production_catalog_rejects_stale_running_session_partial() {
        let root = tempfile::tempdir().unwrap();
        let protocol_root = root.path().join("project/sources/example-source/http");
        let raw_root = protocol_root.join("data/raw");
        std::fs::create_dir_all(&raw_root).unwrap();
        let (_store, prepared, running) = acquisition_session(
            &protocol_root,
            "example-project",
            crate::protocols::http::HTTP_SOURCE_CONTRACT_VERSION,
        );
        let acquisition_session = running.session().clone();
        write_incomplete_response_attempt(
            &raw_root,
            &acquisition_session,
            now_nanos(),
            TX_B,
        );
        drop(prepared);

        let error = discover_http_transactions_for_processing(
            &ProjectIdentity::new("example-project").unwrap(),
            &OwnedRuntimeIdentity::http_processing("example-source", 1),
            &protocol_root,
            &raw_root,
        )
        .unwrap_err();

        assert!(matches!(
            error,
            ProcessingTransactionDiscoveryError::StaleRunningAcquisitionSession {
                acquisition_session: found,
            } if found == acquisition_session
        ));
    }

    #[test]
    fn production_discovery_rejects_foreign_raw_file_without_mutating_it() {
        let root = tempfile::tempdir().unwrap();
        let protocol_root = root.path().join("project/sources/example-source/http");
        let raw_root = protocol_root.join("data/raw");
        std::fs::create_dir_all(&raw_root).unwrap();
        std::fs::create_dir_all(protocol_root.join("get-raw-data")).unwrap();
        let foreign = raw_root.join("foreign.txt");
        std::fs::write(&foreign, b"foreign bytes").unwrap();

        let error = discover_http_transactions_for_processing(
            &ProjectIdentity::new("example-project").unwrap(),
            &OwnedRuntimeIdentity::http_processing("example-source", 1),
            &protocol_root,
            &raw_root,
        ).unwrap_err();

        assert!(matches!(error, ProcessingTransactionDiscoveryError::RawEntryUnexpectedFile { .. }));
        assert_eq!(std::fs::read(foreign).unwrap(), b"foreign bytes");
    }

    #[test]
    fn production_discovery_rejects_malformed_partial_directory_without_mutating_it() {
        let root = tempfile::tempdir().unwrap();
        let protocol_root = root.path().join("project/sources/example-source/http");
        let raw_root = protocol_root.join("data/raw");
        let malformed = raw_root.join(".partial-not-a-valid-transaction");
        std::fs::create_dir_all(&malformed).unwrap();
        std::fs::write(malformed.join("retain"), b"retain").unwrap();
        std::fs::create_dir_all(protocol_root.join("get-raw-data")).unwrap();
        let error = discover_http_transactions_for_processing(
            &ProjectIdentity::new("example-project").unwrap(),
            &OwnedRuntimeIdentity::http_processing("example-source", 1),
            &protocol_root, &raw_root,
        ).unwrap_err();
        assert!(matches!(error, ProcessingTransactionDiscoveryError::RawEntryMalformedPartialDirectory { .. }));
        assert_eq!(std::fs::read(malformed.join("retain")).unwrap(), b"retain");
    }

    #[cfg(unix)]
    #[test]
    fn production_discovery_rejects_raw_entry_symlink_without_following_it() {
        use std::os::unix::fs::symlink;
        let root = tempfile::tempdir().unwrap();
        let protocol_root = root.path().join("project/sources/example-source/http");
        let raw_root = protocol_root.join("data/raw");
        let outside = root.path().join("outside");
        std::fs::create_dir_all(&raw_root).unwrap();
        std::fs::create_dir_all(&outside).unwrap();
        std::fs::write(outside.join("retain"), b"outside").unwrap();
        symlink(&outside, raw_root.join("linked")).unwrap();
        std::fs::create_dir_all(protocol_root.join("get-raw-data")).unwrap();
        let error = discover_http_transactions_for_processing(
            &ProjectIdentity::new("example-project").unwrap(),
            &OwnedRuntimeIdentity::http_processing("example-source", 1),
            &protocol_root, &raw_root,
        ).unwrap_err();
        assert!(matches!(error, ProcessingTransactionDiscoveryError::RawEntrySymlink { .. }));
        assert_eq!(std::fs::read(outside.join("retain")).unwrap(), b"outside");
    }

    #[cfg(windows)]
    #[test]
    fn production_discovery_rejects_windows_reparse_directory_without_following_it() {
        use std::os::windows::fs::symlink_dir;
        let root = tempfile::tempdir().unwrap();
        let protocol_root = root.path().join("project/sources/example-source/http");
        let raw_root = protocol_root.join("data/raw");
        let outside = root.path().join("outside");
        std::fs::create_dir_all(&raw_root).unwrap();
        std::fs::create_dir_all(&outside).unwrap();
        std::fs::write(outside.join("retain"), b"outside").unwrap();
        symlink_dir(&outside, raw_root.join("linked")).expect(
            "native Windows verification requires permission to create a directory reparse point",
        );
        std::fs::create_dir_all(protocol_root.join("get-raw-data")).unwrap();
        let error = discover_http_transactions_for_processing(
            &ProjectIdentity::new("example-project").unwrap(),
            &OwnedRuntimeIdentity::http_processing("example-source", 1),
            &protocol_root, &raw_root,
        ).unwrap_err();
        assert!(matches!(error, ProcessingTransactionDiscoveryError::RawEntrySymlink { .. }));
        assert_eq!(std::fs::read(outside.join("retain")).unwrap(), b"outside");
    }

    #[test]
    fn production_catalog_admits_finalized_transaction_and_binds_session_provenance() {
        let root = tempfile::tempdir().unwrap();
        let protocol_root = root.path().join("project/sources/example-source/http");
        let raw_root = protocol_root.join("data/raw");
        std::fs::create_dir_all(&raw_root).unwrap();
        let (store, prepared, running) = acquisition_session(&protocol_root, "example-project", crate::protocols::http::HTTP_SOURCE_CONTRACT_VERSION);
        let timestamp = now_nanos();
        write_finalized_transaction(&raw_root, running.session(), timestamp, TX_A);
        store.transition_as_lease_owner(
            running.session(), prepared.lease(), running.revision(), crate::session::SessionTransition::ToSucceeded,
        ).unwrap();

        let catalog = discover_http_transactions_for_processing(
            &ProjectIdentity::new("example-project").unwrap(),
            &OwnedRuntimeIdentity::http_processing("example-source", 1),
            &protocol_root, &raw_root,
        ).unwrap();
        assert_eq!(catalog.len(), 1);
        assert_eq!(catalog.as_slice()[0].acquisition_session(), prepared.record().session());
        assert_eq!(catalog.as_slice()[0].transaction().identity().id(), TX_A);
    }

    #[test]
    fn production_catalog_rejects_foreign_project_provenance() {
        let root = tempfile::tempdir().unwrap();
        let protocol_root = root.path().join("project/sources/example-source/http");
        let raw_root = protocol_root.join("data/raw");
        std::fs::create_dir_all(&raw_root).unwrap();
        let (store, prepared, running) = acquisition_session(&protocol_root, "foreign-project", crate::protocols::http::HTTP_SOURCE_CONTRACT_VERSION);
        let timestamp = now_nanos();
        write_finalized_transaction(&raw_root, running.session(), timestamp, TX_B);
        store.transition_as_lease_owner(running.session(), prepared.lease(), running.revision(), crate::session::SessionTransition::ToSucceeded).unwrap();
        let error = discover_http_transactions_for_processing(
            &ProjectIdentity::new("example-project").unwrap(),
            &OwnedRuntimeIdentity::http_processing("example-source", 1),
            &protocol_root, &raw_root,
        ).unwrap_err();
        assert!(matches!(error, ProcessingTransactionDiscoveryError::Provenance(ProcessingTransactionProvenanceError::ProjectMismatch { .. })));
    }

    #[test]
    fn production_catalog_rejects_unsupported_acquisition_runtime_contract_version() {
        let root = tempfile::tempdir().unwrap();
        let protocol_root = root.path().join("project/sources/example-source/http");
        let raw_root = protocol_root.join("data/raw");
        std::fs::create_dir_all(&raw_root).unwrap();
        let (store, prepared, running) = acquisition_session(&protocol_root, "example-project", 99);
        let timestamp = now_nanos();
        write_finalized_transaction(&raw_root, running.session(), timestamp, TX_B);
        store.transition_as_lease_owner(running.session(), prepared.lease(), running.revision(), crate::session::SessionTransition::ToSucceeded).unwrap();
        let error = discover_http_transactions_for_processing(
            &ProjectIdentity::new("example-project").unwrap(),
            &OwnedRuntimeIdentity::http_processing("example-source", 1),
            &protocol_root, &raw_root,
        ).unwrap_err();
        assert!(matches!(error, ProcessingTransactionDiscoveryError::Provenance(
            ProcessingTransactionProvenanceError::RuntimeContractVersionMismatch { found: 99, .. }
        )));
    }

    #[test]
    fn production_catalog_rejects_duplicate_transaction_identity() {
        let root = tempfile::tempdir().unwrap();
        let protocol_root = root.path().join("project/sources/example-source/http");
        let raw_root = protocol_root.join("data/raw");
        std::fs::create_dir_all(&raw_root).unwrap();
        let (store, prepared, running) = acquisition_session(&protocol_root, "example-project", crate::protocols::http::HTTP_SOURCE_CONTRACT_VERSION);
        let first = now_nanos();
        write_finalized_transaction(&raw_root, running.session(), first, TX_DUPLICATE);
        write_finalized_transaction(&raw_root, running.session(), first.saturating_add(10), TX_DUPLICATE);
        store.transition_as_lease_owner(running.session(), prepared.lease(), running.revision(), crate::session::SessionTransition::ToSucceeded).unwrap();
        let error = discover_http_transactions_for_processing(
            &ProjectIdentity::new("example-project").unwrap(),
            &OwnedRuntimeIdentity::http_processing("example-source", 1),
            &protocol_root, &raw_root,
        ).unwrap_err();
        assert!(matches!(error, ProcessingTransactionDiscoveryError::DuplicateTransactionIdentity { .. }));
    }

    #[test]
    fn production_catalog_rejects_finalized_directory_with_incomplete_response() {
        use crate::protocols::http::transaction::metadata::{
            HTTP_TRANSACTION_SCHEMA_VERSION, ResponseMetadataDocument, ResponseOutcomeDocument,
        };
        let root = tempfile::tempdir().unwrap();
        let protocol_root = root.path().join("project/sources/example-source/http");
        let raw_root = protocol_root.join("data/raw");
        std::fs::create_dir_all(&raw_root).unwrap();
        let (store, prepared, running) = acquisition_session(&protocol_root, "example-project", crate::protocols::http::HTTP_SOURCE_CONTRACT_VERSION);
        let timestamp = now_nanos();
        write_finalized_transaction(&raw_root, running.session(), timestamp, TX_B);
        let response = ResponseMetadataDocument {
            schema_version: HTTP_TRANSACTION_SCHEMA_VERSION,
            transaction_id: TX_B.to_string(),
            outcome: ResponseOutcomeDocument::IncompleteResponse {
                status: 200, http_version: None, headers: Vec::new(), failure_class: "io".to_string(),
                body_bytes_recorded: 0, partial_body_sha256: None, failed_at_unix_nanos: timestamp.saturating_add(2),
            },
        };
        std::fs::write(
            raw_root.join(format!("{timestamp}-{TX_B}/response/metadata.json")),
            serde_json::to_vec(&response).unwrap(),
        ).unwrap();
        store.transition_as_lease_owner(running.session(), prepared.lease(), running.revision(), crate::session::SessionTransition::ToSucceeded).unwrap();
        let error = discover_http_transactions_for_processing(
            &ProjectIdentity::new("example-project").unwrap(),
            &OwnedRuntimeIdentity::http_processing("example-source", 1),
            &protocol_root, &raw_root,
        ).unwrap_err();
        assert!(matches!(error, ProcessingTransactionDiscoveryError::TransactionAdmission {
            source: HttpTransactionAdmissionError::IncompleteResponseNotFinalized,
            ..
        }));
    }

    #[test]
    fn production_catalog_rejects_malformed_finalized_metadata_without_mutation() {
        let root = tempfile::tempdir().unwrap();
        let protocol_root = root.path().join("project/sources/example-source/http");
        let raw_root = protocol_root.join("data/raw");
        std::fs::create_dir_all(&raw_root).unwrap();
        let (store, prepared, running) = acquisition_session(
            &protocol_root, "example-project", crate::protocols::http::HTTP_SOURCE_CONTRACT_VERSION,
        );
        let timestamp = now_nanos();
        write_finalized_transaction(&raw_root, running.session(), timestamp, TX_A);
        let metadata = raw_root.join(format!("{timestamp}-{TX_A}/request/metadata.json"));
        std::fs::write(&metadata, b"{not-json").unwrap();
        let before = std::fs::read(&metadata).unwrap();
        store.transition_as_lease_owner(running.session(), prepared.lease(), running.revision(), crate::session::SessionTransition::ToSucceeded).unwrap();
        let error = discover_http_transactions_for_processing(
            &ProjectIdentity::new("example-project").unwrap(),
            &OwnedRuntimeIdentity::http_processing("example-source", 1),
            &protocol_root, &raw_root,
        ).unwrap_err();
        assert!(matches!(error, ProcessingTransactionDiscoveryError::TransactionAdmission {
            source: HttpTransactionAdmissionError::RequestMetadataDecode(_), ..
        }));
        assert_eq!(std::fs::read(metadata).unwrap(), before);
    }

    fn provenance_error_for(
        runtime: OwnedRuntimeIdentity,
        operation: crate::session::SessionOperation,
    ) -> ProcessingTransactionProvenanceError {
        let root = tempfile::tempdir().unwrap();
        let protocol_root = root.path().join("project/sources/example-source/http");
        let raw_root = protocol_root.join("data/raw");
        std::fs::create_dir_all(&raw_root).unwrap();
        let (store, prepared, running) = session_with_identity(
            &protocol_root, "example-project", runtime, operation,
        );
        let timestamp = now_nanos();
        write_finalized_transaction(&raw_root, running.session(), timestamp, TX_B);
        store.transition_as_lease_owner(running.session(), prepared.lease(), running.revision(), crate::session::SessionTransition::ToSucceeded).unwrap();
        match discover_http_transactions_for_processing(
            &ProjectIdentity::new("example-project").unwrap(),
            &OwnedRuntimeIdentity::http_processing("example-source", 1),
            &protocol_root, &raw_root,
        ).unwrap_err() {
            ProcessingTransactionDiscoveryError::Provenance(error) => error,
            other => panic!("expected provenance error, found {other:?}"),
        }
    }

    #[test]
    fn production_catalog_rejects_foreign_runtime_source() {
        let error = provenance_error_for(
            OwnedRuntimeIdentity::http_acquisition(
                "foreign-source", crate::protocols::http::HTTP_SOURCE_CONTRACT_VERSION,
            ),
            crate::session::SessionOperation::Acquisition,
        );
        assert!(matches!(error, ProcessingTransactionProvenanceError::RuntimeSourceMismatch { .. }));
    }

    #[test]
    fn production_catalog_rejects_runtime_operation_mismatch() {
        let error = provenance_error_for(
            OwnedRuntimeIdentity::http_processing(
                "example-source", crate::protocols::http::HTTP_SOURCE_CONTRACT_VERSION,
            ),
            crate::session::SessionOperation::Processing,
        );
        assert!(matches!(error, ProcessingTransactionProvenanceError::RuntimeOperationMismatch { .. }));
    }

    #[test]
    fn production_catalog_rejects_session_operation_mismatch() {
        let error = provenance_error_for(
            OwnedRuntimeIdentity::http_acquisition(
                "example-source", crate::protocols::http::HTTP_SOURCE_CONTRACT_VERSION,
            ),
            crate::session::SessionOperation::Processing,
        );
        assert!(matches!(error, ProcessingTransactionProvenanceError::SessionOperationMismatch { .. }));
    }
}
