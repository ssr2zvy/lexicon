use std::fmt;
use std::fs::{self, File, OpenOptions};
use std::io::{Read, Write};
use std::path::{Path, PathBuf};
use std::time::Duration;

use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

const STATE_SCHEMA_VERSION: u32 = 1;
const STATE_LIMIT: u64 = 16 * 1024;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub(crate) enum ProcessingDatabasePublicationPhase {
    Prepared,
    BackupLinked,
    CanonicalRenamedBeforeState,
    CanonicalInstalled,
}

#[derive(Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct PublicationStateV1 {
    schema_version: u32,
    session_id: String,
    canonical_file_name: String,
    nonce: String,
    baseline_present: bool,
    phase: ProcessingDatabasePublicationPhase,
}

#[derive(Debug)]
pub enum ProcessingDatabasePublicationError {
    InvalidCanonicalPath,
    LockOpen(std::io::Error),
    AlreadyPublishing(std::io::Error),
    StateInspect(std::io::Error),
    StateMalformed,
    Recovery(std::io::Error),
    CanonicalInspect(std::io::Error),
    CanonicalSymlink,
    CanonicalNotRegular,
    CanonicalRead(std::io::Error),
    StagingCreate(rusqlite::Error),
    StagingBackup(rusqlite::Error),
    StagingConfigure(rusqlite::Error),
    StagingIntegrity(rusqlite::Error),
    StagingIntegrityDisagreement(String),
    StagingSync(std::io::Error),
    CanonicalChanged,
    StatePublish(std::io::Error),
    StatePublishAndCleanup {
        publication: std::io::Error,
        cleanup: std::io::Error,
    },
    BackupInstall(std::io::Error),
    CanonicalInstall(std::io::Error),
    RollbackFailed {
        publication: std::io::Error,
        rollback: std::io::Error,
    },
    StagingCleanup(std::io::Error),
    Injected,
    PrimaryAndStagingCleanup {
        primary: Box<ProcessingDatabasePublicationError>,
        cleanup: Box<ProcessingDatabasePublicationError>,
    },
}

impl fmt::Display for ProcessingDatabasePublicationError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidCanonicalPath => f.write_str("processing database canonical path is invalid"),
            Self::AlreadyPublishing(_) => f.write_str("another processing publication owns the database"),
            Self::CanonicalChanged => f.write_str("canonical processing database changed during staging"),
            Self::CanonicalSymlink | Self::CanonicalNotRegular => {
                f.write_str("canonical processing database is not a managed regular file")
            }
            Self::RollbackFailed { .. } => f.write_str("processing database replacement and rollback both failed"),
            Self::Injected => f.write_str("processing database publication fault injected"),
            Self::StagingCleanup(_) => f.write_str("processing staging database cleanup failed before publication"),
            _ => f.write_str("processing database staging or publication failed"),
        }
    }
}

impl std::error::Error for ProcessingDatabasePublicationError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::LockOpen(e) | Self::AlreadyPublishing(e) | Self::StateInspect(e)
            | Self::Recovery(e) | Self::CanonicalInspect(e) | Self::CanonicalRead(e)
            | Self::StagingSync(e) | Self::StatePublish(e) | Self::BackupInstall(e)
            | Self::CanonicalInstall(e) => Some(e),
            Self::StagingCleanup(e) => Some(e),
            Self::StagingCreate(e) | Self::StagingBackup(e) | Self::StagingConfigure(e)
            | Self::StagingIntegrity(e) => Some(e),
            Self::RollbackFailed { publication, .. } => Some(publication),
            Self::StatePublishAndCleanup { publication, .. } => Some(publication),
            Self::PrimaryAndStagingCleanup { primary, .. } => Some(primary.as_ref()),
            _ => None,
        }
    }
}

#[derive(Debug)]
pub(crate) enum ProcessingDatabasePublicationWarning {
    StatePublication(Box<ProcessingDatabasePublicationError>),
    PostInstallFault(Box<ProcessingDatabasePublicationError>),
    CleanupFault {
        step: ProcessingDatabaseCleanupStep,
        source: Box<ProcessingDatabasePublicationError>,
    },
    DirectorySync { path: PathBuf, source: std::io::Error },
    BackupCleanup { path: PathBuf, source: std::io::Error },
    StateCleanup { path: PathBuf, source: std::io::Error },
    CleanupDirectorySync { path: PathBuf, source: std::io::Error },
}

impl fmt::Display for ProcessingDatabasePublicationWarning {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::StatePublication(source) => write!(
                formatter,
                "processing output was atomically installed but its recovery-state update needs reconciliation: {source}",
            ),
            Self::PostInstallFault(source) => write!(
                formatter,
                "processing output was atomically installed with a post-install diagnostic: {source}",
            ),
            Self::CleanupFault { step, source } => write!(
                formatter,
                "processing output was atomically installed but {step:?} cleanup was deferred: {source}",
            ),
            Self::DirectorySync { path, source } => write!(
                formatter,
                "processing output was atomically installed but directory sync failed at '{}': {source}",
                path.display(),
            ),
            Self::BackupCleanup { path, source } => write!(
                formatter,
                "processing publication committed but backup cleanup failed at '{}': {source}",
                path.display(),
            ),
            Self::StateCleanup { path, source } => write!(
                formatter,
                "processing publication committed but state cleanup failed at '{}': {source}",
                path.display(),
            ),
            Self::CleanupDirectorySync { path, source } => write!(
                formatter,
                "processing publication committed but cleanup directory sync failed at '{}': {source}",
                path.display(),
            ),
        }
    }
}

#[derive(Debug, Default)]
pub(crate) struct ProcessingDatabasePublicationOutcome {
    warnings: Vec<ProcessingDatabasePublicationWarning>,
}

impl ProcessingDatabasePublicationOutcome {
    pub(crate) fn warnings(&self) -> &[ProcessingDatabasePublicationWarning] {
        self.warnings.as_slice()
    }
}

pub(crate) trait ProcessingPublicationFaultInjector {
    fn at(&self, _phase: ProcessingDatabasePublicationPhase) -> Result<(), ProcessingDatabasePublicationError> {
        Ok(())
    }

    fn before_cleanup(
        &self,
        _step: ProcessingDatabaseCleanupStep,
    ) -> Result<(), ProcessingDatabasePublicationError> {
        Ok(())
    }
}

pub(crate) struct NoPublicationFaults;
impl ProcessingPublicationFaultInjector for NoPublicationFaults {}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub(crate) enum ProcessingDatabaseCleanupStep {
    InstalledDirectorySync,
    Backup,
    State,
    CleanupDirectorySync,
}

pub(crate) struct ProcessingStagedDatabase {
    canonical: PathBuf,
    staging: PathBuf,
    backup: PathBuf,
    state: PathBuf,
    parent: PathBuf,
    session_id: String,
    baseline_digest: Option<[u8; 32]>,
    lock_file: File,
    published: bool,
}

impl ProcessingStagedDatabase {
    pub(crate) fn prepare(
        canonical: &Path,
        session_id: &str,
    ) -> Result<(Self, rusqlite::Connection), ProcessingDatabasePublicationError> {
        let parent = canonical.parent().ok_or(ProcessingDatabasePublicationError::InvalidCanonicalPath)?.to_path_buf();
        let file_name = canonical.file_name().and_then(|n| n.to_str()).ok_or(ProcessingDatabasePublicationError::InvalidCanonicalPath)?;
        let lock_path = parent.join(format!(".{file_name}.lexicon-processing.lock"));
        let lock_file = OpenOptions::new().read(true).write(true).create(true).open(&lock_path)
            .map_err(ProcessingDatabasePublicationError::LockOpen)?;
        try_lock_exclusive(&lock_file).map_err(ProcessingDatabasePublicationError::AlreadyPublishing)?;

        let state = parent.join(format!(".{file_name}.lexicon-processing-state.json"));
        recover_interrupted_publication(&parent, &state, file_name)?;

        let nonce = uuid::Uuid::new_v4().simple().to_string();
        let staging = parent.join(format!(".{file_name}.staging-{session_id}-{nonce}"));
        let backup = parent.join(format!(".{file_name}.backup-{session_id}-{nonce}"));
        let baseline_digest = inspect_and_digest_canonical(canonical)?;

        let publication = Self {
            canonical: canonical.to_path_buf(), staging, backup, state, parent,
            session_id: session_id.to_string(), baseline_digest, lock_file, published: false,
        };
        publication.write_state(ProcessingDatabasePublicationPhase::Prepared)?;

        let preparation = (|| {
            let mut destination = rusqlite::Connection::open_with_flags(
                &publication.staging,
                rusqlite::OpenFlags::SQLITE_OPEN_READ_WRITE
                    | rusqlite::OpenFlags::SQLITE_OPEN_CREATE
                    | rusqlite::OpenFlags::SQLITE_OPEN_NO_MUTEX,
            ).map_err(ProcessingDatabasePublicationError::StagingCreate)?;
            if canonical.exists() {
                let source = rusqlite::Connection::open_with_flags(
                    canonical,
                    rusqlite::OpenFlags::SQLITE_OPEN_READ_ONLY | rusqlite::OpenFlags::SQLITE_OPEN_NO_MUTEX,
                ).map_err(ProcessingDatabasePublicationError::StagingCreate)?;
                let backup_copy = rusqlite::backup::Backup::new(&source, &mut destination)
                    .map_err(ProcessingDatabasePublicationError::StagingBackup)?;
                backup_copy.run_to_completion(32, Duration::from_millis(0), None)
                    .map_err(ProcessingDatabasePublicationError::StagingBackup)?;
            }
            destination.execute_batch(
                "PRAGMA foreign_keys=ON; PRAGMA journal_mode=DELETE; PRAGMA synchronous=FULL; BEGIN IMMEDIATE;",
            ).map_err(ProcessingDatabasePublicationError::StagingConfigure)?;
            Ok(destination)
        })();
        match preparation {
            Ok(destination) => Ok((publication, destination)),
            Err(preparation) => match publication.abandon() {
                Ok(()) => Err(preparation),
                Err(cleanup) => Err(ProcessingDatabasePublicationError::PrimaryAndStagingCleanup {
                    primary: Box::new(preparation), cleanup: Box::new(cleanup),
                }),
            },
        }
    }

    pub(crate) fn staging_path(&self) -> &Path { &self.staging }
    pub(crate) fn canonical_path(&self) -> &Path { &self.canonical }

    pub(crate) fn verify_integrity(&self) -> Result<(), ProcessingDatabasePublicationError> {
        let connection = rusqlite::Connection::open_with_flags(
            &self.staging,
            rusqlite::OpenFlags::SQLITE_OPEN_READ_ONLY | rusqlite::OpenFlags::SQLITE_OPEN_NO_MUTEX,
        ).map_err(ProcessingDatabasePublicationError::StagingIntegrity)?;
        let outcome: String = connection.query_row("PRAGMA integrity_check;", [], |row| row.get(0))
            .map_err(ProcessingDatabasePublicationError::StagingIntegrity)?;
        if outcome != "ok" {
            return Err(ProcessingDatabasePublicationError::StagingIntegrityDisagreement(outcome));
        }
        Ok(())
    }

    pub(crate) fn abandon(mut self) -> Result<(), ProcessingDatabasePublicationError> {
        cleanup_staging_family(&self.staging)
            .map_err(ProcessingDatabasePublicationError::StagingCleanup)?;
        remove_regular_file_if_present(&self.backup)
            .map_err(ProcessingDatabasePublicationError::StagingCleanup)?;
        remove_regular_file_if_present(&self.state)
            .map_err(ProcessingDatabasePublicationError::StagingCleanup)?;
        sync_directory(&self.parent)
            .map_err(ProcessingDatabasePublicationError::StagingCleanup)?;
        self.published = true;
        Ok(())
    }

    pub(crate) fn publish(
        self,
    ) -> Result<ProcessingDatabasePublicationOutcome, ProcessingDatabasePublicationError> {
        self.publish_with_faults(&NoPublicationFaults)
    }

    pub(crate) fn publish_with_faults(
        mut self,
        faults: &dyn ProcessingPublicationFaultInjector,
    ) -> Result<ProcessingDatabasePublicationOutcome, ProcessingDatabasePublicationError> {
        sync_file(&self.staging).map_err(ProcessingDatabasePublicationError::StagingSync)?;
        if inspect_and_digest_canonical(&self.canonical)? != self.baseline_digest {
            return Err(ProcessingDatabasePublicationError::CanonicalChanged);
        }
        self.write_state(ProcessingDatabasePublicationPhase::Prepared)?;
        faults.at(ProcessingDatabasePublicationPhase::Prepared)?;

        let had_canonical = self.baseline_digest.is_some();
        atomic_replace_database(
            &self.staging,
            &self.canonical,
            had_canonical.then_some(self.backup.as_path()),
            faults,
        )?;

        // Atomic canonical replacement is the publication linearization
        // point. No later cleanup or durability diagnostic may turn the run
        // into a reported failure while leaving the new canonical visible.
        let mut warnings = Vec::new();
        if let Err(error) = faults.at(
            ProcessingDatabasePublicationPhase::CanonicalRenamedBeforeState,
        ) {
            warnings.push(ProcessingDatabasePublicationWarning::PostInstallFault(
                Box::new(error),
            ));
        }
        if let Err(error) = self.write_state(
            ProcessingDatabasePublicationPhase::CanonicalInstalled,
        ) {
            warnings.push(ProcessingDatabasePublicationWarning::StatePublication(
                Box::new(error),
            ));
        }
        if let Err(error) = faults.at(ProcessingDatabasePublicationPhase::CanonicalInstalled) {
            warnings.push(ProcessingDatabasePublicationWarning::PostInstallFault(
                Box::new(error),
            ));
        }

        let installed_directory_synced = match faults.before_cleanup(
            ProcessingDatabaseCleanupStep::InstalledDirectorySync,
        ) {
            Err(source) => {
                warnings.push(ProcessingDatabasePublicationWarning::CleanupFault {
                    step: ProcessingDatabaseCleanupStep::InstalledDirectorySync,
                    source: Box::new(source),
                });
                false
            }
            Ok(()) => match sync_directory(&self.parent) {
                Ok(()) => true,
                Err(source) => {
                warnings.push(ProcessingDatabasePublicationWarning::DirectorySync {
                    path: self.parent.clone(),
                    source,
                });
                false
                }
            },
        };
        if installed_directory_synced {
            self.cleanup_after_commit(had_canonical, faults, &mut warnings);
        }
        self.published = true;
        Ok(ProcessingDatabasePublicationOutcome { warnings })
    }

    fn cleanup_after_commit(
        &self,
        had_canonical: bool,
        faults: &dyn ProcessingPublicationFaultInjector,
        warnings: &mut Vec<ProcessingDatabasePublicationWarning>,
    ) {
        if had_canonical {
            if let Err(source) = faults.before_cleanup(ProcessingDatabaseCleanupStep::Backup) {
                warnings.push(ProcessingDatabasePublicationWarning::CleanupFault {
                    step: ProcessingDatabaseCleanupStep::Backup,
                    source: Box::new(source),
                });
                return;
            }
            if let Err(source) = remove_regular_file_if_present(&self.backup) {
                warnings.push(ProcessingDatabasePublicationWarning::BackupCleanup {
                    path: self.backup.clone(),
                    source,
                });
                return;
            }
        }
        if let Err(source) = faults.before_cleanup(ProcessingDatabaseCleanupStep::State) {
            warnings.push(ProcessingDatabasePublicationWarning::CleanupFault {
                step: ProcessingDatabaseCleanupStep::State,
                source: Box::new(source),
            });
            return;
        }
        if let Err(source) = remove_regular_file_if_present(&self.state) {
            warnings.push(ProcessingDatabasePublicationWarning::StateCleanup {
                path: self.state.clone(),
                source,
            });
            return;
        }
        if let Err(source) = faults.before_cleanup(
            ProcessingDatabaseCleanupStep::CleanupDirectorySync,
        ) {
            warnings.push(ProcessingDatabasePublicationWarning::CleanupFault {
                step: ProcessingDatabaseCleanupStep::CleanupDirectorySync,
                source: Box::new(source),
            });
            return;
        }
        if let Err(source) = sync_directory(&self.parent) {
            warnings.push(ProcessingDatabasePublicationWarning::CleanupDirectorySync {
                path: self.parent.clone(),
                source,
            });
        }
    }

    fn write_state(&self, phase: ProcessingDatabasePublicationPhase) -> Result<(), ProcessingDatabasePublicationError> {
        let document = PublicationStateV1 {
            schema_version: STATE_SCHEMA_VERSION,
            session_id: self.session_id.clone(),
            canonical_file_name: file_name_string(&self.canonical)?,
            nonce: publication_nonce(&self.staging, &document_prefix(&self.canonical, &self.session_id, "staging")?)?,
            baseline_present: self.baseline_digest.is_some(),
            phase,
        };
        let bytes = serde_json::to_vec(&document).map_err(|_| ProcessingDatabasePublicationError::StateMalformed)?;
        let temporary = self.state.with_extension(format!("tmp-{}", uuid::Uuid::new_v4().simple()));
        let result = (|| {
            let mut file = OpenOptions::new().write(true).create_new(true).open(&temporary)?;
            file.write_all(&bytes)?;
            file.sync_all()?;
            atomic_replace_state(&temporary, &self.state)?;
            sync_directory(&self.parent)
        })();
        match result {
            Ok(()) => Ok(()),
            Err(publication) => match remove_regular_file_if_present(&temporary) {
                Ok(()) => Err(ProcessingDatabasePublicationError::StatePublish(publication)),
                Err(cleanup) => Err(ProcessingDatabasePublicationError::StatePublishAndCleanup { publication, cleanup }),
            },
        }
    }
}

impl Drop for ProcessingStagedDatabase {
    fn drop(&mut self) {
        if !self.published { let _ = fs::remove_file(&self.staging); }
        let _ = unlock_file(&self.lock_file);
    }
}

fn file_name_string(path: &Path) -> Result<String, ProcessingDatabasePublicationError> {
    path.file_name().and_then(|n| n.to_str()).map(ToOwned::to_owned)
        .ok_or(ProcessingDatabasePublicationError::InvalidCanonicalPath)
}

fn inspect_and_digest_canonical(path: &Path) -> Result<Option<[u8; 32]>, ProcessingDatabasePublicationError> {
    let metadata = match fs::symlink_metadata(path) {
        Ok(m) => m,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(None),
        Err(e) => return Err(ProcessingDatabasePublicationError::CanonicalInspect(e)),
    };
    if metadata.file_type().is_symlink() { return Err(ProcessingDatabasePublicationError::CanonicalSymlink); }
    if !metadata.is_file() { return Err(ProcessingDatabasePublicationError::CanonicalNotRegular); }
    let mut file = File::open(path).map_err(ProcessingDatabasePublicationError::CanonicalRead)?;
    let mut hash = Sha256::new();
    let mut buffer = [0u8; 64 * 1024];
    loop {
        let count = file.read(&mut buffer).map_err(ProcessingDatabasePublicationError::CanonicalRead)?;
        if count == 0 { break; }
        hash.update(&buffer[..count]);
    }
    Ok(Some(hash.finalize().into()))
}

fn recover_interrupted_publication(parent: &Path, state_path: &Path, expected_canonical: &str) -> Result<(), ProcessingDatabasePublicationError> {
    cleanup_state_temporaries(parent, state_path)?;
    let metadata = match fs::symlink_metadata(state_path) {
        Ok(m) => m,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => return Ok(()),
        Err(e) => return Err(ProcessingDatabasePublicationError::StateInspect(e)),
    };
    if !metadata.is_file() || metadata.len() > STATE_LIMIT { return Err(ProcessingDatabasePublicationError::StateMalformed); }
    let bytes = fs::read(state_path).map_err(ProcessingDatabasePublicationError::StateInspect)?;
    let state: PublicationStateV1 = serde_json::from_slice(&bytes).map_err(|_| ProcessingDatabasePublicationError::StateMalformed)?;
    if state.schema_version != STATE_SCHEMA_VERSION || state.canonical_file_name != expected_canonical
        || state.session_id.is_empty() || state.session_id.contains('/') || state.session_id.contains('\\')
        || uuid::Uuid::parse_str(&state.nonce).is_err() {
        return Err(ProcessingDatabasePublicationError::StateMalformed);
    }
    let canonical = parent.join(&state.canonical_file_name);
    let staging = parent.join(format!(".{}.staging-{}-{}", state.canonical_file_name, state.session_id, state.nonce));
    let backup = parent.join(format!(".{}.backup-{}-{}", state.canonical_file_name, state.session_id, state.nonce));
    match state.phase {
        ProcessingDatabasePublicationPhase::Prepared => {
            // Atomic replacement may have completed immediately before a crash and
            // before the phase record advanced. A replacement backup (or, for a new
            // canonical, the newly present canonical) proves that roll-forward case.
            let replacement_happened = if state.baseline_present {
                backup.exists() && !staging.exists() && canonical.exists()
            } else {
                canonical.exists() && !staging.exists()
            };
            if !replacement_happened {
                if state.baseline_present && !canonical.exists() {
                    return Err(ProcessingDatabasePublicationError::StateMalformed);
                }
                cleanup_staging_family(&staging).map_err(ProcessingDatabasePublicationError::Recovery)?;
            }
            remove_regular_file_if_present(&backup).map_err(ProcessingDatabasePublicationError::Recovery)?;
        }
        ProcessingDatabasePublicationPhase::BackupLinked
        | ProcessingDatabasePublicationPhase::CanonicalRenamedBeforeState => return Err(ProcessingDatabasePublicationError::StateMalformed),
        ProcessingDatabasePublicationPhase::CanonicalInstalled => {
            if !canonical.is_file() { return Err(ProcessingDatabasePublicationError::StateMalformed); }
            remove_regular_file_if_present(&backup).map_err(ProcessingDatabasePublicationError::Recovery)?;
            cleanup_staging_family(&staging).map_err(ProcessingDatabasePublicationError::Recovery)?;
        }
    }
    fs::remove_file(state_path).map_err(ProcessingDatabasePublicationError::Recovery)?;
    sync_directory(parent).map_err(ProcessingDatabasePublicationError::Recovery)
}

fn cleanup_state_temporaries(parent: &Path, state_path: &Path) -> Result<(), ProcessingDatabasePublicationError> {
    let state_name = state_path.file_name().and_then(|name| name.to_str())
        .ok_or(ProcessingDatabasePublicationError::StateMalformed)?;
    let stem = state_name.strip_suffix(".json").ok_or(ProcessingDatabasePublicationError::StateMalformed)?;
    let prefix = format!("{stem}.tmp-");
    let mut removed = false;
    for entry in fs::read_dir(parent).map_err(ProcessingDatabasePublicationError::StateInspect)? {
        let entry = entry.map_err(ProcessingDatabasePublicationError::StateInspect)?;
        let name = entry.file_name();
        let Some(name) = name.to_str() else { continue };
        let Some(nonce) = name.strip_prefix(&prefix) else { continue };
        if uuid::Uuid::parse_str(nonce).is_err() {
            return Err(ProcessingDatabasePublicationError::StateMalformed);
        }
        remove_regular_file_if_present(&entry.path()).map_err(ProcessingDatabasePublicationError::Recovery)?;
        removed = true;
    }
    if removed { sync_directory(parent).map_err(ProcessingDatabasePublicationError::Recovery)?; }
    Ok(())
}

#[cfg(not(windows))]
fn sync_file(path: &Path) -> std::io::Result<()> { File::open(path)?.sync_all() }

#[cfg(windows)]
fn sync_file(path: &Path) -> std::io::Result<()> {
    // FlushFileBuffers requires a handle opened with GENERIC_WRITE.
    OpenOptions::new().read(true).write(true).open(path)?.sync_all()
}

#[cfg(unix)]
fn try_lock_exclusive(file: &File) -> std::io::Result<()> {
    use std::os::fd::AsRawFd;
    let result = unsafe { libc::flock(file.as_raw_fd(), libc::LOCK_EX | libc::LOCK_NB) };
    if result == 0 { Ok(()) } else { Err(std::io::Error::last_os_error()) }
}

#[cfg(unix)]
fn unlock_file(file: &File) -> std::io::Result<()> {
    use std::os::fd::AsRawFd;
    let result = unsafe { libc::flock(file.as_raw_fd(), libc::LOCK_UN) };
    if result == 0 { Ok(()) } else { Err(std::io::Error::last_os_error()) }
}

#[cfg(windows)]
fn try_lock_exclusive(file: &File) -> std::io::Result<()> {
    use std::mem::zeroed;
    use std::os::windows::io::AsRawHandle;
    use windows_sys::Win32::Storage::FileSystem::{LockFileEx, LOCKFILE_EXCLUSIVE_LOCK, LOCKFILE_FAIL_IMMEDIATELY};
    let mut overlapped = unsafe { zeroed() };
    let ok = unsafe { LockFileEx(file.as_raw_handle() as _, LOCKFILE_EXCLUSIVE_LOCK | LOCKFILE_FAIL_IMMEDIATELY, 0, u32::MAX, u32::MAX, &mut overlapped) };
    if ok == 0 { Err(std::io::Error::last_os_error()) } else { Ok(()) }
}

#[cfg(windows)]
fn unlock_file(file: &File) -> std::io::Result<()> {
    use std::mem::zeroed;
    use std::os::windows::io::AsRawHandle;
    use windows_sys::Win32::Storage::FileSystem::UnlockFileEx;
    let mut overlapped = unsafe { zeroed() };
    let ok = unsafe { UnlockFileEx(file.as_raw_handle() as _, 0, u32::MAX, u32::MAX, &mut overlapped) };
    if ok == 0 { Err(std::io::Error::last_os_error()) } else { Ok(()) }
}

fn document_prefix(canonical: &Path, session: &str, kind: &str) -> Result<String, ProcessingDatabasePublicationError> {
    Ok(format!(".{}.{kind}-{session}-", file_name_string(canonical)?))
}

fn publication_nonce(path: &Path, prefix: &str) -> Result<String, ProcessingDatabasePublicationError> {
    let name = file_name_string(path)?;
    let nonce = name.strip_prefix(prefix).ok_or(ProcessingDatabasePublicationError::StateMalformed)?;
    uuid::Uuid::parse_str(nonce).map_err(|_| ProcessingDatabasePublicationError::StateMalformed)?;
    Ok(nonce.to_string())
}

fn remove_regular_file_if_present(path: &Path) -> std::io::Result<()> {
    match fs::symlink_metadata(path) {
        Ok(metadata) if metadata.is_file() && !metadata.file_type().is_symlink() => fs::remove_file(path),
        Ok(_) => Err(std::io::Error::new(std::io::ErrorKind::InvalidData, "managed cleanup target is not a regular file")),
        Err(error) if error.kind() == std::io::ErrorKind::NotFound => Ok(()),
        Err(error) => Err(error),
    }
}

fn sqlite_sidecar_path(database: &Path, suffix: &str) -> PathBuf {
    let mut value = database.as_os_str().to_os_string();
    value.push(suffix);
    PathBuf::from(value)
}

fn cleanup_staging_family(staging: &Path) -> std::io::Result<()> {
    remove_regular_file_if_present(staging)?;
    for suffix in ["-journal", "-wal", "-shm"] {
        remove_regular_file_if_present(&sqlite_sidecar_path(staging, suffix))?;
    }
    Ok(())
}

#[cfg(unix)]
fn atomic_replace_database(
    staging: &Path,
    canonical: &Path,
    backup: Option<&Path>,
    faults: &dyn ProcessingPublicationFaultInjector,
) -> Result<(), ProcessingDatabasePublicationError> {
    if let Some(backup) = backup {
        fs::hard_link(canonical, backup).map_err(ProcessingDatabasePublicationError::BackupInstall)?;
        faults.at(ProcessingDatabasePublicationPhase::BackupLinked)?;
    }
    if let Err(error) = fs::rename(staging, canonical) {
        if let Some(backup) = backup {
            if let Err(rollback) = remove_regular_file_if_present(backup) {
                return Err(ProcessingDatabasePublicationError::RollbackFailed { publication: error, rollback });
            }
        }
        return Err(ProcessingDatabasePublicationError::CanonicalInstall(error));
    }
    Ok(())
}

#[cfg(windows)]
fn atomic_replace_database(
    staging: &Path,
    canonical: &Path,
    backup: Option<&Path>,
    _faults: &dyn ProcessingPublicationFaultInjector,
) -> Result<(), ProcessingDatabasePublicationError> {
    use std::os::windows::ffi::OsStrExt;
    use windows_sys::Win32::Storage::FileSystem::{MoveFileExW, ReplaceFileW, MOVEFILE_REPLACE_EXISTING, MOVEFILE_WRITE_THROUGH, REPLACEFILE_WRITE_THROUGH};
    fn wide(path: &Path) -> Vec<u16> { path.as_os_str().encode_wide().chain(Some(0)).collect() }
    let staging_w = wide(staging); let canonical_w = wide(canonical);
    let ok = if let Some(backup) = backup {
        let backup_w = wide(backup);
        unsafe {
            ReplaceFileW(
                canonical_w.as_ptr(),
                staging_w.as_ptr(),
                backup_w.as_ptr(),
                REPLACEFILE_WRITE_THROUGH,
                std::ptr::null(),
                std::ptr::null(),
            )
        }
    } else {
        unsafe { MoveFileExW(staging_w.as_ptr(), canonical_w.as_ptr(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH) }
    };
    if ok == 0 {
        Err(ProcessingDatabasePublicationError::CanonicalInstall(std::io::Error::last_os_error()))
    } else {
        Ok(())
    }
}

#[cfg(unix)]
fn atomic_replace_state(staging: &Path, state: &Path) -> std::io::Result<()> { fs::rename(staging, state) }

#[cfg(windows)]
fn atomic_replace_state(staging: &Path, state: &Path) -> std::io::Result<()> {
    use std::os::windows::ffi::OsStrExt;
    use windows_sys::Win32::Storage::FileSystem::{MoveFileExW, MOVEFILE_REPLACE_EXISTING, MOVEFILE_WRITE_THROUGH};
    let from: Vec<u16> = staging.as_os_str().encode_wide().chain(Some(0)).collect();
    let to: Vec<u16> = state.as_os_str().encode_wide().chain(Some(0)).collect();
    let ok = unsafe { MoveFileExW(from.as_ptr(), to.as_ptr(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH) };
    if ok == 0 { Err(std::io::Error::last_os_error()) } else { Ok(()) }
}

#[cfg(unix)]
fn sync_directory(path: &Path) -> std::io::Result<()> { File::open(path)?.sync_all() }

#[cfg(windows)]
fn sync_directory(_path: &Path) -> std::io::Result<()> {
    // Windows has no portable directory-fsync analogue: FlushFileBuffers requires
    // GENERIC_WRITE and does not flush directory metadata. Every publication rename
    // above therefore uses MOVEFILE_WRITE_THROUGH or REPLACEFILE_WRITE_THROUGH.
    // Cleanup is idempotent and bounded by the durable state record, so a crash before
    // cleanup is recovered on the next locked prepare rather than treated as success.
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[cfg(unix)]
    #[test]
    fn staging_cleanup_preserves_native_non_utf8_sidecar_paths() {
        use std::os::unix::ffi::OsStringExt;

        let root = tempfile::tempdir().unwrap();
        let native_parent = root.path().join(std::ffi::OsString::from_vec(vec![
            b'n', b'a', b't', b'i', b'v', b'e', b'-', 0xff,
        ]));
        fs::create_dir_all(&native_parent).unwrap();
        let staging = native_parent.join("source.sqlite3");
        fs::write(&staging, b"database").unwrap();
        for suffix in ["-journal", "-wal", "-shm"] {
            fs::write(sqlite_sidecar_path(&staging, suffix), b"sidecar").unwrap();
        }

        let lossy_sentinel = PathBuf::from(format!("{}-wal", staging.to_string_lossy()));
        assert_ne!(lossy_sentinel, sqlite_sidecar_path(&staging, "-wal"));
        fs::create_dir_all(lossy_sentinel.parent().unwrap()).unwrap();
        fs::write(&lossy_sentinel, b"unrelated").unwrap();

        cleanup_staging_family(&staging).unwrap();

        assert!(!staging.exists());
        for suffix in ["-journal", "-wal", "-shm"] {
            assert!(!sqlite_sidecar_path(&staging, suffix).exists());
        }
        assert_eq!(fs::read(lossy_sentinel).unwrap(), b"unrelated");
    }

    struct FailAt(ProcessingDatabasePublicationPhase);
    impl ProcessingPublicationFaultInjector for FailAt {
        fn at(&self, phase: ProcessingDatabasePublicationPhase) -> Result<(), ProcessingDatabasePublicationError> {
            if phase == self.0 { Err(ProcessingDatabasePublicationError::Injected) } else { Ok(()) }
        }
    }

    struct FailCleanupAt(ProcessingDatabaseCleanupStep);
    impl ProcessingPublicationFaultInjector for FailCleanupAt {
        fn before_cleanup(
            &self,
            step: ProcessingDatabaseCleanupStep,
        ) -> Result<(), ProcessingDatabasePublicationError> {
            if step == self.0 {
                Err(ProcessingDatabasePublicationError::Injected)
            } else {
                Ok(())
            }
        }
    }

    struct AbortAt(ProcessingDatabasePublicationPhase);
    impl ProcessingPublicationFaultInjector for AbortAt {
        fn at(&self, phase: ProcessingDatabasePublicationPhase) -> Result<(), ProcessingDatabasePublicationError> {
            if phase == self.0 { std::process::abort(); }
            Ok(())
        }
    }

    #[test]
    #[ignore = "subprocess crash helper"]
    fn processing_publication_crash_child() {
        let canonical = PathBuf::from(std::env::var_os("LEXICON_TEST_PROCESSING_CANONICAL").unwrap());
        let phase_text = std::env::var("LEXICON_TEST_PROCESSING_CRASH_PHASE").unwrap();
        let phase = match phase_text.as_str() {
            "transaction_open" => None,
            "prepared" => Some(ProcessingDatabasePublicationPhase::Prepared),
            "backup_linked" => Some(ProcessingDatabasePublicationPhase::BackupLinked),
            "canonical_renamed_before_state" => Some(ProcessingDatabasePublicationPhase::CanonicalRenamedBeforeState),
            "canonical_installed" => Some(ProcessingDatabasePublicationPhase::CanonicalInstalled),
            other => panic!("unknown crash phase: {other}"),
        };
        let (publication, database) = ProcessingStagedDatabase::prepare(&canonical, "crash-session").unwrap();
        database.execute("INSERT INTO values_v1(value) VALUES ('child')", []).unwrap();
        if phase.is_none() { std::process::abort(); }
        database.execute_batch("COMMIT;").unwrap();
        drop(database);
        let _ = publication.publish_with_faults(&AbortAt(phase.unwrap()));
        panic!("abort fault did not fire");
    }

    fn seed(path: &Path, value: &str) {
        let database = rusqlite::Connection::open(path).unwrap();
        database.execute_batch("CREATE TABLE values_v1(value TEXT NOT NULL);").unwrap();
        database.execute("INSERT INTO values_v1(value) VALUES (?1)", [value]).unwrap();
        drop(database);
        sync_file(path).unwrap();
    }

    fn values(path: &Path) -> Vec<String> {
        let database = rusqlite::Connection::open_with_flags(path, rusqlite::OpenFlags::SQLITE_OPEN_READ_ONLY).unwrap();
        let mut statement = database.prepare("SELECT value FROM values_v1 ORDER BY rowid").unwrap();
        statement.query_map([], |row| row.get(0)).unwrap().map(Result::unwrap).collect()
    }

    #[test]
    fn handler_failure_abandons_staging_and_preserves_canonical_bytes() {
        let root = tempfile::tempdir().unwrap();
        let canonical = root.path().join("source.sqlite3");
        seed(&canonical, "prior");
        let before = fs::read(&canonical).unwrap();
        let (publication, database) = ProcessingStagedDatabase::prepare(&canonical, "session-a").unwrap();
        database.execute("INSERT INTO values_v1(value) VALUES ('unpublished')", []).unwrap();
        database.execute_batch("ROLLBACK;").unwrap();
        drop(database);
        publication.abandon().unwrap();
        assert_eq!(fs::read(&canonical).unwrap(), before);
        assert_eq!(values(&canonical), ["prior"]);
    }

    #[test]
    fn successful_publication_replaces_canonical_with_committed_staging_database() {
        let root = tempfile::tempdir().unwrap();
        let canonical = root.path().join("source.sqlite3");
        seed(&canonical, "prior");
        let (publication, database) = ProcessingStagedDatabase::prepare(&canonical, "session-b").unwrap();
        database.execute("INSERT INTO values_v1(value) VALUES ('next')", []).unwrap();
        database.execute_batch("COMMIT;").unwrap();
        drop(database);
        publication.publish().unwrap();
        assert_eq!(values(&canonical), ["prior", "next"]);
    }

    #[test]
    fn preinstallation_fault_preserves_exact_prior_canonical_bytes() {
        let root = tempfile::tempdir().unwrap();
        let canonical = root.path().join("source.sqlite3");
        seed(&canonical, "prior");
        let before = fs::read(&canonical).unwrap();
        let (publication, database) = ProcessingStagedDatabase::prepare(&canonical, "session-c").unwrap();
        database.execute("INSERT INTO values_v1(value) VALUES ('next')", []).unwrap();
        database.execute_batch("COMMIT;").unwrap();
        drop(database);
        let error = publication.publish_with_faults(&FailAt(ProcessingDatabasePublicationPhase::Prepared)).unwrap_err();
        assert!(matches!(error, ProcessingDatabasePublicationError::Injected));
        assert_eq!(fs::read(&canonical).unwrap(), before);
    }

    #[test]
    fn postinstall_fault_returns_success_warning_and_keeps_new_database() {
        let root = tempfile::tempdir().unwrap();
        let canonical = root.path().join("source.sqlite3");
        seed(&canonical, "prior");
        let (publication, database) = ProcessingStagedDatabase::prepare(&canonical, "session-d").unwrap();
        database.execute("INSERT INTO values_v1(value) VALUES ('published')", []).unwrap();
        database.execute_batch("COMMIT;").unwrap();
        drop(database);
        let outcome = publication
            .publish_with_faults(&FailAt(
                ProcessingDatabasePublicationPhase::CanonicalInstalled,
            ))
            .unwrap();
        assert!(outcome.warnings().iter().any(|warning| matches!(
            warning,
            ProcessingDatabasePublicationWarning::PostInstallFault(_)
        )));
        assert_eq!(values(&canonical), ["prior", "published"]);

        let (recovered, database) = ProcessingStagedDatabase::prepare(&canonical, "session-e").unwrap();
        database.execute_batch("ROLLBACK;").unwrap();
        drop(database);
        recovered.abandon().unwrap();
        assert_eq!(values(&canonical), ["prior", "published"]);
    }

    #[test]
    fn postcommit_directory_sync_warning_retains_recoverable_state() {
        let root = tempfile::tempdir().unwrap();
        let canonical = root.path().join("source.sqlite3");
        seed(&canonical, "prior");
        let (publication, database) =
            ProcessingStagedDatabase::prepare(&canonical, "session-sync-warning").unwrap();
        let state = publication.state.clone();
        let backup = publication.backup.clone();
        database
            .execute("INSERT INTO values_v1(value) VALUES ('published')", [])
            .unwrap();
        database.execute_batch("COMMIT;").unwrap();
        drop(database);

        let outcome = publication
            .publish_with_faults(&FailCleanupAt(
                ProcessingDatabaseCleanupStep::InstalledDirectorySync,
            ))
            .unwrap();
        assert!(outcome.warnings().iter().any(|warning| matches!(
            warning,
            ProcessingDatabasePublicationWarning::CleanupFault {
                step: ProcessingDatabaseCleanupStep::InstalledDirectorySync,
                ..
            }
        )));
        assert!(state.is_file());
        assert!(backup.is_file());
        assert_eq!(values(&canonical), ["prior", "published"]);

        let (recovered, database) =
            ProcessingStagedDatabase::prepare(&canonical, "session-after-sync-warning").unwrap();
        database.execute_batch("ROLLBACK;").unwrap();
        drop(database);
        recovered.abandon().unwrap();
        assert!(!state.exists());
        assert!(!backup.exists());
        assert_eq!(values(&canonical), ["prior", "published"]);
    }

    #[test]
    fn postcommit_backup_cleanup_failure_is_success_and_recovers_cleanup() {
        let root = tempfile::tempdir().unwrap();
        let canonical = root.path().join("source.sqlite3");
        seed(&canonical, "prior");
        let (publication, database) =
            ProcessingStagedDatabase::prepare(&canonical, "session-cleanup-warning").unwrap();
        let state = publication.state.clone();
        let backup = publication.backup.clone();
        database
            .execute("INSERT INTO values_v1(value) VALUES ('published')", [])
            .unwrap();
        database.execute_batch("COMMIT;").unwrap();
        drop(database);

        let outcome = publication
            .publish_with_faults(&FailCleanupAt(ProcessingDatabaseCleanupStep::Backup))
            .unwrap();
        assert!(outcome.warnings().iter().any(|warning| matches!(
            warning,
            ProcessingDatabasePublicationWarning::CleanupFault {
                step: ProcessingDatabaseCleanupStep::Backup,
                ..
            }
        )));
        assert!(state.is_file());
        assert!(backup.is_file());
        assert_eq!(values(&canonical), ["prior", "published"]);

        let (recovered, database) = ProcessingStagedDatabase::prepare(
            &canonical,
            "session-after-cleanup-warning",
        )
        .unwrap();
        database.execute_batch("ROLLBACK;").unwrap();
        drop(database);
        recovered.abandon().unwrap();
        assert!(!state.exists());
        assert!(!backup.exists());
        assert_eq!(values(&canonical), ["prior", "published"]);
    }

    #[test]
    fn postcommit_state_cleanup_failure_is_success_and_recovers_cleanup() {
        let root = tempfile::tempdir().unwrap();
        let canonical = root.path().join("source.sqlite3");
        seed(&canonical, "prior");
        let (publication, database) =
            ProcessingStagedDatabase::prepare(&canonical, "session-state-warning").unwrap();
        let state = publication.state.clone();
        let backup = publication.backup.clone();
        database
            .execute("INSERT INTO values_v1(value) VALUES ('published')", [])
            .unwrap();
        database.execute_batch("COMMIT;").unwrap();
        drop(database);

        let outcome = publication
            .publish_with_faults(&FailCleanupAt(ProcessingDatabaseCleanupStep::State))
            .unwrap();
        assert!(outcome.warnings().iter().any(|warning| matches!(
            warning,
            ProcessingDatabasePublicationWarning::CleanupFault {
                step: ProcessingDatabaseCleanupStep::State,
                ..
            }
        )));
        assert!(state.is_file());
        assert!(!backup.exists());
        assert_eq!(values(&canonical), ["prior", "published"]);

        let (recovered, database) = ProcessingStagedDatabase::prepare(
            &canonical,
            "session-after-state-warning",
        )
        .unwrap();
        database.execute_batch("ROLLBACK;").unwrap();
        drop(database);
        recovered.abandon().unwrap();
        assert!(!state.exists());
        assert_eq!(values(&canonical), ["prior", "published"]);
    }

    #[test]
    fn postcommit_cleanup_sync_failure_is_success_and_keeps_new_database() {
        let root = tempfile::tempdir().unwrap();
        let canonical = root.path().join("source.sqlite3");
        seed(&canonical, "prior");
        let (publication, database) =
            ProcessingStagedDatabase::prepare(&canonical, "session-cleanup-sync-warning").unwrap();
        let state = publication.state.clone();
        let backup = publication.backup.clone();
        database
            .execute("INSERT INTO values_v1(value) VALUES ('published')", [])
            .unwrap();
        database.execute_batch("COMMIT;").unwrap();
        drop(database);

        let outcome = publication
            .publish_with_faults(&FailCleanupAt(
                ProcessingDatabaseCleanupStep::CleanupDirectorySync,
            ))
            .unwrap();
        assert!(outcome.warnings().iter().any(|warning| matches!(
            warning,
            ProcessingDatabasePublicationWarning::CleanupFault {
                step: ProcessingDatabaseCleanupStep::CleanupDirectorySync,
                ..
            }
        )));
        assert!(!state.exists());
        assert!(!backup.exists());
        assert_eq!(values(&canonical), ["prior", "published"]);
    }

    #[test]
    fn malformed_recovery_state_cannot_name_or_delete_an_unrelated_sibling() {
        let root = tempfile::tempdir().unwrap();
        let canonical = root.path().join("source.sqlite3");
        seed(&canonical, "prior");
        let unrelated = root.path().join("keep.txt");
        fs::write(&unrelated, b"keep").unwrap();
        let state = root.path().join(".source.sqlite3.lexicon-processing-state.json");
        fs::write(&state, br#"{"schema_version":1,"session_id":"s","canonical_file_name":"source.sqlite3","nonce":"../keep.txt","baseline_present":true,"phase":"prepared"}"#).unwrap();
        let error = match ProcessingStagedDatabase::prepare(&canonical, "session-f") {
            Ok(_) => panic!("malformed state must be rejected"),
            Err(error) => error,
        };
        assert!(matches!(error, ProcessingDatabasePublicationError::StateMalformed));
        assert_eq!(fs::read(&unrelated).unwrap(), b"keep");
    }

    #[test]
    fn bounded_state_temporary_is_removed_durably_before_new_allocation() {
        let root = tempfile::tempdir().unwrap();
        let canonical = root.path().join("source.sqlite3");
        seed(&canonical, "prior");
        let temporary = root.path().join(format!(
            ".source.sqlite3.lexicon-processing-state.tmp-{}",
            uuid::Uuid::new_v4().simple(),
        ));
        fs::write(&temporary, b"interrupted state publication").unwrap();
        let (publication, database) = ProcessingStagedDatabase::prepare(&canonical, "session-temp").unwrap();
        assert!(!temporary.exists());
        database.execute_batch("ROLLBACK;").unwrap();
        drop(database);
        publication.abandon().unwrap();
        assert_eq!(values(&canonical), ["prior"]);
    }

    #[cfg(windows)]
    #[test]
    fn windows_prepare_commit_and_write_through_replace_publishes_real_database() {
        let root = tempfile::tempdir().unwrap();
        let canonical = root.path().join("source.sqlite3");
        seed(&canonical, "prior");
        let (publication, database) = ProcessingStagedDatabase::prepare(
            &canonical, "windows-publication-session",
        ).unwrap();
        database.execute("INSERT INTO values_v1(value) VALUES ('windows')", []).unwrap();
        database.execute_batch("COMMIT;").unwrap();
        drop(database);
        publication.verify_integrity().unwrap();
        publication.publish().unwrap();
        assert_eq!(values(&canonical), ["prior", "windows"]);
    }

    #[test]
    fn real_subprocess_crash_before_install_preserves_prior_and_after_install_rolls_forward() {
        let mut cases = vec![
            ("transaction_open", vec!["prior"]),
            ("prepared", vec!["prior"]),
            ("canonical_renamed_before_state", vec!["prior", "child"]),
            ("canonical_installed", vec!["prior", "child"]),
        ];
        #[cfg(unix)]
        cases.insert(1, ("backup_linked", vec!["prior"]));
        for (phase, expected) in cases {
            let root = tempfile::tempdir().unwrap();
            let canonical = root.path().join("source.sqlite3");
            seed(&canonical, "prior");
            let status = std::process::Command::new(std::env::current_exe().unwrap())
                .arg("--ignored")
                .arg("--exact")
                .arg("processing::publication::tests::processing_publication_crash_child")
                .env("LEXICON_TEST_PROCESSING_CANONICAL", &canonical)
                .env("LEXICON_TEST_PROCESSING_CRASH_PHASE", phase)
                .status().unwrap();
            assert!(!status.success());

            let (recovery, database) = ProcessingStagedDatabase::prepare(&canonical, "recovery-session").unwrap();
            database.execute_batch("ROLLBACK;").unwrap();
            drop(database);
            recovery.abandon().unwrap();
            assert_eq!(values(&canonical), expected);
            let leftovers: Vec<String> = fs::read_dir(root.path()).unwrap()
                .map(|entry| entry.unwrap().file_name().to_string_lossy().into_owned())
                .filter(|name| name.contains(".staging-") || name.contains(".backup-") || name.contains("processing-state"))
                .collect();
            assert!(leftovers.is_empty(), "orphan publication files after {phase}: {leftovers:?}");
        }
    }
}
