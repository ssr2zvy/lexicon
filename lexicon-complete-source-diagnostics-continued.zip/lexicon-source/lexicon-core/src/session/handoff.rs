use hmac::{Hmac, Mac};
use serde::{Deserialize, Serialize};
use sha2::Sha256;

use crate::session::SessionLeaseIdentity;

pub const HANDOFF_SCHEMA_VERSION: u32 = 1;
pub const HANDOFF_TOKEN_BYTES: usize = 32;
pub const HANDOFF_DIGEST_BYTES: usize = 32;
const DOMAIN: &[u8] = b"lexicon-handoff-authority-v1";

#[derive(Eq, PartialEq)]
pub struct HandoffToken([u8; HANDOFF_TOKEN_BYTES]);

impl HandoffToken {
    pub fn generate() -> Result<Self, HandoffProtocolError> {
        let mut bytes = [0; HANDOFF_TOKEN_BYTES];
        getrandom::getrandom(&mut bytes)
            .map_err(|error| HandoffProtocolError::Randomness(error.to_string()))?;
        if bytes.iter().all(|byte| *byte == 0) {
            return Err(HandoffProtocolError::InvalidToken);
        }
        Ok(Self(bytes))
    }
    pub fn from_hex(value: &str) -> Result<Self, HandoffProtocolError> {
        if value.len() != HANDOFF_TOKEN_BYTES * 2
            || !value.bytes().all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
        {
            return Err(HandoffProtocolError::InvalidToken);
        }
        let mut bytes = [0; HANDOFF_TOKEN_BYTES];
        for (index, slot) in bytes.iter_mut().enumerate() {
            *slot = u8::from_str_radix(&value[index * 2..index * 2 + 2], 16)
                .map_err(|_| HandoffProtocolError::InvalidToken)?;
        }
        if bytes.iter().all(|byte| *byte == 0) {
            return Err(HandoffProtocolError::InvalidToken);
        }
        Ok(Self(bytes))
    }
    pub fn expose_hex_for_private_transport(&self) -> String {
        self.0.iter().map(|byte| format!("{byte:02x}")).collect()
    }
    pub fn digest(&self) -> HandoffTokenDigest {
        let mut mac = <Hmac<Sha256> as Mac>::new_from_slice(DOMAIN).expect("fixed HMAC key");
        mac.update(&self.0);
        let value = mac.finalize().into_bytes();
        let mut bytes = [0; HANDOFF_DIGEST_BYTES];
        bytes.copy_from_slice(&value);
        HandoffTokenDigest(bytes)
    }
}
impl Drop for HandoffToken { fn drop(&mut self) { self.0.fill(0); } }

#[derive(Clone, Copy, Debug, Eq, Hash, PartialEq, Serialize, Deserialize)]
#[serde(transparent)]
pub struct HandoffTokenDigest([u8; HANDOFF_DIGEST_BYTES]);
impl HandoffTokenDigest {
    pub fn matches(self, token: &HandoffToken) -> bool {
        let candidate = token.digest().0;
        self.0.iter().zip(candidate).fold(0u8, |difference, (left, right)| difference | (*left ^ right)) == 0
    }

    fn is_zero(self) -> bool {
        self.0.iter().all(|byte| *byte == 0)
    }
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct OperatorIdentityV1 { pub instance_nonce: String, pub process_id: u32 }

impl OperatorIdentityV1 {
    pub fn validate_reserved(&self) -> Result<(), HandoffProtocolError> {
        validate_nonce(&self.instance_nonce)
    }

    pub fn validate_claim(&self) -> Result<(), HandoffProtocolError> {
        self.validate_reserved()?;
        if self.process_id == 0 {
            return Err(HandoffProtocolError::OperatorMismatch);
        }
        Ok(())
    }
}

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(tag = "state", rename_all = "snake_case", deny_unknown_fields)]
pub enum HandoffAuthorityStateV1 {
    Reserved,
    Ready { ready_at_unix_nanos: u64 },
    Owned {
        owned_at_unix_nanos: u64,
        lease_identity: SessionLeaseIdentity,
    },
    Revoked { revoked_at_unix_nanos: u64, reason: HandoffRevocationReasonV1 },
}

#[derive(Clone, Copy, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum HandoffRevocationReasonV1 { Expired, OperatorExited, Timeout, InitiatorFailure }

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum HandoffFenceOutcome { Revoked, AlreadyOwned }

#[derive(Clone, Debug, Eq, PartialEq, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct HandoffAuthorityRecordV1 {
    pub schema_version: u32,
    pub session_id: String,
    pub epoch: u64,
    pub token_digest: HandoffTokenDigest,
    pub expected_operator: OperatorIdentityV1,
    pub expires_at_unix_nanos: u64,
    pub state: HandoffAuthorityStateV1,
}

pub struct HandoffClaimProof {
    pub session_id: String,
    pub epoch: u64,
    pub token: HandoffToken,
    pub operator: OperatorIdentityV1,
}

#[derive(Debug)]
pub enum HandoffProtocolError {
    Missing, InvalidToken, Randomness(String), Encoding(serde_json::Error), Decoding(serde_json::Error),
    Io(std::io::Error), WrongSchema(u32), SessionMismatch,
    EpochMismatch { expected: u64, actual: u64 }, OperatorMismatch, TokenMismatch,
    Expired, InvalidState, ReservedForSuccessor { epoch: u64 },
}
impl std::fmt::Display for HandoffProtocolError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Missing => f.write_str("handoff authority record is missing"),
            Self::InvalidToken => f.write_str("invalid private handoff token"),
            Self::Randomness(error) => write!(f, "operating-system CSPRNG failed: {error}"),
            Self::Encoding(e) => write!(f, "handoff encoding failed: {e}"),
            Self::Decoding(e) => write!(f, "handoff decoding failed: {e}"),
            Self::Io(e) => write!(f, "handoff I/O failed: {e}"),
            Self::WrongSchema(v) => write!(f, "unsupported handoff schema version {v}"),
            Self::SessionMismatch => f.write_str("handoff session identity mismatch"),
            Self::EpochMismatch { expected, actual } => write!(f, "stale handoff epoch {actual}; current epoch is {expected}"),
            Self::OperatorMismatch => f.write_str("handoff operator identity mismatch"),
            Self::TokenMismatch => f.write_str("handoff token mismatch"),
            Self::Expired => f.write_str("handoff reservation expired"),
            Self::InvalidState => f.write_str("handoff state transition is invalid"),
            Self::ReservedForSuccessor { epoch } => write!(f, "session is reserved for successor at epoch {epoch}"),
        }
    }
}
impl std::error::Error for HandoffProtocolError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self { Self::Encoding(e) | Self::Decoding(e) => Some(e), Self::Io(e) => Some(e), _ => None }
    }
}

pub fn generate_instance_nonce() -> Result<String, HandoffProtocolError> {
    let token = HandoffToken::generate()?;
    Ok(format!("op-{}", token.expose_hex_for_private_transport()))
}

pub(crate) fn validate_authority_record(
    record: &HandoffAuthorityRecordV1,
) -> Result<(), HandoffProtocolError> {
    if record.schema_version != HANDOFF_SCHEMA_VERSION {
        return Err(HandoffProtocolError::WrongSchema(record.schema_version));
    }
    if record.session_id.is_empty()
        || record.epoch == 0
        || record.expires_at_unix_nanos == 0
        || record.token_digest.is_zero()
    {
        return Err(HandoffProtocolError::InvalidState);
    }
    record.expected_operator.validate_reserved()?;
    match &record.state {
        HandoffAuthorityStateV1::Reserved => {
            if record.expected_operator.process_id != 0 {
                return Err(HandoffProtocolError::InvalidState);
            }
        }
        HandoffAuthorityStateV1::Ready { ready_at_unix_nanos } => {
            record.expected_operator.validate_claim()?;
            if *ready_at_unix_nanos == 0 {
                return Err(HandoffProtocolError::InvalidState);
            }
        }
        HandoffAuthorityStateV1::Owned { owned_at_unix_nanos, .. } => {
            record.expected_operator.validate_claim()?;
            if *owned_at_unix_nanos == 0 {
                return Err(HandoffProtocolError::InvalidState);
            }
        }
        HandoffAuthorityStateV1::Revoked { revoked_at_unix_nanos, .. } => {
            if *revoked_at_unix_nanos == 0 {
                return Err(HandoffProtocolError::InvalidState);
            }
        }
    }
    Ok(())
}

fn validate_nonce(value: &str) -> Result<(), HandoffProtocolError> {
    if value.is_empty() || value.len() > 128 || !value.bytes().all(|byte| byte.is_ascii_alphanumeric() || byte == b'-') {
        return Err(HandoffProtocolError::OperatorMismatch);
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn valid_record(state: HandoffAuthorityStateV1) -> HandoffAuthorityRecordV1 {
        HandoffAuthorityRecordV1 {
            schema_version: HANDOFF_SCHEMA_VERSION,
            session_id: "session".into(),
            epoch: 1,
            token_digest: HandoffToken::generate().unwrap().digest(),
            expected_operator: OperatorIdentityV1 {
                instance_nonce: "operator-nonce".into(),
                process_id: if matches!(&state, HandoffAuthorityStateV1::Reserved) { 0 } else { 7 },
            },
            expires_at_unix_nanos: 1,
            state,
        }
    }

    #[test]
    fn decode_validation_rejects_impossible_state_specific_values() {
        let mut reserved = valid_record(HandoffAuthorityStateV1::Reserved);
        reserved.expected_operator.process_id = 7;
        assert!(matches!(validate_authority_record(&reserved), Err(HandoffProtocolError::InvalidState)));

        for state in [
            HandoffAuthorityStateV1::Ready { ready_at_unix_nanos: 0 },
            HandoffAuthorityStateV1::Owned {
                owned_at_unix_nanos: 0,
                lease_identity: SessionLeaseIdentity::from_hex(&"11".repeat(32)).unwrap(),
            },
            HandoffAuthorityStateV1::Revoked {
                revoked_at_unix_nanos: 0,
                reason: HandoffRevocationReasonV1::Timeout,
            },
        ] {
            assert!(matches!(validate_authority_record(&valid_record(state)), Err(HandoffProtocolError::InvalidState)));
        }
    }

    #[test]
    fn private_token_transport_is_canonical_lowercase_and_nonzero() {
        assert!(matches!(
            HandoffToken::from_hex(&"A".repeat(HANDOFF_TOKEN_BYTES * 2)),
            Err(HandoffProtocolError::InvalidToken)
        ));
        assert!(matches!(
            HandoffToken::from_hex(&"0".repeat(HANDOFF_TOKEN_BYTES * 2)),
            Err(HandoffProtocolError::InvalidToken)
        ));
    }
}
