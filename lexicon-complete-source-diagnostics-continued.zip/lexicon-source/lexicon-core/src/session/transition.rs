use crate::session::error::SessionTransitionError;
use crate::session::model::{SessionState, SessionTransition};

/// Validate that transitioning from `current` state with `transition` is legal.
///
/// Allowed transitions:
/// - Prepared  → Running
/// - Prepared  → Failed
/// - Prepared  → Abandoned
/// - Running   → Succeeded
/// - Running   → Failed
/// - Failed    → Abandoned
///
/// All other transitions (including back to Prepared, repeated terminal transitions,
/// Failed → Running, Succeeded → *, Abandoned → *) are rejected.
pub(crate) fn validate_transition(
    current: SessionState,
    transition: &SessionTransition,
) -> Result<(), SessionTransitionError> {
    let target = transition.target_state();

    if current.is_terminal() && target != SessionState::Abandoned {
        if current == SessionState::Succeeded || current == SessionState::Abandoned {
            return Err(SessionTransitionError::TerminalStateReached { state: current });
        }
    }

    let allowed = match (current, target) {
        (SessionState::Prepared, SessionState::Running) => true,
        (SessionState::Prepared, SessionState::Failed) => true,
        (SessionState::Prepared, SessionState::Abandoned) => true,
        (SessionState::Running, SessionState::Succeeded) => true,
        (SessionState::Running, SessionState::Failed) => true,
        (SessionState::Failed, SessionState::Abandoned) => true,
        _ => false,
    };

    if !allowed {
        return Err(SessionTransitionError::InvalidTransition {
            from: current,
            to: target,
        });
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::session::{SafeSessionFailure, SessionFailureCode};

    #[test]
    fn specification_27_transition_table_is_exact() {
        let states = [
            SessionState::Prepared,
            SessionState::Running,
            SessionState::Succeeded,
            SessionState::Failed,
            SessionState::Abandoned,
        ];
        let transitions = [
            SessionTransition::ToRunning,
            SessionTransition::ToSucceeded,
            SessionTransition::ToFailed {
                failure: SafeSessionFailure::runtime_failure(
                    SessionFailureCode::SourceReturnedError,
                    None,
                ),
            },
            SessionTransition::ToAbandoned,
        ];

        for state in states {
            for transition in &transitions {
                let target = transition.target_state();
                let expected = matches!(
                    (state, target),
                    (SessionState::Prepared, SessionState::Running)
                        | (SessionState::Prepared, SessionState::Failed)
                        | (SessionState::Prepared, SessionState::Abandoned)
                        | (SessionState::Running, SessionState::Succeeded)
                        | (SessionState::Running, SessionState::Failed)
                        | (SessionState::Failed, SessionState::Abandoned)
                );
                assert_eq!(
                    validate_transition(state, transition).is_ok(),
                    expected,
                    "unexpected §27 transition result for {state:?} -> {target:?}",
                );
            }
        }
    }

    #[test]
    fn running_session_cannot_transition_directly_to_abandoned() {
        let error = validate_transition(
            SessionState::Running,
            &SessionTransition::ToAbandoned,
        )
        .unwrap_err();
        assert!(matches!(
            error,
            SessionTransitionError::InvalidTransition {
                from: SessionState::Running,
                to: SessionState::Abandoned,
            }
        ));
    }
}
