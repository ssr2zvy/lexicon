use std::fs::{File, OpenOptions};
use std::io::{Read, Seek, SeekFrom, Write};
use std::path::{Path, PathBuf};

use crate::session::error::SessionLeaseError;

/// An exclusive cross-process session lease backed by an operating-system file lock.
///
/// The lease is held as long as this value exists. Dropping the value releases the lock.
///
/// The lock file's mere existence is not treated as proof of active ownership;
/// the OS advisory lock is the ownership primitive.
pub struct SessionLease {
    file: File,
    path: PathBuf,
    identity: SessionLeaseIdentity,
}

#[derive(Clone, Eq, PartialEq)]
pub struct SessionLeaseIdentity([u8; 32]);

impl std::fmt::Debug for SessionLeaseIdentity {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        formatter.write_str("SessionLeaseIdentity([REDACTED])")
    }
}

impl SessionLeaseIdentity {
    fn generate() -> Result<Self, SessionLeaseError> {
        let mut bytes = [0u8; 32];
        getrandom::getrandom(&mut bytes).map_err(|error| {
            SessionLeaseError::Io(std::io::Error::other(format!("lease CSPRNG failed: {error}")))
        })?;
        if bytes.iter().all(|byte| *byte == 0) {
            return Err(SessionLeaseError::Io(std::io::Error::other(
                "lease CSPRNG returned an invalid all-zero identity",
            )));
        }
        Ok(Self(bytes))
    }

    pub fn from_hex(value: &str) -> Result<Self, SessionLeaseError> {
        if value.len() != 64
            || !value.bytes().all(|byte| byte.is_ascii_digit() || (b'a'..=b'f').contains(&byte))
        {
            return Err(SessionLeaseError::InvalidIdentity);
        }
        let mut bytes = [0u8; 32];
        for (index, slot) in bytes.iter_mut().enumerate() {
            *slot = u8::from_str_radix(&value[index * 2..index * 2 + 2], 16)
                .map_err(|_| SessionLeaseError::InvalidIdentity)?;
        }
        if bytes.iter().all(|byte| *byte == 0) {
            return Err(SessionLeaseError::InvalidIdentity);
        }
        Ok(Self(bytes))
    }

    pub fn expose_hex_for_private_transport(&self) -> String {
        self.0.iter().map(|byte| format!("{byte:02x}")).collect()
    }
}

impl serde::Serialize for SessionLeaseIdentity {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        serializer.serialize_str(&self.expose_hex_for_private_transport())
    }
}

impl<'de> serde::Deserialize<'de> for SessionLeaseIdentity {
    fn deserialize<D>(deserializer: D) -> Result<Self, D::Error>
    where
        D: serde::Deserializer<'de>,
    {
        let value = <String as serde::Deserialize>::deserialize(deserializer)?;
        Self::from_hex(&value).map_err(serde::de::Error::custom)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum SessionLeaseState {
    Available,
    Owned,
}

impl std::fmt::Debug for SessionLease {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("SessionLease")
            .field("path", &self.path)
            .finish_non_exhaustive()
    }
}

impl SessionLease {
    /// Attempt to acquire an exclusive non-blocking lease at `path`.
    ///
    /// Returns `Err(SessionLeaseError::AlreadyOwned)` if another process holds the lock.
    pub(crate) fn acquire(path: PathBuf) -> Result<Self, SessionLeaseError> {
        let file = OpenOptions::new()
            .read(true)
            .write(true)
            .create(true)
            .truncate(false)
            .open(&path)
            .map_err(SessionLeaseError::Io)?;

        try_lock_exclusive_nonblocking(&file).map_err(|e| match e {
            LockError::Contended => SessionLeaseError::AlreadyOwned,
            LockError::Io(io) => SessionLeaseError::Io(io),
        })?;

        let identity = SessionLeaseIdentity::generate()?;
        write_owner_record(&file, &identity)?;

        Ok(Self { file, path, identity })
    }

    pub fn inspect_session_lease(path: &Path) -> Result<SessionLeaseState, SessionLeaseError> {
        match SessionLease::acquire(path.to_path_buf()) {
            Ok(lease) => {
                drop(lease);
                Ok(SessionLeaseState::Available)
            }
            Err(SessionLeaseError::AlreadyOwned) => Ok(SessionLeaseState::Owned),
            Err(SessionLeaseError::ReservedForSuccessor { .. }) => Ok(SessionLeaseState::Owned),
            Err(err) => Err(err),
        }
    }

    /// Path to the lock file.
    pub fn path(&self) -> &std::path::Path {
        &self.path
    }

    pub fn identity(&self) -> &SessionLeaseIdentity {
        &self.identity
    }
}

/// Inspect the state of a session lease without permanently acquiring it.
///
/// Returns `Ok(SessionLeaseState::Available)` if the lock can be acquired
/// (no other process holds it), or `Ok(SessionLeaseState::Owned)` if another
/// process currently holds the lock.
pub fn inspect_session_lease(path: &Path) -> Result<SessionLeaseState, SessionLeaseError> {
    SessionLease::inspect_session_lease(path)
}

pub fn inspect_session_lease_identity(
    path: &Path,
) -> Result<Option<SessionLeaseIdentity>, SessionLeaseError> {
    match SessionLease::inspect_session_lease(path)? {
        SessionLeaseState::Available => Ok(None),
        SessionLeaseState::Owned => {
            let mut file = OpenOptions::new().read(true).open(path).map_err(SessionLeaseError::Io)?;
            let mut value = String::new();
            file.take(256).read_to_string(&mut value).map_err(SessionLeaseError::Io)?;
            let mut fields = value.trim_end().split(' ');
            if fields.next() != Some("v1") || fields.next().and_then(|pid| pid.parse::<u32>().ok()).filter(|pid| *pid != 0).is_none() {
                return Err(SessionLeaseError::InvalidIdentity);
            }
            let identity = fields.next().ok_or(SessionLeaseError::InvalidIdentity)?;
            if fields.next().is_some() { return Err(SessionLeaseError::InvalidIdentity); }
            SessionLeaseIdentity::from_hex(identity).map(Some)
        }
    }
}

impl Drop for SessionLease {
    fn drop(&mut self) {
        // The OS lock is released when the file descriptor is closed,
        // but we unlock explicitly for clarity.
        unlock(&self.file);
    }
}

// ---------------------------------------------------------------------------
// Platform-specific locking implementation
// ---------------------------------------------------------------------------

enum LockError {
    Contended,
    Io(std::io::Error),
}

// Windows byte-range locks are mandatory for overlapping reads. Keep the
// ownership lock outside the textual owner record so a supervised child can
// authenticate the live lease identity without acquiring the lease itself.
#[cfg(windows)]
const WINDOWS_LEASE_LOCK_OFFSET: u64 = 4096;
#[cfg(windows)]
const WINDOWS_LEASE_LOCK_LENGTH_LOW: u32 = 1;
#[cfg(windows)]
const WINDOWS_LEASE_LOCK_LENGTH_HIGH: u32 = 0;

#[cfg(windows)]
fn windows_lease_lock_overlapped() -> windows_sys::Win32::System::IO::OVERLAPPED {
    let mut overlapped: windows_sys::Win32::System::IO::OVERLAPPED =
        unsafe { std::mem::zeroed() };
    unsafe {
        overlapped.Anonymous.Anonymous.Offset = WINDOWS_LEASE_LOCK_OFFSET as u32;
        overlapped.Anonymous.Anonymous.OffsetHigh =
            (WINDOWS_LEASE_LOCK_OFFSET >> 32) as u32;
    }
    overlapped
}

#[cfg(unix)]
fn try_lock_exclusive_nonblocking(file: &File) -> Result<(), LockError> {
    use std::os::unix::io::AsRawFd;
    let fd = file.as_raw_fd();
    let result = unsafe { libc::flock(fd, libc::LOCK_EX | libc::LOCK_NB) };
    if result == 0 {
        return Ok(());
    }
    let err = std::io::Error::last_os_error();
    if err.raw_os_error() == Some(libc::EWOULDBLOCK) {
        return Err(LockError::Contended);
    }
    Err(LockError::Io(err))
}

#[cfg(windows)]
fn try_lock_exclusive_nonblocking(file: &File) -> Result<(), LockError> {
    use std::os::windows::io::AsRawHandle;
    use windows_sys::Win32::Foundation::HANDLE;
    use windows_sys::Win32::Storage::FileSystem::{
        LockFileEx, LOCKFILE_EXCLUSIVE_LOCK, LOCKFILE_FAIL_IMMEDIATELY,
    };

    let handle = file.as_raw_handle() as HANDLE;
    let mut overlapped = windows_lease_lock_overlapped();
    let ok = unsafe {
        LockFileEx(
            handle,
            LOCKFILE_EXCLUSIVE_LOCK | LOCKFILE_FAIL_IMMEDIATELY,
            0,
            WINDOWS_LEASE_LOCK_LENGTH_LOW,
            WINDOWS_LEASE_LOCK_LENGTH_HIGH,
            &mut overlapped,
        )
    };
    if ok != 0 {
        Ok(())
    } else {
        let err = std::io::Error::last_os_error();
        if err.raw_os_error() == Some(33) {
            // ERROR_LOCK_VIOLATION
            Err(LockError::Contended)
        } else {
            Err(LockError::Io(err))
        }
    }
}

#[cfg(not(any(unix, windows)))]
fn try_lock_exclusive_nonblocking(_file: &File) -> Result<(), LockError> {
    Err(LockError::Io(std::io::Error::new(
        std::io::ErrorKind::Unsupported,
        "file locking is not supported on this platform",
    )))
}

#[cfg(unix)]
fn unlock(file: &File) {
    use std::os::unix::io::AsRawFd;
    unsafe { libc::flock(file.as_raw_fd(), libc::LOCK_UN) };
}

#[cfg(windows)]
fn unlock(file: &File) {
    use std::os::windows::io::AsRawHandle;
    use windows_sys::Win32::Foundation::HANDLE;
    use windows_sys::Win32::Storage::FileSystem::UnlockFileEx;

    let handle = file.as_raw_handle() as HANDLE;
    let mut overlapped = windows_lease_lock_overlapped();
    unsafe {
        UnlockFileEx(
            handle,
            0,
            WINDOWS_LEASE_LOCK_LENGTH_LOW,
            WINDOWS_LEASE_LOCK_LENGTH_HIGH,
            &mut overlapped,
        )
    };
}

#[cfg(not(any(unix, windows)))]
fn unlock(_file: &File) {}

// ---------------------------------------------------------------------------
// PID diagnostic write
// ---------------------------------------------------------------------------

fn write_owner_record(
    mut file: &File,
    identity: &SessionLeaseIdentity,
) -> Result<(), SessionLeaseError> {
    let pid = std::process::id();
    let value = format!("v1 {pid} {}\n", identity.expose_hex_for_private_transport());
    file.seek(SeekFrom::Start(0)).map_err(SessionLeaseError::Io)?;
    file.write_all(value.as_bytes()).map_err(SessionLeaseError::Io)?;
    file.set_len(value.len() as u64).map_err(SessionLeaseError::Io)?;
    file.sync_all().map_err(SessionLeaseError::Io)
}

#[cfg(all(test, windows))]
mod windows_tests {
    use super::*;

    #[test]
    fn live_owner_record_is_readable_while_non_overlapping_lease_is_held() {
        let root = tempfile::tempdir().unwrap();
        let path = root.path().join("session.lease");
        let lease = SessionLease::acquire(path.clone()).unwrap();

        assert_eq!(
            inspect_session_lease_identity(&path).unwrap().as_ref(),
            Some(lease.identity())
        );
    }
}
