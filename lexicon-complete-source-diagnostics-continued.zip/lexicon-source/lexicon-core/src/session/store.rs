use std::fs;
use std::io::{self, Write};
use std::path::{Path, PathBuf};

use crate::session::error::{
    SessionDecodingError, SessionLeaseError, SessionStoreError,
};
use crate::session::lease::{SessionLease, SessionLeaseState, inspect_session_lease};
use crate::session::model::{
    NewSessionRecord, SafeSessionFailure, SessionClock, SessionIdentity, SessionOperation,
    SessionRecordV1, SessionState, SessionStatusV1, SessionTimestamp, SessionTransition,
    SystemClock, generate_session_id,
};
use crate::session::transition::validate_transition;
use crate::session::handoff::{
    HANDOFF_SCHEMA_VERSION, HandoffAuthorityRecordV1, HandoffAuthorityStateV1,
    HandoffClaimProof, HandoffFenceOutcome, HandoffProtocolError, HandoffRevocationReasonV1,
    HandoffToken, HandoffTokenDigest,
    OperatorIdentityV1, validate_authority_record,
};

// ---------------------------------------------------------------------------
// SessionOperationRoot
// ---------------------------------------------------------------------------

/// Validated path to an operation-level workspace root.
///
/// The root contains `sessions/` and `session_status.json`.
#[derive(Debug, Clone)]
pub struct SessionOperationRoot {
    path: PathBuf,
}

impl SessionOperationRoot {
    /// Construct a `SessionOperationRoot` from an existing directory path.
    ///
    /// The path must be absolute. The directory is not required to exist yet.
    pub fn new(path: PathBuf) -> Result<Self, SessionStoreError> {
        if path.is_relative() {
            return Err(SessionStoreError::Io(io::Error::new(
                io::ErrorKind::InvalidInput,
                "session operation root must be an absolute path",
            )));
        }
        Ok(Self { path })
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    /// `sessions/` directory.
    pub fn sessions_directory(&self) -> PathBuf {
        self.path.join("sessions")
    }

    /// `sessions/<session-id>/` directory.
    pub fn session_directory(&self, session: &SessionIdentity) -> PathBuf {
        self.sessions_directory().join(session.id())
    }

    /// `sessions/<session-id>/session.json`
    pub fn session_record_path(&self, session: &SessionIdentity) -> PathBuf {
        self.session_directory(session).join("session.json")
    }

    /// `sessions/<session-id>/session.lock`
    pub fn lease_path(&self, session: &SessionIdentity) -> PathBuf {
        self.session_directory(session).join("session.lock")
    }

    pub fn handoff_authority_path(&self, session: &SessionIdentity) -> PathBuf {
        self.session_directory(session).join("handoff_authority.json")
    }

    pub fn selection_lease_path(&self) -> PathBuf {
        self.path.join("session-selection.lock")
    }

    fn mutation_lease_path(&self) -> PathBuf {
        self.path.join("session-mutation.lock")
    }

    /// `session_status.json`
    pub fn status_path(&self) -> PathBuf {
        self.path.join("session_status.json")
    }
}

// ---------------------------------------------------------------------------
// PreparedSession
// ---------------------------------------------------------------------------

/// A session record in the `Prepared` state, returned after creation.
pub struct PreparedSession {
    record: SessionRecordV1,
    lease: SessionLease,
}

pub struct OperationSelectionLease {
    lease: SessionLease,
}

impl OperationSelectionLease {
    pub fn path(&self) -> &Path { self.lease.path() }
}

impl PreparedSession {
    pub fn record(&self) -> &SessionRecordV1 {
        &self.record
    }

    pub fn lease(&self) -> &SessionLease { &self.lease }

    pub fn into_owned_parts(self) -> (SessionRecordV1, SessionLease) {
        (self.record, self.lease)
    }
}

impl std::fmt::Debug for PreparedSession {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("PreparedSession")
            .field("session", self.record.session())
            .field("revision", &self.record.revision())
            .finish_non_exhaustive()
    }
}

// ---------------------------------------------------------------------------
// SessionStore
// ---------------------------------------------------------------------------

pub struct SessionStore {
    operation_root: SessionOperationRoot,
    clock: Box<dyn SessionClock>,
}

impl SessionStore {
    pub fn open(operation_root: SessionOperationRoot) -> Result<Self, SessionStoreError> {
        Ok(Self {
            operation_root,
            clock: Box::new(SystemClock),
        })
    }

    /// Read-only access to the validated operation root for this store.
    pub fn operation_root(&self) -> &SessionOperationRoot {
        &self.operation_root
    }

    #[cfg(test)]
    pub(crate) fn open_with_clock(
        operation_root: SessionOperationRoot,
        clock: Box<dyn SessionClock>,
    ) -> Result<Self, SessionStoreError> {
        Ok(Self { operation_root, clock })
    }

    // ------------------------------------------------------------------
    // Session creation
    // ------------------------------------------------------------------

    /// Create a new `Prepared` session record and write it to disk.
    ///
    /// Generates a new session identity and creates the session directory.
    pub fn create_prepared(
        &self,
        input: NewSessionRecord,
    ) -> Result<PreparedSession, SessionStoreError> {
        let selection = self.acquire_selection_lease()?;
        self.create_prepared_while_selected(input, &selection)
    }

    pub fn acquire_selection_lease(&self) -> Result<OperationSelectionLease, SessionStoreError> {
        fs::create_dir_all(self.operation_root.path())
            .map_err(SessionStoreError::DirectoryCreation)?;
        SessionLease::acquire(self.operation_root.selection_lease_path())
            .map(|lease| OperationSelectionLease { lease })
            .map_err(SessionStoreError::LeaseRequired)
    }

    pub fn create_prepared_while_selected(
        &self,
        input: NewSessionRecord,
        selection: &OperationSelectionLease,
    ) -> Result<PreparedSession, SessionStoreError> {
        if selection.path() != self.operation_root.selection_lease_path() {
            return Err(SessionStoreError::LeaseRequired(SessionLeaseError::InvalidIdentity));
        }
        let _mutation = self.acquire_mutation_lease()?;
        let session_id_str = generate_session_id().map_err(SessionStoreError::Io)?;
        let session = crate::runtime::invocation::SessionInvocationIdentity::new(&session_id_str)
            .map_err(|e| SessionStoreError::Io(io::Error::new(
                io::ErrorKind::InvalidData,
                format!("generated invalid session id: {e}"),
            )))?;

        let record = SessionRecordV1::new_prepared(input, session, self.clock.as_ref());

        let sessions_dir = self.operation_root.sessions_directory();
        fs::create_dir_all(&sessions_dir).map_err(SessionStoreError::DirectoryCreation)?;
        sync_directory(self.operation_root.path()).map_err(SessionStoreError::AtomicPersistence)?;

        let session_dir = self.operation_root.session_directory(record.session());
        fs::create_dir(&session_dir).map_err(SessionStoreError::DirectoryCreation)?;

        // Authority is acquired before the first durable Prepared publication.
        // Until session.json is installed, every failure must remove the owned
        // directory: history enumeration treats any retained session directory
        // without a valid record as corruption.
        let lease = match SessionLease::acquire(self.operation_root.lease_path(record.session())) {
            Ok(lease) => lease,
            Err(error) => {
                return Err(self.cleanup_unpublished_session_directory(
                    &session_dir,
                    SessionStoreError::LeaseRequired(error),
                ));
            }
        };

        let record_path = self.operation_root.session_record_path(record.session());
        let json = match record.to_json() {
            Ok(json) => json,
            Err(error) => {
                drop(lease);
                return Err(self.cleanup_unpublished_session_directory(
                    &session_dir,
                    SessionStoreError::Encoding(error),
                ));
            }
        };
        if let Err(error) = write_atomic(&record_path, json.as_bytes()) {
            return Err(self.reconcile_failed_creation(
                &record,
                &lease,
                SessionStoreError::AtomicPersistence(error),
            ));
        }
        if let Err(error) = sync_directory(&sessions_dir) {
            return Err(self.reconcile_failed_creation(
                &record,
                &lease,
                SessionStoreError::AtomicPersistence(error),
            ));
        }

        let status = SessionStatusV1::from_record(&record, self.clock.as_ref());
        match self.write_status(&status) {
            Ok(()) => {}
            Err(summary_err) => {
                return Err(self.reconcile_failed_creation(&record, &lease, summary_err));
            }
        }

        Ok(PreparedSession { record, lease })
    }

    fn cleanup_unpublished_session_directory(
        &self,
        session_dir: &Path,
        cause: SessionStoreError,
    ) -> SessionStoreError {
        let removal = match fs::remove_dir_all(session_dir) {
            Ok(()) => Ok(()),
            Err(error) if error.kind() == io::ErrorKind::NotFound => Ok(()),
            Err(error) => Err(error),
        }
        .and_then(|()| sync_directory(&self.operation_root.sessions_directory()));

        match removal {
            Ok(()) => cause,
            Err(cleanup_error) => SessionStoreError::UnpublishedSessionCleanupFailed {
                cause: Box::new(cause),
                cleanup_error,
            },
        }
    }

    fn reconcile_failed_creation(
        &self,
        prepared: &SessionRecordV1,
        lease: &SessionLease,
        cause: SessionStoreError,
    ) -> SessionStoreError {
        let failed = apply_transition(
            prepared.clone(),
            SessionTransition::ToFailed {
                failure: SafeSessionFailure::runtime_failure(
                    crate::session::SessionFailureCode::RuntimeInitializationFailed,
                    Some("session creation could not complete durable publication".into()),
                ),
            },
            self.clock.as_ref(),
        );
        let record_result = failed
            .to_json()
            .map_err(SessionStoreError::Encoding)
            .and_then(|json| {
                write_atomic(
                    &self.operation_root.session_record_path(failed.session()),
                    json.as_bytes(),
                )
                .map_err(SessionStoreError::AtomicPersistence)
            })
            .and_then(|()| {
                sync_directory(&self.operation_root.sessions_directory())
                    .map_err(SessionStoreError::AtomicPersistence)
            });
        let summary_result = record_result.as_ref().map_or_else(
            |_| Ok(()),
            |_| self.write_status(&SessionStatusV1::from_record(&failed, self.clock.as_ref())),
        );
        // Keep the physical authority alive through every recovery attempt.
        let _authority = lease;
        match (record_result.err(), summary_result.err()) {
            (None, None) => SessionStoreError::CreationFailedAndReconciled {
                cause: Box::new(cause),
                session: failed.session().clone(),
            },
            (terminal_record_error, terminal_summary_error) => {
                SessionStoreError::CreationReconciliationFailed {
                    cause: Box::new(cause),
                    session: failed.session().clone(),
                    terminal_record_error: terminal_record_error.map(Box::new),
                    terminal_summary_error: terminal_summary_error.map(Box::new),
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Load
    // ------------------------------------------------------------------

    pub fn load(
        &self,
        session: &SessionIdentity,
    ) -> Result<SessionRecordV1, SessionStoreError> {
        let path = self.operation_root.session_record_path(session);
        let json = fs::read_to_string(&path).map_err(|e| {
            if e.kind() == io::ErrorKind::NotFound {
                SessionStoreError::MissingSession
            } else {
                SessionStoreError::Io(e)
            }
        })?;
        SessionRecordV1::from_json(&json).map_err(SessionStoreError::CorruptSession)
    }

    pub fn load_status(&self) -> Result<Option<SessionStatusV1>, SessionStoreError> {
        let path = self.operation_root.status_path();
        let json = match fs::read_to_string(&path) {
            Ok(j) => j,
            Err(e) if e.kind() == io::ErrorKind::NotFound => return Ok(None),
            Err(e) => return Err(SessionStoreError::Io(e)),
        };
        let status = SessionStatusV1::from_json(&json).map_err(|e| {
            SessionStoreError::CorruptSession(e)
        })?;
        Ok(Some(status))
    }

    /// Whether any durable session-history entry exists. This intentionally
    /// treats even an incomplete or foreign entry as history: when the root
    /// summary is absent, selection must fail closed rather than orphan it.
    pub fn has_session_history(&self) -> Result<bool, SessionStoreError> {
        self.load_session_history().map(|records| !records.is_empty())
    }

    /// Load the authoritative detailed history in deterministic creation order.
    ///
    /// Every direct entry must be a real session directory whose name, record,
    /// and embedded identity agree. Corrupt, linked, incomplete, or foreign
    /// entries fail closed; selection must never silently step around history it
    /// cannot prove.
    pub fn load_session_history(&self) -> Result<Vec<SessionRecordV1>, SessionStoreError> {
        let entries = match fs::read_dir(self.operation_root.sessions_directory()) {
            Ok(entries) => entries,
            Err(error) if error.kind() == io::ErrorKind::NotFound => return Ok(Vec::new()),
            Err(error) => return Err(SessionStoreError::Io(error)),
        };
        let mut records = Vec::new();
        for entry in entries {
            let entry = entry.map_err(SessionStoreError::Io)?;
            let entry_path = entry.path();
            let entry_metadata = fs::symlink_metadata(&entry_path)
                .map_err(SessionStoreError::Io)?;
            if metadata_is_link_or_reparse(&entry_metadata) || !entry_metadata.is_dir() {
                return Err(SessionStoreError::CorruptSession(
                    SessionDecodingError::InvalidInvariant(
                        "sessions directory contains a non-directory or linked entry".into(),
                    ),
                ));
            }
            let session_name = entry.file_name().into_string().map_err(|_| {
                SessionStoreError::CorruptSession(SessionDecodingError::InvalidInvariant(
                    "session directory name is not valid UTF-8".into(),
                ))
            })?;
            let session = SessionIdentity::new(session_name).map_err(|_| {
                SessionStoreError::CorruptSession(SessionDecodingError::InvalidInvariant(
                    "session directory name is not a valid session identity".into(),
                ))
            })?;
            let record_path = entry_path.join("session.json");
            let metadata = fs::symlink_metadata(&record_path).map_err(|error| {
                if error.kind() == io::ErrorKind::NotFound {
                    SessionStoreError::CorruptSession(SessionDecodingError::InvalidInvariant(
                        "session directory is missing session.json".into(),
                    ))
                } else {
                    SessionStoreError::Io(error)
                }
            })?;
            if metadata_is_link_or_reparse(&metadata) || !metadata.is_file() {
                return Err(SessionStoreError::CorruptSession(
                    SessionDecodingError::InvalidInvariant(
                        "session.json must be a regular non-linked file".into(),
                    ),
                ));
            }
            let json = fs::read_to_string(&record_path).map_err(SessionStoreError::Io)?;
            let record = SessionRecordV1::from_json(&json)
                .map_err(SessionStoreError::CorruptSession)?;
            if record.session() != &session {
                return Err(SessionStoreError::CorruptSession(
                    SessionDecodingError::InvalidInvariant(
                        "session record identity does not match its directory".into(),
                    ),
                ));
            }
            records.push(record);
        }
        records.sort_by(|left, right| {
            (left.created_at(), left.session().id())
                .cmp(&(right.created_at(), right.session().id()))
        });
        Ok(records)
    }

    // ------------------------------------------------------------------
    // Lease
    // ------------------------------------------------------------------

    pub fn acquire_lease(
        &self,
        session: &SessionIdentity,
    ) -> Result<SessionLease, SessionLeaseError> {
        let path = self.operation_root.lease_path(session);
        let lease = SessionLease::acquire(path)?;
        let _mutation = self.acquire_mutation_lease().map_err(|error| {
            SessionLeaseError::Io(io::Error::other(error.to_string()))
        })?;
        if let Some(mut authority) = self.load_handoff_authority(session)
            .map_err(|error| SessionLeaseError::Io(std::io::Error::new(std::io::ErrorKind::InvalidData, error)))?
        {
            if matches!(&authority.state, HandoffAuthorityStateV1::Reserved | HandoffAuthorityStateV1::Ready { .. }) {
                let now = now_unix_nanos().map_err(|error| SessionLeaseError::Io(io::Error::other(error.to_string())))?;
                if now <= authority.expires_at_unix_nanos {
                    let epoch = authority.epoch;
                    drop(lease);
                    return Err(SessionLeaseError::ReservedForSuccessor { epoch });
                }
                authority.state = HandoffAuthorityStateV1::Revoked {
                    revoked_at_unix_nanos: now, reason: HandoffRevocationReasonV1::Expired,
                };
                self.write_handoff_authority(session, &authority)
                    .map_err(|error| SessionLeaseError::Io(io::Error::new(io::ErrorKind::InvalidData, error)))?;
            }
        }
        Ok(lease)
    }

    pub fn load_handoff_authority(
        &self,
        session: &SessionIdentity,
    ) -> Result<Option<HandoffAuthorityRecordV1>, HandoffProtocolError> {
        let path = self.operation_root.handoff_authority_path(session);
        let bytes = match fs::read(&path) {
            Ok(bytes) => bytes,
            Err(error) if error.kind() == io::ErrorKind::NotFound => return Ok(None),
            Err(error) => return Err(HandoffProtocolError::Io(error)),
        };
        if bytes.len() > 64 * 1024 { return Err(HandoffProtocolError::Io(io::Error::new(io::ErrorKind::InvalidData, "handoff record exceeds 64 KiB"))); }
        let record: HandoffAuthorityRecordV1 = serde_json::from_slice(&bytes).map_err(HandoffProtocolError::Decoding)?;
        validate_authority_record(&record)?;
        if record.session_id != session.id() { return Err(HandoffProtocolError::SessionMismatch); }
        Ok(Some(record))
    }

    pub fn reserve_handoff(
        &self,
        session: &SessionIdentity,
        initiating_lease: &SessionLease,
        token_digest: HandoffTokenDigest,
        expected_operator: OperatorIdentityV1,
        expires_at_unix_nanos: u64,
    ) -> Result<HandoffAuthorityRecordV1, HandoffProtocolError> {
        if initiating_lease.path() != self.operation_root.lease_path(session) {
            return Err(HandoffProtocolError::SessionMismatch);
        }
        expected_operator.validate_reserved()?;
        if expected_operator.process_id != 0 {
            return Err(HandoffProtocolError::InvalidState);
        }
        let now = now_unix_nanos()?;
        if expires_at_unix_nanos <= now {
            return Err(HandoffProtocolError::Expired);
        }
        let _mutation = self.acquire_mutation_lease().map_err(store_as_handoff)?;
        let session_record = self.load(session).map_err(|error| HandoffProtocolError::Io(io::Error::new(io::ErrorKind::InvalidData, error)))?;
        if session_record.state() != SessionState::Prepared { return Err(HandoffProtocolError::InvalidState); }
        let current = self.load_handoff_authority(session)?;
        if let Some(record) = current.as_ref() {
            if matches!(&record.state, HandoffAuthorityStateV1::Reserved | HandoffAuthorityStateV1::Ready { .. })
                && now <= record.expires_at_unix_nanos
            { return Err(HandoffProtocolError::ReservedForSuccessor { epoch: record.epoch }); }
        }
        let epoch = match current { Some(record) => record.epoch.checked_add(1).ok_or(HandoffProtocolError::InvalidState)?, None => 1 };
        let record = HandoffAuthorityRecordV1 {
            schema_version: HANDOFF_SCHEMA_VERSION,
            session_id: session.id().to_string(),
            epoch,
            token_digest,
            expected_operator,
            expires_at_unix_nanos,
            state: HandoffAuthorityStateV1::Reserved,
        };
        self.write_handoff_authority(session, &record)?;
        Ok(record)
    }

    pub fn validate_ready_handoff_for_release(
        &self,
        session: &SessionIdentity,
        initiating_lease: &SessionLease,
        epoch: u64,
        token: &HandoffToken,
        expected_operator: &OperatorIdentityV1,
    ) -> Result<(), HandoffProtocolError> {
        if initiating_lease.path() != self.operation_root.lease_path(session) || epoch == 0 {
            return Err(HandoffProtocolError::SessionMismatch);
        }
        let _mutation = self.acquire_mutation_lease().map_err(store_as_handoff)?;
        let record = self.load_handoff_authority(session)?.ok_or(HandoffProtocolError::Missing)?;
        if record.epoch != epoch {
            return Err(HandoffProtocolError::EpochMismatch {
                expected: record.epoch,
                actual: epoch,
            });
        }
        if &record.expected_operator != expected_operator {
            return Err(HandoffProtocolError::OperatorMismatch);
        }
        if !record.token_digest.matches(token) {
            return Err(HandoffProtocolError::TokenMismatch);
        }
        if now_unix_nanos()? > record.expires_at_unix_nanos {
            return Err(HandoffProtocolError::Expired);
        }
        if !matches!(&record.state, HandoffAuthorityStateV1::Ready { .. }) {
            return Err(HandoffProtocolError::InvalidState);
        }
        Ok(())
    }

    pub fn fence_ready_handoff(
        &self,
        session: &SessionIdentity,
        epoch: u64,
        token: &HandoffToken,
        expected_operator: &OperatorIdentityV1,
        reason: HandoffRevocationReasonV1,
    ) -> Result<HandoffFenceOutcome, HandoffProtocolError> {
        if epoch == 0 { return Err(HandoffProtocolError::InvalidState); }
        expected_operator.validate_claim()?;
        let _mutation = self.acquire_mutation_lease().map_err(store_as_handoff)?;
        let mut record = self.load_handoff_authority(session)?.ok_or(HandoffProtocolError::Missing)?;
        if record.epoch != epoch { return Err(HandoffProtocolError::EpochMismatch { expected: record.epoch, actual: epoch }); }
        if &record.expected_operator != expected_operator { return Err(HandoffProtocolError::OperatorMismatch); }
        if !record.token_digest.matches(token) { return Err(HandoffProtocolError::TokenMismatch); }
        match &record.state {
            HandoffAuthorityStateV1::Owned { lease_identity, .. } => {
                let actual = crate::session::inspect_session_lease_identity(
                    &self.operation_root.lease_path(session),
                ).map_err(|error| HandoffProtocolError::Io(io::Error::other(error.to_string())))?;
                if actual.as_ref() == Some(lease_identity) {
                    Ok(HandoffFenceOutcome::AlreadyOwned)
                } else {
                    Err(HandoffProtocolError::InvalidState)
                }
            }
            HandoffAuthorityStateV1::Reserved | HandoffAuthorityStateV1::Ready { .. } => {
                record.state = HandoffAuthorityStateV1::Revoked {
                    revoked_at_unix_nanos: now_unix_nanos()?, reason,
                };
                self.write_handoff_authority(session, &record)?;
                Ok(HandoffFenceOutcome::Revoked)
            }
            HandoffAuthorityStateV1::Revoked { .. } => Err(HandoffProtocolError::InvalidState),
        }
    }

    pub fn mark_handoff_ready(&self, proof: &HandoffClaimProof) -> Result<HandoffAuthorityRecordV1, HandoffProtocolError> {
        proof.operator.validate_claim()?;
        let session = SessionIdentity::new(proof.session_id.clone()).map_err(|_| HandoffProtocolError::SessionMismatch)?;
        let _mutation = self.acquire_mutation_lease().map_err(store_as_handoff)?;
        let mut record = self.load_handoff_authority(&session)?.ok_or(HandoffProtocolError::Missing)?;
        self.validate_handoff_common(&record, proof)?;
        if !matches!(&record.state, HandoffAuthorityStateV1::Reserved) { return Err(HandoffProtocolError::InvalidState); }
        if record.expected_operator.process_id != 0 && record.expected_operator.process_id != proof.operator.process_id {
            return Err(HandoffProtocolError::OperatorMismatch);
        }
        record.expected_operator.process_id = proof.operator.process_id;
        record.state = HandoffAuthorityStateV1::Ready { ready_at_unix_nanos: now_unix_nanos()? };
        self.write_handoff_authority(&session, &record)?;
        Ok(record)
    }

    pub fn acquire_reserved_handoff(&self, proof: &HandoffClaimProof) -> Result<SessionLease, SessionStoreError> {
        proof.operator.validate_claim().map_err(SessionStoreError::Handoff)?;
        let session = SessionIdentity::new(proof.session_id.clone()).map_err(|_| SessionStoreError::Handoff(HandoffProtocolError::SessionMismatch))?;
        let lease = SessionLease::acquire(self.operation_root.lease_path(&session)).map_err(SessionStoreError::LeaseRequired)?;
        let _mutation = self.acquire_mutation_lease()?;
        let record = self.validate_handoff_proof(&session, proof).map_err(SessionStoreError::Handoff)?;
        if !matches!(&record.state, HandoffAuthorityStateV1::Ready { .. }) { return Err(SessionStoreError::Handoff(HandoffProtocolError::InvalidState)); }
        Ok(lease)
    }

    pub fn publish_owned_handoff(
        &self,
        lease: &SessionLease,
        proof: &HandoffClaimProof,
    ) -> Result<HandoffAuthorityRecordV1, SessionStoreError> {
        proof.operator.validate_claim().map_err(SessionStoreError::Handoff)?;
        let session = SessionIdentity::new(proof.session_id.clone())
            .map_err(|_| SessionStoreError::Handoff(HandoffProtocolError::SessionMismatch))?;
        if lease.path() != self.operation_root.lease_path(&session) {
            return Err(SessionStoreError::LeaseRequired(SessionLeaseError::InvalidIdentity));
        }
        self.verify_live_lease_identity(&session, lease.identity())?;
        let _mutation = self.acquire_mutation_lease()?;
        self.verify_live_lease_identity(&session, lease.identity())?;
        let mut record = self.validate_handoff_proof(&session, proof).map_err(SessionStoreError::Handoff)?;
        if !matches!(&record.state, HandoffAuthorityStateV1::Ready { .. }) {
            return Err(SessionStoreError::Handoff(HandoffProtocolError::InvalidState));
        }
        record.state = HandoffAuthorityStateV1::Owned {
            owned_at_unix_nanos: now_unix_nanos().map_err(SessionStoreError::Handoff)?,
            lease_identity: lease.identity().clone(),
        };
        self.write_handoff_authority(&session, &record).map_err(SessionStoreError::Handoff)?;
        Ok(record)
    }

    pub fn revoke_handoff(&self, session: &SessionIdentity, initiating_lease: &SessionLease, epoch: u64, reason: HandoffRevocationReasonV1) -> Result<HandoffAuthorityRecordV1, HandoffProtocolError> {
        if epoch == 0 { return Err(HandoffProtocolError::InvalidState); }
        if initiating_lease.path() != self.operation_root.lease_path(session) {
            return Err(HandoffProtocolError::SessionMismatch);
        }
        let _mutation = self.acquire_mutation_lease().map_err(store_as_handoff)?;
        let mut record = self.load_handoff_authority(session)?.ok_or(HandoffProtocolError::Missing)?;
        if record.epoch != epoch { return Err(HandoffProtocolError::EpochMismatch { expected: record.epoch, actual: epoch }); }
        if matches!(&record.state, HandoffAuthorityStateV1::Owned { .. }) { return Err(HandoffProtocolError::InvalidState); }
        record.state = HandoffAuthorityStateV1::Revoked { revoked_at_unix_nanos: now_unix_nanos()?, reason };
        self.write_handoff_authority(session, &record)?;
        Ok(record)
    }

    pub fn revoke_handoff_after_release(&self, session: &SessionIdentity, epoch: u64, reason: HandoffRevocationReasonV1) -> Result<(SessionLease, HandoffAuthorityRecordV1), SessionStoreError> {
        let lease = SessionLease::acquire(self.operation_root.lease_path(session)).map_err(SessionStoreError::LeaseRequired)?;
        let _mutation = self.acquire_mutation_lease()?;
        let mut record = self.load_handoff_authority(session).map_err(SessionStoreError::Handoff)?
            .ok_or(SessionStoreError::Handoff(HandoffProtocolError::Missing))?;
        if epoch == 0 || record.epoch != epoch {
            return Err(SessionStoreError::Handoff(HandoffProtocolError::EpochMismatch { expected: record.epoch, actual: epoch }));
        }
        if matches!(&record.state, HandoffAuthorityStateV1::Owned { .. }) {
            return Err(SessionStoreError::Handoff(HandoffProtocolError::InvalidState));
        }
        record.state = HandoffAuthorityStateV1::Revoked { revoked_at_unix_nanos: now_unix_nanos().map_err(SessionStoreError::Handoff)?, reason };
        self.write_handoff_authority(session, &record).map_err(SessionStoreError::Handoff)?;
        Ok((lease, record))
    }

    pub fn load_owned_handoff(&self, proof: &HandoffClaimProof) -> Result<HandoffAuthorityRecordV1, HandoffProtocolError> {
        let session = SessionIdentity::new(proof.session_id.clone()).map_err(|_| HandoffProtocolError::SessionMismatch)?;
        let record = self.validate_handoff_proof(&session, proof)?;
        if !matches!(&record.state, HandoffAuthorityStateV1::Owned { .. }) {
            return Err(HandoffProtocolError::InvalidState);
        }
        Ok(record)
    }

    /// Prove that the authenticated successor's durable `Owned` record names
    /// the exact operating-system lease which is still held now.
    ///
    /// The authority record is read on both sides of two physical-lease
    /// observations while the mutation lease is held. This prevents an old
    /// `Owned` document, a replacement lease owner, or a concurrent authority
    /// rewrite from being mistaken for a completed transfer.
    pub fn verify_live_owned_handoff(
        &self,
        session: &SessionIdentity,
        epoch: u64,
        token: &HandoffToken,
        expected_operator: &OperatorIdentityV1,
    ) -> Result<bool, SessionStoreError> {
        let _mutation = self.acquire_mutation_lease()?;
        let before = self.load_handoff_authority(session)
            .map_err(SessionStoreError::Handoff)?
            .ok_or(SessionStoreError::Handoff(HandoffProtocolError::Missing))?;
        if before.epoch != epoch
            || &before.expected_operator != expected_operator
            || !before.token_digest.matches(token)
        {
            return Ok(false);
        }
        let expected_lease = match &before.state {
            HandoffAuthorityStateV1::Owned { lease_identity, .. } => lease_identity,
            _ => return Ok(false),
        };
        let lease_path = self.operation_root.lease_path(session);
        if crate::session::inspect_session_lease_identity(&lease_path)
            .map_err(SessionStoreError::LeaseRequired)?
            .as_ref() != Some(expected_lease)
        {
            return Ok(false);
        }
        let after = self.load_handoff_authority(session)
            .map_err(SessionStoreError::Handoff)?
            .ok_or(SessionStoreError::Handoff(HandoffProtocolError::Missing))?;
        if after != before {
            return Ok(false);
        }
        Ok(crate::session::inspect_session_lease_identity(&lease_path)
            .map_err(SessionStoreError::LeaseRequired)?
            .as_ref() == Some(expected_lease))
    }

    pub fn recover_handoff_after_operator_death(&self, session: &SessionIdentity, epoch: u64, expected_operator: &OperatorIdentityV1, reason: HandoffRevocationReasonV1) -> Result<(SessionLease, HandoffAuthorityRecordV1), SessionStoreError> {
        let lease = SessionLease::acquire(self.operation_root.lease_path(session)).map_err(SessionStoreError::LeaseRequired)?;
        let _mutation = self.acquire_mutation_lease()?;
        let mut record = self.load_handoff_authority(session).map_err(SessionStoreError::Handoff)?.ok_or(SessionStoreError::Handoff(HandoffProtocolError::Missing))?;
        if record.epoch != epoch { return Err(SessionStoreError::Handoff(HandoffProtocolError::EpochMismatch { expected: record.epoch, actual: epoch })); }
        if &record.expected_operator != expected_operator {
            return Err(SessionStoreError::Handoff(HandoffProtocolError::OperatorMismatch));
        }
        if !matches!(&record.state, HandoffAuthorityStateV1::Owned { .. }) {
            return Err(SessionStoreError::Handoff(HandoffProtocolError::InvalidState));
        }
        let owned_lease_identity = match &record.state {
            HandoffAuthorityStateV1::Owned { lease_identity, .. } => lease_identity,
            _ => unreachable!("Owned state checked above"),
        };
        if lease.identity() == owned_lease_identity {
            return Err(SessionStoreError::Handoff(HandoffProtocolError::InvalidState));
        }
        record.state = HandoffAuthorityStateV1::Revoked { revoked_at_unix_nanos: now_unix_nanos().map_err(SessionStoreError::Handoff)?, reason };
        self.write_handoff_authority(session, &record).map_err(SessionStoreError::Handoff)?;
        Ok((lease, record))
    }

    /// Revoke authority after a successor has claimed the handoff but before
    /// its launch owner can be constructed. The caller must retain the exact
    /// claimed physical lease for the entire mutation.
    pub fn revoke_claimed_handoff_as_lease_owner(
        &self,
        session: &SessionIdentity,
        lease: &SessionLease,
        proof: &HandoffClaimProof,
        reason: HandoffRevocationReasonV1,
    ) -> Result<HandoffAuthorityRecordV1, SessionStoreError> {
        if lease.path() != self.operation_root.lease_path(session) {
            return Err(SessionStoreError::LeaseRequired(SessionLeaseError::InvalidIdentity));
        }
        self.verify_live_lease_identity(session, lease.identity())?;
        let _mutation = self.acquire_mutation_lease()?;
        self.verify_live_lease_identity(session, lease.identity())?;
        proof.operator.validate_claim().map_err(SessionStoreError::Handoff)?;
        if proof.session_id != session.id() {
            return Err(SessionStoreError::Handoff(HandoffProtocolError::SessionMismatch));
        }
        let mut record = self.load_handoff_authority(session)
            .map_err(SessionStoreError::Handoff)?
            .ok_or(SessionStoreError::Handoff(HandoffProtocolError::Missing))?;
        if proof.epoch == 0 || record.epoch != proof.epoch {
            return Err(SessionStoreError::Handoff(HandoffProtocolError::EpochMismatch {
                expected: record.epoch,
                actual: proof.epoch,
            }));
        }
        if record.expected_operator != proof.operator {
            return Err(SessionStoreError::Handoff(HandoffProtocolError::OperatorMismatch));
        }
        if !record.token_digest.matches(&proof.token) {
            return Err(SessionStoreError::Handoff(HandoffProtocolError::TokenMismatch));
        }
        match &record.state {
            HandoffAuthorityStateV1::Ready { .. } => {}
            HandoffAuthorityStateV1::Owned { lease_identity, .. }
                if lease_identity == lease.identity() => {}
            _ => return Err(SessionStoreError::Handoff(HandoffProtocolError::InvalidState)),
        }
        record.state = HandoffAuthorityStateV1::Revoked {
            revoked_at_unix_nanos: now_unix_nanos().map_err(SessionStoreError::Handoff)?,
            reason,
        };
        self.write_handoff_authority(session, &record)
            .map_err(SessionStoreError::Handoff)?;
        Ok(record)
    }

    fn validate_handoff_proof(&self, session: &SessionIdentity, proof: &HandoffClaimProof) -> Result<HandoffAuthorityRecordV1, HandoffProtocolError> {
        let record = self.load_handoff_authority(session)?.ok_or(HandoffProtocolError::Missing)?;
        self.validate_handoff_common(&record, proof)?;
        if record.expected_operator != proof.operator { return Err(HandoffProtocolError::OperatorMismatch); }
        Ok(record)
    }

    fn validate_handoff_common(&self, record: &HandoffAuthorityRecordV1, proof: &HandoffClaimProof) -> Result<(), HandoffProtocolError> {
        if proof.session_id != record.session_id { return Err(HandoffProtocolError::SessionMismatch); }
        if proof.epoch == 0 { return Err(HandoffProtocolError::InvalidState); }
        proof.operator.validate_claim()?;
        if record.epoch != proof.epoch { return Err(HandoffProtocolError::EpochMismatch { expected: record.epoch, actual: proof.epoch }); }
        if record.expected_operator.instance_nonce != proof.operator.instance_nonce { return Err(HandoffProtocolError::OperatorMismatch); }
        if !record.token_digest.matches(&proof.token) { return Err(HandoffProtocolError::TokenMismatch); }
        if now_unix_nanos()? > record.expires_at_unix_nanos { return Err(HandoffProtocolError::Expired); }
        Ok(())
    }

    fn write_handoff_authority(&self, session: &SessionIdentity, record: &HandoffAuthorityRecordV1) -> Result<(), HandoffProtocolError> {
        validate_authority_record(record)?;
        if record.session_id != session.id() {
            return Err(HandoffProtocolError::SessionMismatch);
        }
        let bytes = serde_json::to_vec(record).map_err(HandoffProtocolError::Encoding)?;
        write_atomic(&self.operation_root.handoff_authority_path(session), &bytes).map_err(HandoffProtocolError::Io)
    }

    pub fn inspect_lease_state(
        &self,
        session: &SessionIdentity,
    ) -> Result<SessionLeaseState, SessionLeaseError> {
        inspect_session_lease(&self.operation_root.lease_path(session))
    }

    // ------------------------------------------------------------------
    // Transition
    // ------------------------------------------------------------------

    /// Apply a state transition to the session record using optimistic revision control.
    ///
    /// Reads the current record, validates the expected revision, validates the
    /// transition, applies it, persists the updated record, and then updates the
    /// root summary.
    ///
    /// If the summary update fails after the record succeeds, returns
    /// `SessionStoreError::PartialCommit`. Call `rebuild_status_from_record` to recover.
    pub fn transition_as_lease_owner(
        &self,
        session: &SessionIdentity,
        lease: &SessionLease,
        expected_revision: u64,
        transition: SessionTransition,
    ) -> Result<SessionRecordV1, SessionStoreError> {
        if lease.path() != self.operation_root.lease_path(session) {
            return Err(SessionStoreError::LeaseRequired(SessionLeaseError::InvalidIdentity));
        }
        self.transition_verified(session, lease.identity(), expected_revision, transition)
    }

    pub(crate) fn transition_verified(
        &self,
        session: &SessionIdentity,
        identity: &crate::session::SessionLeaseIdentity,
        expected_revision: u64,
        transition: SessionTransition,
    ) -> Result<SessionRecordV1, SessionStoreError> {
        self.verify_live_lease_identity(session, identity)?;
        let _mutation = self.acquire_mutation_lease()?;
        self.verify_live_lease_identity(session, identity)?;
        let current = self.load(session)?;

        if current.revision() != expected_revision {
            return Err(SessionStoreError::RevisionConflict {
                expected: expected_revision,
                actual: current.revision(),
            });
        }

        validate_transition(current.state(), &transition)
            .map_err(SessionStoreError::InvalidTransition)?;

        let updated = apply_transition(current, transition, self.clock.as_ref());

        let record_path = self.operation_root.session_record_path(session);
        let json = updated.to_json().map_err(SessionStoreError::Encoding)?;
        write_atomic(&record_path, json.as_bytes())
            .map_err(SessionStoreError::AtomicPersistence)?;

        // Update root summary
        let status = SessionStatusV1::from_record(&updated, self.clock.as_ref());
        match self.write_status(&status) {
            Ok(()) => {}
            Err(summary_err) => {
                return Err(SessionStoreError::PartialCommit {
                    record_error: None,
                    summary_error: Box::new(summary_err),
                });
            }
        }

        Ok(updated)
    }

    fn verify_live_lease_identity(
        &self,
        session: &SessionIdentity,
        expected: &crate::session::SessionLeaseIdentity,
    ) -> Result<(), SessionStoreError> {
        let actual = crate::session::inspect_session_lease_identity(
            &self.operation_root.lease_path(session),
        ).map_err(SessionStoreError::LeaseRequired)?
            .ok_or(SessionStoreError::LeaseRequired(SessionLeaseError::AlreadyOwned))?;
        if &actual != expected {
            return Err(SessionStoreError::LeaseRequired(SessionLeaseError::InvalidIdentity));
        }
        Ok(())
    }

    // ------------------------------------------------------------------
    // Summary reconstruction
    // ------------------------------------------------------------------

    /// Rebuild the root `session_status.json` from the authoritative detailed record.
    ///
    /// Use this after a `PartialCommit` error to restore consistency.
    pub fn rebuild_status_from_record(
        &self,
        session: &SessionIdentity,
        lease: &SessionLease,
    ) -> Result<SessionStatusV1, SessionStoreError> {
        if lease.path() != self.operation_root.lease_path(session) {
            return Err(SessionStoreError::LeaseRequired(SessionLeaseError::InvalidIdentity));
        }
        self.verify_live_lease_identity(session, lease.identity())?;
        let _mutation = self.acquire_mutation_lease()?;
        self.verify_live_lease_identity(session, lease.identity())?;
        let record = self.load(session)?;
        let status = SessionStatusV1::from_record(&record, self.clock.as_ref());
        self.write_status(&status)?;
        Ok(status)
    }

    // ------------------------------------------------------------------
    // Stale ownership reconciliation
    // ------------------------------------------------------------------

    /// Check whether the current session is stale (process died leaving a non-terminal record).
    ///
    /// 1. Load the current detailed record.
    /// 2. Attempt non-blocking lease acquisition.
    /// 3. Lease contention → live owner → return `Ok(None)`.
    /// 4. Successful lease acquisition of a `Prepared` or `Running` record → stale.
    /// 5. Transition the stale record to `Failed` with `StaleOwnership`.
    /// 6. Update the root summary.
    /// 7. Release the temporary lease.
    pub fn reconcile_stale_current_session(
        &self,
        session: &SessionIdentity,
    ) -> Result<Option<SessionRecordV1>, SessionStoreError> {
        let record = match self.load(session) {
            Ok(r) => r,
            Err(SessionStoreError::MissingSession) => return Ok(None),
            Err(e) => return Err(e),
        };

        if matches!(record.state(), SessionState::Succeeded | SessionState::Abandoned) {
            return Ok(None);
        }

        if record.state() == SessionState::Failed {
            return Ok(None);
        }

        // Attempt non-blocking lease acquisition
        let lease = match self.acquire_lease(session) {
            Ok(lease) => lease,
            Err(SessionLeaseError::AlreadyOwned) => {
                // Live owner holds the lock
                return Ok(None);
            }
            Err(SessionLeaseError::ReservedForSuccessor { .. }) => return Ok(None),
            Err(e) => return Err(SessionStoreError::LeaseRequired(e)),
        };

        // We acquired the lease → the previous owner is gone → stale
        self.revoke_stale_owned_handoff_as_lease_owner(session, &lease)?;
        let revision = record.revision();
        let result = self
            .transition_as_lease_owner(
                session,
                &lease,
                revision,
                SessionTransition::ToFailed {
                    failure: SafeSessionFailure::stale_ownership_failure(),
                },
            )
            .map_err(|e| {
                SessionStoreError::StaleOwnershipReconciliationFailed(Box::new(e))
            })?;

        drop(lease);

        Ok(Some(result))
    }

    fn revoke_stale_owned_handoff_as_lease_owner(
        &self,
        session: &SessionIdentity,
        replacement_lease: &SessionLease,
    ) -> Result<(), SessionStoreError> {
        if replacement_lease.path() != self.operation_root.lease_path(session) {
            return Err(SessionStoreError::LeaseRequired(
                SessionLeaseError::InvalidIdentity,
            ));
        }
        self.verify_live_lease_identity(session, replacement_lease.identity())?;
        let _mutation = self.acquire_mutation_lease()?;
        self.verify_live_lease_identity(session, replacement_lease.identity())?;

        let Some(mut authority) = self
            .load_handoff_authority(session)
            .map_err(SessionStoreError::Handoff)?
        else {
            return Ok(());
        };
        let stale_lease_identity = match &authority.state {
            HandoffAuthorityStateV1::Owned { lease_identity, .. } => lease_identity,
            _ => return Ok(()),
        };
        if stale_lease_identity == replacement_lease.identity() {
            return Err(SessionStoreError::Handoff(
                HandoffProtocolError::InvalidState,
            ));
        }

        authority.state = HandoffAuthorityStateV1::Revoked {
            revoked_at_unix_nanos: now_unix_nanos().map_err(SessionStoreError::Handoff)?,
            reason: HandoffRevocationReasonV1::OperatorExited,
        };
        self.write_handoff_authority(session, &authority)
            .map_err(SessionStoreError::Handoff)
    }

    // ------------------------------------------------------------------
    // Internal helpers
    // ------------------------------------------------------------------

    fn write_status(&self, status: &SessionStatusV1) -> Result<(), SessionStoreError> {
        let path = self.operation_root.status_path();
        let json = status.to_json().map_err(SessionStoreError::Encoding)?;
        write_atomic(&path, json.as_bytes()).map_err(SessionStoreError::AtomicPersistence)?;
        Ok(())
    }

    fn acquire_mutation_lease(&self) -> Result<SessionLease, SessionStoreError> {
        fs::create_dir_all(self.operation_root.path())
            .map_err(SessionStoreError::DirectoryCreation)?;
        SessionLease::acquire(self.operation_root.mutation_lease_path())
            .map_err(SessionStoreError::LeaseRequired)
    }
}

fn metadata_is_link_or_reparse(metadata: &fs::Metadata) -> bool {
    if metadata.file_type().is_symlink() {
        return true;
    }
    #[cfg(windows)]
    {
        use std::os::windows::fs::MetadataExt;
        const FILE_ATTRIBUTE_REPARSE_POINT: u32 = 0x0000_0400;
        if metadata.file_attributes() & FILE_ATTRIBUTE_REPARSE_POINT != 0 {
            return true;
        }
    }
    false
}

fn store_as_handoff(error: SessionStoreError) -> HandoffProtocolError {
    HandoffProtocolError::Io(io::Error::other(error.to_string()))
}

// ---------------------------------------------------------------------------
// Transition application
// ---------------------------------------------------------------------------

fn apply_transition(
    mut record: SessionRecordV1,
    transition: SessionTransition,
    clock: &dyn SessionClock,
) -> SessionRecordV1 {
    use crate::session::model::{SessionFailureV1, SessionState};

    let now = clock.now();
    let new_state = transition.target_state();

    // Apply state-specific mutations
    match &transition {
        SessionTransition::ToRunning => {
            record.started_at = Some(now);
        }
        SessionTransition::ToSucceeded => {
            record.finished_at = Some(now);
        }
        SessionTransition::ToFailed { failure } => {
            record.finished_at = Some(now);
            record.failure = Some(SessionFailureV1::from_safe(failure.clone()));
        }
        SessionTransition::ToAbandoned => {
            record.finished_at = Some(now);
            record.failure = None;
        }
    }

    record.state = new_state;
    record.revision += 1;
    record.updated_at = now;

    record
}

// ---------------------------------------------------------------------------
// Atomic file write
// ---------------------------------------------------------------------------

fn write_atomic(dest: &Path, content: &[u8]) -> Result<(), io::Error> {
    let dir = dest.parent().ok_or_else(|| io::Error::new(
        io::ErrorKind::InvalidInput,
        format!("durable destination has no parent: {}", dest.display()),
    ))?;

    let mut tmp = tempfile::NamedTempFile::new_in(dir)?;
    tmp.write_all(content)?;
    tmp.flush()?;
    tmp.as_file().sync_all()?;
    durable_replace(tmp, dest)?;
    sync_directory(dir)
}

fn durable_replace(tmp: tempfile::NamedTempFile, dest: &Path) -> Result<(), io::Error> {
    #[cfg(not(windows))]
    {
        tmp.persist(dest).map_err(|error| error.error)?;
        return Ok(());
    }
    #[cfg(windows)]
    {
        use std::os::windows::ffi::OsStrExt;
        use windows_sys::Win32::Storage::FileSystem::{MoveFileExW, ReplaceFileW, MOVEFILE_WRITE_THROUGH, REPLACEFILE_WRITE_THROUGH};
        if !dest.exists() {
            use std::os::windows::ffi::OsStrExt;
            let temporary = tmp.into_temp_path();
            let destination_wide: Vec<u16> = dest.as_os_str().encode_wide().chain(Some(0)).collect();
            let temporary_wide: Vec<u16> = temporary.as_os_str().encode_wide().chain(Some(0)).collect();
            if unsafe { MoveFileExW(temporary_wide.as_ptr(), destination_wide.as_ptr(), MOVEFILE_WRITE_THROUGH) } == 0 {
                return Err(io::Error::last_os_error());
            }
            return Ok(());
        }
        let temporary = tmp.into_temp_path();
        let destination_wide: Vec<u16> = dest.as_os_str().encode_wide().chain(Some(0)).collect();
        let temporary_wide: Vec<u16> = temporary.as_os_str().encode_wide().chain(Some(0)).collect();
        let deadline = std::time::Instant::now() + std::time::Duration::from_secs(2);
        loop {
            let replaced = unsafe { ReplaceFileW(
                destination_wide.as_ptr(), temporary_wide.as_ptr(), std::ptr::null(),
                REPLACEFILE_WRITE_THROUGH, std::ptr::null(), std::ptr::null(),
            ) };
            if replaced != 0 { return Ok(()); }
            let error = io::Error::last_os_error();
            if std::time::Instant::now() >= deadline
                || !matches!(error.kind(), io::ErrorKind::PermissionDenied | io::ErrorKind::Other) {
                return Err(error);
            }
            std::thread::sleep(std::time::Duration::from_millis(20));
        }
    }
}

#[cfg(unix)]
fn sync_directory(path: &Path) -> Result<(), io::Error> {
    fs::File::open(path)?.sync_all()
}

#[cfg(windows)]
fn sync_directory(_path: &Path) -> Result<(), io::Error> {
    // Windows publication uses MoveFileExW/ReplaceFileW with WRITE_THROUGH;
    // Windows does not expose a reliable portable directory-fsync contract.
    Ok(())
}

#[cfg(not(any(unix, windows)))]
fn sync_directory(_path: &Path) -> Result<(), io::Error> {
    Err(io::Error::new(io::ErrorKind::Unsupported, "durable directory synchronization is unsupported"))
}

fn now_unix_nanos() -> Result<u64, HandoffProtocolError> {
    std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH)
        .map(|duration| duration.as_nanos().min(u64::MAX as u128) as u64)
        .map_err(|error| HandoffProtocolError::Io(io::Error::other(format!("system clock is before Unix epoch: {error}"))) )
}

#[cfg(test)]
mod history_tests {
    use super::*;

    fn prepared_input() -> NewSessionRecord {
        NewSessionRecord {
            project: crate::runtime::ProjectInvocationIdentity::new("project").unwrap(),
            runtime: crate::runtime::OwnedRuntimeIdentity::http_acquisition("source", 1),
            operation: SessionOperation::Acquisition,
            execution_mode: crate::runtime::RuntimeExecutionMode::Run,
            supervision_mode: crate::runtime::RuntimeSupervisionMode::Foreground,
        }
    }

    #[test]
    fn prepared_creation_publishes_detailed_record_before_root_summary() {
        let temp = tempfile::tempdir().unwrap();
        let root = SessionOperationRoot::new(temp.path().join("operation")).unwrap();
        let store = SessionStore::open(root).unwrap();

        let prepared = store.create_prepared(prepared_input()).unwrap();
        let detailed = store.load(prepared.record().session()).unwrap();
        let summary = store.load_status().unwrap().unwrap();

        assert_eq!(detailed.state(), SessionState::Prepared);
        assert_eq!(summary.current_session(), Some(detailed.session()));
        assert_eq!(summary.current_state(), Some(SessionState::Prepared));
    }

    #[test]
    fn creation_summary_failure_retains_committed_session_identity_and_code() {
        let temp = tempfile::tempdir().unwrap();
        let root = SessionOperationRoot::new(temp.path().join("operation")).unwrap();
        std::fs::create_dir_all(root.path()).unwrap();
        std::fs::create_dir(root.status_path()).unwrap();
        let store = SessionStore::open(root).unwrap();

        let error = store.create_prepared(prepared_input()).unwrap_err();
        let (session, failure_code) = error
            .committed_session_failure()
            .map(|(session, code)| (session.clone(), code))
            .expect("detailed Failed record must remain authoritative");

        assert_eq!(
            failure_code,
            crate::session::SessionFailureCode::RuntimeInitializationFailed
        );
        let record = store.load(&session).unwrap();
        assert_eq!(record.state(), SessionState::Failed);
        assert_eq!(
            record.failure().unwrap().code(),
            crate::session::SessionFailureCode::RuntimeInitializationFailed
        );
    }

    #[test]
    fn unpublished_session_cleanup_prevents_history_poisoning() {
        let temp = tempfile::tempdir().unwrap();
        let root = SessionOperationRoot::new(temp.path().join("operation")).unwrap();
        let store = SessionStore::open(root).unwrap();
        let sessions = store.operation_root().sessions_directory();
        let session = SessionIdentity::new("00000000-0000-4000-8000-000000000001").unwrap();
        let session_dir = store.operation_root().session_directory(&session);
        std::fs::create_dir_all(&session_dir).unwrap();
        std::fs::write(session_dir.join("session.lock"), b"").unwrap();

        let error = store.cleanup_unpublished_session_directory(
            &session_dir,
            SessionStoreError::DirectoryCreation(io::Error::other("injected failure")),
        );

        assert!(matches!(error, SessionStoreError::DirectoryCreation(_)));
        assert!(!session_dir.exists());
        assert!(store.load_session_history().unwrap().is_empty());
        assert!(sessions.is_dir());
    }

    #[test]
    fn history_rejects_non_directory_entries() {
        let temp = tempfile::tempdir().unwrap();
        let root = SessionOperationRoot::new(temp.path().join("operation")).unwrap();
        let store = SessionStore::open(root).unwrap();
        std::fs::create_dir_all(store.operation_root().sessions_directory()).unwrap();
        std::fs::write(
            store.operation_root().sessions_directory().join("foreign-entry"),
            b"not a session directory",
        )
        .unwrap();

        assert!(matches!(
            store.load_session_history(),
            Err(SessionStoreError::CorruptSession(
                SessionDecodingError::InvalidInvariant(_)
            ))
        ));
    }

    #[cfg(unix)]
    #[test]
    fn history_rejects_linked_session_entries_without_following_them() {
        use std::os::unix::fs::symlink;

        let temp = tempfile::tempdir().unwrap();
        let root = SessionOperationRoot::new(temp.path().join("operation")).unwrap();
        let store = SessionStore::open(root).unwrap();
        let sessions = store.operation_root().sessions_directory();
        let outside = temp.path().join("outside");
        std::fs::create_dir_all(&sessions).unwrap();
        std::fs::create_dir_all(&outside).unwrap();
        symlink(&outside, sessions.join("linked-session")).unwrap();

        assert!(matches!(
            store.load_session_history(),
            Err(SessionStoreError::CorruptSession(
                SessionDecodingError::InvalidInvariant(_)
            ))
        ));
        assert!(outside.is_dir());
    }
}

#[cfg(test)]
mod handoff_tests {
    use super::*;
    use crate::runtime::{OwnedRuntimeIdentity, ProjectInvocationIdentity, RuntimeSupervisionMode};
    use crate::session::{HandoffClaimProof, HandoffProtocolError, HandoffRevocationReasonV1, HandoffToken, OperatorIdentityV1};

    fn prepared() -> (tempfile::TempDir, SessionStore, SessionIdentity, SessionLease) {
        let temp = tempfile::tempdir().unwrap();
        let root = SessionOperationRoot::new(temp.path().join("operation")).unwrap();
        let store = SessionStore::open(root).unwrap();
        let prepared = store.create_prepared(NewSessionRecord {
            project: ProjectInvocationIdentity::new("project").unwrap(),
            runtime: OwnedRuntimeIdentity::http_acquisition("source", 1),
            operation: SessionOperation::Acquisition,
            execution_mode: crate::runtime::RuntimeExecutionMode::Run,
            supervision_mode: RuntimeSupervisionMode::Background,
        }).unwrap();
        let session = prepared.record().session().clone();
        let (_, lease) = prepared.into_owned_parts();
        (temp, store, session, lease)
    }

    fn operator() -> OperatorIdentityV1 {
        OperatorIdentityV1 { instance_nonce: "nominated-instance".into(), process_id: 71 }
    }

    fn future_deadline() -> u64 {
        now_unix_nanos().unwrap().checked_add(30_000_000_000).unwrap()
    }

    #[test]
    fn reserved_and_ready_states_fence_ordinary_contenders() {
        let (_temp, store, session, initiating_lease) = prepared();
        let token = HandoffToken::generate().unwrap();
        let reservation = store.reserve_handoff(&session, &initiating_lease, token.digest(),
            OperatorIdentityV1 { instance_nonce: operator().instance_nonce, process_id: 0 }, future_deadline()).unwrap();
        drop(initiating_lease);
        assert!(matches!(store.acquire_lease(&session), Err(SessionLeaseError::ReservedForSuccessor { epoch }) if epoch == reservation.epoch));
        let proof = HandoffClaimProof { session_id: session.id().into(), epoch: reservation.epoch, token, operator: operator() };
        store.mark_handoff_ready(&proof).unwrap();
        assert!(matches!(store.acquire_lease(&session), Err(SessionLeaseError::ReservedForSuccessor { .. })));
        assert!(store.reconcile_stale_current_session(&session).unwrap().is_none());
    }

    #[test]
    fn wrong_token_nonce_and_epoch_fail_closed_and_revoked_epoch_cannot_replay() {
        let (_temp, store, session, initiating_lease) = prepared();
        let token = HandoffToken::generate().unwrap();
        let token_hex = token.expose_hex_for_private_transport();
        let reservation = store.reserve_handoff(&session, &initiating_lease, token.digest(),
            OperatorIdentityV1 { instance_nonce: operator().instance_nonce, process_id: 0 }, future_deadline()).unwrap();
        let wrong_token = HandoffClaimProof { session_id: session.id().into(), epoch: reservation.epoch,
            token: HandoffToken::generate().unwrap(), operator: operator() };
        assert!(matches!(store.mark_handoff_ready(&wrong_token), Err(HandoffProtocolError::TokenMismatch)));
        let wrong_nonce = HandoffClaimProof { session_id: session.id().into(), epoch: reservation.epoch,
            token: HandoffToken::from_hex(&token_hex).unwrap(),
            operator: OperatorIdentityV1 { instance_nonce: "other".into(), process_id: 71 } };
        assert!(matches!(store.mark_handoff_ready(&wrong_nonce), Err(HandoffProtocolError::OperatorMismatch)));
        let wrong_epoch = HandoffClaimProof { session_id: session.id().into(), epoch: reservation.epoch + 1,
            token: HandoffToken::from_hex(&token_hex).unwrap(), operator: operator() };
        assert!(matches!(store.mark_handoff_ready(&wrong_epoch), Err(HandoffProtocolError::EpochMismatch { .. })));
        store.revoke_handoff(&session, &initiating_lease, reservation.epoch, HandoffRevocationReasonV1::InitiatorFailure).unwrap();
        let replay = HandoffClaimProof { session_id: session.id().into(), epoch: reservation.epoch,
            token: HandoffToken::from_hex(&token_hex).unwrap(), operator: operator() };
        assert!(matches!(store.mark_handoff_ready(&replay), Err(HandoffProtocolError::InvalidState)));
    }

    #[test]
    fn expired_reservation_revokes_under_lock_and_permits_stale_recovery() {
        let (_temp, store, session, initiating_lease) = prepared();
        let token = HandoffToken::generate().unwrap();
        let mut reservation = store.reserve_handoff(
            &session,
            &initiating_lease,
            token.digest(),
            OperatorIdentityV1 { instance_nonce: operator().instance_nonce, process_id: 0 },
            future_deadline(),
        ).unwrap();
        reservation.expires_at_unix_nanos = now_unix_nanos().unwrap() - 1;
        store.write_handoff_authority(&session, &reservation).unwrap();
        drop(initiating_lease);
        let lease = store.acquire_lease(&session).expect("expired reservation must be revoked under acquired lock");
        drop(lease);
        assert!(matches!(store.load_handoff_authority(&session).unwrap().unwrap().state, HandoffAuthorityStateV1::Revoked { reason: HandoffRevocationReasonV1::Expired, .. }));
        assert_eq!(store.reconcile_stale_current_session(&session).unwrap().unwrap().state(), SessionState::Failed);
    }

    #[test]
    fn owned_proof_requires_the_exact_live_operator_lease_and_recovers_after_death() {
        let (_temp, store, session, initiating_lease) = prepared();
        let token = HandoffToken::generate().unwrap();
        let token_hex = token.expose_hex_for_private_transport();
        let reservation = store.reserve_handoff(&session, &initiating_lease, token.digest(),
            OperatorIdentityV1 { instance_nonce: operator().instance_nonce, process_id: 0 }, future_deadline()).unwrap();
        let proof = HandoffClaimProof { session_id: session.id().into(), epoch: reservation.epoch, token, operator: operator() };
        store.mark_handoff_ready(&proof).unwrap();
        drop(initiating_lease);
        let operator_lease = store.acquire_reserved_handoff(&proof).unwrap();
        let owned = store.publish_owned_handoff(&operator_lease, &proof).unwrap();
        assert!(matches!(owned.state, HandoffAuthorityStateV1::Owned { .. }));
        assert!(store.verify_live_owned_handoff(
            &session,
            reservation.epoch,
            &HandoffToken::from_hex(&token_hex).unwrap(),
            &operator(),
        ).unwrap());
        assert!(!store.verify_live_owned_handoff(
            &session,
            reservation.epoch,
            &HandoffToken::generate().unwrap(),
            &operator(),
        ).unwrap());
        drop(operator_lease);
        assert!(!store.verify_live_owned_handoff(
            &session,
            reservation.epoch,
            &HandoffToken::from_hex(&token_hex).unwrap(),
            &operator(),
        ).unwrap());
        let (recovery_lease, revoked) = store.recover_handoff_after_operator_death(
            &session,
            reservation.epoch,
            &operator(),
            HandoffRevocationReasonV1::OperatorExited,
        ).unwrap();
        assert!(matches!(revoked.state, HandoffAuthorityStateV1::Revoked {
            reason: HandoffRevocationReasonV1::OperatorExited,
            ..
        }));
        drop(recovery_lease);
        assert_eq!(store.reconcile_stale_current_session(&session).unwrap().unwrap().state(), SessionState::Failed);
    }

    #[test]
    fn ordinary_stale_reconciliation_revokes_dead_operator_authority() {
        let (_temp, store, session, initiating_lease) = prepared();
        let token = HandoffToken::generate().unwrap();
        let reservation = store
            .reserve_handoff(
                &session,
                &initiating_lease,
                token.digest(),
                OperatorIdentityV1 {
                    instance_nonce: operator().instance_nonce,
                    process_id: 0,
                },
                future_deadline(),
            )
            .unwrap();
        let proof = HandoffClaimProof {
            session_id: session.id().into(),
            epoch: reservation.epoch,
            token,
            operator: operator(),
        };
        store.mark_handoff_ready(&proof).unwrap();
        drop(initiating_lease);
        let operator_lease = store.acquire_reserved_handoff(&proof).unwrap();
        store.publish_owned_handoff(&operator_lease, &proof).unwrap();
        drop(operator_lease);

        let reconciled = store
            .reconcile_stale_current_session(&session)
            .unwrap()
            .unwrap();

        assert_eq!(reconciled.state(), SessionState::Failed);
        assert!(matches!(
            store.load_handoff_authority(&session).unwrap().unwrap().state,
            HandoffAuthorityStateV1::Revoked {
                reason: HandoffRevocationReasonV1::OperatorExited,
                ..
            }
        ));
    }
}
