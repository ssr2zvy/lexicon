//! Constrained operator diagnostics shared by the installed CLI, Framework,
//! and managed Core runners.
//!
//! A diagnostic code classifies one terminal, operator-relevant failure. It is
//! deliberately not a transcription of an arbitrary Rust error chain. The
//! associated summary is Core-authored static text so source-controlled values,
//! panic payloads, request data, and secrets cannot accidentally enter the
//! supported terminal surface.

use std::fmt;
use std::io;
use std::process::ExitCode;

use crate::session::SessionFailureCode;

/// Compatibility version for the stable diagnostic and milestone identity
/// registry. It is intentionally independent of the Core contract and runtime
/// invocation protocol versions.
pub const DIAGNOSTIC_CODE_REGISTRY_VERSION: u32 = 1;

/// Stable semantic identity for a terminal failure.
///
/// The `(namespace, name)` pair is a compatibility surface. An identifier must
/// never be reused for a different meaning within the same registry major.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct DiagnosticCode {
    namespace: &'static str,
    name: &'static str,
}

impl DiagnosticCode {
    const fn new(namespace: &'static str, name: &'static str) -> Self {
        Self { namespace, name }
    }

    pub const fn namespace(self) -> &'static str {
        self.namespace
    }

    pub const fn name(self) -> &'static str {
        self.name
    }

    /// Qualify an existing durable session failure without replacing its
    /// serialized snake_case identity.
    pub const fn from_session_failure(code: SessionFailureCode) -> Self {
        Self::new("session", code.identifier())
    }
}

impl fmt::Display for DiagnosticCode {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(formatter, "{}/{}", self.namespace, self.name)
    }
}

/// Broad process-control result. Detailed failure identity belongs in
/// [`DiagnosticCode`], not in the limited shell-status space.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ExitClass {
    Operational,
    Usage,
    Interrupted,
    Terminated,
}

impl ExitClass {
    pub fn exit_code(self) -> ExitCode {
        match self {
            Self::Operational => ExitCode::from(1),
            Self::Usage => ExitCode::from(2),
            Self::Interrupted => ExitCode::from(130),
            Self::Terminated => ExitCode::from(143),
        }
    }
}

/// Safe terminal projection of a typed internal failure.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Diagnostic {
    code: DiagnosticCode,
    safe_summary: &'static str,
    exit_class: ExitClass,
}

impl Diagnostic {
    pub const fn new(
        code: DiagnosticCode,
        safe_summary: &'static str,
        exit_class: ExitClass,
    ) -> Self {
        Self {
            code,
            safe_summary,
            exit_class,
        }
    }

    pub const fn operational(code: DiagnosticCode, safe_summary: &'static str) -> Self {
        Self::new(code, safe_summary, ExitClass::Operational)
    }

    pub const fn code(self) -> DiagnosticCode {
        self.code
    }

    pub const fn safe_summary(self) -> &'static str {
        self.safe_summary
    }

    pub const fn exit_class(self) -> ExitClass {
        self.exit_class
    }
}

/// Implemented only at boundaries that own terminal classification.
pub trait ReportableDiagnostic {
    fn diagnostic(&self) -> Diagnostic;

    /// A bounded secondary condition that occurred while handling the primary
    /// failure. It never replaces the primary terminal identity.
    fn secondary_diagnostic(&self) -> Option<Diagnostic> {
        None
    }
}

/// Render the one supported human terminal form.
pub fn write_terminal_diagnostic<W: io::Write>(
    writer: &mut W,
    diagnostic: Diagnostic,
) -> io::Result<()> {
    writeln!(
        writer,
        "[lexicon] ERROR [{}]: {}",
        diagnostic.code(),
        diagnostic.safe_summary()
    )
}

/// Render one primary terminal error and, when present, one subordinate coded
/// warning. This is the only supported projection for compound failures.
pub fn write_reportable_diagnostic<W, E>(writer: &mut W, error: &E) -> io::Result<()>
where
    W: io::Write,
    E: ReportableDiagnostic + ?Sized,
{
    write_terminal_diagnostic(writer, error.diagnostic())?;
    if let Some(secondary) = error.secondary_diagnostic() {
        write_warning(writer, secondary.code(), secondary.safe_summary())?;
    }
    Ok(())
}

/// Render a non-terminal, Core-classified warning without exposing its raw
/// internal cause chain.
pub fn write_warning<W: io::Write>(
    writer: &mut W,
    code: DiagnosticCode,
    safe_summary: &'static str,
) -> io::Result<()> {
    writeln!(writer, "[lexicon] WARNING [{code}]: {safe_summary}")
}

/// Write supplemental operator information associated with an already emitted
/// milestone. Failure to write this convenience output never changes the
/// authoritative committed outcome.
pub fn write_information<W: io::Write>(
    writer: &mut W,
    message: fmt::Arguments<'_>,
) -> io::Result<()> {
    writeln!(writer, "[lexicon] {message}")
}

/// A sparse successful lifecycle boundary. Milestones are operator progress,
/// not a second durable authority over sessions, transactions, or publication.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct MilestoneCode(DiagnosticCode);

impl MilestoneCode {
    const fn new(namespace: &'static str, name: &'static str) -> Self {
        Self(DiagnosticCode::new(namespace, name))
    }

    pub const fn namespace(self) -> &'static str {
        self.0.namespace()
    }

    pub const fn name(self) -> &'static str {
        self.0.name()
    }
}

impl fmt::Display for MilestoneCode {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(formatter)
    }
}

pub fn write_milestone<W: io::Write>(
    writer: &mut W,
    milestone: MilestoneCode,
    message: fmt::Arguments<'_>,
) -> io::Result<()> {
    writeln!(writer, "[lexicon] MILESTONE [{milestone}]: {message}")
}

/// Replace Rust's default hook before any source handler can run.
///
/// `catch_unwind` runs after the hook, so discarding a caught payload alone is
/// insufficient: the default hook would already have printed source-controlled
/// text. Managed runners therefore suppress hook output and let their typed
/// boundary (or the supervising parent for an abort) issue the safe diagnostic.
pub fn install_managed_runtime_panic_sanitizer() {
    std::panic::set_hook(Box::new(|_panic_information| {}));
}

/// Fixed summaries for the existing durable session code registry.
pub const fn session_failure_summary(code: SessionFailureCode) -> &'static str {
    match code {
        SessionFailureCode::SourceReturnedError => "The source handler returned an error.",
        SessionFailureCode::RuntimeInitializationFailed => {
            "The managed runtime could not initialize."
        }
        SessionFailureCode::RuntimeContextInvalid => "The managed runtime context is invalid.",
        SessionFailureCode::HandlerStateUnavailable => {
            "Required durable handler state is unavailable."
        }
        SessionFailureCode::LaunchFailed => "The managed runtime could not be launched.",
        SessionFailureCode::AbnormalTermination => {
            "The managed runtime terminated abnormally."
        }
        SessionFailureCode::StaleOwnership => {
            "A previous runtime stopped without completing its session."
        }
        SessionFailureCode::InvocationConstructionFailed => {
            "The managed runtime invocation could not be constructed."
        }
        SessionFailureCode::InvocationEncodingFailed => {
            "The managed runtime invocation could not be encoded."
        }
        SessionFailureCode::ExecutableIntegrityFailed => {
            "The admitted runtime executable failed its integrity check."
        }
        SessionFailureCode::ZeroExitWithoutCompletion => {
            "The runtime exited successfully without completing its session."
        }
        SessionFailureCode::NonzeroExitWithoutFailureRecord => {
            "The runtime failed without recording a terminal session failure."
        }
        SessionFailureCode::ProcessingTransactionDiscoveryFailed => {
            "Processing could not discover valid raw transactions."
        }
        SessionFailureCode::ProcessingTransactionProvenanceFailed => {
            "A raw transaction failed processing provenance validation."
        }
        SessionFailureCode::ProcessingDatabasePathInvalid => {
            "The processed database path failed validation."
        }
        SessionFailureCode::ProcessingDatabaseOpenFailed => {
            "The processed database could not be opened safely."
        }
        SessionFailureCode::ProcessingDatabaseTransactionFailed => {
            "The processing database transaction failed."
        }
        SessionFailureCode::ProcessingContextConstructionFailed => {
            "The processing context could not be constructed safely."
        }
        SessionFailureCode::HandlerPanicked => "The source handler terminated unexpectedly.",
    }
}

/// Stable terminal code registry. Codes describe actionable semantic classes,
/// not every nested `io::Error` or retry attempt.
pub mod codes {
    use super::{DiagnosticCode, MilestoneCode};

    pub const CLI_INVALID_ARGUMENTS: DiagnosticCode =
        DiagnosticCode::new("cli", "invalid_arguments");
    pub const CLI_HELP_OUTPUT_FAILED: DiagnosticCode =
        DiagnosticCode::new("cli", "help_output_failed");
    pub const CLI_PROTOCOL_INVALID: DiagnosticCode =
        DiagnosticCode::new("cli", "protocol_invalid");

    pub const PROJECT_INITIALIZATION_FAILED: DiagnosticCode =
        DiagnosticCode::new("project", "initialization_failed");
    pub const PROJECT_CURRENT_DIRECTORY_FAILED: DiagnosticCode =
        DiagnosticCode::new("project", "current_directory_failed");
    pub const PROJECT_DISCOVERY_FAILED: DiagnosticCode =
        DiagnosticCode::new("project", "discovery_failed");
    pub const PROJECT_CONFIGURATION_INVALID: DiagnosticCode =
        DiagnosticCode::new("project", "configuration_invalid");
    pub const PROJECT_LAYOUT_INVALID: DiagnosticCode =
        DiagnosticCode::new("project", "layout_invalid");

    pub const SOURCE_NAME_INVALID: DiagnosticCode =
        DiagnosticCode::new("source", "name_invalid");
    pub const SOURCE_PROTOCOL_INVALID: DiagnosticCode =
        DiagnosticCode::new("source", "protocol_invalid");
    pub const SOURCE_DESTINATION_INVALID: DiagnosticCode =
        DiagnosticCode::new("source", "destination_invalid");
    pub const SOURCE_DESTINATION_EXISTS: DiagnosticCode =
        DiagnosticCode::new("source", "destination_exists");
    pub const SOURCE_SCAFFOLD_IO_FAILED: DiagnosticCode =
        DiagnosticCode::new("source", "scaffold_io_failed");
    pub const SOURCE_CORE_MATERIALIZATION_FAILED: DiagnosticCode =
        DiagnosticCode::new("source", "core_materialization_failed");
    pub const SOURCE_SESSION_IDENTITY_FAILED: DiagnosticCode =
        DiagnosticCode::new("source", "session_identity_failed");
    pub const SOURCE_SESSION_ENCODING_FAILED: DiagnosticCode =
        DiagnosticCode::new("source", "session_encoding_failed");
    pub const SOURCE_PUBLICATION_FAILED: DiagnosticCode =
        DiagnosticCode::new("source", "publication_failed");
    pub const SOURCE_NOT_FOUND: DiagnosticCode = DiagnosticCode::new("source", "not_found");
    pub const SOURCE_PROTOCOL_LAYOUT_MISSING: DiagnosticCode =
        DiagnosticCode::new("source", "protocol_layout_missing");
    pub const SOURCE_MANIFEST_MISSING: DiagnosticCode =
        DiagnosticCode::new("source", "manifest_missing");
    pub const SOURCE_MANIFEST_INVALID: DiagnosticCode =
        DiagnosticCode::new("source", "manifest_invalid");
    pub const SOURCE_OPERATION_LAYOUT_MISSING: DiagnosticCode =
        DiagnosticCode::new("source", "operation_layout_missing");

    pub const BUILD_SOURCE_LOCATION_INVALID: DiagnosticCode =
        DiagnosticCode::new("build", "source_location_invalid");
    pub const BUILD_WORKSPACE_INVALID: DiagnosticCode =
        DiagnosticCode::new("build", "workspace_invalid");
    pub const BUILD_METADATA_FAILED: DiagnosticCode =
        DiagnosticCode::new("build", "metadata_failed");
    pub const BUILD_CARGO_FAILED: DiagnosticCode =
        DiagnosticCode::new("build", "cargo_failed");
    pub const BUILD_ACQUISITION_VERIFICATION_FAILED: DiagnosticCode =
        DiagnosticCode::new("build", "acquisition_verification_failed");
    pub const BUILD_PROCESSING_VERIFICATION_FAILED: DiagnosticCode =
        DiagnosticCode::new("build", "processing_verification_failed");
    pub const BUILD_ACQUISITION_STAGING_FAILED: DiagnosticCode =
        DiagnosticCode::new("build", "acquisition_staging_failed");
    pub const BUILD_PROCESSING_STAGING_FAILED: DiagnosticCode =
        DiagnosticCode::new("build", "processing_staging_failed");
    pub const BUILD_PUBLICATION_FAILED: DiagnosticCode =
        DiagnosticCode::new("build", "publication_failed");
    pub const BUILD_LOCKFILE_MISSING: DiagnosticCode =
        DiagnosticCode::new("build", "lockfile_missing");
    pub const BUILD_LOCKFILE_READ_FAILED: DiagnosticCode =
        DiagnosticCode::new("build", "lockfile_read_failed");
    pub const BUILD_LOCKFILE_MODIFIED: DiagnosticCode =
        DiagnosticCode::new("build", "lockfile_modified");
    pub const BUILD_RUNTIME_DIRECTORY_FAILED: DiagnosticCode =
        DiagnosticCode::new("build", "runtime_directory_failed");
    pub const BUILD_TEMPORARY_DIRECTORY_FAILED: DiagnosticCode =
        DiagnosticCode::new("build", "temporary_directory_failed");
    pub const BUILD_DISCOVERY_LAYOUT_INVALID: DiagnosticCode =
        DiagnosticCode::new("build", "discovery_layout_invalid");
    pub const BUILD_TARGETS_FAILED: DiagnosticCode =
        DiagnosticCode::new("build", "targets_failed");
    pub const BUILD_POST_PUBLICATION_INCOMPLETE: DiagnosticCode =
        DiagnosticCode::new("build", "post_publication_incomplete");

    pub const OPERATOR_HOST_ENCODING_FAILED: DiagnosticCode =
        DiagnosticCode::new("operator", "host_encoding_failed");
    pub const OPERATOR_HOST_DECODING_FAILED: DiagnosticCode =
        DiagnosticCode::new("operator", "host_decoding_failed");
    pub const OPERATOR_HOST_REEXEC_FAILED: DiagnosticCode =
        DiagnosticCode::new("operator", "host_reexec_failed");
    pub const OPERATOR_HOST_OWNERSHIP_CHECK_FAILED: DiagnosticCode =
        DiagnosticCode::new("operator", "ownership_check_failed");
    pub const OPERATOR_HOST_EXITED_EARLY: DiagnosticCode =
        DiagnosticCode::new("operator", "host_exited_early");
    pub const OPERATOR_HOST_OWNERSHIP_TIMEOUT: DiagnosticCode =
        DiagnosticCode::new("operator", "ownership_timeout");
    pub const OPERATOR_HOST_HANDOFF_FAILED: DiagnosticCode =
        DiagnosticCode::new("operator", "handoff_failed");
    pub const OPERATOR_HOST_HANDOFF_CLEANUP_FAILED: DiagnosticCode =
        DiagnosticCode::new("operator", "handoff_cleanup_failed");
    pub const OPERATOR_CANCELLED: DiagnosticCode =
        DiagnosticCode::new("operator", "cancelled");

    pub const RUNTIME_BUNDLE_MISSING: DiagnosticCode =
        DiagnosticCode::new("runtime", "bundle_missing");
    pub const RUNTIME_PAIR_ADMISSION_FAILED: DiagnosticCode =
        DiagnosticCode::new("runtime", "pair_admission_failed");
    pub const RUNTIME_BUNDLE_ADMISSION_FAILED: DiagnosticCode =
        DiagnosticCode::new("runtime", "bundle_admission_failed");
    pub const RUNTIME_PROBE_FAILED: DiagnosticCode =
        DiagnosticCode::new("runtime", "probe_failed");
    pub const RUNTIME_IDENTITY_MISMATCH: DiagnosticCode =
        DiagnosticCode::new("runtime", "identity_mismatch");
    pub const RUNTIME_SUPERVISION_FAILED: DiagnosticCode =
        DiagnosticCode::new("runtime", "supervision_failed");
    pub const RUNTIME_CONTROL_FAILED: DiagnosticCode =
        DiagnosticCode::new("runtime", "control_failed");
    pub const RUNTIME_PROBE_ARGUMENTS_INVALID: DiagnosticCode =
        DiagnosticCode::new("runtime", "probe_arguments_invalid");
    pub const RUNTIME_PROBE_ENCODING_FAILED: DiagnosticCode =
        DiagnosticCode::new("runtime", "probe_encoding_failed");
    pub const RUNTIME_PROBE_OUTPUT_FAILED: DiagnosticCode =
        DiagnosticCode::new("runtime", "probe_output_failed");

    pub const SESSION_RECONCILIATION_FAILED: DiagnosticCode =
        DiagnosticCode::new("session", "reconciliation_failed");
    pub const SESSION_SELECTION_FAILED: DiagnosticCode =
        DiagnosticCode::new("session", "selection_failed");
    pub const SESSION_RESUME_UNAVAILABLE: DiagnosticCode =
        DiagnosticCode::new("session", "resume_unavailable");
    pub const SESSION_ABANDONMENT_FAILED: DiagnosticCode =
        DiagnosticCode::new("session", "abandonment_failed");
    pub const SESSION_PREPARATION_FAILED: DiagnosticCode =
        DiagnosticCode::new("session", "preparation_failed");
    pub const SESSION_FAILURE_PERSISTENCE_FAILED: DiagnosticCode =
        DiagnosticCode::new("session", "failure_persistence_failed");
    pub const SESSION_RECORD_MISSING: DiagnosticCode =
        DiagnosticCode::new("session", "record_missing");
    pub const SESSION_RECORD_CORRUPT: DiagnosticCode =
        DiagnosticCode::new("session", "record_corrupt");
    pub const SESSION_IDENTITY_MISMATCH: DiagnosticCode =
        DiagnosticCode::new("session", "identity_mismatch");
    pub const SESSION_ROOT_SUMMARY_FAILED: DiagnosticCode =
        DiagnosticCode::new("session", "root_summary_failed");
    pub const SESSION_EXIT_STATE_DISAGREEMENT: DiagnosticCode =
        DiagnosticCode::new("session", "exit_state_disagreement");

    pub const PROCESSING_POST_PUBLICATION_INCOMPLETE: DiagnosticCode =
        DiagnosticCode::new("processing", "post_publication_incomplete");

    pub const INTERNAL_BOUNDARY_VIOLATION: DiagnosticCode =
        DiagnosticCode::new("internal", "boundary_violation");

    pub const PROJECT_INITIALIZED: MilestoneCode =
        MilestoneCode::new("project", "initialized");
    pub const SOURCE_SCAFFOLD_PUBLISHED: MilestoneCode =
        MilestoneCode::new("source", "scaffold_published");
    pub const RUNTIME_PAIR_PUBLISHED: MilestoneCode =
        MilestoneCode::new("build", "runtime_pair_published");
    pub const BUILD_COMPLETED: MilestoneCode = MilestoneCode::new("build", "completed");
    pub const SESSION_BACKGROUND_HANDOFF_ACCEPTED: MilestoneCode =
        MilestoneCode::new("session", "background_handoff_accepted");
    pub const SESSION_SUCCEEDED: MilestoneCode = MilestoneCode::new("session", "succeeded");
}

#[cfg(test)]
mod tests {
    use std::collections::HashSet;

    use super::{
        DIAGNOSTIC_CODE_REGISTRY_VERSION, Diagnostic, DiagnosticCode, ExitClass,
        MilestoneCode, ReportableDiagnostic, codes,
        session_failure_summary, write_reportable_diagnostic, write_terminal_diagnostic,
    };
    use crate::session::SessionFailureCode;

    const STATIC_CODES: &[DiagnosticCode] = &[
        codes::CLI_INVALID_ARGUMENTS,
        codes::CLI_HELP_OUTPUT_FAILED,
        codes::CLI_PROTOCOL_INVALID,
        codes::PROJECT_INITIALIZATION_FAILED,
        codes::PROJECT_CURRENT_DIRECTORY_FAILED,
        codes::PROJECT_DISCOVERY_FAILED,
        codes::PROJECT_CONFIGURATION_INVALID,
        codes::PROJECT_LAYOUT_INVALID,
        codes::SOURCE_NAME_INVALID,
        codes::SOURCE_PROTOCOL_INVALID,
        codes::SOURCE_DESTINATION_INVALID,
        codes::SOURCE_DESTINATION_EXISTS,
        codes::SOURCE_SCAFFOLD_IO_FAILED,
        codes::SOURCE_CORE_MATERIALIZATION_FAILED,
        codes::SOURCE_SESSION_IDENTITY_FAILED,
        codes::SOURCE_SESSION_ENCODING_FAILED,
        codes::SOURCE_PUBLICATION_FAILED,
        codes::SOURCE_NOT_FOUND,
        codes::SOURCE_PROTOCOL_LAYOUT_MISSING,
        codes::SOURCE_MANIFEST_MISSING,
        codes::SOURCE_MANIFEST_INVALID,
        codes::SOURCE_OPERATION_LAYOUT_MISSING,
        codes::BUILD_SOURCE_LOCATION_INVALID,
        codes::BUILD_WORKSPACE_INVALID,
        codes::BUILD_METADATA_FAILED,
        codes::BUILD_CARGO_FAILED,
        codes::BUILD_ACQUISITION_VERIFICATION_FAILED,
        codes::BUILD_PROCESSING_VERIFICATION_FAILED,
        codes::BUILD_ACQUISITION_STAGING_FAILED,
        codes::BUILD_PROCESSING_STAGING_FAILED,
        codes::BUILD_PUBLICATION_FAILED,
        codes::BUILD_LOCKFILE_MISSING,
        codes::BUILD_LOCKFILE_READ_FAILED,
        codes::BUILD_LOCKFILE_MODIFIED,
        codes::BUILD_RUNTIME_DIRECTORY_FAILED,
        codes::BUILD_TEMPORARY_DIRECTORY_FAILED,
        codes::BUILD_DISCOVERY_LAYOUT_INVALID,
        codes::BUILD_TARGETS_FAILED,
        codes::BUILD_POST_PUBLICATION_INCOMPLETE,
        codes::OPERATOR_HOST_ENCODING_FAILED,
        codes::OPERATOR_HOST_DECODING_FAILED,
        codes::OPERATOR_HOST_REEXEC_FAILED,
        codes::OPERATOR_HOST_OWNERSHIP_CHECK_FAILED,
        codes::OPERATOR_HOST_EXITED_EARLY,
        codes::OPERATOR_HOST_OWNERSHIP_TIMEOUT,
        codes::OPERATOR_HOST_HANDOFF_FAILED,
        codes::OPERATOR_HOST_HANDOFF_CLEANUP_FAILED,
        codes::OPERATOR_CANCELLED,
        codes::RUNTIME_BUNDLE_MISSING,
        codes::RUNTIME_PAIR_ADMISSION_FAILED,
        codes::RUNTIME_BUNDLE_ADMISSION_FAILED,
        codes::RUNTIME_PROBE_FAILED,
        codes::RUNTIME_IDENTITY_MISMATCH,
        codes::RUNTIME_SUPERVISION_FAILED,
        codes::RUNTIME_CONTROL_FAILED,
        codes::RUNTIME_PROBE_ARGUMENTS_INVALID,
        codes::RUNTIME_PROBE_ENCODING_FAILED,
        codes::RUNTIME_PROBE_OUTPUT_FAILED,
        codes::SESSION_RECONCILIATION_FAILED,
        codes::SESSION_SELECTION_FAILED,
        codes::SESSION_RESUME_UNAVAILABLE,
        codes::SESSION_ABANDONMENT_FAILED,
        codes::SESSION_PREPARATION_FAILED,
        codes::SESSION_FAILURE_PERSISTENCE_FAILED,
        codes::SESSION_RECORD_MISSING,
        codes::SESSION_RECORD_CORRUPT,
        codes::SESSION_IDENTITY_MISMATCH,
        codes::SESSION_ROOT_SUMMARY_FAILED,
        codes::SESSION_EXIT_STATE_DISAGREEMENT,
        codes::PROCESSING_POST_PUBLICATION_INCOMPLETE,
        codes::INTERNAL_BOUNDARY_VIOLATION,
    ];

    const SESSION_CODES: &[SessionFailureCode] = &[
        SessionFailureCode::SourceReturnedError,
        SessionFailureCode::RuntimeInitializationFailed,
        SessionFailureCode::RuntimeContextInvalid,
        SessionFailureCode::HandlerStateUnavailable,
        SessionFailureCode::LaunchFailed,
        SessionFailureCode::AbnormalTermination,
        SessionFailureCode::StaleOwnership,
        SessionFailureCode::InvocationConstructionFailed,
        SessionFailureCode::InvocationEncodingFailed,
        SessionFailureCode::ExecutableIntegrityFailed,
        SessionFailureCode::ZeroExitWithoutCompletion,
        SessionFailureCode::NonzeroExitWithoutFailureRecord,
        SessionFailureCode::ProcessingTransactionDiscoveryFailed,
        SessionFailureCode::ProcessingTransactionProvenanceFailed,
        SessionFailureCode::ProcessingDatabasePathInvalid,
        SessionFailureCode::ProcessingDatabaseOpenFailed,
        SessionFailureCode::ProcessingDatabaseTransactionFailed,
        SessionFailureCode::ProcessingContextConstructionFailed,
        SessionFailureCode::HandlerPanicked,
    ];

    const MILESTONE_CODES: &[MilestoneCode] = &[
        codes::PROJECT_INITIALIZED,
        codes::SOURCE_SCAFFOLD_PUBLISHED,
        codes::RUNTIME_PAIR_PUBLISHED,
        codes::BUILD_COMPLETED,
        codes::SESSION_BACKGROUND_HANDOFF_ACCEPTED,
        codes::SESSION_SUCCEEDED,
    ];

    #[test]
    fn stable_code_registry_is_unique_and_well_formed() {
        assert!(DIAGNOSTIC_CODE_REGISTRY_VERSION > 0);
        let mut seen = HashSet::new();
        for code in STATIC_CODES.iter().copied().chain(
            SESSION_CODES
                .iter()
                .copied()
                .map(DiagnosticCode::from_session_failure),
        ) {
            assert!(!code.namespace().is_empty());
            assert!(!code.name().is_empty());
            assert!(
                code.namespace()
                    .bytes()
                    .all(|byte| byte.is_ascii_lowercase() || byte == b'_')
            );
            assert!(
                code.name()
                    .bytes()
                    .all(|byte| byte.is_ascii_lowercase() || byte == b'_')
            );
            assert!(seen.insert(code.to_string()), "duplicate code: {code}");
        }
        for milestone in MILESTONE_CODES {
            assert!(!milestone.namespace().is_empty());
            assert!(!milestone.name().is_empty());
            assert!(
                milestone
                    .namespace()
                    .bytes()
                    .all(|byte| byte.is_ascii_lowercase() || byte == b'_')
            );
            assert!(
                milestone
                    .name()
                    .bytes()
                    .all(|byte| byte.is_ascii_lowercase() || byte == b'_')
            );
            assert!(
                seen.insert(milestone.to_string()),
                "duplicate diagnostic or milestone code: {milestone}"
            );
        }
    }

    #[test]
    fn every_session_code_has_a_safe_summary() {
        for code in SESSION_CODES {
            assert!(!session_failure_summary(*code).is_empty());
        }
    }

    #[test]
    fn renderer_has_one_stable_coded_line() {
        let mut output = Vec::new();
        write_terminal_diagnostic(
            &mut output,
            Diagnostic::new(
                codes::RUNTIME_BUNDLE_ADMISSION_FAILED,
                "A published runtime bundle failed admission.",
                ExitClass::Operational,
            ),
        )
        .unwrap();

        assert_eq!(
            String::from_utf8(output).unwrap(),
            "[lexicon] ERROR [runtime/bundle_admission_failed]: A published runtime bundle failed admission.\n"
        );
    }

    #[test]
    fn compound_renderer_preserves_primary_and_marks_secondary_as_warning() {
        struct CompoundFailure;

        impl ReportableDiagnostic for CompoundFailure {
            fn diagnostic(&self) -> Diagnostic {
                Diagnostic::operational(
                    codes::RUNTIME_BUNDLE_ADMISSION_FAILED,
                    "A published runtime bundle failed admission.",
                )
            }

            fn secondary_diagnostic(&self) -> Option<Diagnostic> {
                Some(Diagnostic::operational(
                    codes::SESSION_FAILURE_PERSISTENCE_FAILED,
                    "The terminal session failure could not also be persisted.",
                ))
            }
        }

        let mut output = Vec::new();
        write_reportable_diagnostic(&mut output, &CompoundFailure).unwrap();

        assert_eq!(
            String::from_utf8(output).unwrap(),
            concat!(
                "[lexicon] ERROR [runtime/bundle_admission_failed]: A published runtime bundle failed admission.\n",
                "[lexicon] WARNING [session/failure_persistence_failed]: The terminal session failure could not also be persisted.\n",
            )
        );
    }

    const PANIC_HOOK_CHILD_ENV: &str = "LEXICON_TEST_PANIC_HOOK_CHILD";
    const PANIC_HOOK_SECRET: &str = "source-controlled-panic-secret";

    #[test]
    fn managed_runtime_panic_hook_suppresses_payload_in_subprocess() {
        if std::env::var_os(PANIC_HOOK_CHILD_ENV).is_some() {
            super::install_managed_runtime_panic_sanitizer();
            panic!("{PANIC_HOOK_SECRET}");
        }

        let output = std::process::Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "diagnostic::tests::managed_runtime_panic_hook_suppresses_payload_in_subprocess",
                "--nocapture",
            ])
            .env(PANIC_HOOK_CHILD_ENV, "1")
            .output()
            .unwrap();

        assert!(!output.status.success(), "the child panic must remain a failure");
        let stdout = String::from_utf8_lossy(&output.stdout);
        let stderr = String::from_utf8_lossy(&output.stderr);
        assert!(!stdout.contains(PANIC_HOOK_SECRET), "stdout leaked panic payload");
        assert!(!stderr.contains(PANIC_HOOK_SECRET), "stderr leaked panic payload");
    }
}
