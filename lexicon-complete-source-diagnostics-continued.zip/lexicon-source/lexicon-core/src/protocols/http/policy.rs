use std::fmt;
use std::time::Duration;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HttpRedirectPolicy { None, Follow { maximum: u32 } }

impl HttpRedirectPolicy {
    pub const DEFAULT_MAXIMUM_REDIRECTS: u32 = 10;
    pub const fn none() -> Self { Self::None }
    pub fn follow(maximum: u32) -> Result<Self, HttpPolicyError> {
        if maximum == 0 { return Err(HttpPolicyError::InvalidRedirectMaximum); }
        Ok(Self::Follow { maximum })
    }
    pub(crate) fn max_redirects(self) -> u32 {
        match self { Self::None => 0, Self::Follow { maximum } => maximum }
    }
}

impl Default for HttpRedirectPolicy { fn default() -> Self { Self::None } }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HttpRetryDelayPolicy {
    None,
    Fixed(Duration),
    Exponential { initial: Duration, maximum: Duration },
}

impl HttpRetryDelayPolicy {
    fn delay_for_retry(self, retry_index: u32) -> Duration {
        match self {
            Self::None => Duration::ZERO,
            Self::Fixed(delay) => delay,
            Self::Exponential { initial, maximum } => {
                let shift = retry_index.saturating_sub(1).min(31);
                initial.saturating_mul(1u32 << shift).min(maximum)
            }
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct HttpRetryPolicy {
    maximum_attempts: u32,
    retryable_transport_failures: bool,
    retryable_statuses: Vec<u16>,
    permitted_methods: Vec<String>,
    delay: HttpRetryDelayPolicy,
    honor_retry_after: bool,
    total_elapsed_budget: Duration,
}

impl HttpRetryPolicy {
    pub const DEFAULT_MAXIMUM_ATTEMPTS: u32 = 3;
    pub const DEFAULT_TOTAL_ELAPSED_BUDGET: Duration = Duration::from_secs(60);

    pub const fn none() -> Self {
        Self {
            maximum_attempts: 1,
            retryable_transport_failures: false,
            retryable_statuses: Vec::new(),
            permitted_methods: Vec::new(),
            delay: HttpRetryDelayPolicy::None,
            honor_retry_after: false,
            total_elapsed_budget: Duration::ZERO,
        }
    }

    pub fn transient(maximum_attempts: u32) -> Result<Self, HttpPolicyError> {
        if maximum_attempts == 0 { return Err(HttpPolicyError::InvalidRetryMaximumAttempts); }
        Ok(Self {
            maximum_attempts,
            retryable_transport_failures: true,
            retryable_statuses: vec![408, 425, 429, 500, 502, 503, 504],
            permitted_methods: vec![
                "GET".into(), "HEAD".into(), "PUT".into(), "DELETE".into(),
                "OPTIONS".into(), "TRACE".into(),
            ],
            delay: HttpRetryDelayPolicy::Exponential {
                initial: Duration::from_millis(100),
                maximum: Duration::from_secs(5),
            },
            honor_retry_after: true,
            total_elapsed_budget: Self::DEFAULT_TOTAL_ELAPSED_BUDGET,
        })
    }

    pub fn custom<M, S>(
        maximum_attempts: u32,
        retryable_transport_failures: bool,
        retryable_statuses: impl Into<Vec<u16>>,
        permitted_methods: M,
        delay: HttpRetryDelayPolicy,
        honor_retry_after: bool,
        total_elapsed_budget: Duration,
    ) -> Result<Self, HttpPolicyError>
    where
        M: IntoIterator<Item = S>,
        S: AsRef<str>,
    {
        if maximum_attempts == 0 { return Err(HttpPolicyError::InvalidRetryMaximumAttempts); }
        if maximum_attempts > 1 && total_elapsed_budget.is_zero() {
            return Err(HttpPolicyError::InvalidRetryElapsedBudget);
        }
        if let HttpRetryDelayPolicy::Exponential { initial, maximum } = delay {
            if initial.is_zero() || maximum < initial {
                return Err(HttpPolicyError::InvalidRetryDelay);
            }
        }
        let mut statuses = retryable_statuses.into();
        if statuses.iter().any(|status| !(100..=599).contains(status)) {
            return Err(HttpPolicyError::InvalidRetryStatus);
        }
        statuses.sort_unstable();
        statuses.dedup();
        let mut methods = Vec::new();
        for method in permitted_methods {
            let method = method.as_ref().trim().to_ascii_uppercase();
            if method.is_empty() || reqwest::Method::from_bytes(method.as_bytes()).is_err() {
                return Err(HttpPolicyError::InvalidRetryMethod);
            }
            if !methods.contains(&method) { methods.push(method); }
        }
        if maximum_attempts > 1 && methods.is_empty() {
            return Err(HttpPolicyError::MissingRetryMethods);
        }
        if maximum_attempts > 1 && !retryable_transport_failures && statuses.is_empty() {
            return Err(HttpPolicyError::MissingRetryTrigger);
        }
        Ok(Self {
            maximum_attempts,
            retryable_transport_failures,
            retryable_statuses: statuses,
            permitted_methods: methods,
            delay,
            honor_retry_after,
            total_elapsed_budget,
        })
    }

    pub const fn maximum_attempts(&self) -> u32 { self.maximum_attempts }
    pub const fn retryable_transport_failures(&self) -> bool { self.retryable_transport_failures }
    pub fn retryable_statuses(&self) -> &[u16] { &self.retryable_statuses }
    pub fn permitted_methods(&self) -> &[String] { &self.permitted_methods }
    pub const fn delay_policy(&self) -> HttpRetryDelayPolicy { self.delay }
    pub const fn honors_retry_after(&self) -> bool { self.honor_retry_after }
    pub const fn total_elapsed_budget(&self) -> Duration { self.total_elapsed_budget }
    pub(crate) fn permits_method(&self, method: &str) -> bool {
        self.maximum_attempts == 1 || self.permitted_methods.iter().any(|item| item == method)
    }
    pub(crate) fn should_retry_status(&self, status: u16) -> bool {
        self.retryable_statuses.contains(&status)
    }
    pub(crate) fn delay_before_retry(
        &self,
        retry_index: u32,
        retry_after: Option<Duration>,
    ) -> Duration {
        if self.honor_retry_after {
            if let Some(retry_after) = retry_after { return retry_after; }
        }
        self.delay.delay_for_retry(retry_index)
    }
}

impl Default for HttpRetryPolicy { fn default() -> Self { Self::none() } }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HttpPolicyError {
    InvalidRedirectMaximum,
    InvalidRetryMaximumAttempts,
    InvalidRetryMethod,
    InvalidRetryElapsedBudget,
    InvalidRetryStatus,
    InvalidRetryDelay,
    MissingRetryMethods,
    MissingRetryTrigger,
}

impl fmt::Display for HttpPolicyError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        formatter.write_str(match self {
            Self::InvalidRedirectMaximum => "invalid redirect policy: maximum redirects must be greater than zero",
            Self::InvalidRetryMaximumAttempts => "invalid retry policy: maximum attempts must be greater than zero",
            Self::InvalidRetryMethod => "invalid retry policy: permitted method is invalid",
            Self::InvalidRetryElapsedBudget => "invalid retry policy: multi-attempt policy requires a positive elapsed-time budget",
            Self::InvalidRetryStatus => "invalid retry policy: retryable status is not an HTTP status code",
            Self::InvalidRetryDelay => "invalid retry policy: exponential delay must be positive and bounded",
            Self::MissingRetryMethods => "invalid retry policy: multi-attempt policy requires permitted methods",
            Self::MissingRetryTrigger => "invalid retry policy: multi-attempt policy requires a retry trigger",
        })
    }
}

impl std::error::Error for HttpPolicyError {}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn transient_policy_permits_only_default_idempotent_methods() {
        let policy = HttpRetryPolicy::transient(3).unwrap();
        for method in ["GET", "HEAD", "PUT", "DELETE", "OPTIONS", "TRACE"] {
            assert!(policy.permits_method(method));
        }
        for method in ["POST", "PATCH", "CONNECT"] {
            assert!(!policy.permits_method(method));
        }
    }

    #[test]
    fn fixed_exponential_and_retry_after_delays_are_exact() {
        let fixed = HttpRetryPolicy::custom(
            3, false, vec![503], ["GET"],
            HttpRetryDelayPolicy::Fixed(Duration::from_millis(7)), false,
            Duration::from_secs(1),
        ).unwrap();
        assert_eq!(fixed.delay_before_retry(1, Some(Duration::from_secs(9))), Duration::from_millis(7));
        let exponential = HttpRetryPolicy::custom(
            4, false, vec![503], ["GET"],
            HttpRetryDelayPolicy::Exponential {
                initial: Duration::from_millis(5), maximum: Duration::from_millis(12),
            }, true, Duration::from_secs(1),
        ).unwrap();
        assert_eq!(exponential.delay_before_retry(1, None), Duration::from_millis(5));
        assert_eq!(exponential.delay_before_retry(2, None), Duration::from_millis(10));
        assert_eq!(exponential.delay_before_retry(3, None), Duration::from_millis(12));
        assert_eq!(exponential.delay_before_retry(1, Some(Duration::from_millis(3))), Duration::from_millis(3));
    }

    #[test]
    fn malformed_custom_retry_policies_fail_closed() {
        assert!(matches!(HttpRetryPolicy::custom(
            2, true, Vec::<u16>::new(), std::iter::empty::<&str>(),
            HttpRetryDelayPolicy::None, false, Duration::from_secs(1),
        ), Err(HttpPolicyError::MissingRetryMethods)));
        assert!(matches!(HttpRetryPolicy::custom(
            2, false, vec![99], ["GET"], HttpRetryDelayPolicy::None, false,
            Duration::from_secs(1),
        ), Err(HttpPolicyError::InvalidRetryStatus)));
    }
}
