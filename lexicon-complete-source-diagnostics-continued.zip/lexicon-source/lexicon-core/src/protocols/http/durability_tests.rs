use std::collections::HashSet;
use std::sync::Arc;

use crate::protocols::http::request::HttpRequest;
use crate::protocols::http::test_support::{
    BlockingHttpRecorderObserver, FailingHttpRecorderObserver, ScriptedStep,
};
use crate::protocols::http::transaction::error::HttpRecorderError;
use crate::protocols::http::transaction::metadata::{
    HttpTransactionAdmissionError, MAX_HTTP_TRANSACTION_METADATA_BYTES,
    admit_transaction_from_disk,
};
use crate::protocols::http::transaction::recorder::{
    HttpRecorderPhase, NoopHttpRecorderObserver, RecordedAttemptContext,
    record_transaction_attempt_observed,
};
use crate::protocols::http::transaction::HttpAttemptIdentity;
use crate::protocols::http::transport::ReqwestHttpTransport;

struct BlockedRecorderWorker {
    observer: Arc<BlockingHttpRecorderObserver>,
    join: Option<std::thread::JoinHandle<Result<
        crate::protocols::http::transaction::FinalizedRecordedAttempt,
        HttpRecorderError,
    >>>,
}

impl BlockedRecorderWorker {
    fn finish(mut self) -> crate::protocols::http::transaction::FinalizedRecordedAttempt {
        self.observer.release();
        self.join.take().unwrap().join().expect("recorder thread panicked")
            .expect("recorded attempt")
    }
}

impl Drop for BlockedRecorderWorker {
    fn drop(&mut self) {
        self.observer.release();
        if let Some(join) = self.join.take() {
            let _ = join.join();
        }
    }
}

fn attempt(raw_root: &std::path::Path) -> RecordedAttemptContext {
    RecordedAttemptContext {
        session_id: "http-durability-session".to_owned(),
        raw_data_root: raw_root.to_path_buf(),
        logical_request_key: None,
        parent_transaction_id: None,
        attempt_identity: HttpAttemptIdentity::new(1, 0, 0).expect("attempt identity"),
        sensitive_query_names: HashSet::from(["api_key".to_owned()]),
        sensitive_header_names: HashSet::from(["x-api-key".to_owned()]),
    }
}

#[test]
fn request_tree_is_durable_and_visible_before_network_dispatch() {
    let server = Arc::new(crate::protocols::http::test_support::start_scripted_server(vec![
        ScriptedStep::Respond { status: 200, body: b"response".to_vec() },
    ]));
    let temp = tempfile::tempdir().expect("tempdir");
    let raw_root = temp.path().join("raw");
    std::fs::create_dir(&raw_root).expect("raw root");
    let secret = "request-secret-sentinel";
    let request = HttpRequest::post(format!("{}/submit?api_key={secret}", server.base_url))
        .expect("request")
        .sensitive_query_name("api_key").expect("sensitive query")
        .sensitive_header("X-Api-Key", secret).expect("sensitive header")
        .body_bytes(b"exact-request-body\0\xff".to_vec())
        .finalize().expect("finalized request");
    assert!(!format!("{request:?}").contains(secret));

    let observer = Arc::new(BlockingHttpRecorderObserver::new(
        HttpRecorderPhase::DispatchStartedStateSynced,
    ));
    let thread_observer = Arc::clone(&observer);
    let thread_raw = raw_root.clone();
    let join = std::thread::spawn(move || {
        let transport = ReqwestHttpTransport::new().expect("transport");
        record_transaction_attempt_observed(
            attempt(&thread_raw),
            &request,
            &transport,
            thread_observer.as_ref(),
        )
    });

    let worker = BlockedRecorderWorker { observer: Arc::clone(&observer), join: Some(join) };
    observer.wait_until_reached();
    assert_eq!(server.request_count(), 0, "network dispatch occurred before durable request evidence");
    let partials: Vec<_> = std::fs::read_dir(&raw_root).expect("raw entries")
        .map(|entry| entry.expect("raw entry").path()).collect();
    assert_eq!(partials.len(), 1);
    let partial = &partials[0];
    assert!(partial.file_name().unwrap().to_string_lossy().starts_with(".partial-"));
    let metadata = std::fs::read(partial.join("request/metadata.json")).expect("request metadata");
    let body = std::fs::read(partial.join("request/body")).expect("request body");
    assert_eq!(body, b"exact-request-body\0\xff");
    assert!(!metadata.windows(secret.len()).any(|window| window == secret.as_bytes()));
    let request_document: serde_json::Value = serde_json::from_slice(&metadata)
        .expect("request metadata JSON");
    assert_eq!(request_document["attempt_state"], "dispatch_started");
    assert!(request_document["dispatch_started_at_unix_nanos"].as_u64().is_some());

    let finalized = worker.finish();
    assert_eq!(server.request_count(), 1);
    server.assert_clean();
    let received = server.last_request().expect("received request");
    assert_eq!(received.method, "POST");
    assert!(received.path.starts_with("/submit?"));
    assert!(received.path.contains(&format!("api_key={secret}")));
    assert_eq!(received.body, body);
    assert!(received.headers.iter().any(|(name, value)|
        name.eq_ignore_ascii_case("x-api-key") && value == secret.as_bytes()));
    assert!(received.headers.iter().any(|(name, value)|
        name.eq_ignore_ascii_case("content-length")
            && value == body.len().to_string().as_bytes()));
    let admitted = admit_transaction_from_disk(&raw_root, finalized.transaction.directory())
        .expect("fresh disk admission");
    assert_eq!(admitted.request().body_length(), body.len() as u64);
    assert_eq!(std::fs::read(admitted.request().body_path().unwrap()).unwrap(), body);
    let final_metadata = std::fs::read_to_string(
        admitted.directory().join("request/metadata.json"),
    ).expect("final request metadata");
    assert!(final_metadata.to_ascii_lowercase().contains("host"));
    assert!(final_metadata.to_ascii_lowercase().contains("content-length"));
    assert!(!final_metadata.contains(secret));
    let events = observer.events();
    let durable = events.iter().position(|event| *event == HttpRecorderPhase::RawRootSyncedBeforeDispatch)
        .expect("raw-root durability event");
    let dispatch = events.iter().position(|event| *event == HttpRecorderPhase::DispatchStarting)
        .expect("dispatch event");
    assert!(durable < dispatch);
    let dispatched = events.iter().position(|event| {
        *event == HttpRecorderPhase::DispatchStartedStateSynced
    }).expect("durable dispatched-state event");
    assert!(durable < dispatched && dispatched < dispatch);
}

#[test]
fn failure_after_raw_root_sync_prevents_dispatch_and_leaves_diagnostic_partial() {
    let server = crate::protocols::http::test_support::start_scripted_server(vec![
        ScriptedStep::Respond { status: 200, body: b"must-not-be-sent".to_vec() },
    ]);
    let temp = tempfile::tempdir().expect("tempdir");
    let raw_root = temp.path().join("raw");
    std::fs::create_dir(&raw_root).expect("raw root");
    let request = HttpRequest::get(format!("{}/never", server.base_url))
        .expect("request").finalize().expect("finalized request");
    let observer = FailingHttpRecorderObserver::new(
        HttpRecorderPhase::RawRootSyncedBeforeDispatch,
    );
    let transport = ReqwestHttpTransport::new().expect("transport");
    let error = record_transaction_attempt_observed(
        attempt(&raw_root),
        &request,
        &transport,
        &observer,
    ).expect_err("failpoint must fail recording");
    assert!(matches!(error, HttpRecorderError::DurabilityObserver {
        phase: HttpRecorderPhase::RawRootSyncedBeforeDispatch,
        ..
    }));
    assert_eq!(server.request_count(), 0);
    server.assert_clean();
    assert!(!observer.events().contains(&HttpRecorderPhase::DispatchStarting));
    assert_eq!(std::fs::read_dir(raw_root).expect("raw entries").count(), 1);
}

#[test]
fn request_debug_and_fixed_errors_do_not_disclose_request_secrets() {
    let secret = "opaque-secret-value";
    let request = HttpRequest::post(format!("https://example.invalid/path?token={secret}"))
        .expect("request")
        .sensitive_query_name("token").expect("sensitive query")
        .sensitive_header("Authorization", secret).expect("sensitive header")
        .body_bytes(secret.as_bytes().to_vec());
    let debug = format!("{request:?}");
    assert!(!debug.contains(secret));
    let prohibited = HttpRequest::get(format!("https://user:{secret}@example.invalid/"))
        .expect("builder")
        .finalize()
        .expect_err("URL credentials must fail closed");
    let rendered = format!("{prohibited:?} {prohibited}");
    assert!(!rendered.contains(secret));
}

#[test]
fn fresh_admission_streams_large_body_hash_and_rejects_oversized_metadata() {
    let response_body = vec![0x5au8; 2 * 1024 * 1024];
    let server = crate::protocols::http::test_support::start_scripted_server(vec![
        ScriptedStep::Respond { status: 200, body: response_body.clone() },
    ]);
    let temp = tempfile::tempdir().expect("tempdir");
    let raw_root = temp.path().join("raw");
    std::fs::create_dir(&raw_root).expect("raw root");
    let request = HttpRequest::get(format!("{}/large", server.base_url))
        .expect("request").finalize().expect("finalized request");
    let transport = ReqwestHttpTransport::new().expect("transport");
    let finalized = record_transaction_attempt_observed(
        attempt(&raw_root),
        &request,
        &transport,
        &NoopHttpRecorderObserver,
    ).expect("recorded attempt");
    server.assert_clean();
    let directory = finalized.transaction.directory().to_path_buf();
    let admitted = admit_transaction_from_disk(&raw_root, &directory)
        .expect("stream-hash admission");
    assert_eq!(admitted.response().body_length(), response_body.len() as u64);
    assert_eq!(std::fs::metadata(admitted.response().body_path()).unwrap().len(), response_body.len() as u64);

    let request_metadata_path = directory.join("request/metadata.json");
    let response_metadata_path = directory.join("response/metadata.json");
    let original_request = std::fs::read(&request_metadata_path).unwrap();
    let original_response = std::fs::read(&response_metadata_path).unwrap();
    std::fs::write(
        &request_metadata_path,
        vec![b' '; MAX_HTTP_TRANSACTION_METADATA_BYTES as usize + 1],
    ).unwrap();
    assert!(matches!(
        admit_transaction_from_disk(&raw_root, &directory),
        Err(HttpTransactionAdmissionError::RequestMetadataOversized { .. })
    ));
    std::fs::write(&request_metadata_path, &original_request).unwrap();
    std::fs::write(
        &response_metadata_path,
        vec![b' '; MAX_HTTP_TRANSACTION_METADATA_BYTES as usize + 1],
    ).unwrap();
    assert!(matches!(
        admit_transaction_from_disk(&raw_root, &directory),
        Err(HttpTransactionAdmissionError::ResponseMetadataOversized { .. })
    ));
    std::fs::write(&response_metadata_path, &original_response).unwrap();

    let mut invalid_request: serde_json::Value =
        serde_json::from_slice(&original_request).unwrap();
    invalid_request["method"] = serde_json::Value::String("GET bad".to_owned());
    std::fs::write(
        &request_metadata_path,
        serde_json::to_vec(&invalid_request).unwrap(),
    )
    .unwrap();
    assert!(matches!(
        admit_transaction_from_disk(&raw_root, &directory),
        Err(HttpTransactionAdmissionError::InvalidRequestMethod)
    ));
    std::fs::write(&request_metadata_path, &original_request).unwrap();

    let mut invalid_response: serde_json::Value =
        serde_json::from_slice(&original_response).unwrap();
    invalid_response["status"] = serde_json::Value::from(0u64);
    std::fs::write(
        &response_metadata_path,
        serde_json::to_vec(&invalid_response).unwrap(),
    )
    .unwrap();
    assert!(matches!(
        admit_transaction_from_disk(&raw_root, &directory),
        Err(HttpTransactionAdmissionError::InvalidResponseStatus)
    ));
    std::fs::write(response_metadata_path, original_response).unwrap();
}
