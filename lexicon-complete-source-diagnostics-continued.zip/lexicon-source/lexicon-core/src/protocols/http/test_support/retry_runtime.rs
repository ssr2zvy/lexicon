use std::sync::Mutex;
use std::time::{Duration, SystemTime};

use crate::protocols::http::context::HttpRetryRuntime;

#[derive(Debug)]
pub(crate) struct DeterministicHttpRetryRuntime {
    state: Mutex<State>,
}

#[derive(Debug)]
struct State {
    elapsed: Duration,
    wall_time: SystemTime,
    sleeps: Vec<Duration>,
}

impl DeterministicHttpRetryRuntime {
    pub(crate) fn new(wall_time: SystemTime) -> Self {
        Self {
            state: Mutex::new(State {
                elapsed: Duration::ZERO,
                wall_time,
                sleeps: Vec::new(),
            }),
        }
    }

    pub(crate) fn advance(&self, duration: Duration) {
        let mut state = self.state.lock().expect("retry runtime mutex poisoned");
        state.elapsed = state.elapsed.saturating_add(duration);
        state.wall_time = state.wall_time.checked_add(duration).unwrap_or(state.wall_time);
    }

    pub(crate) fn sleeps(&self) -> Vec<Duration> {
        self.state.lock().expect("retry runtime mutex poisoned").sleeps.clone()
    }
}

impl HttpRetryRuntime for DeterministicHttpRetryRuntime {
    fn monotonic_elapsed(&self) -> Duration {
        self.state.lock().expect("retry runtime mutex poisoned").elapsed
    }

    fn wall_time(&self) -> SystemTime {
        self.state.lock().expect("retry runtime mutex poisoned").wall_time
    }

    fn sleep(&self, duration: Duration) {
        let mut state = self.state.lock().expect("retry runtime mutex poisoned");
        state.sleeps.push(duration);
        state.elapsed = state.elapsed.saturating_add(duration);
        state.wall_time = state.wall_time.checked_add(duration).unwrap_or(state.wall_time);
    }
}
