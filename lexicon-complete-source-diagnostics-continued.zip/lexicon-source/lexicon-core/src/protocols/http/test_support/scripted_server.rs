use std::io::{Read, Write};
use std::net::{Shutdown, TcpListener, TcpStream};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::thread;
use std::time::{Duration, Instant};

#[derive(Clone, Debug)]
pub(crate) enum ScriptedStep {
    Respond { status: u16, body: Vec<u8> },
    Response {
        status: u16,
        headers: Vec<(Vec<u8>, Vec<u8>)>,
        body: Vec<u8>,
    },
    Redirect { location: String },
    RawResponse(Vec<u8>),
    Truncate { status: u16, announced_len: usize, truncate_to: usize },
    CloseAfter { status: u16, body_prefix: Vec<u8>, close_after_bytes: usize },
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub(crate) struct ReceivedRequest {
    pub method: String,
    pub path: String,
    pub headers: Vec<(String, Vec<u8>)>,
    pub body: Vec<u8>,
}

#[derive(Default)]
struct ServerState {
    requests: Mutex<Vec<ReceivedRequest>>,
    errors: Mutex<Vec<String>>,
}

pub(crate) struct ScriptedServerHandle {
    pub base_url: String,
    state: Arc<ServerState>,
    stop: Arc<AtomicBool>,
    join: Option<thread::JoinHandle<()>>,
}

impl ScriptedServerHandle {
    pub fn request_count(&self) -> u32 { self.requests().len() as u32 }
    pub fn attempt_counter(&self) -> u32 { self.request_count() }
    pub fn last_request(&self) -> Option<ReceivedRequest> { self.requests().last().cloned() }
    pub fn requests(&self) -> Vec<ReceivedRequest> {
        self.state.requests.lock().expect("server mutex poisoned").clone()
    }
    pub fn assert_clean(&self) {
        let errors = self.state.errors.lock().expect("server mutex poisoned");
        assert!(errors.is_empty(), "scripted server errors: {errors:?}");
    }
}

impl Drop for ScriptedServerHandle {
    fn drop(&mut self) {
        self.stop.store(true, Ordering::SeqCst);
        if let Some(join) = self.join.take() {
            join.join().expect("scripted server thread panicked");
        }
    }
}

pub(crate) fn start_scripted_server(steps: Vec<ScriptedStep>) -> ScriptedServerHandle {
    let listener = TcpListener::bind("127.0.0.1:0").expect("bind scripted server");
    listener.set_nonblocking(true).expect("set scripted server nonblocking");
    let address = listener.local_addr().expect("scripted server address");
    let state = Arc::new(ServerState::default());
    let stop = Arc::new(AtomicBool::new(false));
    let thread_state = Arc::clone(&state);
    let thread_stop = Arc::clone(&stop);
    let join = thread::spawn(move || run_listener(listener, steps, thread_state, thread_stop));
    ScriptedServerHandle {
        base_url: format!("http://{address}"),
        state,
        stop,
        join: Some(join),
    }
}

fn run_listener(
    listener: TcpListener,
    steps: Vec<ScriptedStep>,
    state: Arc<ServerState>,
    stop: Arc<AtomicBool>,
) {
    let mut index = 0usize;
    while !stop.load(Ordering::SeqCst) {
        match listener.accept() {
            Ok((mut stream, _)) => {
                let request = match read_request(&mut stream) {
                    Ok(request) => request,
                    Err(error) => {
                        state.errors.lock().expect("server mutex poisoned").push(error);
                        continue;
                    }
                };
                state.requests.lock().expect("server mutex poisoned").push(request);
                let Some(step) = steps.get(index) else {
                    state.errors.lock().expect("server mutex poisoned")
                        .push("received an unscripted request".to_owned());
                    let _ = stream.shutdown(Shutdown::Both);
                    continue;
                };
                index += 1;
                if let Err(error) = write_step(&mut stream, step) {
                    state.errors.lock().expect("server mutex poisoned").push(error);
                }
            }
            Err(error) if error.kind() == std::io::ErrorKind::WouldBlock => {
                thread::sleep(Duration::from_millis(1));
            }
            Err(error) => {
                state.errors.lock().expect("server mutex poisoned")
                    .push(format!("accept failed: {error}"));
                break;
            }
        }
    }
}

fn read_request(stream: &mut TcpStream) -> Result<ReceivedRequest, String> {
    stream.set_read_timeout(Some(Duration::from_secs(2))).map_err(|e| e.to_string())?;
    let deadline = Instant::now() + Duration::from_secs(2);
    let mut bytes = Vec::new();
    let header_end;
    loop {
        if bytes.len() > 1024 * 1024 { return Err("request headers exceeded test limit".to_owned()); }
        if let Some(position) = bytes.windows(4).position(|window| window == b"\r\n\r\n") {
            header_end = position + 4;
            break;
        }
        if Instant::now() >= deadline { return Err("request header timeout".to_owned()); }
        let mut buffer = [0u8; 8192];
        let read = stream.read(&mut buffer).map_err(|e| e.to_string())?;
        if read == 0 { return Err("connection closed before request headers".to_owned()); }
        bytes.extend_from_slice(&buffer[..read]);
    }
    let header_text = std::str::from_utf8(&bytes[..header_end]).map_err(|_| "non-UTF-8 request headers".to_owned())?;
    let mut lines = header_text.split("\r\n");
    let request_line = lines.next().ok_or_else(|| "missing request line".to_owned())?;
    let mut parts = request_line.split_whitespace();
    let method = parts.next().unwrap_or("").to_owned();
    let path = parts.next().unwrap_or("").to_owned();
    let mut headers = Vec::new();
    let mut content_length = 0usize;
    for line in lines {
        if line.is_empty() { break; }
        let (name, value) = line.split_once(':').ok_or_else(|| "malformed request header".to_owned())?;
        let value = value.trim_start().as_bytes().to_vec();
        if name.eq_ignore_ascii_case("content-length") {
            content_length = std::str::from_utf8(&value).map_err(|_| "non-UTF-8 content length".to_owned())?
                .parse().map_err(|_| "invalid content length".to_owned())?;
        }
        headers.push((name.to_owned(), value));
    }
    while bytes.len() - header_end < content_length {
        let mut buffer = [0u8; 8192];
        let read = stream.read(&mut buffer).map_err(|e| e.to_string())?;
        if read == 0 { return Err("connection closed before request body".to_owned()); }
        bytes.extend_from_slice(&buffer[..read]);
    }
    Ok(ReceivedRequest {
        method,
        path,
        headers,
        body: bytes[header_end..header_end + content_length].to_vec(),
    })
}

fn write_step(stream: &mut TcpStream, step: &ScriptedStep) -> Result<(), String> {
    match step {
        ScriptedStep::Respond { status, body } => write_response(stream, *status, &[], body),
        ScriptedStep::Response { status, headers, body } => write_response(stream, *status, headers, body),
        ScriptedStep::Redirect { location } => write_response(
            stream,
            302,
            &[(b"Location".to_vec(), location.as_bytes().to_vec())],
            &[],
        ),
        ScriptedStep::RawResponse(bytes) => stream.write_all(bytes).map_err(|e| e.to_string()),
        ScriptedStep::Truncate { status, announced_len, truncate_to } => {
            write!(stream, "HTTP/1.1 {status} Test\r\nContent-Length: {announced_len}\r\nConnection: close\r\n\r\n")
                .map_err(|e| e.to_string())?;
            stream.write_all(&vec![b'X'; *truncate_to]).map_err(|e| e.to_string())
        }
        ScriptedStep::CloseAfter { status, body_prefix, close_after_bytes } => {
            write!(stream, "HTTP/1.1 {status} Test\r\nContent-Length: {}\r\nConnection: close\r\n\r\n", body_prefix.len())
                .map_err(|e| e.to_string())?;
            stream.write_all(&body_prefix[..(*close_after_bytes).min(body_prefix.len())]).map_err(|e| e.to_string())?;
            stream.shutdown(Shutdown::Both).map_err(|e| e.to_string())
        }
    }
}

fn write_response(
    stream: &mut TcpStream,
    status: u16,
    headers: &[(Vec<u8>, Vec<u8>)],
    body: &[u8],
) -> Result<(), String> {
    write!(stream, "HTTP/1.1 {status} Test\r\nContent-Length: {}\r\nConnection: close\r\n", body.len())
        .map_err(|e| e.to_string())?;
    for (name, value) in headers {
        stream.write_all(name).map_err(|e| e.to_string())?;
        stream.write_all(b": ").map_err(|e| e.to_string())?;
        stream.write_all(value).map_err(|e| e.to_string())?;
        stream.write_all(b"\r\n").map_err(|e| e.to_string())?;
    }
    stream.write_all(b"\r\n").map_err(|e| e.to_string())?;
    stream.write_all(body).map_err(|e| e.to_string())?;
    stream.flush().map_err(|e| e.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn server_is_bounded_and_retains_exact_request_history() {
        let server = start_scripted_server(vec![ScriptedStep::Respond { status: 200, body: b"ok".to_vec() }]);
        assert_eq!(server.request_count(), 0);
        server.assert_clean();
    }
}
