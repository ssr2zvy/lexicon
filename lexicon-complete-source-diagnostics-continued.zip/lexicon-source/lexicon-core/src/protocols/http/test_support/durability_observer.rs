use std::io;
use std::sync::{Condvar, Mutex};
use std::time::{Duration, Instant};

use crate::protocols::http::transaction::recorder::{
    HttpRecorderObserver, HttpRecorderPhase,
};

#[derive(Default)]
pub(crate) struct RecordingHttpRecorderObserver {
    events: Mutex<Vec<HttpRecorderPhase>>,
}

impl RecordingHttpRecorderObserver {
    pub(crate) fn events(&self) -> Vec<HttpRecorderPhase> {
        self.events.lock().expect("observer mutex poisoned").clone()
    }
}

impl HttpRecorderObserver for RecordingHttpRecorderObserver {
    fn after(&self, event: HttpRecorderPhase) -> Result<(), io::Error> {
        self.events.lock().expect("observer mutex poisoned").push(event);
        Ok(())
    }
}

pub(crate) struct BlockingHttpRecorderObserver {
    state: Mutex<BlockingState>,
    changed: Condvar,
    block_at: HttpRecorderPhase,
}

#[derive(Default)]
struct BlockingState {
    events: Vec<HttpRecorderPhase>,
    reached: bool,
    released: bool,
}

impl BlockingHttpRecorderObserver {
    pub(crate) fn new(block_at: HttpRecorderPhase) -> Self {
        Self {
            state: Mutex::new(BlockingState::default()),
            changed: Condvar::new(),
            block_at,
        }
    }

    pub(crate) fn wait_until_reached(&self) {
        let mut state = self.state.lock().expect("observer mutex poisoned");
        let deadline = Instant::now() + Duration::from_secs(5);
        while !state.reached {
            let remaining = deadline.checked_duration_since(Instant::now())
                .expect("timed out waiting for recorder failpoint");
            let (next, timeout) = self.changed.wait_timeout(state, remaining)
                .expect("observer mutex poisoned");
            state = next;
            assert!(!timeout.timed_out() || state.reached, "timed out waiting for recorder failpoint");
        }
    }

    pub(crate) fn release(&self) {
        let mut state = self.state.lock().expect("observer mutex poisoned");
        state.released = true;
        self.changed.notify_all();
    }

    pub(crate) fn events(&self) -> Vec<HttpRecorderPhase> {
        self.state.lock().expect("observer mutex poisoned").events.clone()
    }
}

impl HttpRecorderObserver for BlockingHttpRecorderObserver {
    fn after(&self, event: HttpRecorderPhase) -> Result<(), io::Error> {
        let mut state = self.state.lock().expect("observer mutex poisoned");
        state.events.push(event);
        if event == self.block_at {
            state.reached = true;
            self.changed.notify_all();
            let deadline = Instant::now() + Duration::from_secs(5);
            while !state.released {
                let Some(remaining) = deadline.checked_duration_since(Instant::now()) else {
                    return Err(io::Error::new(io::ErrorKind::TimedOut, "recorder block release timed out"));
                };
                let (next, timeout) = self.changed.wait_timeout(state, remaining)
                    .expect("observer mutex poisoned");
                state = next;
                if timeout.timed_out() && !state.released {
                    return Err(io::Error::new(io::ErrorKind::TimedOut, "recorder block release timed out"));
                }
            }
        }
        Ok(())
    }
}

pub(crate) struct FailingHttpRecorderObserver {
    fail_at: HttpRecorderPhase,
    events: Mutex<Vec<HttpRecorderPhase>>,
}

impl FailingHttpRecorderObserver {
    pub(crate) fn new(fail_at: HttpRecorderPhase) -> Self {
        Self { fail_at, events: Mutex::new(Vec::new()) }
    }

    pub(crate) fn events(&self) -> Vec<HttpRecorderPhase> {
        self.events.lock().expect("observer mutex poisoned").clone()
    }
}

impl HttpRecorderObserver for FailingHttpRecorderObserver {
    fn after(&self, event: HttpRecorderPhase) -> Result<(), io::Error> {
        self.events.lock().expect("observer mutex poisoned").push(event);
        if event == self.fail_at {
            return Err(io::Error::new(io::ErrorKind::Other, "injected recorder failpoint"));
        }
        Ok(())
    }
}
