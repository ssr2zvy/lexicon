pub mod capability;
pub mod checkpoint;
pub mod context;
pub mod contract;
pub mod error;
pub mod invocation;
pub mod policy;
pub mod request;
pub mod runner;
pub(crate) mod sensitivity;
pub(crate) mod transport;
pub mod transaction;

#[cfg(test)]
pub(crate) mod test_support;
#[cfg(test)]
mod durability_tests;

pub use context::{
    AcquisitionProgressError, HttpAcquisitionContext, HttpProgressPartialCommit,
    SessionValidationError,
};
pub use crate::runtime::{
    MissingHttpCapabilities, ParsedRuntimeInvocation, RuntimeCompatibilityError, RuntimeIdentity,
    RuntimeInformationV1, RuntimeOperation, RuntimeProtocol,
};
pub use capability::{HttpCapability, HttpCapabilitySet};
pub use checkpoint::{
    CommittedHttpCheckpoint, HTTP_CHECKPOINT_SCHEMA_VERSION, MAX_HTTP_CHECKPOINT_DOCUMENT_BYTES,
    HttpCheckpointAdmissionError, HttpCheckpointCommitError, HttpCheckpointDecodingError,
    HttpCheckpointEncodingError, HttpCheckpointKeyError, HttpCheckpointLookupError,
    HttpCheckpointPartialCommit, HttpHistoricalLookupError,
};
pub use contract::{
    HTTP_SOURCE_CONTRACT_IDENTIFIER, HTTP_SOURCE_CONTRACT_VERSION, HttpAcquireFn, HttpResumeFn,
    HttpSourceContractV1,
};
pub use error::{
    AcquisitionError, AcquisitionResult, HttpExecutionError, HttpRedirectFailure,
    HttpRedirectFailureKind, HttpRetryExhaustionError, HttpRetryExhaustionReason,
    HttpRetryFinalOutcome,
    RecordedHttpTransportFailure,
};
pub use invocation::{
    AdmittedHttpHandler, AdmittedHttpRuntimeInvocation, HttpRuntimeInvocationAdmissionError,
    admit_http_runtime_invocation,
};
pub use policy::{HttpPolicyError, HttpRedirectPolicy, HttpRetryDelayPolicy, HttpRetryPolicy};
pub use request::{HttpRequest, HttpRequestError};
pub use runner::{
    HttpRuntimeInvocationExecutionError, RUNTIME_INFORMATION_PROBE_ARGUMENT,
    RuntimeInformationProbeError, RuntimeInformationProbeOutcome, run_http_runtime_invocation,
    run_http_source, try_write_runtime_information_probe,
};
pub use transaction::{
    HttpAttemptIdentity, HttpAttemptIdentityError, HttpLogicalRequestKey,
    HttpLogicalRequestKeyError, HttpRecordedOutcome, HttpRecordedOutcomeKind,
    HttpResponseStatusError, HttpTransactionIdentity, HttpTransactionIdentityError,
    IncompleteHttpAttemptPhase, IncompleteRecordedHttpAttempt,
    RecordedHeader, RecordedHeaderCollection, RecordedHeaderValue, RecordedHttpRequest,
    RecordedHttpResponse, RecordedTransaction, RecordedTransportFailure,
};
pub use transaction::error::{
    HttpBodyStreamingError, HttpClockError, HttpIncompleteMarkerError, HttpManagedPathError,
    HttpManagedPathTargetType, HttpManagedPathValidationMode, HttpMetadataPersistenceError,
    HttpRecorderError, HttpTransactionIdentityAllocationError, HttpTransactionPublicationError,
    IncompleteHttpResponseFailure,
};
pub use transaction::metadata::{
    AcquisitionProgressAdvanceError, HttpTransactionAdmissionError,
    StoredTransportFailureClass,
};
pub use transport::{HttpTransportFailure, StoredHttpVersion};
