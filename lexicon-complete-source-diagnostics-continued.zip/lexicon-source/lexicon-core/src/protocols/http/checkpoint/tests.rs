use std::path::PathBuf;

use super::error::{
    HttpCheckpointCommitError, HttpCheckpointDecodingError, HttpCheckpointPublicationError,
};
use super::model::{
    CheckpointProjectIdentityDocument, CheckpointRuntimeIdentityDocument,
    CheckpointSessionIdentityDocument, CommittedHttpCheckpoint, HTTP_CHECKPOINT_SCHEMA_VERSION,
    HttpCheckpointDocumentV1, HttpCheckpointPublicationObserver, HttpCheckpointPublicationPhase,
    decode_checkpoint_document, encode_checkpoint_document, key_sha256_hex,
    write_checkpoint_atomic_observed,
};
use crate::protocols::http::transaction::{
    HttpAttemptIdentity, HttpLogicalRequestKey, HttpTransactionIdentity,
};
use crate::runtime::OwnedRuntimeIdentity;
use crate::session::{ProjectIdentity, SessionIdentity};

fn document(key: &HttpLogicalRequestKey) -> HttpCheckpointDocumentV1 {
    HttpCheckpointDocumentV1 {
        schema_version: HTTP_CHECKPOINT_SCHEMA_VERSION,
        key: key.as_str().to_string(),
        key_sha256: key_sha256_hex(key),
        project: CheckpointProjectIdentityDocument { name: "project-a".into() },
        runtime: CheckpointRuntimeIdentityDocument {
            source: "source-a".into(),
            protocol: "http".into(),
            operation: "get-raw-data".into(),
            source_contract_version: 1,
        },
        session: CheckpointSessionIdentityDocument { id: "session-a".into() },
        transaction_id: HttpTransactionIdentity::new().unwrap().id().to_string(),
        physical_attempt_index: 1,
        redirect_index: 0,
        retry_index: 0,
        committed_at_unix_nanos: 10,
    }
}

fn receipt(path: PathBuf, key: HttpLogicalRequestKey) -> CommittedHttpCheckpoint {
    CommittedHttpCheckpoint::new(
        ProjectIdentity::new("project-a").unwrap(),
        OwnedRuntimeIdentity::http_acquisition("source-a", 1),
        SessionIdentity::new("session-a").unwrap(),
        key.clone(),
        key_sha256_hex(&key),
        HttpTransactionIdentity::new().unwrap(),
        HttpAttemptIdentity::new(1, 0, 0).unwrap(),
        path,
        10,
    )
}

#[test]
fn checkpoint_decoder_rejects_unknown_fields_wrong_schema_and_filename_digest() {
    let key = HttpLogicalRequestKey::new("work/item-a").unwrap();
    let mut value = serde_json::to_value(document(&key)).unwrap();
    value["foreign"] = serde_json::Value::Bool(true);
    let error = decode_checkpoint_document(
        &serde_json::to_vec(&value).unwrap(),
        &key_sha256_hex(&key),
    )
    .unwrap_err();
    assert!(matches!(error, HttpCheckpointDecodingError::Deserialization(_)));

    let mut wrong_schema = document(&key);
    wrong_schema.schema_version += 1;
    let error = decode_checkpoint_document(
        &serde_json::to_vec(&wrong_schema).unwrap(),
        &key_sha256_hex(&key),
    )
    .unwrap_err();
    assert!(matches!(error, HttpCheckpointDecodingError::UnknownSchemaVersion { .. }));

    let error = decode_checkpoint_document(
        &encode_checkpoint_document(&document(&key)).unwrap(),
        &"0".repeat(64),
    )
    .unwrap_err();
    assert!(matches!(error, HttpCheckpointDecodingError::FilenameMismatch));
}

#[test]
fn checkpoint_no_replace_publication_preserves_first_receipt() {
    let temp = tempfile::tempdir().unwrap();
    let key = HttpLogicalRequestKey::new("work/item-a").unwrap();
    let target = temp.path().join(format!("{}.json", key_sha256_hex(&key)));
    let checkpoint = receipt(target.clone(), key.clone());
    let bytes = encode_checkpoint_document(&document(&key)).unwrap();
    write_checkpoint_atomic_observed(
        temp.path(),
        &target,
        &bytes,
        &checkpoint,
        &NeverFail,
    )
    .unwrap();
    let first = std::fs::read(&target).unwrap();
    let error = write_checkpoint_atomic_observed(
        temp.path(),
        &target,
        b"replacement",
        &checkpoint,
        &NeverFail,
    )
    .unwrap_err();
    assert!(matches!(
        error,
        HttpCheckpointCommitError::Publication(HttpCheckpointPublicationError::Collision)
    ));
    assert_eq!(std::fs::read(&target).unwrap(), first);
}

struct NeverFail;

impl HttpCheckpointPublicationObserver for NeverFail {
    fn after(&self, _: HttpCheckpointPublicationPhase) -> Result<(), std::io::Error> {
        Ok(())
    }
}
