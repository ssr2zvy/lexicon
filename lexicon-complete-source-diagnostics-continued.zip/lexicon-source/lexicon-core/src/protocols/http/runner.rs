use std::ffi::{OsStr, OsString};
use std::fmt;

use crate::HttpAcquisitionContext;
use crate::protocols::http::error::AcquisitionError;
use crate::protocols::http::invocation::{
    AdmittedHttpHandler, HttpRuntimeInvocationAdmissionError, admit_http_runtime_invocation,
};
use crate::protocols::http::{HttpCapabilitySet, HttpSourceContractV1};
use crate::runtime::{
    RuntimeIdentity, RuntimeInformationEncodingError, RuntimeInformationV1,
    RuntimeInvocationTransportDecodingError, parse_runtime_invocation,
};
use crate::session::{
    CoreRunnerSessionError, RuntimeContextPaths, SessionDataPaths, SessionOperationRoot,
    SessionStore, bind_runtime_session_with_lease_identity, decode_runtime_context_from_env,
};

pub const RUNTIME_INFORMATION_PROBE_ARGUMENT: &str =
    crate::runtime::RUNTIME_INFORMATION_PROBE_ARGUMENT;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RuntimeInformationProbeOutcome {
    NotRequested,
    Written,
}

#[derive(Debug)]
pub enum RuntimeInformationProbeError {
    UnexpectedArguments,
    Encoding(RuntimeInformationEncodingError),
    Output(std::io::Error),
}

impl fmt::Display for RuntimeInformationProbeError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::UnexpectedArguments => {
                formatter.write_str("unexpected runtime information probe arguments")
            }
            Self::Encoding(error) => {
                write!(formatter, "runtime information encoding error: {error}")
            }
            Self::Output(error) => {
                write!(formatter, "runtime information probe output error: {error}")
            }
        }
    }
}

impl std::error::Error for RuntimeInformationProbeError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::UnexpectedArguments => None,
            Self::Encoding(error) => Some(error),
            Self::Output(error) => Some(error),
        }
    }
}

impl crate::diagnostic::ReportableDiagnostic for RuntimeInformationProbeError {
    fn diagnostic(&self) -> crate::diagnostic::Diagnostic {
        use crate::diagnostic::{Diagnostic, codes};

        match self {
            Self::UnexpectedArguments => Diagnostic::operational(
                codes::RUNTIME_PROBE_ARGUMENTS_INVALID,
                "The runtime-information probe received unexpected arguments.",
            ),
            Self::Encoding(_) => Diagnostic::operational(
                codes::RUNTIME_PROBE_ENCODING_FAILED,
                "Runtime information could not be encoded.",
            ),
            Self::Output(_) => Diagnostic::operational(
                codes::RUNTIME_PROBE_OUTPUT_FAILED,
                "Runtime information could not be written to the probe channel.",
            ),
        }
    }
}

pub fn try_write_runtime_information_probe<W: std::io::Write>(
    identity: RuntimeIdentity,
    source: &HttpSourceContractV1,
    available_capabilities: HttpCapabilitySet,
    arguments: &[OsString],
    output: &mut W,
) -> Result<RuntimeInformationProbeOutcome, RuntimeInformationProbeError> {
    let Some(first_argument) = arguments.first() else {
        return Ok(RuntimeInformationProbeOutcome::NotRequested);
    };

    if first_argument.as_os_str() != OsStr::new(RUNTIME_INFORMATION_PROBE_ARGUMENT) {
        return Ok(RuntimeInformationProbeOutcome::NotRequested);
    }

    if arguments.len() != 1 {
        return Err(RuntimeInformationProbeError::UnexpectedArguments);
    }

    let json = RuntimeInformationV1::from_http_source(identity, source, available_capabilities)
        .to_json()
        .map_err(RuntimeInformationProbeError::Encoding)?;

    let mut document = json.into_bytes();
    document.push(b'\n');

    std::io::Write::write_all(output, &document).map_err(RuntimeInformationProbeError::Output)?;
    std::io::Write::flush(output).map_err(RuntimeInformationProbeError::Output)?;

    Ok(RuntimeInformationProbeOutcome::Written)
}

/// Complete managed acquisition entrypoint. Generated binaries delegate here
/// immediately so Core exclusively owns argument collection, probe routing,
/// admission, diagnostics, and exit-code conversion.
pub fn run_http_source(
    identity: RuntimeIdentity,
    source: &HttpSourceContractV1,
) -> std::process::ExitCode {
    crate::diagnostic::install_managed_runtime_panic_sanitizer();

    let arguments: Vec<OsString> = std::env::args_os().skip(1).collect();
    {
        let stdout = std::io::stdout();
        let mut stdout = stdout.lock();
        match try_write_runtime_information_probe(
            identity,
            source,
            HttpCapabilitySet::empty(),
            &arguments,
            &mut stdout,
        ) {
            Ok(RuntimeInformationProbeOutcome::Written) => {
                return std::process::ExitCode::SUCCESS;
            }
            Ok(RuntimeInformationProbeOutcome::NotRequested) => {}
            Err(error) => {
                let _ = crate::diagnostic::write_reportable_diagnostic(
                    &mut std::io::stderr().lock(),
                    &error,
                );
                return std::process::ExitCode::FAILURE;
            }
        }
    }

    if let Err(_error) = run_http_runtime_invocation(
        &arguments,
        identity,
        source,
        HttpCapabilitySet::empty(),
    ) {
        // The ordinary runtime is always supervised. Its durable session
        // transition and exit status are consumed by the parent, which owns
        // the one operator-visible terminal report. Printing here would make
        // foreground execution report the same failure twice, while detached
        // background stderr is intentionally unavailable.
        return std::process::ExitCode::FAILURE;
    }
    std::process::ExitCode::SUCCESS
}

#[cfg(test)]
mod tests {
    use std::ffi::OsString;
    use std::io::{self, Write};

    use super::{
        RUNTIME_INFORMATION_PROBE_ARGUMENT, RuntimeInformationProbeError,
        RuntimeInformationProbeOutcome, run_http_source, try_write_runtime_information_probe,
    };
    use crate::http::{HttpCapability, HttpCapabilitySet};
    use crate::protocols::http::{AcquisitionResult, HttpSourceContractV1};
    use crate::runtime::RuntimeInformationV1;
    use crate::{HttpAcquisitionContext, runtime::RuntimeIdentity};

    fn acquire_handler(
        _context: &mut HttpAcquisitionContext,
        _args: &[std::ffi::OsString],
    ) -> AcquisitionResult<()> {
        Ok(())
    }

    fn resume_handler(
        _context: &mut HttpAcquisitionContext,
        _args: &[std::ffi::OsString],
    ) -> AcquisitionResult<()> {
        Ok(())
    }

    const ORDINARY_ENTRYPOINT_CHILD_ENV: &str =
        "LEXICON_TEST_HTTP_ORDINARY_ENTRYPOINT_CHILD";

    #[test]
    fn ordinary_managed_http_failure_does_not_duplicate_parent_terminal_output() {
        if std::env::var_os(ORDINARY_ENTRYPOINT_CHILD_ENV).is_some() {
            fn handler_must_not_run(
                _context: &mut HttpAcquisitionContext,
                _args: &[OsString],
            ) -> AcquisitionResult<()> {
                panic!("ordinary-http-handler-secret");
            }

            let outcome = run_http_source(
                RuntimeIdentity::http_acquisition("example-source", 1),
                &HttpSourceContractV1::new(handler_must_not_run),
            );
            std::process::exit(if outcome == std::process::ExitCode::FAILURE {
                1
            } else {
                99
            });
        }

        let output = std::process::Command::new(std::env::current_exe().unwrap())
            .args([
                "--exact",
                "protocols::http::runner::tests::ordinary_managed_http_failure_does_not_duplicate_parent_terminal_output",
                "--nocapture",
            ])
            .env(ORDINARY_ENTRYPOINT_CHILD_ENV, "1")
            .output()
            .unwrap();

        assert_eq!(output.status.code(), Some(1));
        let stderr = String::from_utf8_lossy(&output.stderr);
        assert!(!stderr.contains("[lexicon] ERROR"));
        assert!(!stderr.contains("ordinary-http-handler-secret"));
    }

    fn failing_acquire(
        _context: &mut HttpAcquisitionContext,
        _args: &[std::ffi::OsString],
    ) -> AcquisitionResult<()> {
        panic!("acquire should not be invoked while probing runtime information");
    }

    fn failing_resume(
        _context: &mut HttpAcquisitionContext,
        _args: &[std::ffi::OsString],
    ) -> AcquisitionResult<()> {
        panic!("resume should not be invoked while probing runtime information");
    }

    #[derive(Default)]
    struct RecordingWriter {
        bytes: Vec<u8>,
        fail_write: bool,
        fail_flush: bool,
    }

    impl Write for RecordingWriter {
        fn write(&mut self, buffer: &[u8]) -> io::Result<usize> {
            if self.fail_write {
                return Err(io::Error::new(io::ErrorKind::Other, "write failed"));
            }
            self.bytes.extend_from_slice(buffer);
            Ok(buffer.len())
        }

        fn flush(&mut self) -> io::Result<()> {
            if self.fail_flush {
                return Err(io::Error::new(io::ErrorKind::Other, "flush failed"));
            }
            Ok(())
        }
    }

    #[test]
    fn empty_arguments_return_not_requested() {
        let mut output = Vec::new();
        let outcome = try_write_runtime_information_probe(
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire_handler),
            HttpCapabilitySet::empty(),
            &[],
            &mut output,
        )
        .unwrap();

        assert_eq!(outcome, RuntimeInformationProbeOutcome::NotRequested);
        assert!(output.is_empty());
    }

    #[test]
    fn unrelated_argument_returns_not_requested() {
        let mut output = Vec::new();
        let outcome = try_write_runtime_information_probe(
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire_handler),
            HttpCapabilitySet::empty(),
            &[OsString::from("--not-the-probe")],
            &mut output,
        )
        .unwrap();

        assert_eq!(outcome, RuntimeInformationProbeOutcome::NotRequested);
        assert!(output.is_empty());
    }

    #[test]
    fn exact_probe_argument_returns_written() {
        let mut output = Vec::new();
        let outcome = try_write_runtime_information_probe(
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire_handler),
            HttpCapabilitySet::empty(),
            &[OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT)],
            &mut output,
        )
        .unwrap();

        assert_eq!(outcome, RuntimeInformationProbeOutcome::Written);
        assert!(!output.is_empty());
    }

    #[test]
    fn not_requested_writes_no_bytes() {
        let mut output = Vec::new();
        let outcome = try_write_runtime_information_probe(
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire_handler),
            HttpCapabilitySet::empty(),
            &[OsString::from("--ordinary-source-value")],
            &mut output,
        )
        .unwrap();

        assert_eq!(outcome, RuntimeInformationProbeOutcome::NotRequested);
        assert!(output.is_empty());
    }

    #[test]
    fn successful_output_parses_through_runtime_information_json() {
        let source = HttpSourceContractV1::new(acquire_handler)
            .with_resume(resume_handler)
            .requires(HttpCapability::ClientCertificateV1);
        let identity = RuntimeIdentity::http_acquisition("example-source", 2);
        let available = HttpCapabilitySet::empty().insert(HttpCapability::ClientCertificateV1);

        let mut output = Vec::new();
        let outcome = try_write_runtime_information_probe(
            identity,
            &source,
            available,
            &[OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT)],
            &mut output,
        )
        .unwrap();

        assert_eq!(outcome, RuntimeInformationProbeOutcome::Written);
        let text = std::str::from_utf8(&output).unwrap();
        let parsed = RuntimeInformationV1::from_json(text.trim_end_matches('\n')).unwrap();

        assert_eq!(parsed.identity(), identity);
        assert_eq!(
            parsed.required_capabilities(),
            source.required_capabilities()
        );
        assert_eq!(parsed.available_capabilities(), available);
        assert_eq!(parsed.resume_handler_registered(), true);
    }

    #[test]
    fn successful_output_ends_with_exactly_one_newline() {
        let mut output = Vec::new();
        try_write_runtime_information_probe(
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire_handler),
            HttpCapabilitySet::empty(),
            &[OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT)],
            &mut output,
        )
        .unwrap();

        assert!(output.ends_with(b"\n"));
        assert!(!output.ends_with(b"\n\n"));
        let text = String::from_utf8(output).unwrap();
        assert_eq!(text.matches('\n').count(), 1);
    }

    #[test]
    fn successful_output_contains_only_json_document_and_newline() {
        let source = HttpSourceContractV1::new(acquire_handler)
            .with_resume(resume_handler)
            .requires(HttpCapability::ClientCertificateV1);
        let identity = RuntimeIdentity::http_acquisition("example-source", 1);
        let available = HttpCapabilitySet::empty().insert(HttpCapability::ClientCertificateV1);

        let expected = RuntimeInformationV1::from_http_source(identity, &source, available)
            .to_json()
            .unwrap();

        let mut output = Vec::new();
        try_write_runtime_information_probe(
            identity,
            &source,
            available,
            &[OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT)],
            &mut output,
        )
        .unwrap();

        assert_eq!(String::from_utf8(output).unwrap(), format!("{expected}\n"));
    }

    #[test]
    fn runtime_identity_is_preserved() {
        let identity = RuntimeIdentity::http_acquisition("source-alpha", 7);
        let mut output = Vec::new();
        try_write_runtime_information_probe(
            identity,
            &HttpSourceContractV1::new(acquire_handler),
            HttpCapabilitySet::empty(),
            &[OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT)],
            &mut output,
        )
        .unwrap();

        let parsed =
            RuntimeInformationV1::from_json(std::str::from_utf8(&output).unwrap().trim()).unwrap();
        assert_eq!(parsed.identity(), identity);
    }

    #[test]
    fn descriptor_contract_version_is_preserved() {
        let identity = RuntimeIdentity::http_acquisition("example-source", 1);
        let source = HttpSourceContractV1::new(acquire_handler);
        let mut output = Vec::new();
        try_write_runtime_information_probe(
            identity,
            &source,
            HttpCapabilitySet::empty(),
            &[OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT)],
            &mut output,
        )
        .unwrap();

        let parsed =
            RuntimeInformationV1::from_json(std::str::from_utf8(&output).unwrap().trim()).unwrap();
        assert_eq!(
            parsed.descriptor_contract_version(),
            HttpSourceContractV1::CONTRACT_VERSION
        );
    }

    #[test]
    fn required_capabilities_are_preserved() {
        let identity = RuntimeIdentity::http_acquisition("example-source", 1);
        let source = HttpSourceContractV1::new(acquire_handler)
            .requires(HttpCapability::ClientCertificateV1);
        let mut output = Vec::new();
        try_write_runtime_information_probe(
            identity,
            &source,
            HttpCapabilitySet::empty(),
            &[OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT)],
            &mut output,
        )
        .unwrap();

        let parsed =
            RuntimeInformationV1::from_json(std::str::from_utf8(&output).unwrap().trim()).unwrap();
        assert_eq!(
            parsed.required_capabilities(),
            source.required_capabilities()
        );
    }

    #[test]
    fn available_capabilities_are_preserved_independently() {
        let identity = RuntimeIdentity::http_acquisition("example-source", 1);
        let source = HttpSourceContractV1::new(acquire_handler)
            .requires(HttpCapability::ClientCertificateV1);
        let available = HttpCapabilitySet::empty().insert(HttpCapability::ClientCertificateV1);
        let mut output = Vec::new();
        try_write_runtime_information_probe(
            identity,
            &source,
            available,
            &[OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT)],
            &mut output,
        )
        .unwrap();

        let parsed =
            RuntimeInformationV1::from_json(std::str::from_utf8(&output).unwrap().trim()).unwrap();
        assert_eq!(
            parsed.required_capabilities(),
            source.required_capabilities()
        );
        assert_eq!(parsed.available_capabilities(), available);
    }

    #[test]
    fn resume_registration_is_preserved() {
        let identity = RuntimeIdentity::http_acquisition("example-source", 1);
        let source = HttpSourceContractV1::new(acquire_handler).with_resume(resume_handler);
        let mut output = Vec::new();
        try_write_runtime_information_probe(
            identity,
            &source,
            HttpCapabilitySet::empty(),
            &[OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT)],
            &mut output,
        )
        .unwrap();

        let parsed =
            RuntimeInformationV1::from_json(std::str::from_utf8(&output).unwrap().trim()).unwrap();
        assert!(parsed.resume_handler_registered());
    }

    #[test]
    fn incompatible_capability_combination_is_reported() {
        let identity = RuntimeIdentity::http_acquisition("example-source", 1);
        let source = HttpSourceContractV1::new(acquire_handler)
            .requires(HttpCapability::ClientCertificateV1);
        let available = HttpCapabilitySet::empty();
        let mut output = Vec::new();

        let outcome = try_write_runtime_information_probe(
            identity,
            &source,
            available,
            &[OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT)],
            &mut output,
        )
        .unwrap();

        assert_eq!(outcome, RuntimeInformationProbeOutcome::Written);
        let parsed =
            RuntimeInformationV1::from_json(std::str::from_utf8(&output).unwrap().trim()).unwrap();
        assert!(parsed.validate_capabilities().is_err());
    }

    #[test]
    fn probe_execution_does_not_invoke_acquire() {
        let identity = RuntimeIdentity::http_acquisition("example-source", 1);
        let source = HttpSourceContractV1::new(failing_acquire);
        let mut output = Vec::new();

        let outcome = try_write_runtime_information_probe(
            identity,
            &source,
            HttpCapabilitySet::empty(),
            &[OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT)],
            &mut output,
        )
        .unwrap();

        assert_eq!(outcome, RuntimeInformationProbeOutcome::Written);
    }

    #[test]
    fn probe_execution_does_not_invoke_resume() {
        let identity = RuntimeIdentity::http_acquisition("example-source", 1);
        let source = HttpSourceContractV1::new(acquire_handler).with_resume(failing_resume);
        let mut output = Vec::new();

        let outcome = try_write_runtime_information_probe(
            identity,
            &source,
            HttpCapabilitySet::empty(),
            &[OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT)],
            &mut output,
        )
        .unwrap();

        assert_eq!(outcome, RuntimeInformationProbeOutcome::Written);
    }

    #[test]
    fn additional_arguments_after_probe_flag_return_unexpected_arguments() {
        let identity = RuntimeIdentity::http_acquisition("example-source", 1);
        let mut output = Vec::new();

        let error = try_write_runtime_information_probe(
            identity,
            &HttpSourceContractV1::new(acquire_handler),
            HttpCapabilitySet::empty(),
            &[
                OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT),
                OsString::from("extra"),
            ],
            &mut output,
        )
        .unwrap_err();

        assert!(matches!(
            error,
            RuntimeInformationProbeError::UnexpectedArguments
        ));
        assert!(output.is_empty());
    }

    #[test]
    fn probe_flag_in_later_position_returns_not_requested() {
        let mut output = Vec::new();
        let outcome = try_write_runtime_information_probe(
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire_handler),
            HttpCapabilitySet::empty(),
            &[
                OsString::from("--another-mode"),
                OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT),
            ],
            &mut output,
        )
        .unwrap();

        assert_eq!(outcome, RuntimeInformationProbeOutcome::NotRequested);
        assert!(output.is_empty());
    }

    #[test]
    fn writer_failure_returns_output_error() {
        let identity = RuntimeIdentity::http_acquisition("example-source", 1);
        let source = HttpSourceContractV1::new(acquire_handler);
        let mut writer = RecordingWriter {
            fail_write: true,
            ..RecordingWriter::default()
        };

        let error = try_write_runtime_information_probe(
            identity,
            &source,
            HttpCapabilitySet::empty(),
            &[OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT)],
            &mut writer,
        )
        .unwrap_err();

        assert!(matches!(error, RuntimeInformationProbeError::Output(_)));
    }

    #[test]
    fn flush_failure_returns_output_error() {
        let identity = RuntimeIdentity::http_acquisition("example-source", 1);
        let source = HttpSourceContractV1::new(acquire_handler);
        let mut writer = RecordingWriter {
            fail_flush: true,
            ..RecordingWriter::default()
        };

        let error = try_write_runtime_information_probe(
            identity,
            &source,
            HttpCapabilitySet::empty(),
            &[OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT)],
            &mut writer,
        )
        .unwrap_err();

        assert!(matches!(error, RuntimeInformationProbeError::Output(_)));
    }

    #[cfg(unix)]
    #[test]
    fn unrelated_non_utf8_unix_argument_returns_not_requested() {
        use std::os::unix::ffi::OsStringExt;

        let mut output = Vec::new();
        let outcome = try_write_runtime_information_probe(
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire_handler),
            HttpCapabilitySet::empty(),
            &[OsString::from_vec(vec![0xFF, 0xFE, 0x00])],
            &mut output,
        )
        .unwrap();

        assert_eq!(outcome, RuntimeInformationProbeOutcome::NotRequested);
        assert!(output.is_empty());
    }
}

// --- Normal-invocation execution ---

#[derive(Debug)]
pub enum HttpRuntimeInvocationExecutionError {
    Transport(RuntimeInvocationTransportDecodingError),
    Admission(HttpRuntimeInvocationAdmissionError),
    Session(CoreRunnerSessionError),
    SourceStateDirectoryPreparation(crate::protocols::http::context::SessionValidationError),
    SourceStateDirectoryPreparationAndPersistence {
        setup_error: crate::protocols::http::context::SessionValidationError,
        session_error: crate::session::SessionStoreError,
    },
    Handler(AcquisitionError),
    /// The acquisition or resume handler propagated a Rust panic across the
    /// Core boundary. Core caught the unwinding and translated it to this
    /// fixed status so the durable record never retains arbitrary panic
    /// text and the session reconciliation never reports success.
    HandlerPanicked,
    HandlerPanicPersistence {
        session_error: crate::session::SessionStoreError,
    },
    TerminalPersistence {
        handler_error: Option<AcquisitionError>,
        session_error: crate::session::SessionStoreError,
    },
}

impl fmt::Display for HttpRuntimeInvocationExecutionError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Transport(_) => {
                formatter.write_str("HTTP runtime invocation transport decoding error")
            }
            Self::Admission(_) => formatter.write_str("HTTP runtime invocation admission error"),
            Self::Session(_) => formatter.write_str("HTTP runtime session initialization error"),
            Self::SourceStateDirectoryPreparation(_) => {
                formatter.write_str("failed to prepare the durable source-state directory")
            }
            Self::SourceStateDirectoryPreparationAndPersistence { .. } => {
                formatter.write_str("failed to prepare durable source state and failed to persist the terminal session failure")
            }
            Self::Handler(_) => formatter.write_str("acquisition handler error"),
            Self::HandlerPanicked => {
                formatter.write_str(
                    "HTTP runtime handler panicked; session is reconciled as failed",
                )
            }
            Self::HandlerPanicPersistence { .. } => {
                formatter.write_str("HTTP runtime handler panicked and terminal failure persistence also failed")
            }
            Self::TerminalPersistence { handler_error: Some(_), .. } => {
                formatter.write_str("acquisition handler error; terminal session state persistence also failed")
            }
            Self::TerminalPersistence { handler_error: None, .. } => {
                formatter.write_str("terminal session state persistence failed after successful handler")
            }
        }
    }
}

impl std::error::Error for HttpRuntimeInvocationExecutionError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::Transport(e) => Some(e),
            Self::Admission(e) => Some(e),
            Self::Session(e) => Some(e),
            Self::SourceStateDirectoryPreparation(e) => Some(e),
            Self::SourceStateDirectoryPreparationAndPersistence { setup_error, .. } => Some(setup_error),
            Self::Handler(e) => Some(e),
            Self::HandlerPanicked => None,
            Self::HandlerPanicPersistence { session_error } => Some(session_error),
            Self::TerminalPersistence { session_error, .. } => Some(session_error),
        }
    }
}

/// Run an HTTP runtime invocation with full session lifecycle.
///
/// Supported order:
/// 1. Parse invocation argv.
/// 2. Admit invocation.
/// 3. Decode runtime context configuration from the environment.
/// 4. Compare context identities with admitted envelope.
/// 5. Open session store.
/// 6. Acquire/confirm session lease.
/// 7. Construct the bound operation context.
/// 8. Durably establish and revalidate source-owned state.
/// 9. Transition Prepared → Running.
/// 10. Invoke the selected handler.
/// 11. Persist Succeeded or ordinary Failed.
/// 12. Return typed result.
pub fn run_http_runtime_invocation(
    arguments: &[OsString],
    compiled_identity: RuntimeIdentity,
    source: &HttpSourceContractV1,
    available_capabilities: HttpCapabilitySet,
) -> Result<(), HttpRuntimeInvocationExecutionError> {
    let parsed = parse_runtime_invocation(arguments)
        .map_err(HttpRuntimeInvocationExecutionError::Transport)?;

    let admitted =
        admit_http_runtime_invocation(parsed, compiled_identity, source, available_capabilities)
            .map_err(HttpRuntimeInvocationExecutionError::Admission)?;

    let (envelope, source_arguments, handler, _) = admitted.into_parts();

    // Decode runtime context and compare identities against admitted envelope.
    let context_document = decode_runtime_context_from_env(
        envelope.project(),
        envelope.runtime(),
        envelope.session(),
    )
    .map_err(|e| {
        HttpRuntimeInvocationExecutionError::Session(CoreRunnerSessionError::ContextDecode(e))
    })?;

    let operation_root = SessionOperationRoot::new(
        context_document.paths.operation_root().to_path_buf(),
    )
    .map_err(|e| {
        HttpRuntimeInvocationExecutionError::Session(CoreRunnerSessionError::StoreOpen(e))
    })?;

    let store = SessionStore::open(operation_root).map_err(|e| {
        HttpRuntimeInvocationExecutionError::Session(CoreRunnerSessionError::StoreOpen(e))
    })?;

    let bound = bind_runtime_session_with_lease_identity(
        &store,
        &envelope,
        context_document.lease_identity.as_ref(),
    ).map_err(|err| {
        HttpRuntimeInvocationExecutionError::Session(CoreRunnerSessionError::SessionBinding(err))
    })?;
    let data_paths = SessionDataPaths::from_context_paths(&context_document.paths);
    let mut context =
        HttpAcquisitionContext::from_session_data_paths(data_paths, envelope.session().clone());

    // Create, durably publish, and revalidate the source-state directory while
    // the durable session is still Prepared. `Running` means all mandatory
    // operation resources exist and source dispatch can begin.
    if let Err(setup_error) = context.ensure_source_state_directory_ready() {
        return Err(match bound.fail_runtime(
            crate::session::SessionFailureCode::HandlerStateUnavailable,
            Some("durable source-state directory preparation failed".to_string()),
        ) {
            Ok(_) => HttpRuntimeInvocationExecutionError::SourceStateDirectoryPreparation(setup_error),
            Err(session_error) => {
                HttpRuntimeInvocationExecutionError::SourceStateDirectoryPreparationAndPersistence {
                    setup_error,
                    session_error,
                }
            }
        });
    }

    let running = bound.enter_running().map_err(|e| {
        HttpRuntimeInvocationExecutionError::Session(
            CoreRunnerSessionError::TransitionToRunning(e),
        )
    })?;

    // Invoke the selected handler with panic catching so an unwinding source
    // never escapes Core's boundary. Core translates the panic to a typed
    // `HandlerPanicked` error and reconciles the session as failed before
    // returning; the durable record carries the fixed `HandlerPanicked`
    // failure code, never arbitrary panic text.
    let handler_result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| match handler {
        AdmittedHttpHandler::Acquire(f) => f(&mut context, &source_arguments),
        AdmittedHttpHandler::Resume(f) => f(&mut context, &source_arguments),
    }));

    match handler_result {
        Ok(Ok(())) => {
            running.complete().map_err(|e| {
                HttpRuntimeInvocationExecutionError::TerminalPersistence {
                    handler_error: None,
                    session_error: e,
                }
            })?;
            Ok(())
        }
        Ok(Err(acquisition_error)) => {
            if let Err(persist_error) = running.fail_source() {
                return Err(HttpRuntimeInvocationExecutionError::TerminalPersistence {
                    handler_error: Some(acquisition_error),
                    session_error: persist_error,
                });
            }
            Err(HttpRuntimeInvocationExecutionError::Handler(acquisition_error))
        }
        Err(panic_payload) => {
            // Replace panic payload with a sanitized, fixed diagnostic so
            // arbitrary source panic text never reaches the durable session
            // failure record.
            drop(panic_payload);
            match running.fail_runtime(
                crate::session::SessionFailureCode::HandlerPanicked,
                Some("handler panicked; sanitizer did not propagate payload".to_string()),
            ) {
                Ok(_) => Err(HttpRuntimeInvocationExecutionError::HandlerPanicked),
                Err(session_error) => Err(
                    HttpRuntimeInvocationExecutionError::HandlerPanicPersistence { session_error },
                ),
            }
        }
    }
}

// A prior `execution_tests` module here (matching-acquire/resume dispatch, source-
// argument fidelity, and success/handler-error assertions) predated
// `run_http_runtime_invocation` growing full session-store/lease/env-context binding
// (see the function's doc comment above: steps 3-8). Those tests never set up a
// `SessionStore`, a `Prepared` session record, a held lease, or the
// `LEXICON_RUNTIME_CONTEXT_V1` env var, so every test that expected the handler to be
// reached failed with `Session(ContextDecode(MissingEnvironmentVariable))`, and were
// removed rather than left disabled with `#[ignore]`. The tests immediately below are
// the subset that never reached session-context decoding in the first place (pure
// transport/admission rejection paths) and remain valid, unmodified coverage.
//
// Full handler-dispatch coverage is restored further down using
// `crate::session::test_support::RuntimeInvocationFixture`, which builds the real
// minimum session-store/lease/runtime-context environment the production path
// requires (see `session::test_support` for the fixture's design).
#[cfg(test)]
mod execution_tests {
    use std::ffi::OsString;
    use std::path::Path;
    use std::sync::{Arc, OnceLock};
    use std::sync::atomic::{AtomicUsize, Ordering};

    use crate::HttpAcquisitionContext;
    use crate::protocols::http::{
        AcquisitionError, AcquisitionResult, HttpCapability, HttpCapabilitySet,
        HttpSourceContractV1,
    };
    use crate::runtime::{
        ProjectInvocationIdentity, RuntimeExecutionMode, RuntimeIdentity,
        RuntimeInvocationEnvelopeV1, RuntimeSupervisionMode, SessionInvocationIdentity,
    };
    use crate::session::test_support::RuntimeInvocationFixture;

    use super::{HttpRuntimeInvocationExecutionError, run_http_runtime_invocation};

    fn run_envelope() -> RuntimeInvocationEnvelopeV1 {
        RuntimeInvocationEnvelopeV1::new(
            ProjectInvocationIdentity::new("example-project").unwrap(),
            RuntimeIdentity::http_acquisition("example-source", 1),
            SessionInvocationIdentity::new("session-abc").unwrap(),
            RuntimeExecutionMode::Run,
            RuntimeSupervisionMode::Foreground,
        )
        .unwrap()
    }

    fn resume_envelope() -> RuntimeInvocationEnvelopeV1 {
        RuntimeInvocationEnvelopeV1::new(
            ProjectInvocationIdentity::new("example-project").unwrap(),
            RuntimeIdentity::http_acquisition("example-source", 1),
            SessionInvocationIdentity::new("session-abc").unwrap(),
            RuntimeExecutionMode::Resume,
            RuntimeSupervisionMode::Foreground,
        )
        .unwrap()
    }

    fn encode(envelope: &RuntimeInvocationEnvelopeV1, source_args: &[OsString]) -> Vec<OsString> {
        let mut args = vec![
            OsString::from("--lexicon-invocation-v1"),
            OsString::from(envelope.to_json().unwrap()),
            OsString::from("--"),
        ];
        args.extend_from_slice(source_args);
        args
    }

    // Test 1: malformed transport returns Transport error
    #[test]
    fn malformed_transport_returns_transport_error() {
        let args = vec![OsString::from("--not-invocation-flag")];
        let err = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(|_: &mut HttpAcquisitionContext, _: &[OsString]| Ok(())),
            HttpCapabilitySet::empty(),
        )
        .unwrap_err();
        assert!(matches!(
            err,
            HttpRuntimeInvocationExecutionError::Transport(_)
        ));
    }

    // Test 2: probe arguments passed to normal invocation return transport error
    #[test]
    fn probe_arguments_return_transport_error() {
        use crate::runtime::RUNTIME_INFORMATION_PROBE_ARGUMENT;
        let args = vec![OsString::from(RUNTIME_INFORMATION_PROBE_ARGUMENT)];
        let err = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(|_: &mut HttpAcquisitionContext, _: &[OsString]| Ok(())),
            HttpCapabilitySet::empty(),
        )
        .unwrap_err();
        assert!(matches!(
            err,
            HttpRuntimeInvocationExecutionError::Transport(_)
        ));
    }

    // Test 3: identity mismatch returns Admission error
    #[test]
    fn identity_mismatch_returns_admission_error() {
        fn acquire(_ctx: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            Ok(())
        }
        let args = encode(&run_envelope(), &[]);
        let err = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("different-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        )
        .unwrap_err();
        assert!(matches!(
            err,
            HttpRuntimeInvocationExecutionError::Admission(_)
        ));
    }

    // Test 4: missing capabilities return Admission error
    #[test]
    fn missing_capabilities_return_admission_error() {
        fn acquire(_ctx: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            Ok(())
        }
        let args = encode(&run_envelope(), &[]);
        let err = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire).requires(HttpCapability::ClientCertificateV1),
            HttpCapabilitySet::empty(),
        )
        .unwrap_err();
        assert!(matches!(
            err,
            HttpRuntimeInvocationExecutionError::Admission(_)
        ));
    }

    // Test 5: missing resume returns Admission error
    #[test]
    fn missing_resume_handler_returns_admission_error() {
        fn acquire(_ctx: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            Ok(())
        }
        let args = encode(&resume_envelope(), &[]);
        let err = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire), // no resume registered
            HttpCapabilitySet::empty(),
        )
        .unwrap_err();
        assert!(matches!(
            err,
            HttpRuntimeInvocationExecutionError::Admission(_)
        ));
    }

    // Test 6: wrong compiled operation returns Admission error
    #[test]
    fn wrong_compiled_operation_returns_admission_error() {
        fn acquire(_ctx: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            Ok(())
        }
        let args = encode(&run_envelope(), &[]);
        let err = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::from_parts(
                "example-source",
                crate::runtime::RuntimeProtocol::Http,
                crate::runtime::RuntimeOperation::Processing,
                1,
            ),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        )
        .unwrap_err();
        assert!(matches!(
            err,
            HttpRuntimeInvocationExecutionError::Admission(_)
        ));
    }

    // Test 7: transport failure invokes neither acquire nor resume
    #[test]
    fn transport_failure_invokes_neither_handler() {
        fn acquire_must_not_be_called(
            _ctx: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            panic!("acquire must not be called on transport failure");
        }
        fn resume_must_not_be_called(
            _ctx: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            panic!("resume must not be called on transport failure");
        }
        let args = vec![]; // empty → transport error
        let err = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire_must_not_be_called)
                .with_resume(resume_must_not_be_called),
            HttpCapabilitySet::empty(),
        )
        .unwrap_err();
        assert!(matches!(
            err,
            HttpRuntimeInvocationExecutionError::Transport(_)
        ));
    }

    // Test 8: admission failure invokes neither acquire nor resume
    #[test]
    fn admission_failure_invokes_neither_handler() {
        fn acquire_must_not_be_called(
            _ctx: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            panic!("acquire must not be called on admission failure");
        }
        fn resume_must_not_be_called(
            _ctx: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            panic!("resume must not be called on admission failure");
        }
        let args = encode(&run_envelope(), &[]);
        let err = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("wrong-source", 1),
            &HttpSourceContractV1::new(acquire_must_not_be_called)
                .with_resume(resume_must_not_be_called),
            HttpCapabilitySet::empty(),
        )
        .unwrap_err();
        assert!(matches!(
            err,
            HttpRuntimeInvocationExecutionError::Admission(_)
        ));
    }

    // Test 9: error formatting does not expose source arguments
    #[test]
    fn error_formatting_does_not_expose_source_arguments() {
        fn acquire(_ctx: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            Ok(())
        }
        let source_args = vec![
            OsString::from("secret-arg"),
            OsString::from("another-secret"),
        ];
        let args = encode(&run_envelope(), &source_args);
        let err = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("wrong-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        )
        .unwrap_err();
        let msg = format!("{err}");
        assert!(
            !msg.contains("secret-arg"),
            "message exposed source args: {msg}"
        );
        assert!(
            !msg.contains("another-secret"),
            "message exposed source args: {msg}"
        );
    }

    // Test 10: error formatting does not expose envelope JSON
    #[test]
    fn error_formatting_does_not_expose_envelope_json() {
        fn acquire(_ctx: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            Ok(())
        }
        let args = encode(&run_envelope(), &[]);
        let err = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("wrong-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        )
        .unwrap_err();
        let msg = format!("{err}");
        assert!(
            !msg.contains("schema_version"),
            "message exposed envelope JSON: {msg}"
        );
        assert!(
            !msg.contains('{'),
            "message exposed JSON-like content: {msg}"
        );
    }

    // --- Fixture-backed handler-dispatch coverage ---
    //
    // Each test below builds a real `SessionStore`-backed `Prepared` session, an owned
    // lease, and a valid `LEXICON_RUNTIME_CONTEXT_V1` environment via
    // `RuntimeInvocationFixture`, then drives `run_http_runtime_invocation` through the
    // unmodified production path so the acquire/resume handler is genuinely reached.

    // Test 11: a matching invocation reaches the acquire handler exactly once with a
    // real, mutable `HttpAcquisitionContext`.
    #[test]
    fn matching_invocation_reaches_acquire_handler_exactly_once_with_real_context() {
        static CALLS: AtomicUsize = AtomicUsize::new(0);
        fn acquire(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            CALLS.fetch_add(1, Ordering::SeqCst);
            assert!(context.session_identity().is_some());
            assert!(
                context
                    .protocol_root()
                    .to_string_lossy()
                    .contains("example-source")
            );
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(RuntimeIdentity::http_acquisition(
            "example-source",
            1,
        ));
        let args = fixture.build_argv(&[]);

        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );

        assert!(result.is_ok(), "{result:?}");
        assert_eq!(CALLS.load(Ordering::SeqCst), 1);
    }

    // Test 12: background supervision also reaches the handler.
    #[test]
    fn background_invocation_reaches_handler() {
        static CALLS: AtomicUsize = AtomicUsize::new(0);
        fn acquire(_ctx: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            CALLS.fetch_add(1, Ordering::SeqCst);
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::background_run(RuntimeIdentity::http_acquisition(
            "example-source",
            1,
        ));
        let args = fixture.build_argv(&[]);

        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );

        assert!(result.is_ok(), "{result:?}");
        assert_eq!(CALLS.load(Ordering::SeqCst), 1);
    }

    // Test 13: a resume-mode invocation reaches the resume handler, never acquire.
    #[test]
    fn resume_invocation_reaches_resume_handler_not_acquire() {
        static ACQUIRE_CALLS: AtomicUsize = AtomicUsize::new(0);
        static RESUME_CALLS: AtomicUsize = AtomicUsize::new(0);
        fn acquire(_ctx: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            ACQUIRE_CALLS.fetch_add(1, Ordering::SeqCst);
            Ok(())
        }
        fn resume(_ctx: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            RESUME_CALLS.fetch_add(1, Ordering::SeqCst);
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::new(
            RuntimeIdentity::http_acquisition("example-source", 1),
            RuntimeExecutionMode::Resume,
            RuntimeSupervisionMode::Foreground,
        );
        let args = fixture.build_argv(&[]);

        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire).with_resume(resume),
            HttpCapabilitySet::empty(),
        );

        assert!(result.is_ok(), "{result:?}");
        assert_eq!(ACQUIRE_CALLS.load(Ordering::SeqCst), 0);
        assert_eq!(RESUME_CALLS.load(Ordering::SeqCst), 1);
    }

    // Test 14: source-argument fidelity — order, duplicates, empty values, a literal
    // `--`, reserved-looking flags, and Unicode all survive dispatch unchanged.
    #[test]
    fn source_argument_fidelity_is_preserved_across_dispatch() {
        static SEEN: OnceLock<Vec<OsString>> = OnceLock::new();
        fn acquire(_ctx: &mut HttpAcquisitionContext, args: &[OsString]) -> AcquisitionResult<()> {
            let _ = SEEN.set(args.to_vec());
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(RuntimeIdentity::http_acquisition(
            "example-source",
            1,
        ));
        let source_args = vec![
            OsString::from("alpha"),
            OsString::from("alpha"),
            OsString::from(""),
            OsString::from("--"),
            OsString::from("--looks-like-a-flag"),
            OsString::from("héllo-üñîçødé"),
        ];
        let args = fixture.build_argv(&source_args);

        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );

        assert!(result.is_ok(), "{result:?}");
        assert_eq!(SEEN.get().unwrap(), &source_args);
    }

    // Test 15: non-UTF-8 Unix source arguments are preserved byte-for-byte.
    #[cfg(unix)]
    #[test]
    fn non_utf8_unix_source_argument_is_preserved_byte_for_byte() {
        use std::os::unix::ffi::OsStringExt;

        static SEEN: OnceLock<Vec<OsString>> = OnceLock::new();
        fn acquire(_ctx: &mut HttpAcquisitionContext, args: &[OsString]) -> AcquisitionResult<()> {
            let _ = SEEN.set(args.to_vec());
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(RuntimeIdentity::http_acquisition(
            "example-source",
            1,
        ));
        let source_args = vec![OsString::from_vec(vec![b'a', 0x80, b'z'])];
        let args = fixture.build_argv(&source_args);

        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );

        assert!(result.is_ok(), "{result:?}");
        assert_eq!(SEEN.get().unwrap(), &source_args);
    }

    // Test 16: a source-authored error maps to `Handler(_)` with exactly one dispatch.
    #[test]
    fn source_authored_error_returns_handler_error_without_reinvocation() {
        static CALLS: AtomicUsize = AtomicUsize::new(0);
        fn acquire(_ctx: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            CALLS.fetch_add(1, Ordering::SeqCst);
            Err(AcquisitionError::source_message("network unreachable"))
        }

        let fixture = RuntimeInvocationFixture::foreground_run(RuntimeIdentity::http_acquisition(
            "example-source",
            1,
        ));
        let args = fixture.build_argv(&[]);

        let err = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        )
        .unwrap_err();

        assert!(matches!(err, HttpRuntimeInvocationExecutionError::Handler(_)));
        assert_eq!(CALLS.load(Ordering::SeqCst), 1);
    }

    // Test 17: a successful handler moves the session Prepared -> Running -> Succeeded.
    #[test]
    fn session_transitions_to_succeeded_after_successful_handler() {
        fn acquire(_ctx: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(RuntimeIdentity::http_acquisition(
            "example-source",
            1,
        ));
        let args = fixture.build_argv(&[]);

        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );
        assert!(result.is_ok(), "{result:?}");

        let record = fixture.store().load(fixture.session()).unwrap();
        assert_eq!(record.state(), crate::session::SessionState::Succeeded);
    }

    // Test 18: a source-authored failure moves the session Prepared -> Running -> Failed.
    #[test]
    fn session_transitions_to_failed_after_source_authored_error() {
        fn acquire(_ctx: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            Err(AcquisitionError::source_message("network unreachable"))
        }

        let fixture = RuntimeInvocationFixture::foreground_run(RuntimeIdentity::http_acquisition(
            "example-source",
            1,
        ));
        let args = fixture.build_argv(&[]);

        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );
        assert!(result.is_err());

        let record = fixture.store().load(fixture.session()).unwrap();
        assert_eq!(record.state(), crate::session::SessionState::Failed);
    }

    // Test 19: an envelope session that was never prepared/leased in this fixture's
    // store is rejected before the handler is ever dispatched (lease/invocation
    // session identities must agree).
    #[test]
    fn session_identity_mismatch_is_rejected_before_handler_dispatch() {
        fn acquire_must_not_be_called(
            _ctx: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            panic!("acquire must not be called when the envelope session was never prepared");
        }

        // Establishes a real session-store/lease/env-context environment for a
        // different session id than the one encoded below.
        let _fixture = RuntimeInvocationFixture::foreground_run(RuntimeIdentity::http_acquisition(
            "example-source",
            1,
        ));

        let foreign_envelope = RuntimeInvocationEnvelopeV1::new(
            ProjectInvocationIdentity::new("example-project").unwrap(),
            RuntimeIdentity::http_acquisition("example-source", 1),
            SessionInvocationIdentity::new("never-prepared-session").unwrap(),
            RuntimeExecutionMode::Run,
            RuntimeSupervisionMode::Foreground,
        )
        .unwrap();
        let args = vec![
            OsString::from("--lexicon-invocation-v1"),
            OsString::from(foreign_envelope.to_json().unwrap()),
            OsString::from("--"),
        ];

        let err = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire_must_not_be_called),
            HttpCapabilitySet::empty(),
        )
        .unwrap_err();

        assert!(matches!(err, HttpRuntimeInvocationExecutionError::Session(_)));
    }

    // Test 20: Core creates and validates `source_state_directory()` before the
    // acquire handler runs, and it is writable from inside the handler.
    #[test]
    fn source_state_directory_is_created_and_writable_before_handler_runs() {
        fn acquire(context: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            let state_dir = context.source_state_directory();
            assert!(state_dir.is_dir(), "Core must create the directory before dispatch");
            assert!(state_dir.ends_with("get-raw-data/state"));
            std::fs::write(state_dir.join("marker.txt"), b"seen")
                .expect("handler must be able to write into source_state_directory");
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(RuntimeIdentity::http_acquisition(
            "example-source",
            1,
        ));
        let args = fixture.build_argv(&[]);

        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );

        assert!(result.is_ok(), "{result:?}");
    }

    #[test]
    fn source_state_setup_failure_never_publishes_running_or_dispatches_handler() {
        static CALLS: AtomicUsize = AtomicUsize::new(0);
        fn must_not_run(
            _context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            CALLS.fetch_add(1, Ordering::SeqCst);
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        std::fs::write(fixture.source_state_directory(), b"not-a-directory").unwrap();
        let result = run_http_runtime_invocation(
            &fixture.build_argv(&[]),
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(must_not_run),
            HttpCapabilitySet::empty(),
        );

        assert!(matches!(
            result,
            Err(HttpRuntimeInvocationExecutionError::SourceStateDirectoryPreparation(_))
        ));
        assert_eq!(CALLS.load(Ordering::SeqCst), 0);
        let record = fixture.store().load(fixture.session()).unwrap();
        assert_eq!(record.state(), crate::session::SessionState::Failed);
        assert!(record.started_at().is_none(), "state setup failure must occur before Running");
    }

    #[test]
    fn checkpoint_commit_rejects_key_without_durable_transaction() {
        fn acquire(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            let error = context.commit_checkpoint("work/no-transaction").unwrap_err();
            assert!(matches!(
                error,
                AcquisitionError::CheckpointCommit(
                    crate::protocols::http::HttpCheckpointCommitError::NoTransactionForKey
                )
            ));
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        run_http_runtime_invocation(
            &fixture.build_argv(&[]),
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        )
        .unwrap();
    }

    #[test]
    fn checkpoint_lookup_fails_closed_when_backing_transaction_is_missing() {
        use crate::protocols::http::checkpoint::error::{
            HttpCheckpointAdmissionError, HttpCheckpointLookupError,
            HttpCheckpointTransactionLookupError,
        };
        use crate::protocols::http::request::HttpRequest;

        static URL: OnceLock<String> = OnceLock::new();
        fn commit(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            context.execute(
                HttpRequest::get(URL.get().unwrap())
                    .unwrap()
                    .logical_key("missing/backing")
                    .unwrap(),
            )?;
            context.commit_checkpoint("missing/backing")?;
            Ok(())
        }
        fn lookup(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            let error = context.has_checkpoint("missing/backing").unwrap_err();
            let AcquisitionError::CheckpointLookup(
                HttpCheckpointLookupError::CandidateAdmission { source, .. },
            ) = error
            else {
                panic!("unexpected lookup error: {error:?}");
            };
            assert!(matches!(
                *source,
                HttpCheckpointAdmissionError::TransactionLookup(
                    HttpCheckpointTransactionLookupError::MissingTransaction
                )
            ));
            Ok(())
        }

        let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        URL.set(format!("http://{}/one", listener.local_addr().unwrap())).unwrap();
        let server = std::thread::spawn(move || {
            use std::io::{Read, Write};
            let (mut stream, _) = listener.accept().unwrap();
            let mut request = [0_u8; 1024];
            let _ = stream.read(&mut request);
            stream
                .write_all(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok")
                .unwrap();
            stream.flush().unwrap();
        });

        let mut fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        run_http_runtime_invocation(
            &fixture.build_argv(&[]),
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(commit),
            HttpCapabilitySet::empty(),
        )
        .unwrap();
        server.join().unwrap();
        let transaction = std::fs::read_dir(fixture.raw_data_directory())
            .unwrap()
            .next()
            .unwrap()
            .unwrap()
            .path();
        std::fs::remove_dir_all(transaction).unwrap();

        fixture.advance_to_new_session();
        run_http_runtime_invocation(
            &fixture.build_argv(&[]),
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(lookup),
            HttpCapabilitySet::empty(),
        )
        .unwrap();
    }

    #[test]
    fn checkpoint_lookup_rejects_malformed_foreign_mismatched_and_replayed_receipts() {
        use crate::protocols::http::checkpoint::error::{
            HttpCheckpointAdmissionError, HttpCheckpointDecodingError,
            HttpCheckpointLookupError,
        };
        use crate::protocols::http::request::HttpRequest;
        use sha2::{Digest, Sha256};

        static URL: OnceLock<String> = OnceLock::new();
        static CASE: AtomicUsize = AtomicUsize::new(0);
        fn commit(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            context.execute(
                HttpRequest::get(URL.get().unwrap())
                    .unwrap()
                    .logical_key("binding/key")
                    .unwrap(),
            )?;
            context.commit_checkpoint("binding/key")?;
            Ok(())
        }
        fn reject(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            let error = context.has_checkpoint("binding/key").unwrap_err();
            let AcquisitionError::CheckpointLookup(
                HttpCheckpointLookupError::CandidateAdmission { source, .. },
            ) = error
            else {
                panic!("unexpected lookup error: {error:?}");
            };
            let matches_case = match CASE.load(Ordering::SeqCst) {
                0 => matches!(source.as_ref(), HttpCheckpointAdmissionError::Decoding(_)),
                1 => matches!(source.as_ref(), HttpCheckpointAdmissionError::OversizedDocument { .. }),
                2 => matches!(source.as_ref(), HttpCheckpointAdmissionError::ProjectMismatch),
                3 | 5 | 6 => matches!(source.as_ref(), HttpCheckpointAdmissionError::RuntimeMismatch),
                4 => matches!(
                    source.as_ref(),
                    HttpCheckpointAdmissionError::Decoding(
                        HttpCheckpointDecodingError::InvalidRuntimeIdentity
                    )
                ),
                7 | 11 => matches!(source.as_ref(), HttpCheckpointAdmissionError::SessionMismatch),
                8 => matches!(source.as_ref(), HttpCheckpointAdmissionError::AttemptMismatch),
                9 => matches!(source.as_ref(), HttpCheckpointAdmissionError::TransactionKeyMismatch),
                10 => matches!(source.as_ref(), HttpCheckpointAdmissionError::TransactionSessionMismatch),
                12 => matches!(source.as_ref(), HttpCheckpointAdmissionError::TimestampBeforeTransaction),
                13 => matches!(source.as_ref(), HttpCheckpointAdmissionError::TimestampAfterSessionFinish),
                case => panic!("unknown checkpoint rejection case {case}"),
            };
            assert!(matches_case, "wrong admission error for case {}: {source:?}", CASE.load(Ordering::SeqCst));
            Ok(())
        }

        let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        URL.set(format!("http://{}/binding", listener.local_addr().unwrap())).unwrap();
        let server = std::thread::spawn(move || {
            use std::io::{Read, Write};
            let (mut stream, _) = listener.accept().unwrap();
            let mut request = [0_u8; 1024];
            let _ = stream.read(&mut request);
            stream
                .write_all(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok")
                .unwrap();
            stream.flush().unwrap();
        });

        let mut fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let receipt_session = fixture.session().clone();
        run_http_runtime_invocation(
            &fixture.build_argv(&[]),
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(commit),
            HttpCapabilitySet::empty(),
        )
        .unwrap();
        server.join().unwrap();

        let digest = format!("{:x}", Sha256::digest(b"binding/key"));
        let checkpoint_path = fixture
            .operation_root()
            .join("sessions")
            .join(receipt_session.id())
            .join("checkpoints")
            .join(format!("{digest}.json"));
        let valid_checkpoint = std::fs::read(&checkpoint_path).unwrap();
        let transaction_directory = std::fs::read_dir(fixture.raw_data_directory())
            .unwrap()
            .next()
            .unwrap()
            .unwrap()
            .path();
        let request_metadata_path = transaction_directory.join("request/metadata.json");
        let valid_request_metadata = std::fs::read(&request_metadata_path).unwrap();

        let run_case = |fixture: &mut RuntimeInvocationFixture, case: usize| {
            CASE.store(case, Ordering::SeqCst);
            fixture.advance_to_new_session();
            run_http_runtime_invocation(
                &fixture.build_argv(&[]),
                RuntimeIdentity::http_acquisition("example-source", 1),
                &HttpSourceContractV1::new(reject),
                HttpCapabilitySet::empty(),
            )
            .unwrap();
        };

        std::fs::write(&checkpoint_path, b"{").unwrap();
        run_case(&mut fixture, 0);
        std::fs::write(
            &checkpoint_path,
            vec![b'x'; crate::protocols::http::MAX_HTTP_CHECKPOINT_DOCUMENT_BYTES + 1],
        )
        .unwrap();
        run_case(&mut fixture, 1);

        for (case, pointer, value) in [
            (2, "/project/name", serde_json::Value::String("foreign-project".into())),
            (3, "/runtime/source", serde_json::Value::String("foreign-source".into())),
            (4, "/runtime/protocol", serde_json::Value::String("foreign-protocol".into())),
            (5, "/runtime/operation", serde_json::Value::String("process-data".into())),
            (6, "/runtime/source_contract_version", serde_json::Value::from(2)),
            (7, "/session/id", serde_json::Value::String("foreign-session".into())),
            (8, "/physical_attempt_index", serde_json::Value::from(2)),
        ] {
            let mut document: serde_json::Value = serde_json::from_slice(&valid_checkpoint).unwrap();
            *document.pointer_mut(pointer).unwrap() = value;
            std::fs::write(&checkpoint_path, serde_json::to_vec(&document).unwrap()).unwrap();
            run_case(&mut fixture, case);
        }

        std::fs::write(&checkpoint_path, &valid_checkpoint).unwrap();
        let mut request: serde_json::Value = serde_json::from_slice(&valid_request_metadata).unwrap();
        request["logical_request_key"] = serde_json::Value::String("foreign/key".into());
        std::fs::write(&request_metadata_path, serde_json::to_vec(&request).unwrap()).unwrap();
        run_case(&mut fixture, 9);

        std::fs::write(&request_metadata_path, &valid_request_metadata).unwrap();
        let mut request: serde_json::Value = serde_json::from_slice(&valid_request_metadata).unwrap();
        request["session_id"] = serde_json::Value::String(fixture.session().id().to_string());
        std::fs::write(&request_metadata_path, serde_json::to_vec(&request).unwrap()).unwrap();
        run_case(&mut fixture, 10);

        std::fs::write(&request_metadata_path, &valid_request_metadata).unwrap();
        std::fs::write(&checkpoint_path, &valid_checkpoint).unwrap();

        let mut document: serde_json::Value = serde_json::from_slice(&valid_checkpoint).unwrap();
        document["committed_at_unix_nanos"] = serde_json::Value::from(1_u64);
        std::fs::write(&checkpoint_path, serde_json::to_vec(&document).unwrap()).unwrap();
        run_case(&mut fixture, 12);

        let mut document: serde_json::Value = serde_json::from_slice(&valid_checkpoint).unwrap();
        document["committed_at_unix_nanos"] = serde_json::Value::from(u64::MAX);
        std::fs::write(&checkpoint_path, serde_json::to_vec(&document).unwrap()).unwrap();
        run_case(&mut fixture, 13);

        std::fs::write(&checkpoint_path, &valid_checkpoint).unwrap();
        fixture.advance_to_new_session();
        let replay = fixture
            .operation_root()
            .join("sessions")
            .join(fixture.session().id())
            .join("checkpoints")
            .join(format!("{digest}.json"));
        std::fs::create_dir_all(replay.parent().unwrap()).unwrap();
        std::fs::write(&replay, &valid_checkpoint).unwrap();
        CASE.store(11, Ordering::SeqCst);
        run_http_runtime_invocation(
            &fixture.build_argv(&[]),
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(reject),
            HttpCapabilitySet::empty(),
        )
        .unwrap();
    }

    #[derive(Clone)]
    struct FailingCheckpointObserver {
        phase: crate::protocols::http::checkpoint::model::HttpCheckpointPublicationPhase,
    }

    impl crate::protocols::http::checkpoint::model::HttpCheckpointPublicationObserver
        for FailingCheckpointObserver
    {
        fn after(
            &self,
            phase: crate::protocols::http::checkpoint::model::HttpCheckpointPublicationPhase,
        ) -> Result<(), std::io::Error> {
            if phase == self.phase {
                Err(std::io::Error::other("injected checkpoint publication failure"))
            } else {
                Ok(())
            }
        }
    }

    #[test]
    fn checkpoint_publication_faults_distinguish_uncommitted_from_partial_commit() {
        use crate::protocols::http::checkpoint::model::HttpCheckpointPublicationPhase;
        use crate::protocols::http::request::HttpRequest;

        static URL: OnceLock<String> = OnceLock::new();
        static PHASE: AtomicUsize = AtomicUsize::new(0);
        fn acquire(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            let phases = [
                HttpCheckpointPublicationPhase::CheckpointDirectoryPublished,
                HttpCheckpointPublicationPhase::TemporaryDocumentWritten,
                HttpCheckpointPublicationPhase::TemporaryDocumentSynced,
                HttpCheckpointPublicationPhase::DocumentPublished,
                HttpCheckpointPublicationPhase::CheckpointDirectorySynced,
            ];
            let phase = phases[PHASE.load(Ordering::SeqCst)];
            context.set_checkpoint_observer(Arc::new(FailingCheckpointObserver { phase }));
            context.execute(
                HttpRequest::get(URL.get().unwrap()).unwrap().logical_key("fault/key").unwrap(),
            )?;
            let error = context.commit_checkpoint("fault/key").unwrap_err();
            match phase {
                HttpCheckpointPublicationPhase::CheckpointDirectoryPublished
                | HttpCheckpointPublicationPhase::TemporaryDocumentWritten
                | HttpCheckpointPublicationPhase::TemporaryDocumentSynced => assert!(matches!(
                    error,
                    AcquisitionError::CheckpointCommit(
                        crate::protocols::http::HttpCheckpointCommitError::DurabilityObserver { .. }
                    )
                )),
                HttpCheckpointPublicationPhase::DocumentPublished
                | HttpCheckpointPublicationPhase::CheckpointDirectorySynced => assert!(matches!(
                    error,
                    AcquisitionError::CheckpointCommit(
                        crate::protocols::http::HttpCheckpointCommitError::PartialCommit(_)
                    )
                )),
            }
            Ok(())
        }

        fn verify_absent(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            assert!(!context.has_checkpoint("fault/key")?);
            Ok(())
        }

        fn verify_present(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            assert!(context.has_checkpoint("fault/key")?);
            Ok(())
        }

        let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        let address = listener.local_addr().unwrap();
        URL.set(format!("http://{address}/checkpoint")).unwrap();
        let server = std::thread::spawn(move || {
            use std::io::{Read, Write};
            for _ in 0..5 {
                let (mut stream, _) = listener.accept().unwrap();
                let mut request = [0_u8; 1024];
                let _ = stream.read(&mut request);
                stream
                    .write_all(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok")
                    .unwrap();
                stream.flush().unwrap();
            }
        });

        for phase in 0..5 {
            PHASE.store(phase, Ordering::SeqCst);
            let mut fixture = RuntimeInvocationFixture::foreground_run(
                RuntimeIdentity::http_acquisition("example-source", 1),
            );
            run_http_runtime_invocation(
                &fixture.build_argv(&[]),
                RuntimeIdentity::http_acquisition("example-source", 1),
                &HttpSourceContractV1::new(acquire),
                HttpCapabilitySet::empty(),
            )
            .unwrap();
            fixture.advance_to_new_session();
            let verification: crate::protocols::http::HttpAcquireFn =
                if phase <= 2 { verify_absent } else { verify_present };
            run_http_runtime_invocation(
                &fixture.build_argv(&[]),
                RuntimeIdentity::http_acquisition("example-source", 1),
                &HttpSourceContractV1::new(verification),
                HttpCapabilitySet::empty(),
            )
            .unwrap();
        }
        server.join().unwrap();
    }

    #[test]
    fn background_managed_runtime_uses_the_same_checkpoint_commit_and_resume_boundary() {
        use crate::protocols::http::request::HttpRequest;

        static URL: OnceLock<String> = OnceLock::new();
        fn commit(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            context.execute(
                HttpRequest::get(URL.get().unwrap())
                    .unwrap()
                    .logical_key("background/key")
                    .unwrap(),
            )?;
            context.commit_checkpoint("background/key")?;
            Ok(())
        }
        fn resume(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            assert!(context.has_checkpoint("background/key")?);
            Ok(())
        }

        let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
        URL.set(format!("http://{}/background", listener.local_addr().unwrap())).unwrap();
        let server = std::thread::spawn(move || {
            use std::io::{Read, Write};
            let (mut stream, _) = listener.accept().unwrap();
            let mut request = [0_u8; 1024];
            let _ = stream.read(&mut request);
            stream
                .write_all(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok")
                .unwrap();
            stream.flush().unwrap();
        });
        let mut fixture = RuntimeInvocationFixture::background_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        run_http_runtime_invocation(
            &fixture.build_argv(&[]),
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(commit),
            HttpCapabilitySet::empty(),
        )
        .unwrap();
        server.join().unwrap();
        fixture.advance_to_new_session();
        run_http_runtime_invocation(
            &fixture.build_argv(&[]),
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(resume),
            HttpCapabilitySet::empty(),
        )
        .unwrap();
    }

    // Test 21: durable source state survives across two sequential sessions against
    // the same fixture (same protocol/operation root, different session identities),
    // per specs.md §44's "state survives sessions" requirement.
    #[test]
    fn source_state_directory_persists_across_sequential_sessions() {
        fn write_marker(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            let state_dir = context.source_state_directory();
            std::fs::write(state_dir.join("marker.txt"), b"from-session-one").unwrap();
            Ok(())
        }
        fn read_marker(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            let state_dir = context.source_state_directory();
            let contents = std::fs::read(state_dir.join("marker.txt"))
                .expect("marker written by the prior session must still be present");
            assert_eq!(contents, b"from-session-one");
            Ok(())
        }

        let mut fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let first_args = fixture.build_argv(&[]);
        let first_result = run_http_runtime_invocation(
            &first_args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(write_marker),
            HttpCapabilitySet::empty(),
        );
        assert!(first_result.is_ok(), "{first_result:?}");

        fixture.advance_to_new_session();
        let second_args = fixture.build_argv(&[]);
        let second_result = run_http_runtime_invocation(
            &second_args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(read_marker),
            HttpCapabilitySet::empty(),
        );
        assert!(second_result.is_ok(), "{second_result:?}");
    }

    // -----------------------------------------------------------------------
    // Canonical source-owned WorkLedger (specs.md §13-§15, §44)
    // -----------------------------------------------------------------------

    #[derive(Debug, Clone, PartialEq, Eq)]
    struct WorkItemRecord {
        kind: String,
        stable_key: String,
        payload_version: i64,
        payload: Vec<u8>,
        status: String,
        attempt_count: i64,
        last_error: Option<String>,
        origin_transaction_id: Option<String>,
        created_at: String,
        updated_at: String,
    }

    struct WorkLedger {
        conn: rusqlite::Connection,
    }

    impl WorkLedger {
        fn open(db_path: &Path) -> Result<Self, rusqlite::Error> {
            let conn = rusqlite::Connection::open(db_path)?;
            conn.execute_batch(
                "CREATE TABLE IF NOT EXISTS work_items (
                    kind TEXT NOT NULL,
                    stable_key TEXT NOT NULL,
                    payload_version INTEGER NOT NULL,
                    payload BLOB NOT NULL,
                    status TEXT NOT NULL,
                    attempt_count INTEGER NOT NULL DEFAULT 0,
                    last_error TEXT,
                    origin_transaction_id TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (kind, stable_key)
                );",
            )?;
            Ok(Self { conn })
        }

        fn insert_if_absent(
            &self,
            kind: &str,
            stable_key: &str,
            payload: &[u8],
            origin_tx: Option<&str>,
        ) -> Result<bool, rusqlite::Error> {
            let now = "2026-08-28T00:00:00Z";
            let rows = self.conn.execute(
                "INSERT OR IGNORE INTO work_items (
                    kind, stable_key, payload_version, payload, status, attempt_count,
                    last_error, origin_transaction_id, created_at, updated_at
                ) VALUES (?1, ?2, 1, ?3, 'pending', 0, NULL, ?4, ?5, ?5)",
                rusqlite::params![kind, stable_key, payload, origin_tx, now],
            )?;
            Ok(rows > 0)
        }

        fn mark_active(&self, kind: &str, stable_key: &str) -> Result<(), rusqlite::Error> {
            self.conn.execute(
                "UPDATE work_items SET status = 'active', attempt_count = attempt_count + 1 WHERE kind = ?1 AND stable_key = ?2",
                rusqlite::params![kind, stable_key],
            )?;
            Ok(())
        }

        fn mark_complete(&self, kind: &str, stable_key: &str) -> Result<(), rusqlite::Error> {
            self.conn.execute(
                "UPDATE work_items SET status = 'complete' WHERE kind = ?1 AND stable_key = ?2",
                rusqlite::params![kind, stable_key],
            )?;
            Ok(())
        }

        fn get_item(&self, kind: &str, stable_key: &str) -> Result<Option<WorkItemRecord>, rusqlite::Error> {
            let mut stmt = self.conn.prepare(
                "SELECT kind, stable_key, payload_version, payload, status, attempt_count, last_error, origin_transaction_id, created_at, updated_at
                 FROM work_items WHERE kind = ?1 AND stable_key = ?2",
            )?;
            let mut rows = stmt.query(rusqlite::params![kind, stable_key])?;
            if let Some(row) = rows.next()? {
                Ok(Some(WorkItemRecord {
                    kind: row.get(0)?,
                    stable_key: row.get(1)?,
                    payload_version: row.get(2)?,
                    payload: row.get(3)?,
                    status: row.get(4)?,
                    attempt_count: row.get(5)?,
                    last_error: row.get(6)?,
                    origin_transaction_id: row.get(7)?,
                    created_at: row.get(8)?,
                    updated_at: row.get(9)?,
                }))
            } else {
                Ok(None)
            }
        }

        fn count_items(&self) -> Result<usize, rusqlite::Error> {
            self.conn.query_row("SELECT COUNT(*) FROM work_items", [], |r| r.get(0))
        }
    }

    // Test 22: work insertion deduplication (specs.md §13, §44).
    #[test]
    fn work_insertion_deduplication_converges_without_duplicate_rows() {
        fn acquire(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            let state_dir = context.source_state_directory();
            let ledger = WorkLedger::open(&state_dir.join("ledger.db")).unwrap();

            // Insert initial items
            assert!(ledger.insert_if_absent("video-download", "vid-1", b"{}", None).unwrap());
            assert!(ledger.insert_if_absent("video-download", "vid-2", b"{}", None).unwrap());

            // Repeated insertion of the same items must return false (already present)
            assert!(!ledger.insert_if_absent("video-download", "vid-1", b"{}", None).unwrap());
            assert!(!ledger.insert_if_absent("video-download", "vid-2", b"{}", None).unwrap());

            // Total count remains exactly 2
            assert_eq!(ledger.count_items().unwrap(), 2);
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let args = fixture.build_argv(&[]);
        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );
        assert!(result.is_ok(), "{result:?}");
    }

    // Test 23: repeated discovery convergence across sequential sessions (specs.md §14, §44).
    #[test]
    fn repeated_discovery_converges_without_duplicating_work() {
        use crate::protocols::http::request::HttpRequest;

        static DISCOVERY_URL: OnceLock<String> = OnceLock::new();

        fn spawn_mock_server() -> String {
            use std::io::{Read, Write};
            let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
            let port = listener.local_addr().unwrap().port();
            let url = format!("http://127.0.0.1:{port}/discover");
            std::thread::spawn(move || {
                for stream in listener.incoming() {
                    if let Ok(mut stream) = stream {
                        let mut buffer = [0; 512];
                        let _ = stream.read(&mut buffer);
                        let body = "[\"vid-101\",\"vid-102\",\"vid-103\"]";
                        let response = format!(
                            "HTTP/1.1 200 OK\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
                            body.len(),
                            body
                        );
                        let _ = stream.write_all(response.as_bytes());
                        let _ = stream.flush();
                    }
                }
            });
            url
        }

        let url = DISCOVERY_URL.get_or_init(spawn_mock_server);

        fn interrupted_discovery(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            let state_dir = context.source_state_directory();
            let ledger = WorkLedger::open(&state_dir.join("ledger.db")).unwrap();

            // First discovery run inserts items but simulates failure before checkpoint commit
            ledger.insert_if_absent("video-download", "vid-101", b"payload1", None).unwrap();
            ledger.insert_if_absent("video-download", "vid-102", b"payload2", None).unwrap();

            // Simulate failure before execute/commit_checkpoint
            Err(AcquisitionError::source_message("simulated discovery interruption"))
        }

        fn resumed_discovery(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            let state_dir = context.source_state_directory();
            let ledger = WorkLedger::open(&state_dir.join("ledger.db")).unwrap();

            let logical_key = "discover/history-videos";
            let url = DISCOVERY_URL.get().expect("server url initialized");
            let req = HttpRequest::get(url)
                .unwrap()
                .logical_key(logical_key)
                .unwrap();
            let _tx = context.execute(req)?;

            // Second session re-runs discovery for the same query
            ledger.insert_if_absent("video-download", "vid-101", b"payload1", None).unwrap();
            ledger.insert_if_absent("video-download", "vid-102", b"payload2", None).unwrap();
            ledger.insert_if_absent("video-download", "vid-103", b"payload3", None).unwrap();

            // Checkpoint discovery
            context.commit_checkpoint(logical_key).unwrap();
            assert!(context.has_checkpoint(logical_key).unwrap());

            // Count items: 2 from first attempt + 1 new = exactly 3
            assert_eq!(ledger.count_items().unwrap(), 3);
            Ok(())
        }

        let mut fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let first_args = fixture.build_argv(&[]);
        let first_result = run_http_runtime_invocation(
            &first_args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(interrupted_discovery),
            HttpCapabilitySet::empty(),
        );
        assert!(first_result.is_err());

        fixture.advance_to_new_session();
        let second_args = fixture.build_argv(&[]);
        let second_result = run_http_runtime_invocation(
            &second_args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(resumed_discovery),
            HttpCapabilitySet::empty(),
        );
        assert!(second_result.is_ok(), "{second_result:?}");
    }

    // Test 24a: handler panic is caught and translated to a typed error
    // (PROCESS-01 / contract.md). The audit requires confirming:
    //   - the unwinding termination is caught at the Core boundary,
    //   - the durable session record never carries the panic payload text,
    //   - `SessionFailureCode::HandlerPanicked` is the only failure code.
    #[test]
    fn handler_panic_is_caught_reconciled_and_rolls_back() {
        fn panicking_acquire(
            _context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            panic!("synthetic handler panic for PROCESS-01 panic coverage");
        }

        let fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let args = fixture.build_argv(&[]);
        let error = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(panicking_acquire),
            HttpCapabilitySet::empty(),
        )
        .expect_err("panic must surface as typed HandlerPanicked, not Ok");

        assert!(
            matches!(error, HttpRuntimeInvocationExecutionError::HandlerPanicked),
            "expected HandlerPanicked typed error, got: {error:?}"
        );

        // Verify the durable session record carries HandlerPanicked as the
        // typed failure code, never the panic payload text. The forensic
        // record survives the panic; Core's sanitizer replaces panic text
        // with a fixed diagnostic.
        let session_id = fixture.session().clone();
        let stored_record = fixture
            .store()
            .load(&session_id)
            .expect("durable session record must exist after panic");
        let failure = stored_record
            .failure()
            .expect("session must reconcile to Failed with a stored failure");
        assert_eq!(
            failure.code().identifier(),
            "handler_panicked",
            "durable failure code must identify the panic-recovery path"
        );
        let diagnostic = failure
            .diagnostic()
            .expect("HandlerPanicked must carry a sanitized diagnostic");
        assert!(
            !diagnostic.contains("synthetic"),
            "durable diagnostic must NOT preserve arbitrary source panic text: got {diagnostic:?}"
        );
    }

    // Test 24: crash after checkpoint before work completion is reconciled on next session (specs.md §15, §44).
    #[test]
    fn crash_after_checkpoint_before_work_completion_is_reconciled() {
        use crate::protocols::http::request::HttpRequest;

        const LOGICAL_KEY: &str = "work/video-download/vid-201";
        static WORK_URL: OnceLock<String> = OnceLock::new();

        fn spawn_mock_server() -> String {
            use std::io::{Read, Write};
            let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
            let port = listener.local_addr().unwrap().port();
            let url = format!("http://127.0.0.1:{port}/work");
            std::thread::spawn(move || {
                for stream in listener.incoming() {
                    if let Ok(mut stream) = stream {
                        let mut buffer = [0; 512];
                        let _ = stream.read(&mut buffer);
                        let body = "{\"status\":\"ok\"}";
                        let response = format!(
                            "HTTP/1.1 200 OK\r\nContent-Length: {}\r\nConnection: close\r\n\r\n{}",
                            body.len(),
                            body
                        );
                        let _ = stream.write_all(response.as_bytes());
                        let _ = stream.flush();
                    }
                }
            });
            url
        }

        let _ = WORK_URL.get_or_init(spawn_mock_server);

        fn crashed_work_execution(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            let state_dir = context.source_state_directory();
            let ledger = WorkLedger::open(&state_dir.join("ledger.db")).unwrap();

            ledger.insert_if_absent("video-download", "vid-201", b"{}", None).unwrap();
            ledger.mark_active("video-download", "vid-201").unwrap();

            // Execute HTTP request to register transaction
            let url = WORK_URL.get().expect("work url initialized");
            let req = HttpRequest::get(url)
                .unwrap()
                .logical_key(LOGICAL_KEY)
                .unwrap();
            let _tx = context.execute(req)?;

            // Checkpoint committed, but process crashes before work.mark_complete
            context.commit_checkpoint(LOGICAL_KEY).unwrap();

            // Simulate process abort / error before mark_complete
            Err(AcquisitionError::source_message("crash after checkpoint before complete"))
        }

        fn recovery_work_execution(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            let state_dir = context.source_state_directory();
            let ledger = WorkLedger::open(&state_dir.join("ledger.db")).unwrap();

            // Recovery checks if checkpoint already committed
            if context.has_checkpoint(LOGICAL_KEY).unwrap() {
                ledger.mark_complete("video-download", "vid-201").unwrap();
            }

            let item = ledger.get_item("video-download", "vid-201").unwrap().unwrap();
            assert_eq!(item.status, "complete");
            Ok(())
        }

        let mut fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let first_args = fixture.build_argv(&[]);
        let first_result = run_http_runtime_invocation(
            &first_args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(crashed_work_execution),
            HttpCapabilitySet::empty(),
        );
        assert!(first_result.is_err());

        fixture.advance_to_new_session();
        let second_args = fixture.build_argv(&[]);
        let second_result = run_http_runtime_invocation(
            &second_args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(recovery_work_execution),
            HttpCapabilitySet::empty(),
        );
        assert!(second_result.is_ok(), "{second_result:?}");
    }

    // Test 25: SQLite schema migration inside source state directory (specs.md §14, §44).
    #[test]
    fn sqlite_schema_migration_upgrades_tables_and_preserves_records() {
        fn run_v1_and_migrate_to_v2(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            let state_dir = context.source_state_directory();
            let db_path = state_dir.join("migrated.db");

            // Initial setup: schema version 1
            {
                let conn = rusqlite::Connection::open(&db_path).unwrap();
                conn.execute_batch(
                    "PRAGMA user_version = 1;
                     CREATE TABLE work_items (
                        kind TEXT NOT NULL,
                        stable_key TEXT NOT NULL,
                        status TEXT NOT NULL,
                        PRIMARY KEY (kind, stable_key)
                     );
                     INSERT INTO work_items VALUES ('video', 'item-1', 'pending');
                     INSERT INTO work_items VALUES ('video', 'item-2', 'complete');",
                )
                .unwrap();
            }

            // Migration to schema version 2 inside a transaction
            {
                let mut conn = rusqlite::Connection::open(&db_path).unwrap();
                let tx = conn.transaction().unwrap();
                let version: i64 = tx
                    .query_row("PRAGMA user_version", [], |row| row.get(0))
                    .unwrap();
                assert_eq!(version, 1);

                tx.execute_batch(
                    "ALTER TABLE work_items ADD COLUMN priority INTEGER DEFAULT 0;
                     PRAGMA user_version = 2;",
                )
                .unwrap();
                tx.commit().unwrap();
            }

            // Verify version 2 has upgraded schema and preserved existing records
            {
                let conn = rusqlite::Connection::open(&db_path).unwrap();
                let version: i64 = conn
                    .query_row("PRAGMA user_version", [], |row| row.get(0))
                    .unwrap();
                assert_eq!(version, 2);

                let count: i64 = conn
                    .query_row("SELECT COUNT(*) FROM work_items WHERE priority = 0", [], |row| {
                        row.get(0)
                    })
                    .unwrap();
                assert_eq!(count, 2);
            }

            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let args = fixture.build_argv(&[]);
        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(run_v1_and_migrate_to_v2),
            HttpCapabilitySet::empty(),
        );
        assert!(result.is_ok(), "{result:?}");
    }

    // Test 26: simultaneous unsupported writer rejection via SQLite locking (specs.md §44).
    #[test]
    fn simultaneous_unsupported_writer_rejection_via_sqlite_locking() {
        fn test_concurrent_writer_rejection(
            context: &mut HttpAcquisitionContext,
            _args: &[OsString],
        ) -> AcquisitionResult<()> {
            let state_dir = context.source_state_directory();
            let db_path = state_dir.join("locked.db");

            let conn1 = rusqlite::Connection::open(&db_path).unwrap();
            conn1.execute_batch(
                "CREATE TABLE items (id INTEGER PRIMARY KEY);
                 BEGIN EXCLUSIVE;",
            )
            .unwrap();

            let conn2 = rusqlite::Connection::open(&db_path).unwrap();
            conn2.busy_timeout(std::time::Duration::from_millis(10)).unwrap();

            let write_result = conn2.execute("INSERT INTO items VALUES (1)", []);
            assert!(
                write_result.is_err(),
                "concurrent write transaction must be rejected by SQLite locking"
            );

            conn1.execute_batch("COMMIT;").unwrap();
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let args = fixture.build_argv(&[]);
        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(test_concurrent_writer_rejection),
            HttpCapabilitySet::empty(),
        );
        assert!(result.is_ok(), "{result:?}");
    }

    // -----------------------------------------------------------------------
    // Comprehensive HTTP Recording Behavioral Tests (specs.md §44)
    // -----------------------------------------------------------------------

    // HTTP execution evidence uses only scoped, bounded scripted servers and
    // the production context.execute path.

    #[test]
    fn compressed_response_preserves_exact_entity_body_bytes_and_hash() {
        use crate::protocols::http::request::HttpRequest;
        use sha2::Digest as _;

        fn acquire(context: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            let expected = [0x1f, 0x8b, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03];
            let server = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Response {
                    status: 200,
                    headers: vec![(b"Content-Encoding".to_vec(), b"gzip".to_vec())],
                    body: expected.to_vec(),
                },
            ]);
            let req = HttpRequest::get(format!("{}/compressed", server.base_url)).unwrap();
            let tx = context.execute(req)?;
            let raw_body = std::fs::read(tx.directory().join("response/body")).unwrap();
            assert_eq!(raw_body, expected);
            assert_eq!(tx.response().body_length(), expected.len() as u64);
            assert_eq!(tx.response().body_sha256(), Some(format!(
                "{:x}", sha2::Sha256::digest(expected)
            ).as_str()));
            let admitted = crate::protocols::http::transaction::metadata::admit_transaction_from_disk(
                context.raw_data_directory(), tx.directory(),
            ).unwrap();
            assert_eq!(std::fs::read(admitted.response().body_path()).unwrap(), expected);
            assert_eq!(server.request_count(), 1);
            let received = server.last_request().expect("compressed GET request");
            assert_eq!(received.method, "GET");
            assert_eq!(received.path, "/compressed");
            server.assert_clean();
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let args = fixture.build_argv(&[]);
        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );
        assert!(result.is_ok(), "{result:?}");
    }

    #[test]
    fn redirect_chain_persists_each_attempt_with_parent_identity() {
        use crate::protocols::http::policy::HttpRedirectPolicy;
        use crate::protocols::http::request::HttpRequest;

        fn acquire(context: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            let server = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Redirect {
                    location: "/redirect-target".to_owned(),
                },
                crate::protocols::http::test_support::ScriptedStep::Respond {
                    status: 200,
                    body: b"ok".to_vec(),
                },
            ]);
            let req = HttpRequest::get(format!("{}/redirect-start", server.base_url))
                .unwrap()
                .redirect_policy(HttpRedirectPolicy::follow(5).unwrap());
            let tx = context.execute(req)?;
            assert_eq!(tx.attempt_identity().redirect_index(), 1);
            assert!(tx.parent_transaction_id().is_some());
            let mut admitted = std::fs::read_dir(context.raw_data_directory()).unwrap()
                .map(|entry| entry.unwrap().path())
                .filter(|path| !path.file_name().unwrap().to_string_lossy().starts_with('.'))
                .map(|path| crate::protocols::http::transaction::metadata::admit_transaction_from_disk(
                    context.raw_data_directory(), &path,
                ).unwrap())
                .collect::<Vec<_>>();
            admitted.sort_by_key(|item| item.attempt_identity().physical_attempt_index());
            assert_eq!(admitted.len(), 2);
            assert_eq!(admitted[0].response_status(), Some(302));
            assert_eq!(admitted[1].response_status(), Some(200));
            assert_eq!(admitted[1].parent_transaction_id(), Some(admitted[0].identity()));
            assert_eq!(server.request_count(), 2);
            server.assert_clean();
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let args = fixture.build_argv(&[]);
        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );
        assert!(result.is_ok(), "{result:?}");
    }

    #[test]
    fn retry_policy_persists_exactly_three_distinct_attempts() {
        use crate::protocols::http::policy::HttpRetryPolicy;
        use crate::protocols::http::request::HttpRequest;

        fn acquire(context: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            let server = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Respond { status: 500, body: b"one".to_vec() },
                crate::protocols::http::test_support::ScriptedStep::Respond { status: 500, body: b"two".to_vec() },
                crate::protocols::http::test_support::ScriptedStep::Respond { status: 500, body: b"three".to_vec() },
            ]);
            let req = HttpRequest::get(format!("{}/500-retry", server.base_url))
                .unwrap()
                .retry_policy(HttpRetryPolicy::transient(3).unwrap());
            let result = context.execute(req);
            assert!(result.is_err(), "retry exhaustion must error");
            let mut admitted = std::fs::read_dir(context.raw_data_directory()).unwrap()
                .map(|entry| entry.unwrap().path())
                .filter(|path| !path.file_name().unwrap().to_string_lossy().starts_with('.'))
                .map(|path| crate::protocols::http::transaction::metadata::admit_transaction_from_disk(
                    context.raw_data_directory(), &path,
                ).unwrap())
                .collect::<Vec<_>>();
            admitted.sort_by_key(|item| item.attempt_identity().physical_attempt_index());
            assert_eq!(admitted.len(), 3);
            for (index, item) in admitted.iter().enumerate() {
                assert_eq!(item.response_status(), Some(500));
                assert_eq!(item.attempt_identity().physical_attempt_index(), index as u32 + 1);
                assert_eq!(item.attempt_identity().retry_index(), index as u32);
                if index > 0 {
                    assert_eq!(item.parent_transaction_id(), Some(admitted[index - 1].identity()));
                }
            }
            assert_eq!(server.request_count(), 3);
            server.assert_clean();
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let args = fixture.build_argv(&[]);
        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );
        assert!(result.is_ok(), "{result:?}");
    }

    #[test]
    fn retry_admission_budget_retry_after_and_location_redaction_use_production_execute() {
        fn acquire(context: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            use crate::protocols::http::{
                HttpExecutionError, HttpRetryDelayPolicy, HttpRetryExhaustionReason,
                HttpRetryPolicy, HttpRequest, HttpRequestError,
            };
            use std::time::Duration;

            let denied_server = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Respond { status: 200, body: vec![] },
            ]);
            let denied = HttpRequest::post(format!("{}/post", denied_server.base_url)).unwrap()
                .retry_policy(HttpRetryPolicy::transient(2).unwrap());
            assert!(matches!(context.execute(denied),
                Err(AcquisitionError::Request(HttpRequestError::RetryMethodNotPermitted))));
            assert_eq!(denied_server.request_count(), 0);

            let retry_server = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Response {
                    status: 503,
                    headers: vec![(b"Retry-After".to_vec(), b"0".to_vec())],
                    body: vec![],
                },
                crate::protocols::http::test_support::ScriptedStep::Response {
                    status: 503,
                    headers: vec![(b"Retry-After".to_vec(), b"Sun, 06 Nov 1994 08:49:37 GMT".to_vec())],
                    body: vec![],
                },
                crate::protocols::http::test_support::ScriptedStep::Respond { status: 200, body: b"ok".to_vec() },
            ]);
            let policy = HttpRetryPolicy::custom(
                3, false, vec![503], ["GET"], HttpRetryDelayPolicy::Fixed(Duration::ZERO),
                true, Duration::from_secs(1),
            ).unwrap();
            let result = context.execute(HttpRequest::get(format!("{}/retry", retry_server.base_url))
                .unwrap().retry_policy(policy))?;
            assert_eq!(result.response_status(), Some(200));
            assert_eq!(retry_server.request_count(), 3);

            let budget_server = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Response {
                    status: 503,
                    headers: vec![(b"Retry-After".to_vec(), b"999".to_vec())],
                    body: vec![],
                },
            ]);
            let budget_policy = HttpRetryPolicy::custom(
                2, false, vec![503], ["GET"], HttpRetryDelayPolicy::None,
                true, Duration::from_millis(10),
            ).unwrap();
            let budget_result = context.execute(HttpRequest::get(format!("{}/budget", budget_server.base_url))
                .unwrap().retry_policy(budget_policy));
            assert!(matches!(budget_result,
                Err(AcquisitionError::Execution(HttpExecutionError::RetryExhausted(ref error)))
                    if error.reason() == HttpRetryExhaustionReason::ElapsedBudget));
            assert_eq!(budget_server.request_count(), 1);

            let secret = "location-echo-secret";
            let location_server = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Redirect {
                    location: format!("/next?api_key={secret}"),
                },
            ]);
            let transaction = context.execute(HttpRequest::get(format!(
                "{}/start?api_key={secret}", location_server.base_url,
            )).unwrap().sensitive_query_name("api_key").unwrap())?;
            let metadata = std::fs::read_to_string(
                transaction.directory().join("response/metadata.json"),
            ).unwrap();
            assert!(!metadata.contains(secret));
            assert!(metadata.contains("redacted"));
            assert_eq!(location_server.request_count(), 1);
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let result = run_http_runtime_invocation(
            &fixture.build_argv(&[]),
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );
        assert!(result.is_ok(), "{result:?}");
    }

    #[test]
    fn connection_failure_persists_finalized_failure_metadata() {
        use crate::protocols::http::request::HttpRequest;

        fn acquire(context: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            use crate::protocols::http::{HttpExecutionError, HttpRecordedOutcome};
            let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
            let address = listener.local_addr().unwrap();
            drop(listener);
            let req = HttpRequest::get(format!("http://{address}/closed")).unwrap();
            let error = context.execute(req).unwrap_err();
            let failure = match error {
                AcquisitionError::Execution(HttpExecutionError::RecordedTransportFailure(failure)) => failure,
                other => panic!("unexpected failure: {other:?}"),
            };
            assert_eq!(failure.physical_attempt_index(), 1);
            let admitted = crate::protocols::http::transaction::metadata::admit_transaction_from_disk(
                context.raw_data_directory(), failure.transaction_directory(),
            ).unwrap();
            assert!(matches!(admitted.response().outcome(), HttpRecordedOutcome::TransportFailure(_)));
            assert_eq!(admitted.attempt_identity().physical_attempt_index(), 1);
            let metadata = std::fs::read_to_string(admitted.directory().join("response/metadata.json")).unwrap();
            assert!(metadata.contains("transport_failure"));
            assert!(metadata.contains("connect"));
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let args = fixture.build_argv(&[]);
        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );
        assert!(result.is_ok(), "{result:?}");
    }

    #[test]
    fn truncated_body_preserves_partial_bytes_and_incomplete_marker() {
        use crate::protocols::http::request::HttpRequest;
        use sha2::Digest as _;

        fn acquire(context: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            let server = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Truncate {
                    status: 200,
                    announced_len: 100,
                    truncate_to: 10,
                },
            ]);
            let req = HttpRequest::get(format!("{}/truncated", server.base_url)).unwrap();
            let result = context.execute(req);
            assert!(result.is_err());
            let partial = std::fs::read_dir(context.raw_data_directory())
                .unwrap()
                .map(|entry| entry.unwrap().path())
                .find(|path| path.file_name().unwrap().to_string_lossy().starts_with(".partial-"))
                .expect("diagnostic partial transaction");
            let body = std::fs::read(partial.join("response/body")).unwrap();
            assert_eq!(body, b"partial-10");
            let metadata: serde_json::Value = serde_json::from_slice(
                &std::fs::read(partial.join("response/metadata.json")).unwrap(),
            ).unwrap();
            assert_eq!(metadata["outcome"], "incomplete_response");
            assert_eq!(metadata["status"], 200);
            assert_eq!(metadata["body_bytes_recorded"], body.len() as u64);
            assert_eq!(metadata["partial_body_sha256"], format!(
                "{:x}", sha2::Sha256::digest(&body)
            ));
            assert!(metadata["headers"].as_array().unwrap().iter().any(|header| {
                header["name"].as_str().unwrap().eq_ignore_ascii_case("content-length")
            }));
            assert_eq!(server.request_count(), 1);
            server.assert_clean();
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let args = fixture.build_argv(&[]);
        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );
        assert!(result.is_ok(), "{result:?}");
    }

    #[test]
    fn all_mandatory_and_explicit_headers_are_structurally_redacted() {
        use crate::protocols::http::request::HttpRequest;

        fn acquire(context: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            let server = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Response {
                    status: 200,
                    headers: vec![
                        (b"Set-Cookie".to_vec(), b"response-cookie-secret".to_vec()),
                        (b"X-Api-Key".to_vec(), b"response-explicit-secret".to_vec()),
                    ],
                    body: b"ok".to_vec(),
                },
            ]);
            let req = HttpRequest::get(format!("{}/explicit-redact", server.base_url))
                .unwrap()
                .header("Authorization", "Bearer top-secret")
                .unwrap()
                .header("Cookie", "session=secret")
                .unwrap()
                .header("Proxy-Authorization", "proxy-secret")
                .unwrap()
                .header("Set-Cookie", "request-cookie-secret")
                .unwrap()
                .sensitive_header("X-Api-Key", "request-explicit-secret")
                .unwrap();
            let tx = context.execute(req)?;
            let secrets = [
                "top-secret", "session=secret", "proxy-secret", "request-cookie-secret",
                "request-explicit-secret", "response-cookie-secret", "response-explicit-secret",
            ];
            fn scan(path: &std::path::Path, secrets: &[&str]) {
                for entry in std::fs::read_dir(path).unwrap() {
                    let entry = entry.unwrap();
                    if entry.file_type().unwrap().is_dir() { scan(&entry.path(), secrets); }
                    else {
                        let bytes = std::fs::read(entry.path()).unwrap();
                        for secret in secrets {
                            assert!(!bytes.windows(secret.len()).any(|window| window == secret.as_bytes()));
                        }
                    }
                }
            }
            scan(tx.directory(), &secrets);
            let admitted = crate::protocols::http::transaction::metadata::admit_transaction_from_disk(
                context.raw_data_directory(), tx.directory(),
            ).unwrap();
            for header in admitted.response().headers().as_slice() {
                if ["set-cookie", "x-api-key"].iter().any(|name| header.name().eq_ignore_ascii_case(name)) {
                    assert!(matches!(header.value(), crate::protocols::http::RecordedHeaderValue::Redacted));
                }
            }
            let meta_json = std::fs::read_to_string(tx.directory().join("request/metadata.json")).unwrap();
            let request_document: serde_json::Value = serde_json::from_str(&meta_json).unwrap();
            for header in request_document["headers"].as_array().unwrap() {
                let name = header["name"].as_str().unwrap();
                if ["authorization", "cookie", "proxy-authorization", "set-cookie", "x-api-key"]
                    .iter().any(|expected| name.eq_ignore_ascii_case(expected))
                {
                    assert_eq!(header["value"]["encoding"], "redacted");
                }
            }
            assert_eq!(server.request_count(), 1);
            server.assert_clean();
            assert!(meta_json.contains("\"encoding\":\"redacted\""));
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let args = fixture.build_argv(&[]);
        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );
        assert!(result.is_ok(), "{result:?}");
    }

    #[test]
    fn sensitive_query_never_appears_in_any_durable_or_diagnostic_text() {
        use crate::protocols::http::request::HttpRequest;

        fn acquire(context: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            let server = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Respond {
                    status: 200,
                    body: b"ok".to_vec(),
                },
            ]);
            let req = HttpRequest::get(format!(
                "{}/search?q=public&api_key=top-secret-value", server.base_url
            ))
            .unwrap()
            .sensitive_query_name("api_key")
            .unwrap();
            let tx = context.execute(req)?;
            fn scan(path: &std::path::Path, needle: &[u8]) {
                for entry in std::fs::read_dir(path).unwrap() {
                    let entry = entry.unwrap();
                    if entry.file_type().unwrap().is_dir() {
                        scan(&entry.path(), needle);
                    } else {
                        let bytes = std::fs::read(entry.path()).unwrap();
                        assert!(!bytes.windows(needle.len()).any(|window| window == needle));
                    }
                }
            }
            scan(context.raw_data_directory(), b"top-secret-value");
            assert!(!format!("{tx:?}").contains("top-secret-value"));
            assert_eq!(server.request_count(), 1);
            server.assert_clean();
            Ok(())
        }

        let fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let args = fixture.build_argv(&[]);
        let result = run_http_runtime_invocation(
            &args,
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );
        assert!(result.is_ok(), "{result:?}");
    }

    #[test]
    fn fixed_retry_delay_uses_virtual_sleeper_on_production_execute_path() {
        fn acquire(context: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            use std::sync::Arc;
            use std::time::{Duration, UNIX_EPOCH};
            use crate::protocols::http::{HttpRetryDelayPolicy, HttpRetryPolicy, HttpRequest};
            use crate::protocols::http::test_support::DeterministicHttpRetryRuntime;
            let clock = Arc::new(DeterministicHttpRetryRuntime::new(UNIX_EPOCH));
            context.set_retry_runtime(clock.clone());
            let server = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Respond { status: 503, body: vec![] },
                crate::protocols::http::test_support::ScriptedStep::Respond { status: 503, body: vec![] },
                crate::protocols::http::test_support::ScriptedStep::Respond { status: 200, body: b"ok".to_vec() },
            ]);
            let policy = HttpRetryPolicy::custom(
                3, false, vec![503], ["GET"],
                HttpRetryDelayPolicy::Fixed(Duration::from_millis(7)), false,
                Duration::from_secs(1),
            ).unwrap();
            let tx = context.execute(HttpRequest::get(format!("{}/fixed", server.base_url)).unwrap().retry_policy(policy))?;
            assert_eq!(tx.response_status(), Some(200));
            assert_eq!(clock.sleeps(), vec![Duration::from_millis(7), Duration::from_millis(7)]);
            assert_eq!(server.request_count(), 3);
            server.assert_clean();
            Ok(())
        }
        run_http_test_handler(acquire);
    }

    #[test]
    fn transient_retry_policy_rejects_non_idempotent_method_before_dispatch() {
        fn acquire(context: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            use crate::protocols::http::{HttpRequest, HttpRequestError, HttpRetryPolicy};
            let server = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Respond { status: 200, body: vec![] },
            ]);
            let request = HttpRequest::post(format!("{}/post", server.base_url)).unwrap()
                .retry_policy(HttpRetryPolicy::transient(2).unwrap());
            assert!(matches!(context.execute(request),
                Err(AcquisitionError::Request(HttpRequestError::RetryMethodNotPermitted))));
            assert_eq!(server.request_count(), 0);
            server.assert_clean();
            Ok(())
        }
        run_http_test_handler(acquire);
    }

    #[test]
    fn exponential_retry_delay_caps_without_wall_clock_sleep() {
        fn acquire(context: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            use std::sync::Arc;
            use std::time::{Duration, UNIX_EPOCH};
            use crate::protocols::http::{HttpRetryDelayPolicy, HttpRetryPolicy, HttpRequest};
            use crate::protocols::http::test_support::DeterministicHttpRetryRuntime;
            let clock = Arc::new(DeterministicHttpRetryRuntime::new(UNIX_EPOCH));
            context.set_retry_runtime(clock.clone());
            let server = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Respond { status: 503, body: vec![] },
                crate::protocols::http::test_support::ScriptedStep::Respond { status: 503, body: vec![] },
                crate::protocols::http::test_support::ScriptedStep::Respond { status: 503, body: vec![] },
                crate::protocols::http::test_support::ScriptedStep::Respond { status: 200, body: b"ok".to_vec() },
            ]);
            let policy = HttpRetryPolicy::custom(
                4, false, vec![503], ["GET"],
                HttpRetryDelayPolicy::Exponential {
                    initial: Duration::from_millis(5), maximum: Duration::from_millis(12),
                }, false, Duration::from_secs(1),
            ).unwrap();
            context.execute(HttpRequest::get(format!("{}/exponential", server.base_url)).unwrap().retry_policy(policy))?;
            assert_eq!(clock.sleeps(), vec![
                Duration::from_millis(5), Duration::from_millis(10), Duration::from_millis(12),
            ]);
            assert_eq!(server.request_count(), 4);
            server.assert_clean();
            Ok(())
        }
        run_http_test_handler(acquire);
    }

    #[test]
    fn positive_retry_after_delta_and_date_override_policy_delay() {
        fn acquire(context: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            use std::sync::Arc;
            use std::time::{Duration, UNIX_EPOCH};
            use crate::protocols::http::{HttpRetryDelayPolicy, HttpRetryPolicy, HttpRequest};
            use crate::protocols::http::test_support::DeterministicHttpRetryRuntime;
            let wall = UNIX_EPOCH + Duration::from_secs(784_111_776);
            let clock = Arc::new(DeterministicHttpRetryRuntime::new(wall));
            context.set_retry_runtime(clock.clone());
            let server = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Response {
                    status: 503, headers: vec![(b"Retry-After".to_vec(), b"3".to_vec())], body: vec![],
                },
                crate::protocols::http::test_support::ScriptedStep::Response {
                    status: 503,
                    headers: vec![(b"Retry-After".to_vec(), b"Sun, 06 Nov 1994 08:49:41 GMT".to_vec())],
                    body: vec![],
                },
                crate::protocols::http::test_support::ScriptedStep::Respond { status: 200, body: b"ok".to_vec() },
            ]);
            let policy = HttpRetryPolicy::custom(
                3, false, vec![503], ["GET"],
                HttpRetryDelayPolicy::Fixed(Duration::from_secs(20)), true,
                Duration::from_secs(30),
            ).unwrap();
            context.execute(HttpRequest::get(format!("{}/retry-after", server.base_url)).unwrap().retry_policy(policy))?;
            assert_eq!(clock.sleeps(), vec![Duration::from_secs(3), Duration::from_secs(2)]);
            assert_eq!(server.request_count(), 3);
            server.assert_clean();
            Ok(())
        }
        run_http_test_handler(acquire);
    }

    #[test]
    fn elapsed_retry_budget_prevents_sleep_and_extra_dispatch() {
        fn acquire(context: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            use std::sync::Arc;
            use std::time::{Duration, UNIX_EPOCH};
            use crate::protocols::http::{HttpExecutionError, HttpRetryDelayPolicy, HttpRetryExhaustionReason, HttpRetryPolicy, HttpRequest};
            use crate::protocols::http::test_support::DeterministicHttpRetryRuntime;
            let clock = Arc::new(DeterministicHttpRetryRuntime::new(UNIX_EPOCH));
            context.set_retry_runtime(clock.clone());
            let server = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Respond { status: 503, body: vec![] },
            ]);
            let policy = HttpRetryPolicy::custom(
                2, false, vec![503], ["GET"],
                HttpRetryDelayPolicy::Fixed(Duration::from_millis(11)), false,
                Duration::from_millis(10),
            ).unwrap();
            let error = context.execute(HttpRequest::get(format!("{}/budget", server.base_url)).unwrap().retry_policy(policy)).unwrap_err();
            assert!(matches!(error,
                AcquisitionError::Execution(HttpExecutionError::RetryExhausted(ref exhausted))
                    if exhausted.reason() == HttpRetryExhaustionReason::ElapsedBudget));
            assert!(clock.sleeps().is_empty());
            assert_eq!(server.request_count(), 1);
            server.assert_clean();
            Ok(())
        }
        run_http_test_handler(acquire);
    }

    #[test]
    fn redirect_failures_are_recorded_and_never_dispatch_past_the_boundary() {
        fn acquire(context: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            use crate::protocols::http::{HttpExecutionError, HttpRedirectFailureKind, HttpRedirectPolicy, HttpRequest};

            let malformed = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Redirect {
                    location: "http://[::1".to_owned(),
                },
            ]);
            let malformed_error = context.execute(
                HttpRequest::get(format!("{}/malformed", malformed.base_url)).unwrap()
                    .redirect_policy(HttpRedirectPolicy::follow(3).unwrap()),
            ).unwrap_err();
            assert!(matches!(malformed_error,
                AcquisitionError::Execution(HttpExecutionError::RedirectFailure(ref failure))
                    if failure.kind() == HttpRedirectFailureKind::InvalidTarget));
            assert_eq!(malformed.request_count(), 1);
            malformed.assert_clean();

            let cycle = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Redirect { location: "/b".to_owned() },
                crate::protocols::http::test_support::ScriptedStep::Redirect { location: "/a".to_owned() },
            ]);
            let cycle_error = context.execute(
                HttpRequest::get(format!("{}/a", cycle.base_url)).unwrap()
                    .redirect_policy(HttpRedirectPolicy::follow(5).unwrap()),
            ).unwrap_err();
            assert!(matches!(cycle_error,
                AcquisitionError::Execution(HttpExecutionError::RedirectFailure(ref failure))
                    if failure.kind() == HttpRedirectFailureKind::LoopDetected
                        && failure.total_physical_attempt_count() == 2));
            assert_eq!(cycle.request_count(), 2);
            cycle.assert_clean();

            let limited = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Redirect { location: "/second".to_owned() },
                crate::protocols::http::test_support::ScriptedStep::Redirect { location: "/must-not-dispatch".to_owned() },
            ]);
            let limit_error = context.execute(
                HttpRequest::get(format!("{}/first", limited.base_url)).unwrap()
                    .redirect_policy(HttpRedirectPolicy::follow(1).unwrap()),
            ).unwrap_err();
            assert!(matches!(limit_error,
                AcquisitionError::Execution(HttpExecutionError::RedirectFailure(ref failure))
                    if failure.kind() == HttpRedirectFailureKind::MaximumExceeded
                        && failure.total_physical_attempt_count() == 2));
            assert_eq!(limited.request_count(), 2);
            limited.assert_clean();
            Ok(())
        }
        run_http_test_handler(acquire);
    }

    fn run_http_test_handler(handler: crate::protocols::http::HttpAcquireFn) {
        let fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let result = run_http_runtime_invocation(
            &fixture.build_argv(&[]),
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(handler),
            HttpCapabilitySet::empty(),
        );
        assert!(result.is_ok(), "{result:?}");
    }

    #[test]
    fn cross_origin_redirect_strips_secrets_for_ip_literal_hosts() {
        fn acquire(context: &mut HttpAcquisitionContext, _args: &[OsString]) -> AcquisitionResult<()> {
            use crate::protocols::http::{HttpRedirectPolicy, HttpRequest};
            let target = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Respond {
                    status: 200,
                    body: b"target".to_vec(),
                },
            ]);
            let source = crate::protocols::http::test_support::start_scripted_server(vec![
                crate::protocols::http::test_support::ScriptedStep::Redirect {
                    location: format!("{}/target", target.base_url),
                },
            ]);
            let secrets = ["auth-secret", "cookie-secret", "proxy-secret", "explicit-secret"];
            let request = HttpRequest::get(format!("{}/start", source.base_url))
                .unwrap()
                .header("Authorization", secrets[0]).unwrap()
                .header("Cookie", secrets[1]).unwrap()
                .header("Proxy-Authorization", secrets[2]).unwrap()
                .sensitive_header("X-Source-Secret", secrets[3]).unwrap()
                .redirect_policy(HttpRedirectPolicy::follow(2).unwrap());
            let transaction = context.execute(request)?;
            assert_eq!(transaction.response_status(), Some(200));
            let received = target.last_request().expect("target request");
            for prohibited in ["authorization", "cookie", "proxy-authorization", "x-source-secret"] {
                assert!(!received.headers.iter().any(|(name, _)| name.eq_ignore_ascii_case(prohibited)));
            }
            fn scan(path: &std::path::Path, secrets: &[&str]) {
                for entry in std::fs::read_dir(path).unwrap() {
                    let entry = entry.unwrap();
                    if entry.file_type().unwrap().is_dir() { scan(&entry.path(), secrets); }
                    else {
                        let bytes = std::fs::read(entry.path()).unwrap();
                        for secret in secrets {
                            assert!(!bytes.windows(secret.len()).any(|window| window == secret.as_bytes()));
                        }
                    }
                }
            }
            scan(context.raw_data_directory(), &secrets);
            assert_eq!(source.request_count(), 1);
            assert_eq!(target.request_count(), 1);
            source.assert_clean();
            target.assert_clean();
            Ok(())
        }
        let fixture = RuntimeInvocationFixture::foreground_run(
            RuntimeIdentity::http_acquisition("example-source", 1),
        );
        let result = run_http_runtime_invocation(
            &fixture.build_argv(&[]),
            RuntimeIdentity::http_acquisition("example-source", 1),
            &HttpSourceContractV1::new(acquire),
            HttpCapabilitySet::empty(),
        );
        assert!(result.is_ok(), "{result:?}");
    }

}
