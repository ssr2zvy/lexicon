use std::fs;
use std::path::Path;
use std::process::{Command, Output};

fn write_file(path: &Path, contents: &str) {
    fs::create_dir_all(path.parent().expect("fixture file parent")).unwrap();
    fs::write(path, contents).unwrap();
}

fn check_two_package_boundary(implementation: &str, runner: &str) -> Output {
    let fixture = tempfile::tempdir().unwrap();
    let core = Path::new(env!("CARGO_MANIFEST_DIR"));
    write_file(
        &fixture.path().join("Cargo.toml"),
        &format!(
            "[workspace]\nresolver = \"2\"\nmembers = [\"implementation\", \"runner\"]\n\n[workspace.dependencies]\nlexicon_core = {{ package = \"lexicon-core\", path = {:?} }}\n",
            core
        ),
    );
    write_file(
        &fixture.path().join("implementation/Cargo.toml"),
        "[package]\nname = \"contract-fixture-implementation\"\nversion = \"0.0.0\"\nedition = \"2024\"\n\n[lib]\npath = \"src/lib.rs\"\n\n[dependencies]\nlexicon_core = { workspace = true }\n",
    );
    write_file(
        &fixture.path().join("implementation/src/lib.rs"),
        implementation,
    );
    write_file(
        &fixture.path().join("runner/Cargo.toml"),
        "[package]\nname = \"contract-fixture-runner\"\nversion = \"0.0.0\"\nedition = \"2024\"\n\n[[bin]]\nname = \"contract-fixture-runtime\"\npath = \"src/main.rs\"\n\n[dependencies]\nsource_implementation = { package = \"contract-fixture-implementation\", path = \"../implementation\" }\nlexicon_core = { workspace = true }\n",
    );
    write_file(&fixture.path().join("runner/src/main.rs"), runner);

    Command::new(env!("CARGO"))
        .args(["check", "--offline", "--package", "contract-fixture-runner"])
        .arg("--manifest-path")
        .arg(fixture.path().join("Cargo.toml"))
        .arg("--target-dir")
        .arg(fixture.path().join("target"))
        .env("CARGO_NET_OFFLINE", "true")
        .output()
        .expect("execute Cargo for actual implementation-to-runner boundary")
}

#[test]
fn acquisition_runner_rejects_missing_exported_source_descriptor() {
    let output = check_two_package_boundary(
        "pub fn unrelated() {}\n",
        "use source_implementation::SOURCE;\nfn main() { let _ = &SOURCE; }\n",
    );
    assert!(!output.status.success());
    assert!(String::from_utf8_lossy(&output.stderr).contains("SOURCE"));
}

#[test]
fn processing_runner_rejects_missing_exported_processor_descriptor() {
    let output = check_two_package_boundary(
        "pub fn unrelated() {}\n",
        "use source_implementation::PROCESSOR;\nfn main() { let _ = &PROCESSOR; }\n",
    );
    assert!(!output.status.success());
    assert!(String::from_utf8_lossy(&output.stderr).contains("PROCESSOR"));
}

#[test]
fn acquisition_library_rejects_wrong_handler_signature_before_runner_link() {
    let output = check_two_package_boundary(
        "use lexicon_core::http::HttpSourceContractV1;\npub fn acquire(_: &mut lexicon_core::HttpAcquisitionContext, _: &[String]) -> lexicon_core::http::AcquisitionResult<()> { Ok(()) }\npub const SOURCE: HttpSourceContractV1 = HttpSourceContractV1::new(acquire);\n",
        "use source_implementation::SOURCE;\nfn main() { let _ = &SOURCE; }\n",
    );
    assert!(!output.status.success());
    assert!(String::from_utf8_lossy(&output.stderr).contains("mismatched types"));
}

#[test]
fn processing_library_rejects_wrong_handler_signature_before_runner_link() {
    let output = check_two_package_boundary(
        "use lexicon_core::processing::{ProcessingSourceContractV1, ProcessingResult};\npub fn process(_: &lexicon_core::processing::ProcessingContext, _: &[std::ffi::OsString]) -> ProcessingResult<()> { Ok(()) }\npub const PROCESSOR: ProcessingSourceContractV1 = ProcessingSourceContractV1::new(process);\n",
        "use source_implementation::PROCESSOR;\nfn main() { let _ = &PROCESSOR; }\n",
    );
    assert!(!output.status.success());
    assert!(String::from_utf8_lossy(&output.stderr).contains("mismatched types"));
}

#[test]
fn normative_processing_api_compiles_across_implementation_runner_boundary() {
    let output = check_two_package_boundary(
        "use std::ffi::OsString;\nuse lexicon_core::processing::{ProcessingContext, ProcessingError, ProcessingHttpRawEntry, ProcessingResult, ProcessingSourceContractV1};\npub fn process(context: &mut ProcessingContext, _: &[OsString]) -> ProcessingResult<()> {\n    let transactions = context.raw_transactions()?;\n    let database = context.create_staged_database()?;\n    for entry in transactions.entries() { match entry { ProcessingHttpRawEntry::Complete(transaction) => { let _ = transaction.transaction().identity(); }, ProcessingHttpRawEntry::Incomplete(attempt) => { let _ = attempt.attempt().phase(); } } }\n    database.execute_batch(\"CREATE TABLE IF NOT EXISTS processed_v1(value TEXT NOT NULL);\").map_err(|error| ProcessingError::source(\"write staged database\", error))?;\n    context.publish_database(database)?;\n    Ok(())\n}\npub const PROCESSOR: ProcessingSourceContractV1 = ProcessingSourceContractV1::new(process);\n",
        "use source_implementation::PROCESSOR;\nfn main() { let _ = &PROCESSOR; }\n",
    );
    assert!(
        output.status.success(),
        "external normative processing API failed to compile: {}",
        String::from_utf8_lossy(&output.stderr),
    );
}
