use std::ffi::OsString;
use std::io::{Read, Write};
use std::process::Command;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

use lexicon_core::protocols::http::{
    AcquisitionResult, HttpAcquisitionContext, HttpCapabilitySet, HttpRequest,
    HttpSourceContractV1, run_http_runtime_invocation,
};
use lexicon_core::runtime::{
    RuntimeExecutionMode, RuntimeIdentity, RuntimeInvocationEnvelopeV1,
    RuntimeOperation, RuntimeSupervisionMode,
};
use lexicon_core::session::{
    NewSessionRecord, ProjectIdentity, RuntimeContextPaths, SafeSessionFailure,
    SessionFailureCode, SessionOperation, SessionOperationRoot, SessionState, SessionStore,
    SessionTransition, RUNTIME_CONTEXT_ENVIRONMENT_VARIABLE, encode_runtime_context_with_lease,
};

const PROJECT: &str = "checkpoint-recovery-project";
const SOURCE: &str = "checkpoint-recovery-source";
const LOGICAL_KEY: &str = "work/video/item-001";
const TEST_INVOCATION_ENV: &str = "LEXICON_TEST_INVOCATION_JSON";
const TEST_URL_ENV: &str = "LEXICON_TEST_HTTP_URL";
const TEST_SERVER_WAIT: Duration = Duration::from_secs(10);
const TEST_PROCESS_WAIT: Duration = Duration::from_secs(30);
const OK_RESPONSE: &[u8] =
    b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nok";

fn serve_expected_requests(
    listener: std::net::TcpListener,
    expected_requests: usize,
    requests: Arc<AtomicUsize>,
) {
    listener.set_nonblocking(true).unwrap();
    for observed in 0..expected_requests {
        let deadline = Instant::now() + TEST_SERVER_WAIT;
        let (mut stream, _) = loop {
            match listener.accept() {
                Ok(connection) => break connection,
                Err(error) if error.kind() == std::io::ErrorKind::WouldBlock => {
                    assert!(
                        Instant::now() < deadline,
                        "timed out waiting for HTTP request {} of {}",
                        observed + 1,
                        expected_requests,
                    );
                    std::thread::sleep(Duration::from_millis(10));
                }
                Err(error) => panic!("checkpoint test listener failed: {error}"),
            }
        };
        stream.set_read_timeout(Some(TEST_SERVER_WAIT)).unwrap();
        stream.set_write_timeout(Some(TEST_SERVER_WAIT)).unwrap();
        let mut request = [0_u8; 2048];
        let count = stream.read(&mut request).unwrap();
        assert!(count > 0, "client connected without sending an HTTP request");
        requests.fetch_add(1, Ordering::SeqCst);
        stream.write_all(OK_RESPONSE).unwrap();
        stream.flush().unwrap();
    }
}

fn run_fixture(command: &mut Command) -> std::process::ExitStatus {
    let mut child = command.spawn().expect("spawn checkpoint subprocess fixture");
    let deadline = Instant::now() + TEST_PROCESS_WAIT;
    loop {
        match child.try_wait().expect("poll checkpoint subprocess fixture") {
            Some(status) => return status,
            None if Instant::now() < deadline => {
                std::thread::sleep(Duration::from_millis(10));
            }
            None => {
                let kill_error = child.kill().err();
                let wait_error = child.wait().err();
                panic!(
                    "checkpoint subprocess exceeded {TEST_PROCESS_WAIT:?}; kill={kill_error:?}; wait={wait_error:?}",
                );
            }
        }
    }
}

struct PreparedInvocation {
    store: SessionStore,
    session: lexicon_core::session::SessionIdentity,
    lease: lexicon_core::session::SessionLease,
    context: String,
    invocation: String,
}

fn prepare_invocation(
    project_root: &std::path::Path,
    execution_mode: RuntimeExecutionMode,
) -> PreparedInvocation {
    let sources_root = project_root.join("sources");
    let protocol_root = sources_root.join(SOURCE).join("http");
    let operation_root = protocol_root.join("get-raw-data");
    let raw = protocol_root.join("data").join("raw");
    let processed = protocol_root.join("data").join("processed");
    std::fs::create_dir_all(&raw).unwrap();
    std::fs::create_dir_all(&processed).unwrap();
    std::fs::create_dir_all(&operation_root).unwrap();

    let project = ProjectIdentity::new(PROJECT).unwrap();
    let runtime = RuntimeIdentity::http_acquisition(SOURCE, 1);
    let store = SessionStore::open(SessionOperationRoot::new(operation_root.clone()).unwrap())
        .unwrap();
    let prepared = store
        .create_prepared(NewSessionRecord {
            project: project.clone(),
            runtime: runtime.into_owned_identity(),
            operation: SessionOperation::Acquisition,
            execution_mode,
            supervision_mode: RuntimeSupervisionMode::Foreground,
        })
        .unwrap();
    let (record, lease) = prepared.into_owned_parts();
    let session = record.session().clone();
    let paths = RuntimeContextPaths::new(
        project_root.to_path_buf(),
        sources_root,
        protocol_root,
        SOURCE,
        operation_root.clone(),
        operation_root.join("sessions").join(session.id()),
        raw,
        processed,
        Some(operation_root.join("state")),
        RuntimeOperation::Acquisition,
        &session,
    )
    .unwrap();
    let context = encode_runtime_context_with_lease(
        &project,
        &runtime.into_owned_identity(),
        &session,
        &paths,
        lease.identity(),
    )
    .unwrap();
    let invocation = RuntimeInvocationEnvelopeV1::new(
        project,
        runtime,
        session.clone(),
        execution_mode,
        RuntimeSupervisionMode::Foreground,
    )
    .unwrap()
    .to_json()
    .unwrap();
    PreparedInvocation { store, session, lease, context, invocation }
}

fn invocation_arguments() -> Vec<OsString> {
    vec![
        OsString::from("--lexicon-invocation-v1"),
        OsString::from(std::env::var(TEST_INVOCATION_ENV).unwrap()),
        OsString::from("--"),
    ]
}

fn open_ledger(path: &std::path::Path) -> rusqlite::Connection {
    let connection = rusqlite::Connection::open(path).unwrap();
    connection
        .execute_batch(
            "PRAGMA journal_mode = WAL;
             PRAGMA synchronous = FULL;
             CREATE TABLE IF NOT EXISTS work_items (
                 kind TEXT NOT NULL,
                 stable_key TEXT NOT NULL,
                 status TEXT NOT NULL,
                 attempt_count INTEGER NOT NULL DEFAULT 0,
                 PRIMARY KEY (kind, stable_key)
             );",
        )
        .unwrap();
    connection
}

#[test]
#[ignore = "subprocess fixture invoked by checkpoint_crash_then_fresh_resume_uses_receipt_without_repeating_http"]
fn checkpoint_crash_process() {
    fn acquire(
        context: &mut HttpAcquisitionContext,
        _arguments: &[OsString],
    ) -> AcquisitionResult<()> {
        let mut ledger = open_ledger(&context.source_state_directory().join("work.sqlite"));
        let transaction = ledger.transaction().unwrap();
        transaction
            .execute(
                "INSERT OR IGNORE INTO work_items(kind, stable_key, status, attempt_count)
                 VALUES ('video', 'item-001', 'pending', 0)",
                [],
            )
            .unwrap();
        transaction
            .execute(
                "UPDATE work_items SET status = 'active', attempt_count = attempt_count + 1
                 WHERE kind = 'video' AND stable_key = 'item-001'",
                [],
            )
            .unwrap();
        transaction.commit().unwrap();

        let request = HttpRequest::get(std::env::var(TEST_URL_ENV).unwrap())
            .map_err(lexicon_core::protocols::http::AcquisitionError::request)?
            .logical_key(LOGICAL_KEY)
            .map_err(lexicon_core::protocols::http::AcquisitionError::request)?;
        context.execute(request)?;
        context.commit_checkpoint(LOGICAL_KEY)?;
        std::process::abort();
    }

    let _ = run_http_runtime_invocation(
        &invocation_arguments(),
        RuntimeIdentity::http_acquisition(SOURCE, 1),
        &HttpSourceContractV1::new(acquire),
        HttpCapabilitySet::empty(),
    );
    unreachable!("crash fixture must abort after the durable checkpoint commit");
}

#[test]
#[ignore = "subprocess fixture invoked by checkpoint_crash_then_fresh_resume_uses_receipt_without_repeating_http"]
fn checkpoint_resume_process() {
    fn acquire_must_not_run(
        _context: &mut HttpAcquisitionContext,
        _arguments: &[OsString],
    ) -> AcquisitionResult<()> {
        panic!("acquire must not be selected on resume")
    }

    fn resume(
        context: &mut HttpAcquisitionContext,
        _arguments: &[OsString],
    ) -> AcquisitionResult<()> {
        assert!(context.has_checkpoint(LOGICAL_KEY)?);
        let mut ledger = open_ledger(&context.source_state_directory().join("work.sqlite"));
        let transaction = ledger.transaction().unwrap();
        let updated = transaction
            .execute(
                "UPDATE work_items SET status = 'complete'
                 WHERE kind = 'video' AND stable_key = 'item-001' AND status = 'active'",
                [],
            )
            .unwrap();
        assert_eq!(updated, 1);
        transaction.commit().unwrap();
        Ok(())
    }

    run_http_runtime_invocation(
        &invocation_arguments(),
        RuntimeIdentity::http_acquisition(SOURCE, 1),
        &HttpSourceContractV1::new(acquire_must_not_run).with_resume(resume),
        HttpCapabilitySet::empty(),
    )
    .unwrap();
}

#[test]
#[ignore = "subprocess fixture invoked by crash_after_response_before_checkpoint_repeats_keyed_request"]
fn response_before_checkpoint_crash_process() {
    fn acquire(
        context: &mut HttpAcquisitionContext,
        _arguments: &[OsString],
    ) -> AcquisitionResult<()> {
        let request = HttpRequest::get(std::env::var(TEST_URL_ENV).unwrap())
            .map_err(lexicon_core::protocols::http::AcquisitionError::request)?
            .logical_key(LOGICAL_KEY)
            .map_err(lexicon_core::protocols::http::AcquisitionError::request)?;
        context.execute(request)?;
        std::process::abort();
    }
    let _ = run_http_runtime_invocation(
        &invocation_arguments(),
        RuntimeIdentity::http_acquisition(SOURCE, 1),
        &HttpSourceContractV1::new(acquire),
        HttpCapabilitySet::empty(),
    );
    unreachable!("fixture must abort after response recording and before checkpoint commit");
}

#[test]
#[ignore = "subprocess fixture invoked by crash_after_response_before_checkpoint_repeats_keyed_request"]
fn response_before_checkpoint_retry_process() {
    fn acquire_must_not_run(
        _context: &mut HttpAcquisitionContext,
        _arguments: &[OsString],
    ) -> AcquisitionResult<()> {
        panic!("resume must be selected")
    }
    fn resume(
        context: &mut HttpAcquisitionContext,
        _arguments: &[OsString],
    ) -> AcquisitionResult<()> {
        assert!(!context.has_checkpoint(LOGICAL_KEY)?);
        let request = HttpRequest::get(std::env::var(TEST_URL_ENV).unwrap())
            .map_err(lexicon_core::protocols::http::AcquisitionError::request)?
            .logical_key(LOGICAL_KEY)
            .map_err(lexicon_core::protocols::http::AcquisitionError::request)?;
        context.execute(request)?;
        context.commit_checkpoint(LOGICAL_KEY)?;
        Ok(())
    }
    run_http_runtime_invocation(
        &invocation_arguments(),
        RuntimeIdentity::http_acquisition(SOURCE, 1),
        &HttpSourceContractV1::new(acquire_must_not_run).with_resume(resume),
        HttpCapabilitySet::empty(),
    )
    .unwrap();
}

#[test]
fn checkpoint_crash_then_fresh_resume_uses_receipt_without_repeating_http() {
    let temp = tempfile::tempdir().unwrap();
    let project_root = temp.path().join("project");
    let requests = Arc::new(AtomicUsize::new(0));
    let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
    let url = format!("http://{}/work", listener.local_addr().unwrap());
    let server_requests = requests.clone();
    let server = std::thread::spawn(move || {
        serve_expected_requests(listener, 1, server_requests);
    });

    let first = prepare_invocation(&project_root, RuntimeExecutionMode::Run);
    let mut command = Command::new(std::env::current_exe().unwrap());
    command
        .args(["--ignored", "--exact", "checkpoint_crash_process", "--nocapture"])
        .env(RUNTIME_CONTEXT_ENVIRONMENT_VARIABLE, &first.context)
        .env(TEST_INVOCATION_ENV, &first.invocation)
        .env(TEST_URL_ENV, &url);
    let status = run_fixture(&mut command);
    let server_result = server.join();
    assert!(!status.success(), "the first managed runtime must terminate abnormally");
    server_result.expect("checkpoint HTTP server must complete");
    assert_eq!(requests.load(Ordering::SeqCst), 1);

    let running = first.store.load(&first.session).unwrap();
    assert_eq!(running.state(), SessionState::Running);
    first
        .store
        .transition_as_lease_owner(
            &first.session,
            &first.lease,
            running.revision(),
            SessionTransition::ToFailed {
                failure: SafeSessionFailure::runtime_failure(
                    SessionFailureCode::AbnormalTermination,
                    Some("managed runtime terminated before terminal reconciliation".into()),
                ),
            },
        )
        .unwrap();
    drop(first);

    let ledger_path = project_root
        .join("sources")
        .join(SOURCE)
        .join("http/get-raw-data/state/work.sqlite");
    let ledger = open_ledger(&ledger_path);
    let status_before: String = ledger
        .query_row(
            "SELECT status FROM work_items WHERE kind = 'video' AND stable_key = 'item-001'",
            [],
            |row| row.get(0),
        )
        .unwrap();
    assert_eq!(status_before, "active");
    drop(ledger);

    let second = prepare_invocation(&project_root, RuntimeExecutionMode::Resume);
    let mut command = Command::new(std::env::current_exe().unwrap());
    command
        .args(["--ignored", "--exact", "checkpoint_resume_process", "--nocapture"])
        .env(RUNTIME_CONTEXT_ENVIRONMENT_VARIABLE, &second.context)
        .env(TEST_INVOCATION_ENV, &second.invocation);
    let status = run_fixture(&mut command);
    assert!(status.success(), "fresh managed resume process must succeed");
    assert_eq!(requests.load(Ordering::SeqCst), 1, "checkpoint recovery must not repeat HTTP");

    let ledger = open_ledger(&ledger_path);
    let recovered: (String, i64) = ledger
        .query_row(
            "SELECT status, attempt_count FROM work_items
             WHERE kind = 'video' AND stable_key = 'item-001'",
            [],
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .unwrap();
    assert_eq!(recovered, ("complete".to_string(), 1));
    let terminal = second.store.load(&second.session).unwrap();
    assert_eq!(terminal.state(), SessionState::Succeeded);
}

#[test]
fn crash_after_response_before_checkpoint_repeats_keyed_request() {
    let temp = tempfile::tempdir().unwrap();
    let project_root = temp.path().join("project");
    let requests = Arc::new(AtomicUsize::new(0));
    let listener = std::net::TcpListener::bind("127.0.0.1:0").unwrap();
    let url = format!("http://{}/work", listener.local_addr().unwrap());
    let server_requests = requests.clone();
    let server = std::thread::spawn(move || {
        serve_expected_requests(listener, 2, server_requests);
    });

    let first = prepare_invocation(&project_root, RuntimeExecutionMode::Run);
    let mut command = Command::new(std::env::current_exe().unwrap());
    command
        .args(["--ignored", "--exact", "response_before_checkpoint_crash_process", "--nocapture"])
        .env(RUNTIME_CONTEXT_ENVIRONMENT_VARIABLE, &first.context)
        .env(TEST_INVOCATION_ENV, &first.invocation)
        .env(TEST_URL_ENV, &url);
    let status = run_fixture(&mut command);
    assert!(!status.success());
    let running = first.store.load(&first.session).unwrap();
    first
        .store
        .transition_as_lease_owner(
            &first.session,
            &first.lease,
            running.revision(),
            SessionTransition::ToFailed {
                failure: SafeSessionFailure::runtime_failure(
                    SessionFailureCode::AbnormalTermination,
                    Some("managed runtime terminated before checkpoint commit".into()),
                ),
            },
        )
        .unwrap();
    drop(first);

    let second = prepare_invocation(&project_root, RuntimeExecutionMode::Resume);
    let mut command = Command::new(std::env::current_exe().unwrap());
    command
        .args(["--ignored", "--exact", "response_before_checkpoint_retry_process", "--nocapture"])
        .env(RUNTIME_CONTEXT_ENVIRONMENT_VARIABLE, &second.context)
        .env(TEST_INVOCATION_ENV, &second.invocation)
        .env(TEST_URL_ENV, &url);
    let status = run_fixture(&mut command);
    let server_result = server.join();
    assert!(status.success());
    server_result.expect("checkpoint HTTP server must complete");
    assert_eq!(requests.load(Ordering::SeqCst), 2);
    assert_eq!(second.store.load(&second.session).unwrap().state(), SessionState::Succeeded);
}
