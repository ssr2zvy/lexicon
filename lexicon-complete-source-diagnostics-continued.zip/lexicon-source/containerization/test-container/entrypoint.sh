#!/usr/bin/env bash
set -euo pipefail

export PATH="/usr/local/cargo/bin:${PATH}"

LEXICON_ROOT="${LEXICON_ROOT:-/lexicon}"
REPO_DIR="${REPO_DIR:-$LEXICON_ROOT}"
RELEASE_SCRIPT="$REPO_DIR/automation/build_bundle_mza/build_release.sh"

tc_echo() {
    echo "[[TEST_CONTAINER]] $1"
}

wait_for_work() {
    tc_echo "Container is idle. Use podman/docker exec to run workspace commands."
    exec tail -f /dev/null
}

verify_test_repo() {
    tc_echo "Verifying test workspace in $REPO_DIR"
    for path in \
        "$REPO_DIR/Cargo.toml" \
        "$REPO_DIR/Cargo.lock" \
        "$REPO_DIR/lexicon-cli" \
        "$REPO_DIR/lexicon-core" \
        "$REPO_DIR/lexicon-framework"; do
        if [ ! -e "$path" ]; then
            tc_echo "Missing required test path: $path" >&2
            exit 1
        fi
    done
}

run_release_pipeline() {
    verify_test_repo
    if [ ! -f "$RELEASE_SCRIPT" ]; then
        tc_echo "Release pipeline is unavailable in this checkout." >&2
        exit 2
    fi
    cd "$REPO_DIR"
    bash "$RELEASE_SCRIPT" "$@"
}

if [ "$#" -gt 0 ]; then
    case "$1" in
        build|release|bundle)
            shift
            run_release_pipeline "$@"
            ;;
        shell|bash)
            shift
            exec bash "$@"
            ;;
        exec)
            shift
            exec "$@"
            ;;
        *)
            exec "$@"
            ;;
    esac
fi

verify_test_repo
wait_for_work
