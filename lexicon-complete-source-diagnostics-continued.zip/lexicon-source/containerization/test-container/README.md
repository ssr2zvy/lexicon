# Test container

Run these commands from the repository root:

```bash
podman build \
  -f containerization/test-container/Containerfile \
  -t lexicon-local-test-image \
  .

podman run \
  -d \
  --name lexicon-local-test \
  -v "$PWD":/lexicon \
  --workdir /lexicon \
  lexicon-local-test-image

podman exec lexicon-local-test \
  bash -lc 'cargo check --workspace --locked'

podman exec lexicon-local-test \
  bash -lc 'cargo test --workspace --locked'
```

The no-argument container validates only the files needed for development and
testing, then stays alive for `podman exec`. Release-only files are checked only
when the container is explicitly started with `release`, `build`, or `bundle`.

This image improves reproducibility by pinning Rust, Zig, cargo-zigbuild, and
the base image. It is still a development container: the bind-mounted source is
writable and ordinary runs have network access. It does not replace the
network-disabled, read-only, vendored builder required by
`workspace/specs/release-policy.md`.

Use `-it` only for an interactive shell:

```bash
podman exec -it lexicon-local-test bash
```
