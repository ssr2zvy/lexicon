//! Library boundary shared by the installed `lexicon` binary and tests.
//!
//! The public surface deliberately exposes parsing, typed dispatch errors, and
//! exit-code helpers. Parsed command variants stay inside the crate so the
//! reserved operator-host role cannot become a public Rust API.

pub mod cli;

pub use cli::{
    Cli, CliError, cancellation_exit_code, dispatch, exit_code_for_outcome, run_native,
};
