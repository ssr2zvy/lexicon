use clap::{Parser, Subcommand};
use lexicon_framework::identity::{ManagedProtocol, ProtocolArgumentError};

#[derive(Parser, Debug, Clone)]
#[command(
    name = "source",
    about = "Create or build a source definition and project scaffold."
)]
pub struct SourceCommand {
    #[command(subcommand)]
    pub action: SourceAction,
}

#[derive(Subcommand, Debug, Clone)]
pub enum SourceAction {
    Create(CreateSourceCommand),
    Build(BuildSourceCommand),
}

#[derive(Parser, Debug, Clone)]
pub struct CreateSourceCommand {
    #[arg(value_name = "SOURCE_NAME")]
    pub source_name: String,

    #[arg(
        long,
        value_name = "PROTOCOL",
        required = true,
        help = "Acquisition protocol for the source. The supported value is exactly `http`."
    )]
    pub protocol: String,
}

#[derive(Parser, Debug, Clone)]
pub struct BuildSourceCommand {
    #[arg(value_name = "SOURCE_NAME")]
    pub source_name: String,

    #[arg(
        long,
        value_name = "PROTOCOL",
        required = true,
        help = "Protocol implementation to build. The supported value is exactly `http`."
    )]
    pub protocol: String,
}

impl CreateSourceCommand {
    /// Admit the explicit public protocol token without trimming or case
    /// folding. Callers must use the returned identity for framework dispatch.
    pub fn managed_protocol(&self) -> Result<ManagedProtocol, ProtocolArgumentError> {
        ManagedProtocol::parse_cli(&self.protocol)
    }
}

impl BuildSourceCommand {
    /// Admit the explicit public protocol token without trimming or case
    /// folding. Callers must use the returned identity for framework dispatch.
    pub fn managed_protocol(&self) -> Result<ManagedProtocol, ProtocolArgumentError> {
        ManagedProtocol::parse_cli(&self.protocol)
    }
}

#[cfg(test)]
mod tests {
    use super::{BuildSourceCommand, CreateSourceCommand, SourceAction, SourceCommand};
    use crate::cli::{Cli, RootCommand};
    use clap::Parser;
    use lexicon_framework::identity::ManagedProtocol;

    #[test]
    fn rejects_create_source_command_when_protocol_is_missing() {
        let result = Cli::try_parse_from(["lexicon", "source", "create", "example-source"]);
        assert!(
            result.is_err(),
            "--protocol must be required and cannot be omitted"
        );
    }

    #[test]
    fn rejects_create_source_command_when_protocol_value_is_missing() {
        let result = Cli::try_parse_from([
            "lexicon",
            "source",
            "create",
            "example-source",
            "--protocol",
        ]);
        assert!(
            result.is_err(),
            "--protocol requires a value and must fail without one"
        );
    }

    #[test]
    fn parses_create_source_command_with_protocol_flag() {
        let cli = Cli::try_parse_from([
            "lexicon",
            "source",
            "create",
            "example-source",
            "--protocol",
            "http",
        ])
        .expect("lexicon source create --protocol http should parse");

        match cli.command {
            Some(RootCommand::Source(SourceCommand {
                action: SourceAction::Create(command),
            })) => {
                assert_eq!(command.source_name, "example-source");
                assert_eq!(command.protocol, "http");
                assert_eq!(command.managed_protocol(), Ok(ManagedProtocol::Http));
            }
            other => panic!("expected Source::Create subcommand, got {other:?}"),
        }
    }

    #[test]
    fn parses_build_source_command_with_source_name_and_protocol() {
        let cli = Cli::try_parse_from([
            "lexicon",
            "source",
            "build",
            "example-source",
            "--protocol",
            "http",
        ])
        .expect("lexicon source build example-source --protocol http should parse");

        match cli.command {
            Some(RootCommand::Source(SourceCommand {
                action: SourceAction::Build(command),
            })) => {
                assert_eq!(command.source_name, "example-source");
                assert_eq!(command.protocol, "http");
                assert_eq!(command.managed_protocol(), Ok(ManagedProtocol::Http));
            }
            other => panic!("expected Source::Build subcommand, got {other:?}"),
        }
    }

    #[test]
    fn rejects_build_source_command_without_protocol() {
        let result = Cli::try_parse_from(["lexicon", "source", "build", "example-source"]);
        assert!(result.is_err(), "source build requires --protocol");
    }

    #[test]
    fn rejects_build_source_command_without_protocol_value() {
        let result =
            Cli::try_parse_from(["lexicon", "source", "build", "example-source", "--protocol"]);
        assert!(result.is_err(), "--protocol requires a value");
    }

    #[test]
    fn rejects_old_source_new_command() {
        let result = Cli::try_parse_from([
            "lexicon",
            "source",
            "new",
            "example-source",
            "--protocol",
            "http",
        ]);
        assert!(result.is_err(), "source new must be rejected");
    }

    #[test]
    fn rejects_old_source_add_command() {
        let result = Cli::try_parse_from(["lexicon", "source", "add", "example-source"]);
        assert!(result.is_err(), "source add must be rejected");
    }

    #[test]
    fn rejects_build_command_without_source_name() {
        let result = Cli::try_parse_from(["lexicon", "source", "build"]);
        assert!(result.is_err(), "source build requires a source name");
    }

    #[test]
    fn protocol_parser_is_byte_exact_for_create_and_build() {
        for rejected in ["browser", "HTTP", "Http", " http", "http ", "http\n"] {
            let create = CreateSourceCommand {
                source_name: "example-source".to_owned(),
                protocol: rejected.to_owned(),
            };
            let build = BuildSourceCommand {
                source_name: "example-source".to_owned(),
                protocol: rejected.to_owned(),
            };

            let create_error = create.managed_protocol().unwrap_err();
            let build_error = build.managed_protocol().unwrap_err();

            assert_eq!(create_error.rejected(), rejected);
            assert_eq!(build_error.rejected(), rejected);
        }
    }

    #[test]
    fn build_command_struct_has_source_name_and_protocol() {
        let command = BuildSourceCommand {
            source_name: "example-source".to_owned(),
            protocol: "http".to_owned(),
        };

        assert_eq!(command.source_name, "example-source");
        assert_eq!(command.managed_protocol(), Ok(ManagedProtocol::Http));
    }
}
