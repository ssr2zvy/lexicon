use std::ffi::{OsStr, OsString};
use std::io::Write;
use std::process::ExitCode;

use clap::{CommandFactory, Parser, Subcommand, error::ErrorKind};
use lexicon_core::diagnostic::{
    Diagnostic, ExitClass, ReportableDiagnostic, codes, write_information,
    write_milestone, write_reportable_diagnostic, write_terminal_diagnostic, write_warning,
};
use lexicon_framework::identity::ProtocolArgumentError;

pub mod build;
pub mod data;
pub mod init;
mod operator_host;
pub mod source;

pub use build::BuildCommand;
pub use data::{DataCommand, DataMode};
pub use init::InitCommand;
use operator_host::OperatorHostCommand;
pub use source::{SourceAction, SourceCommand};

/// Map a supervised cancellation onto the conventional shell exit status.
pub fn cancellation_exit_code(
    kind: lexicon_framework::process::CancellationKind,
    _forced: bool,
) -> ExitCode {
    match kind {
        lexicon_framework::process::CancellationKind::Interrupt
        | lexicon_framework::process::CancellationKind::ConsoleClose => ExitCode::from(130),
        lexicon_framework::process::CancellationKind::Terminate => ExitCode::from(143),
    }
}

/// Translate a supervision result without erasing a cancellation outcome.
pub fn exit_code_for_outcome(
    outcome: &lexicon_framework::process::SupervisionOutcome,
) -> ExitCode {
    match outcome {
        lexicon_framework::process::SupervisionOutcome::Completed { status } => {
            match status.code() {
                Some(0) => ExitCode::SUCCESS,
                Some(_) | None => ExitCode::from(1),
            }
        }
        lexicon_framework::process::SupervisionOutcome::CancelledGracefully { kind, .. }
        | lexicon_framework::process::SupervisionOutcome::CancelledForcefully { kind, .. } => {
            cancellation_exit_code(*kind, false)
        }
        lexicon_framework::process::SupervisionOutcome::CancellationControlFailedButTerminated { .. } => {
            ExitCode::from(1)
        }
    }
}

#[derive(Parser, Debug, Clone)]
#[command(
    name = "lexicon",
    version,
    about = "Lexicon: make data",
    long_about = "Lexicon CLI for raw-data acquisition, processing, source management, and build orchestration."
)]
pub struct Cli {
    #[command(subcommand)]
    command: Option<RootCommand>,
}

impl Cli {
    /// Parse native process arguments while enforcing the architectural `--`
    /// boundary even when the source-owned tail is empty.
    ///
    /// Clap's delimiter is not retained in `ArgMatches`, so `last = true`
    /// alone cannot distinguish an empty tail introduced by `--` from a
    /// missing boundary. This wrapper validates the original `OsString`
    /// sequence first and then delegates parsing without converting it to
    /// UTF-8.
    pub fn try_parse_from<I, T>(arguments: I) -> Result<Self, clap::Error>
    where
        I: IntoIterator<Item = T>,
        T: Into<OsString>,
    {
        let arguments = arguments.into_iter().map(Into::into).collect::<Vec<_>>();
        validate_native_argument_boundary(&arguments)?;
        <Self as Parser>::try_parse_from(arguments)
    }

    /// Build the public command description. The private operator-host variant
    /// remains hidden by its `Subcommand` metadata.
    pub fn command() -> clap::Command {
        <Self as CommandFactory>::command()
    }
}

fn validate_native_argument_boundary(arguments: &[OsString]) -> Result<(), clap::Error> {
    let Some(root_command) = arguments.get(1).map(OsString::as_os_str) else {
        return Ok(());
    };

    let command_requires_boundary =
        root_command == OsStr::new("data") || root_command == OsStr::new("__operator-host");
    if !command_requires_boundary {
        return Ok(());
    }

    let command_arguments = &arguments[2..];
    let help_requested = command_arguments
        .iter()
        .map(OsString::as_os_str)
        .any(|argument| argument == OsStr::new("--help") || argument == OsStr::new("-h"));
    if help_requested {
        return Ok(());
    }

    let has_boundary = command_arguments
        .iter()
        .map(OsString::as_os_str)
        .any(|argument| argument == OsStr::new("--"));
    if has_boundary {
        return Ok(());
    }

    Err(clap::Error::raw(
        ErrorKind::MissingRequiredArgument,
        "a literal `--` is required before the source-argument tail",
    ))
}

#[derive(Subcommand, Debug, Clone)]
enum RootCommand {
    Data(DataCommand),
    Source(SourceCommand),
    Init(InitCommand),
    Build(BuildCommand),
    /// Reserved re-execution entrypoint; not part of the public CLI API.
    #[command(name = "__operator-host", hide = true)]
    OperatorHost(OperatorHostCommand),
}

/// Stable, operation-specific failures returned by CLI dispatch.
///
/// Concrete framework errors are retained whenever the exact baseline API
/// exposes them. The three string payloads correspond to baseline framework
/// command APIs that already return `String`; they remain separate variants so
/// callers never have to classify a generic message.
#[derive(Debug)]
#[non_exhaustive]
pub enum CliError {
    Help(std::io::Error),
    Protocol(ProtocolArgumentError),
    ForegroundData(lexicon_framework::data::ForegroundDataExecutionError),
    BackgroundHandoff(lexicon_framework::data::ForegroundDataExecutionError),
    SourceCreate(lexicon_framework::SourceCreateError),
    SourceBuild(lexicon_framework::ManagedSourceBuildError),
    Init(String),
    BuildAllDiscovery(lexicon_framework::BuildAllError),
    BuildTargets(Vec<lexicon_framework::commands::SourceBuildFailure>),
    OperatorHostEnvelope(
        lexicon_framework::supervision::OperatorHostInvocationDecodingError,
    ),
    OperatorHostExecution(lexicon_framework::data::ForegroundDataExecutionError),
    Interrupted {
        kind: lexicon_framework::process::CancellationKind,
        unix_signal: Option<u8>,
        forced: bool,
    },
}

impl std::fmt::Display for CliError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Help(error) => write!(formatter, "failed to render help output: {error}"),
            Self::Protocol(error) => write!(formatter, "invalid --protocol value: {error}"),
            Self::ForegroundData(error) => write!(formatter, "foreground data failed: {error}"),
            Self::BackgroundHandoff(error) => {
                write!(formatter, "background handoff failed: {error}")
            }
            Self::SourceCreate(error) => write!(formatter, "source creation failed: {error}"),
            Self::SourceBuild(error) => write!(formatter, "source build failed: {error}"),
            Self::Init(error) => write!(formatter, "project initialization failed: {error}"),
            Self::BuildAllDiscovery(error) => {
                write!(formatter, "project build discovery failed: {error}")
            }
            Self::BuildTargets(failures) => {
                write!(formatter, "{} source build(s) failed", failures.len())?;
                for failure in failures {
                    write!(
                        formatter,
                        "; {}/{}: {}",
                        failure.source_name, failure.protocol, failure.error
                    )?;
                }
                Ok(())
            }
            Self::OperatorHostEnvelope(error) => {
                write!(formatter, "invalid private operator-host envelope: {error}")
            }
            Self::OperatorHostExecution(error) => {
                write!(formatter, "private operator-host execution failed: {error}")
            }
            Self::Interrupted {
                kind,
                unix_signal,
                forced,
            } => write!(
                formatter,
                "operator interrupted (kind={kind}, unix_signal={unix_signal:?}, forced={forced})"
            ),
        }
    }
}

impl std::error::Error for CliError {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Self::Help(error) => Some(error),
            Self::Protocol(error) => Some(error),
            Self::ForegroundData(error)
            | Self::BackgroundHandoff(error)
            | Self::OperatorHostExecution(error) => Some(error),
            Self::BuildAllDiscovery(error) => Some(error),
            Self::OperatorHostEnvelope(error) => Some(error),
            Self::SourceCreate(error) => Some(error),
            Self::SourceBuild(error) => Some(error),
            Self::Init(_)
            | Self::BuildTargets(_)
            | Self::Interrupted { .. } => None,
        }
    }
}

impl CliError {
    /// Map typed failures to process status without collapsing cancellation or
    /// command-usage errors into success.
    pub fn exit_code(&self) -> ExitCode {
        self.diagnostic().exit_class().exit_code()
    }

    /// Write the one terminal error report owned by the installed CLI.
    ///
    /// A workspace-wide build may retain several independently failed targets;
    /// those are rendered as bounded, coded subordinate details before the one
    /// aggregate terminal report. Raw nested error strings are never emitted.
    pub fn write_terminal<W: Write>(&self, writer: &mut W) -> std::io::Result<()> {
        if let Self::BuildTargets(failures) = self {
            for failure in failures {
                let diagnostic = failure.error.diagnostic();
                writeln!(
                    writer,
                    "[lexicon] DETAIL [{}]: {} source='{}' protocol='{}'",
                    diagnostic.code(),
                    diagnostic.safe_summary(),
                    failure.source_name,
                    failure.protocol,
                )?;
            }
        }

        write_reportable_diagnostic(writer, self)?;

        let execution_error = match self {
            Self::ForegroundData(error)
            | Self::BackgroundHandoff(error)
            | Self::OperatorHostExecution(error) => Some(error),
            _ => None,
        };
        if let Some(session) = execution_error.and_then(|error| error.validated_session()) {
            writeln!(writer, "[lexicon] Session: {}", session.id())
        } else {
            Ok(())
        }
    }
}

impl ReportableDiagnostic for CliError {
    fn diagnostic(&self) -> Diagnostic {
        match self {
            Self::Help(_) => Diagnostic::operational(
                codes::CLI_HELP_OUTPUT_FAILED,
                "Command help could not be written.",
            ),
            Self::Protocol(_) => Diagnostic::new(
                codes::CLI_PROTOCOL_INVALID,
                "The selected protocol is invalid or unsupported.",
                ExitClass::Usage,
            ),
            Self::ForegroundData(error)
            | Self::BackgroundHandoff(error)
            | Self::OperatorHostExecution(error) => error.diagnostic(),
            Self::SourceCreate(error) => error.diagnostic(),
            Self::SourceBuild(error) => error.diagnostic(),
            Self::Init(_) => Diagnostic::operational(
                codes::PROJECT_INITIALIZATION_FAILED,
                "The Lexicon project could not be initialized atomically.",
            ),
            Self::BuildAllDiscovery(error) => error.diagnostic(),
            Self::BuildTargets(_) => Diagnostic::operational(
                codes::BUILD_TARGETS_FAILED,
                "One or more discovered source runtime pairs failed to build.",
            ),
            Self::OperatorHostEnvelope(_) => Diagnostic::operational(
                codes::OPERATOR_HOST_DECODING_FAILED,
                "The private background operator-host envelope is invalid.",
            ),
            Self::Interrupted { kind, .. } => {
                let exit_class = match kind {
                    lexicon_framework::process::CancellationKind::Interrupt
                    | lexicon_framework::process::CancellationKind::ConsoleClose => {
                        ExitClass::Interrupted
                    }
                    lexicon_framework::process::CancellationKind::Terminate => {
                        ExitClass::Terminated
                    }
                };
                Diagnostic::new(
                    codes::OPERATOR_CANCELLED,
                    "The operator cancelled the Lexicon command.",
                    exit_class,
                )
            }
        }
    }

    fn secondary_diagnostic(&self) -> Option<Diagnostic> {
        match self {
            Self::ForegroundData(error)
            | Self::BackgroundHandoff(error)
            | Self::OperatorHostExecution(error) => error.secondary_diagnostic(),
            _ => None,
        }
    }
}

/// Parse, dispatch, and report one native command without allowing Clap or a
/// nested subsystem to create a second terminal error path.
pub fn run_native<I, T>(arguments: I) -> ExitCode
where
    I: IntoIterator<Item = T>,
    T: Into<OsString>,
{
    let cli = match Cli::try_parse_from(arguments) {
        Ok(cli) => cli,
        Err(error)
            if matches!(
                error.kind(),
                ErrorKind::DisplayHelp | ErrorKind::DisplayVersion
            ) =>
        {
            return match error.print() {
                Ok(()) => ExitCode::SUCCESS,
                Err(_) => {
                    let diagnostic = Diagnostic::operational(
                        codes::CLI_HELP_OUTPUT_FAILED,
                        "Command help could not be written.",
                    );
                    let _ = write_terminal_diagnostic(
                        &mut std::io::stderr().lock(),
                        diagnostic,
                    );
                    diagnostic.exit_class().exit_code()
                }
            };
        }
        Err(_) => {
            let diagnostic = Diagnostic::new(
                codes::CLI_INVALID_ARGUMENTS,
                "The command arguments are invalid; run `lexicon --help` for the supported grammar.",
                ExitClass::Usage,
            );
            let _ = write_terminal_diagnostic(&mut std::io::stderr().lock(), diagnostic);
            return diagnostic.exit_class().exit_code();
        }
    };

    match dispatch(cli) {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            let _ = error.write_terminal(&mut std::io::stderr().lock());
            error.exit_code()
        }
    }
}

pub fn dispatch(cli: Cli) -> Result<(), CliError> {
    match cli.command {
        None => {
            let mut command = Cli::command();
            command.print_help().map_err(CliError::Help)?;
            Ok(())
        }
        Some(RootCommand::Data(command)) => {
            let protocol = command.managed_protocol().map_err(CliError::Protocol)?;
            let (operation, source_name) = match command.mode() {
                DataMode::Get(source) => {
                    (lexicon_framework::data::DataOperation::Acquisition, source)
                }
                DataMode::Process(source) => {
                    (lexicon_framework::data::DataOperation::Processing, source)
                }
            };
            let background = command.bg;
            let request = lexicon_framework::data::DataExecutionRequest {
                operation,
                source_name,
                protocol: protocol.as_str().to_owned(),
                abandon_past_failure: command.abandon_past_fail,
                background,
                source_arguments: command.source_arguments,
            };

            if background {
                let outcome = lexicon_framework::data::execute_background_data(request)
                    .map_err(CliError::BackgroundHandoff)?;
                let _ = write_milestone(
                    &mut std::io::stdout().lock(),
                    codes::SESSION_BACKGROUND_HANDOFF_ACCEPTED,
                    format_args!(
                        "{} supervision accepted: source='{}' session={}",
                        outcome.operation.display_name(),
                        outcome.source,
                        outcome.session.id()
                    ),
                );
            } else {
                let outcome = lexicon_framework::data::execute_foreground_data(request)
                    .map_err(CliError::ForegroundData)?;
                let _ = write_milestone(
                    &mut std::io::stdout().lock(),
                    codes::SESSION_SUCCEEDED,
                    format_args!(
                        "{} complete: source='{}' session={}",
                        outcome.operation.display_name(),
                        outcome.source,
                        outcome.session.id()
                    ),
                );
            }
            Ok(())
        }
        Some(RootCommand::Source(command)) => match command.action {
            SourceAction::Create(create_command) => {
                let protocol = create_command
                    .managed_protocol()
                    .map_err(CliError::Protocol)?;
                let result = lexicon_framework::commands::source_create(
                    &create_command.source_name,
                    protocol.as_str(),
                )
                .map_err(CliError::SourceCreate)?;
                let _ = write_milestone(
                    &mut std::io::stdout().lock(),
                    codes::SOURCE_SCAFFOLD_PUBLISHED,
                    format_args!(
                        "source='{}' protocol='{}'",
                        result.source_name,
                        result.protocol,
                    ),
                );
                let _ = write_information(
                    &mut std::io::stdout().lock(),
                    format_args!("Files to edit next:"),
                );
                for file in &result.created_files {
                    let _ = write_information(
                        &mut std::io::stdout().lock(),
                        format_args!("  - {file:?}"),
                    );
                }
                Ok(())
            }
            SourceAction::Build(build_command) => {
                let protocol = build_command
                    .managed_protocol()
                    .map_err(CliError::Protocol)?;
                let result = lexicon_framework::commands::source_build(
                    &build_command.source_name,
                    protocol.as_str(),
                )
                .map_err(CliError::SourceBuild)?;
                let _ = write_milestone(
                    &mut std::io::stdout().lock(),
                    codes::RUNTIME_PAIR_PUBLISHED,
                    format_args!(
                        "source='{}' protocol='{}'",
                        result.source_name, result.protocol
                    ),
                );
                let _ = write_information(
                    &mut std::io::stdout().lock(),
                    format_args!("Runtime executables:"),
                );
                let _ = write_information(
                    &mut std::io::stdout().lock(),
                    format_args!("  - {:?}", result.get_runtime),
                );
                let _ = write_information(
                    &mut std::io::stdout().lock(),
                    format_args!("  - {:?}", result.process_runtime),
                );
                if !result.cleanup_warnings.is_empty() {
                    let _ = write_warning(
                        &mut std::io::stderr().lock(),
                        codes::BUILD_POST_PUBLICATION_INCOMPLETE,
                        "The runtime pair was published, but post-publication cleanup or directory durability was not fully confirmed.",
                    );
                }
                Ok(())
            }
        },
        Some(RootCommand::Init(command)) => {
            lexicon_framework::commands::init(&command.parent_path, &command.project_name)
                .map_err(CliError::Init)?;
            let _ = write_milestone(
                &mut std::io::stdout().lock(),
                codes::PROJECT_INITIALIZED,
                format_args!("project='{}'", command.project_name),
            );
            Ok(())
        }
        Some(RootCommand::Build(_)) => {
            let outcome = lexicon_framework::commands::build_all()
                .map_err(CliError::BuildAllDiscovery)?;
            for result in &outcome.succeeded {
                let _ = write_milestone(
                    &mut std::io::stdout().lock(),
                    codes::RUNTIME_PAIR_PUBLISHED,
                    format_args!(
                        "source='{}' protocol='{}'",
                        result.source_name, result.protocol
                    ),
                );
                let _ = write_information(
                    &mut std::io::stdout().lock(),
                    format_args!("  - {:?}", result.get_runtime),
                );
                let _ = write_information(
                    &mut std::io::stdout().lock(),
                    format_args!("  - {:?}", result.process_runtime),
                );
                if !result.cleanup_warnings.is_empty() {
                    let _ = write_warning(
                        &mut std::io::stderr().lock(),
                        codes::BUILD_POST_PUBLICATION_INCOMPLETE,
                        "The runtime pair was published, but post-publication cleanup or directory durability was not fully confirmed.",
                    );
                }
            }
            if outcome.is_success() {
                let _ = write_milestone(
                    &mut std::io::stdout().lock(),
                    codes::BUILD_COMPLETED,
                    format_args!("{} source(s) built, 0 failed", outcome.succeeded.len()),
                );
                Ok(())
            } else {
                Err(CliError::BuildTargets(outcome.failed))
            }
        }
        Some(RootCommand::OperatorHost(command)) => {
            let handoff_token =
                lexicon_framework::supervision::take_operator_host_handoff_token()
                    .map_err(CliError::OperatorHostEnvelope)?;
            let reference = lexicon_framework::supervision::OperatorHostInvocationV1::from_json(
                &command.reference,
            )
            .map_err(CliError::OperatorHostEnvelope)?;
            let outcome = lexicon_framework::data::execute_operator_host(
                reference,
                handoff_token,
                command.source_arguments,
            )
            .map_err(CliError::OperatorHostExecution)?;
            let _ = write_milestone(
                &mut std::io::stdout().lock(),
                codes::SESSION_SUCCEEDED,
                format_args!(
                    "{} complete: source='{}' session={}",
                    outcome.operation.display_name(),
                    outcome.source,
                    outcome.session.id()
                ),
            );
            Ok(())
        }
    }
}

#[cfg(test)]
mod tests {
    use std::fs;
    use std::process::ExitCode;
    use std::sync::Mutex;

    use super::{Cli, CliError, RootCommand, exit_code_for_outcome};
    use crate::cli::source::{CreateSourceCommand, SourceAction, SourceCommand};

    static TEST_CWD_LOCK: Mutex<()> = Mutex::new(());

    #[cfg(unix)]
    fn exit_status(code: Option<i32>) -> std::process::ExitStatus {
        use std::os::unix::process::ExitStatusExt;
        match code {
            Some(code) => std::process::ExitStatus::from_raw(code << 8),
            None => std::process::ExitStatus::from_raw(9),
        }
    }

    #[cfg(windows)]
    fn exit_status(code: Option<i32>) -> std::process::ExitStatus {
        use std::os::windows::process::ExitStatusExt;
        std::process::ExitStatus::from_raw(code.unwrap_or(1) as u32)
    }

    #[test]
    fn completed_supervision_uses_coarse_shell_statuses() {
        for (status, expected) in [(Some(0), 0), (Some(7), 1), (Some(255), 1)] {
            let outcome = lexicon_framework::process::SupervisionOutcome::Completed {
                status: exit_status(status),
            };
            assert_eq!(exit_code_for_outcome(&outcome), ExitCode::from(expected));
        }
    }

    #[test]
    fn terminal_renderer_uses_stable_code_and_omits_raw_error_text() {
        let error = CliError::Init("secret-bearing internal cause".to_string());
        let mut output = Vec::new();

        error.write_terminal(&mut output).unwrap();

        let output = String::from_utf8(output).unwrap();
        assert_eq!(
            output,
            "[lexicon] ERROR [project/initialization_failed]: The Lexicon project could not be initialized atomically.\n"
        );
        assert!(!output.contains("secret-bearing"));
        assert_eq!(error.exit_code(), ExitCode::from(1));
    }

    #[test]
    fn durable_session_code_is_the_terminal_cli_code() {
        let error = CliError::ForegroundData(
            lexicon_framework::data::ForegroundDataExecutionError::ChildFailed {
                operation: lexicon_framework::data::DataOperation::Acquisition,
                source: "example-source".to_string(),
                session: lexicon_core::session::SessionIdentity::new("session-abc").unwrap(),
                failure_kind: lexicon_core::session::SessionFailureKind::Runtime,
                failure_code: lexicon_core::session::SessionFailureCode::HandlerPanicked,
                exit_code: Some(1),
            },
        );
        let mut output = Vec::new();

        error.write_terminal(&mut output).unwrap();

        let output = String::from_utf8(output).unwrap();
        assert!(output.contains("ERROR [session/handler_panicked]"));
        assert!(output.contains("Session: session-abc"));
        assert!(!output.contains("example-source"));
    }

    #[test]
    fn validated_session_wrapper_is_retained_in_the_terminal_report() {
        let session = lexicon_core::session::SessionIdentity::new("session-bound-abc").unwrap();
        let error = CliError::ForegroundData(
            lexicon_framework::data::ForegroundDataExecutionError::SessionBound {
                session,
                source: Box::new(
                    lexicon_framework::data::ForegroundDataExecutionError::BackgroundModeUnsupported,
                ),
            },
        );
        let mut output = Vec::new();

        error.write_terminal(&mut output).unwrap();

        assert_eq!(
            String::from_utf8(output).unwrap(),
            concat!(
                "[lexicon] ERROR [internal/boundary_violation]: An internal command-routing invariant was violated.\n",
                "[lexicon] Session: session-bound-abc\n",
            )
        );
    }

    #[test]
    fn authoritative_session_code_is_not_duplicated_as_a_warning() {
        let session = lexicon_core::session::SessionIdentity::new("session-terminal-abc").unwrap();
        let error = CliError::ForegroundData(
            lexicon_framework::data::ForegroundDataExecutionError::TerminalSessionFailure {
                session: session.clone(),
                failure_code:
                    lexicon_core::session::SessionFailureCode::ZeroExitWithoutCompletion,
                source: Box::new(
                    lexicon_framework::data::ForegroundDataExecutionError::ZeroExitSessionIncomplete {
                        session,
                        operation: lexicon_framework::data::DataOperation::Acquisition,
                    },
                ),
            },
        );
        let mut output = Vec::new();

        error.write_terminal(&mut output).unwrap();

        assert_eq!(
            String::from_utf8(output).unwrap(),
            concat!(
                "[lexicon] ERROR [session/zero_exit_without_completion]: The runtime exited successfully without completing its session.\n",
                "[lexicon] Session: session-terminal-abc\n",
            )
        );
    }

    #[test]
    fn authoritative_session_code_keeps_distinct_handoff_context_subordinate() {
        let session = lexicon_core::session::SessionIdentity::new("session-handoff-abc").unwrap();
        let error = CliError::BackgroundHandoff(
            lexicon_framework::data::ForegroundDataExecutionError::TerminalSessionFailure {
                session,
                failure_code:
                    lexicon_core::session::SessionFailureCode::RuntimeInitializationFailed,
                source: Box::new(
                    lexicon_framework::data::ForegroundDataExecutionError::OperatorHostOwnershipTimeout,
                ),
            },
        );
        let mut output = Vec::new();

        error.write_terminal(&mut output).unwrap();

        assert_eq!(
            String::from_utf8(output).unwrap(),
            concat!(
                "[lexicon] ERROR [session/runtime_initialization_failed]: The managed runtime could not initialize.\n",
                "[lexicon] WARNING [operator/ownership_timeout]: Background ownership was not acknowledged before the handoff deadline.\n",
                "[lexicon] Session: session-handoff-abc\n",
            )
        );
    }

    #[test]
    fn cancellation_keeps_durable_session_code_and_signal_exit_class() {
        let session = lexicon_core::session::SessionIdentity::new(
            "session-cancelled-abc",
        )
        .unwrap();
        let error = CliError::ForegroundData(
            lexicon_framework::data::ForegroundDataExecutionError::SessionBound {
                session: session.clone(),
                source: Box::new(
                    lexicon_framework::data::ForegroundDataExecutionError::OperatorCancelled {
                        kind: lexicon_framework::process::CancellationKind::Terminate,
                        forced: true,
                        observed_termination:
                            lexicon_framework::data::outcome::ObservedChildTermination::Signaled {
                                signal: Some(15),
                            },
                        reconciliation_error: Some(Box::new(
                            lexicon_framework::data::ForegroundDataExecutionError::AbnormalTermination {
                                operation:
                                    lexicon_framework::data::DataOperation::Acquisition,
                                source: "example-source".to_string(),
                                session,
                                signal: Some(15),
                            },
                        )),
                    },
                ),
            },
        );
        let mut output = Vec::new();

        error.write_terminal(&mut output).unwrap();

        assert_eq!(
            String::from_utf8(output).unwrap(),
            concat!(
                "[lexicon] ERROR [session/abnormal_termination]: The managed runtime terminated abnormally.\n",
                "[lexicon] WARNING [operator/cancelled]: The operator cancelled the managed runtime.\n",
                "[lexicon] Session: session-cancelled-abc\n",
            )
        );
        assert_eq!(error.exit_code(), ExitCode::from(143));
    }

    #[test]
    fn aggregate_build_failure_uses_coded_safe_subordinate_details() {
        let failure = lexicon_framework::commands::SourceBuildFailure {
            source_name: "example-source".to_string(),
            protocol: "http".to_string(),
            error: lexicon_framework::ManagedSourceBuildError::MissingLockfile(
                std::path::PathBuf::from("/secret/location/Cargo.lock"),
            ),
        };
        let error = CliError::BuildTargets(vec![failure]);
        let mut output = Vec::new();

        error.write_terminal(&mut output).unwrap();

        let output = String::from_utf8(output).unwrap();
        assert!(output.contains("DETAIL [build/lockfile_missing]"));
        assert!(output.contains("source='example-source' protocol='http'"));
        assert!(output.contains("ERROR [build/targets_failed]"));
        assert!(!output.contains("/secret/location"));
    }

    #[test]
    fn abnormal_completed_status_fails() {
        let outcome = lexicon_framework::process::SupervisionOutcome::Completed {
            status: exit_status(None),
        };
        assert_eq!(exit_code_for_outcome(&outcome), ExitCode::from(1));
    }

    #[cfg(windows)]
    #[test]
    fn out_of_range_windows_status_fails_without_wrapping() {
        for status in [Some(-1), Some(256), Some(999)] {
            let outcome = lexicon_framework::process::SupervisionOutcome::Completed {
                status: exit_status(status),
            };
            assert_eq!(exit_code_for_outcome(&outcome), ExitCode::from(1));
        }
    }

    #[test]
    fn cancellation_control_failure_is_never_success() {
        let outcome = lexicon_framework::process::SupervisionOutcome::CancellationControlFailedButTerminated {
            kind: lexicon_framework::process::CancellationKind::Interrupt,
            graceful_error: None,
            force_error: std::io::Error::other("force failed"),
            status: exit_status(Some(0)),
        };
        assert_eq!(exit_code_for_outcome(&outcome), ExitCode::from(1));
    }

    fn with_test_cwd<T>(project_root: &std::path::Path, func: impl FnOnce() -> T) -> T {
        let _guard = TEST_CWD_LOCK.lock().unwrap();
        let original = std::env::current_dir().unwrap();
        std::env::set_current_dir(project_root).unwrap();
        let result = func();
        std::env::set_current_dir(&original).unwrap();
        result
    }

    #[test]
    fn dispatch_source_create_produces_only_framework_output() {
        let cli = Cli::try_parse_from([
            "lexicon",
            "source",
            "create",
            "example-source",
            "--protocol",
            "http",
        ])
        .unwrap();

        match cli.command {
            Some(RootCommand::Source(SourceCommand {
                action:
                    SourceAction::Create(CreateSourceCommand {
                        source_name,
                        protocol,
                    }),
            })) => {
                assert_eq!(source_name, "example-source");
                assert_eq!(protocol, "http");
            }
            other => panic!("expected source create command, got {other:?}"),
        }
    }

    #[test]
    fn unsupported_public_protocol_is_a_typed_error() {
        for arguments in [
            vec![
                "lexicon",
                "source",
                "create",
                "example-source",
                "--protocol",
                "HTTP",
            ],
            vec![
                "lexicon",
                "source",
                "build",
                "example-source",
                "--protocol",
                " http",
            ],
            vec![
                "lexicon",
                "data",
                "--get",
                "example-source",
                "--protocol",
                "http ",
                "--",
            ],
        ] {
            let cli = Cli::try_parse_from(arguments).unwrap();
            match super::dispatch(cli).unwrap_err() {
                CliError::Protocol(error) => assert_ne!(error.rejected(), "http"),
                other => panic!("expected typed protocol error, got {other:?}"),
            }
        }
    }

    #[test]
    fn cli_source_create_calls_framework_library_directly() {
        let temp = tempfile::tempdir().unwrap();
        let project_root = temp.path();
        fs::write(
            project_root.join("lexicon.toml"),
            "schema_version = 1\n[project]\nname = \"demo\"\n[paths]\nsources_directory = \"sources\"\n",
        )
        .unwrap();

        let result = with_test_cwd(project_root, || {
            lexicon_framework::commands::source_create("example-source", "http")
        });

        assert!(result.is_ok(), "source scaffold should succeed");
        let info = result.unwrap();
        assert_eq!(info.source_name, "example-source");
        assert_eq!(info.protocol, "http");
        assert!(info.protocol_dir.exists());
    }

    #[test]
    fn unsupported_protocol_returns_error_not_exit() {
        let temp = tempfile::tempdir().unwrap();
        let project_root = temp.path();
        fs::write(
            project_root.join("lexicon.toml"),
            "schema_version = 1\n[project]\nname = \"demo\"\n[paths]\nsources_directory = \"sources\"\n",
        )
        .unwrap();

        let result = with_test_cwd(project_root, || {
            lexicon_framework::commands::source_create("example-source", "browser")
        });

        assert!(result.is_err(), "unsupported protocol should return Err");
        let message = result.unwrap_err().to_string();
        assert!(
            message.contains("unsupported protocol"),
            "error must mention unsupported protocol: {message}"
        );
    }

    #[test]
    fn source_build_requires_protocol_flag() {
        let result = Cli::try_parse_from(["lexicon", "source", "build", "example-source"]);
        assert!(result.is_err());
    }

    #[test]
    fn cli_help_does_not_expose_framework_or_operator_host() {
        let command = Cli::command();
        let help = format!("{}", command.clone().render_long_help());
        assert!(
            !help.contains("framework-path"),
            "help must not expose --framework-path: {help}"
        );
        assert!(
            !help.contains("LEXICON_FRAMEWORK_PATH"),
            "help must not expose LEXICON_FRAMEWORK_PATH: {help}"
        );
        assert!(
            !help.contains("__operator-host"),
            "help must not expose the private operator host: {help}"
        );
    }

    #[test]
    fn unrelated_preexisting_directory_remains_untouched() {
        let temp = tempfile::tempdir().unwrap();
        let project_root = temp.path();
        fs::write(
            project_root.join("lexicon.toml"),
            "schema_version = 1\n[project]\nname = \"demo\"\n[paths]\nsources_directory = \"sources\"\n",
        )
        .unwrap();
        fs::create_dir_all(project_root.join("sources/preexisting-scratch")).unwrap();
        fs::write(
            project_root.join("sources/preexisting-scratch/keep.txt"),
            "keep-me\n",
        )
        .unwrap();

        let result = with_test_cwd(project_root, || {
            lexicon_framework::commands::source_create("example-source", "http")
        });
        assert!(result.is_ok(), "valid source creation should succeed");

        assert_eq!(
            fs::read_to_string(project_root.join("sources/preexisting-scratch/keep.txt")).unwrap(),
            "keep-me\n"
        );
        assert!(
            !project_root
                .join("sources/preexisting-scratch")
                .read_dir()
                .unwrap()
                .next()
                .is_none()
        );
    }

    #[test]
    fn dispatch_build_command_runs_build_all_on_empty_project() {
        let temp = tempfile::tempdir().unwrap();
        let project_root = temp.path();
        fs::write(
            project_root.join("lexicon.toml"),
            "schema_version = 1\n[project]\nname = \"demo\"\n[paths]\nsources_directory = \"sources\"\n",
        )
        .unwrap();
        fs::create_dir_all(project_root.join("sources")).unwrap();

        let cli = Cli::try_parse_from(["lexicon", "build"]).unwrap();
        let result = with_test_cwd(project_root, || super::dispatch(cli));
        assert!(
            matches!(result, Ok(())),
            "build on empty project should succeed: {result:?}"
        );
    }

    #[test]
    fn dispatch_init_and_source_create_uses_embedded_core_identity() {
        let temp = tempfile::tempdir().unwrap();
        let parent_path = temp.path();

        let init_cli = Cli::try_parse_from([
            "lexicon",
            "init",
            parent_path.to_str().unwrap(),
            "test-project",
        ])
        .unwrap();
        let init_result = super::dispatch(init_cli);
        assert!(init_result.is_ok(), "init failed: {init_result:?}");

        let project_dir = parent_path.join("test-project");
        assert!(project_dir.join("lexicon.toml").is_file());

        let create_cli = Cli::try_parse_from([
            "lexicon",
            "source",
            "create",
            "my-src",
            "--protocol",
            "http",
        ])
        .unwrap();
        let create_result = with_test_cwd(&project_dir, || super::dispatch(create_cli));
        assert!(
            matches!(create_result, Ok(())),
            "source create failed: {create_result:?}"
        );

        let protocol_dir = project_dir.join("sources/my-src/http");
        assert!(protocol_dir.join("source.toml").is_file());

        let acquisition_manifest =
            fs::read_to_string(protocol_dir.join("get-raw-data/Cargo.toml")).unwrap();
        assert!(acquisition_manifest.contains(
            lexicon_framework::core_provenance::MANAGED_CORE_RELATIVE_PATH,
        ));
        assert!(protocol_dir.join("get-raw-data/Cargo.lock").is_file());

        let processing_manifest =
            fs::read_to_string(protocol_dir.join("process-data/Cargo.toml")).unwrap();
        assert!(processing_manifest.contains(
            lexicon_framework::core_provenance::MANAGED_CORE_RELATIVE_PATH,
        ));
        assert!(protocol_dir.join("process-data/Cargo.lock").is_file());
        lexicon_framework::core_provenance::validate_managed_core(
            &protocol_dir.join("vendor/lexicon-core"),
        )
        .unwrap();
    }
}
