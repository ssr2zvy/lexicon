use std::ffi::OsString;

use clap::{ArgGroup, Parser};
use lexicon_framework::identity::{ManagedProtocol, ProtocolArgumentError};

#[derive(Parser, Debug, Clone)]
#[command(
    name = "data",
    about = "Fetch or process raw data for a source.",
    group(
        ArgGroup::new("data_action")
            .required(true)
            .multiple(false)
            .args(["get", "process"])
    )
)]
pub struct DataCommand {
    #[arg(
        long,
        value_name = "SOURCE_NAME",
        help = "Fetch raw data for SOURCE_NAME.",
        group = "data_action"
    )]
    pub get: Option<String>,

    #[arg(
        long,
        value_name = "SOURCE_NAME",
        help = "Process data for SOURCE_NAME.",
        group = "data_action"
    )]
    pub process: Option<String>,

    #[arg(
        long,
        value_name = "PROTOCOL",
        required = true,
        help = "Protocol for the source operation. The supported value is exactly `http`."
    )]
    pub protocol: String,

    #[arg(long, help = "Run the operation in the background.")]
    pub bg: bool,

    #[arg(
        long,
        help = "Abandon the previous failed session before running this command."
    )]
    pub abandon_past_fail: bool,

    /// Source-owned arguments. `last = true` makes the first literal `--` the
    /// only route into this vector; [`crate::cli::Cli::try_parse_from`] also
    /// verifies that the boundary exists when the vector is empty.
    #[arg(
        last = true,
        value_name = "SOURCE_ARGUMENT",
        allow_hyphen_values = true,
        help = "Arguments forwarded after `--` to the selected source implementation."
    )]
    pub source_arguments: Vec<OsString>,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum DataMode {
    Get(String),
    Process(String),
}

impl DataCommand {
    pub fn mode(&self) -> DataMode {
        match (self.get.as_deref(), self.process.as_deref()) {
            (Some(source_name), None) => DataMode::Get(source_name.to_owned()),
            (None, Some(source_name)) => DataMode::Process(source_name.to_owned()),
            _ => unreachable!("exactly one data action is required by clap validation"),
        }
    }

    /// Admit the explicit public protocol token without trimming or case
    /// folding. Callers must use the returned identity for framework dispatch.
    pub fn managed_protocol(&self) -> Result<ManagedProtocol, ProtocolArgumentError> {
        ManagedProtocol::parse_cli(&self.protocol)
    }
}

#[cfg(test)]
mod tests {
    use std::ffi::OsString;

    use crate::cli::{Cli, RootCommand};
    use lexicon_framework::identity::ManagedProtocol;

    #[test]
    fn parses_get_command_and_preserves_source_arguments() {
        let cli = Cli::try_parse_from([
            "lexicon",
            "data",
            "--get",
            "example-source",
            "--protocol",
            "http",
            "--bg",
            "--",
            "--from",
            "2024-01-01",
        ])
        .expect("lexicon data --get should parse");

        match cli.command {
            Some(RootCommand::Data(command)) => {
                assert_eq!(command.get.as_deref(), Some("example-source"));
                assert_eq!(command.process, None);
                assert_eq!(command.managed_protocol(), Ok(ManagedProtocol::Http));
                assert!(command.bg);
                assert_eq!(
                    command.source_arguments,
                    vec![OsString::from("--from"), OsString::from("2024-01-01")]
                );
            }
            other => panic!("expected Data command, got {other:?}"),
        }
    }

    #[test]
    fn parses_process_command_with_required_empty_tail_boundary() {
        let cli = Cli::try_parse_from([
            "lexicon",
            "data",
            "--process",
            "example-source",
            "--protocol",
            "http",
            "--abandon-past-fail",
            "--",
        ])
        .expect("lexicon data --process should parse");

        match cli.command {
            Some(RootCommand::Data(command)) => {
                assert_eq!(command.process.as_deref(), Some("example-source"));
                assert_eq!(command.managed_protocol(), Ok(ManagedProtocol::Http));
                assert!(!command.bg);
                assert!(command.abandon_past_fail);
                assert!(command.source_arguments.is_empty());
            }
            other => panic!("expected Data command, got {other:?}"),
        }
    }

    #[test]
    fn rejects_data_command_when_protocol_is_missing() {
        let result =
            Cli::try_parse_from(["lexicon", "data", "--get", "example-source", "--"]);
        assert!(result.is_err(), "data command requires --protocol");
    }

    #[test]
    fn rejects_data_command_when_protocol_value_is_missing() {
        let result = Cli::try_parse_from([
            "lexicon",
            "data",
            "--get",
            "example-source",
            "--protocol",
            "--",
        ]);
        assert!(result.is_err(), "--protocol requires a value");
    }

    #[test]
    fn get_and_process_are_mutually_exclusive() {
        let result = Cli::try_parse_from([
            "lexicon",
            "data",
            "--get",
            "first-source",
            "--process",
            "second-source",
            "--protocol",
            "http",
            "--",
        ]);
        assert!(result.is_err(), "one invocation cannot get and process");
    }

    #[test]
    fn literal_separator_is_required_even_for_an_empty_source_tail() {
        let result = Cli::try_parse_from([
            "lexicon",
            "data",
            "--get",
            "example-source",
            "--protocol",
            "http",
        ]);
        assert!(result.is_err(), "the public data grammar requires `--`");
    }

    #[test]
    fn values_cannot_enter_the_source_tail_without_the_separator() {
        let result = Cli::try_parse_from([
            "lexicon",
            "data",
            "--get",
            "example-source",
            "--protocol",
            "http",
            "--phase",
            "download",
        ]);
        assert!(result.is_err(), "source arguments require a literal `--`");
    }

    #[test]
    fn source_tail_preserves_empty_hyphenated_and_literal_separator_values() {
        let cli = Cli::try_parse_from([
            "lexicon",
            "data",
            "--get",
            "example-source",
            "--protocol",
            "http",
            "--",
            "",
            "--phase",
            "--",
        ])
        .expect("every value after the first `--` belongs to the source");

        match cli.command {
            Some(RootCommand::Data(command)) => assert_eq!(
                command.source_arguments,
                vec![OsString::from(""), OsString::from("--phase"), OsString::from("--")]
            ),
            other => panic!("expected Data command, got {other:?}"),
        }
    }

    #[test]
    fn data_protocol_parser_is_byte_exact() {
        for rejected in ["https", "HTTP", "Http", " http", "http ", "http\n"] {
            let cli = Cli::try_parse_from([
                "lexicon",
                "data",
                "--get",
                "example-source",
                "--protocol",
                rejected,
                "--",
            ])
            .expect("the typed protocol is admitted during dispatch, not normalized by clap");

            match cli.command {
                Some(RootCommand::Data(command)) => {
                    let error = command.managed_protocol().unwrap_err();
                    assert_eq!(error.rejected(), rejected);
                }
                other => panic!("expected Data command, got {other:?}"),
            }
        }
    }

    #[cfg(unix)]
    #[test]
    fn non_utf8_source_argument_remains_an_os_string() {
        use std::os::unix::ffi::OsStringExt;

        let native = OsString::from_vec(vec![b'v', 0x80, b'l']);
        let cli = Cli::try_parse_from(vec![
            OsString::from("lexicon"),
            OsString::from("data"),
            OsString::from("--get"),
            OsString::from("example-source"),
            OsString::from("--protocol"),
            OsString::from("http"),
            OsString::from("--"),
            native.clone(),
        ])
        .expect("non-UTF-8 source arguments must parse after `--`");

        match cli.command {
            Some(RootCommand::Data(command)) => {
                assert_eq!(command.source_arguments, vec![native]);
            }
            other => panic!("expected Data command, got {other:?}"),
        }
    }

    #[cfg(windows)]
    #[test]
    fn windows_wide_source_argument_remains_an_os_string() {
        use std::os::windows::ffi::OsStringExt;

        let native = OsString::from_wide(&[0x0061, 0xd83d, 0xde80, 0x0062]);
        let cli = Cli::try_parse_from(vec![
            OsString::from("lexicon"),
            OsString::from("data"),
            OsString::from("--process"),
            OsString::from("example-source"),
            OsString::from("--protocol"),
            OsString::from("http"),
            OsString::from("--"),
            native.clone(),
        ])
        .expect("Windows source arguments must remain native after `--`");

        match cli.command {
            Some(RootCommand::Data(command)) => {
                assert_eq!(command.source_arguments, vec![native]);
            }
            other => panic!("expected Data command, got {other:?}"),
        }
    }

    #[test]
    fn parses_private_operator_host_boundary() {
        let reference_json = r#"{"schema_version":1,"source_name":"example-source","protocol":"http","operation":"get-raw-data","session_id":"session-abc"}"#;
        let cli = Cli::try_parse_from([
            "lexicon",
            "__operator-host",
            reference_json,
            "--",
            "--from",
            "2024-01-01",
        ])
        .expect("the private operator host should parse its re-exec grammar");

        match cli.command {
            Some(RootCommand::OperatorHost(command)) => {
                assert_eq!(command.reference, reference_json);
                assert_eq!(
                    command.source_arguments,
                    vec![OsString::from("--from"), OsString::from("2024-01-01")]
                );
            }
            other => panic!("expected private OperatorHost command, got {other:?}"),
        }
    }

    #[test]
    fn private_operator_host_requires_the_separator() {
        let empty_tail = Cli::try_parse_from(["lexicon", "__operator-host", "{}"]);
        assert!(
            empty_tail.is_err(),
            "operator-host empty source tail still requires `--`"
        );

        let populated_tail = Cli::try_parse_from([
            "lexicon",
            "__operator-host",
            "{}",
            "--from",
            "2024-01-01",
        ]);
        assert!(
            populated_tail.is_err(),
            "operator-host source arguments require `--`"
        );
    }

    #[test]
    fn operator_host_command_is_hidden_from_help_output() {
        let mut command = Cli::command();
        let help = command.render_help().to_string();
        assert!(
            !help.contains("__operator-host"),
            "the reserved internal entrypoint must not appear in help:\n{help}"
        );
    }
}
