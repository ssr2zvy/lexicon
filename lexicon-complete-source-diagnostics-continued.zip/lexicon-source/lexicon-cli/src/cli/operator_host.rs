use std::ffi::OsString;

use clap::Parser;

/// Reserved internal entrypoint used only by re-execution for background
/// execution (`lexicon data ... --bg`).
///
/// This command and its fields are visible only inside the CLI module. The
/// subcommand is also hidden from generated help, so it cannot become part of
/// the ordinary public command API by re-export.
#[derive(Parser, Debug, Clone)]
#[command(
    name = "__operator-host",
    hide = true,
    about = "Reserved internal entrypoint. Do not invoke directly."
)]
pub(super) struct OperatorHostCommand {
    /// The encoded non-secret `OperatorHostInvocationV1` reference. The
    /// single-use handoff capability is never admitted through argv.
    #[arg(value_name = "INVOCATION_REFERENCE")]
    pub(super) reference: String,

    /// Native source arguments. `last = true` prevents any value from being
    /// admitted here until the re-executor supplies the literal `--` boundary.
    #[arg(
        last = true,
        value_name = "SOURCE_ARGUMENT",
        allow_hyphen_values = true,
        help = "Arguments forwarded after `--` to the selected source implementation."
    )]
    pub(super) source_arguments: Vec<OsString>,
}
