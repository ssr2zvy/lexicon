use std::process::ExitCode;

fn main() -> ExitCode {
    lexicon_cli::run_native(std::env::args_os())
}
