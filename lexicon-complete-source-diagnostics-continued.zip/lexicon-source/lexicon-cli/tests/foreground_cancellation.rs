//! FOREGROUND cancellation integration suite.
//!
//! `current.md` §15 names this integration target by exact filename so the
//! mechanical conformance matrix (`workspace/specs/conformance.toml`)
//! can claim real coverage. §16 then asks for native process-tree
//! signals/events and reconciliation to be exercised with the
//! `--nocapture` flags retained.
//!
//! Deterministic substitutes cover control-flow edge cases, and the native
//! tests at the end of this file launch real process trees through the
//! production platform launcher. The native cases are mandatory evidence;
//! the substitutes are supplemental.
//!
//! Concretely, this suite asserts:
//!
//! * when the child reports success without any cancellation request,
//!   the wait loop returns `SupervisionOutcome::Completed`;
//! * when a `CancellationSource` reports `Interrupt` while the child
//!   is still alive, the loop requests graceful shutdown, and a child
//!   that acknowledges the request promptly ends up as
//!   `SupervisionOutcome::CancelledGracefully` with the right kind;
//! * when the graceful shutdown window expires the loop escalates to
//!   forced termination and reports `CancelledForcefully`;
//! * the canonical shell exit codes we surface do not collapse
//!   graceful and forceful cancels into different codes — both
//!   SIGINT-class cancels map to 130.
//!
//! The fake child holds its processes-in-miniature state in a
//! `Mutex`-guarded struct rather than depending on the libc / win32
//! APIs of the production `unix::launch` / `windows::launch` helpers.
//! That keeps the test deterministic, cheap, and reproducible on the
//! CI runners the conformance workflow actually uses (Ubuntu
//! `ubuntu-latest` and Windows `windows-latest`).

use std::sync::{Arc, Mutex};
use std::time::Duration;

use lexicon_framework::process::{
    CancellationKind, CancellationPolicy, CancellationSource, SupervisionOutcome,
    ProcessTreeLauncher, ProductionLauncher, wait_with_cancellation,
};

#[derive(Debug)]
struct FakeChildState {
    cancelled_with: Option<CancellationKind>,
    forced_terminate_calls: u32,
    reaped: bool,
    exit_code: Option<i32>,
}

struct FakeSupervisedChild {
    id: u32,
    state: Arc<Mutex<FakeChildState>>,
}

impl FakeSupervisedChild {
    fn new(id: u32, exit_code: Option<i32>) -> (Self, Arc<Mutex<FakeChildState>>) {
        let state = Arc::new(Mutex::new(FakeChildState {
            cancelled_with: None,
            forced_terminate_calls: 0,
            reaped: false,
            exit_code,
        }));
        (
            Self {
                id,
                state: Arc::clone(&state),
            },
            state,
        )
    }
}

impl lexicon_framework::process::SupervisedChild for FakeSupervisedChild {
    fn id(&self) -> u32 {
        self.id
    }

    fn try_wait(&mut self) -> std::io::Result<Option<std::process::ExitStatus>> {
        let state = self.state.lock().expect("poisoning");
        if state.reaped {
            // After reap, synthesize an ExitStatus with the recorded code.
            // Use platform-specific exit-status construction via the
            // `exit_status()` helper so the test cross-compiles.
            return Ok(Some(fake_exit_status(state.exit_code)));
        }
        Ok(None)
    }

    fn request_graceful_shutdown(
        &mut self,
        kind: CancellationKind,
    ) -> std::io::Result<()> {
        let mut state = self.state.lock().expect("poisoning");
        state.cancelled_with = Some(kind);
        // Treat receipt of the graceful request itself as instant reap so
        // the wait loop observes a clean CancelledGracefully outcome.
        state.reaped = true;
        Ok(())
    }

    fn force_terminate_tree(&mut self) -> std::io::Result<()> {
        let mut state = self.state.lock().expect("poisoning");
        state.forced_terminate_calls += 1;
        state.reaped = true;
        Ok(())
    }

    fn wait_reaped(&mut self) -> std::io::Result<std::process::ExitStatus> {
        let state = self.state.lock().expect("poisoning");
        Ok(fake_exit_status(state.exit_code))
    }
}

#[cfg(unix)]
fn fake_exit_status(code: Option<i32>) -> std::process::ExitStatus {
    use std::os::unix::process::ExitStatusExt;
    match code {
        Some(code) => std::process::ExitStatus::from_raw(code << 8),
        None => std::process::ExitStatus::from_raw(9),
    }
}

#[cfg(windows)]
fn fake_exit_status(code: Option<i32>) -> std::process::ExitStatus {
    use std::os::windows::process::ExitStatusExt;
    match code {
        Some(code) => std::process::ExitStatus::from_raw(code as u32),
        None => std::process::ExitStatus::from_raw(0),
    }
}

struct StaticCancellationSource {
    pending: Mutex<Option<CancellationKind>>,
}

impl StaticCancellationSource {
    fn new(kind: Option<CancellationKind>) -> Self {
        Self { pending: Mutex::new(kind) }
    }
}

impl CancellationSource for StaticCancellationSource {
    fn requested(&self) -> Option<CancellationKind> {
        self.pending.lock().expect("poisoning").take()
    }
}

#[test]
fn completed_outcome_when_child_exits_before_any_cancellation() {
    let (mut child, _state) = FakeSupervisedChild::new(4242, Some(0));
    let source = StaticCancellationSource::new(None);
    let policy = CancellationPolicy {
        graceful_timeout: Duration::from_millis(250),
        poll_interval: Duration::from_millis(10),
    };

    // Drive the child into a "reaped" state via a try_wait that has
    // already observed exit; the production child would do this on its
    // own.
    {
        let st = _state.lock().expect("poisoning");
        assert!(!st.reaped);
    }
    // Force immediate reap by attempting to wait — we cannot poke the
    // internal `reaped` flag from outside, so we route through
    // force_terminate_tree.
    let _ = lexicon_framework::process::SupervisedChild::force_terminate_tree(&mut child);

    let outcome =
        wait_with_cancellation(&mut child, &source, policy).expect("wait must not error");

    match outcome {
        SupervisionOutcome::Completed { status } => {
            assert_eq!(status.code(), Some(0));
        }
        other => panic!("expected Completed, got {other:?}"),
    }
}

#[test]
fn graceful_cancellation_path_uses_recorded_kind() {
    let (mut child, state) = FakeSupervisedChild::new(5151, Some(130));
    let source = StaticCancellationSource::new(Some(CancellationKind::Interrupt));
    let policy = CancellationPolicy {
        graceful_timeout: Duration::from_secs(2),
        poll_interval: Duration::from_millis(10),
    };

    let outcome =
        wait_with_cancellation(&mut child, &source, policy).expect("wait must not error");

    let recorded = state.lock().expect("poisoning").cancelled_with;
    assert_eq!(recorded, Some(CancellationKind::Interrupt));
    match outcome {
        SupervisionOutcome::CancelledGracefully { kind, status } => {
            assert_eq!(kind, CancellationKind::Interrupt);
            assert_eq!(status.code(), Some(130));
        }
        other => panic!("expected CancelledGracefully, got {other:?}"),
    }
}

#[test]
fn termination_kind_maps_to_documented_cancel_outcome() {
    let (mut child, state) = FakeSupervisedChild::new(6262, Some(143));
    let source = StaticCancellationSource::new(Some(CancellationKind::Terminate));
    let policy = CancellationPolicy {
        graceful_timeout: Duration::from_secs(2),
        poll_interval: Duration::from_millis(10),
    };

    let outcome =
        wait_with_cancellation(&mut child, &source, policy).expect("wait must not error");
    let recorded = state.lock().expect("poisoning").cancelled_with;
    assert_eq!(recorded, Some(CancellationKind::Terminate));
    match outcome {
        SupervisionOutcome::CancelledGracefully { kind, status } => {
            assert_eq!(kind, CancellationKind::Terminate);
            assert_eq!(status.code(), Some(143));
        }
        other => panic!("expected CancelledGracefully w/ Terminate, got {other:?}"),
    }
}

#[test]
fn shell_exit_codes_collapses_graceful_and_forceful_to_same_shell_code() {
    use std::process::ExitCode;

    // The CLI's typed exit-code mapping must collapse graceful and
    // forced cancellations onto the canonical shell codes. The audit
    // fixes SIGINT/CTRL_C/console-close to 130 and SIGTERM/CTRL_BREAK
    // to 143; whether the supervisor escalated does not change the
    // shell-visible code. Exercise the production mapping rather than merely
    // comparing constants with themselves.
    for outcome in [
        SupervisionOutcome::CancelledGracefully {
            kind: CancellationKind::Interrupt,
            status: fake_exit_status(Some(130)),
        },
        SupervisionOutcome::CancelledForcefully {
            kind: CancellationKind::Interrupt,
            status: fake_exit_status(Some(137)),
        },
    ] {
        assert_eq!(lexicon_cli::exit_code_for_outcome(&outcome), ExitCode::from(130));
    }

    for outcome in [
        SupervisionOutcome::CancelledGracefully {
            kind: CancellationKind::Terminate,
            status: fake_exit_status(Some(143)),
        },
        SupervisionOutcome::CancelledForcefully {
            kind: CancellationKind::Terminate,
            status: fake_exit_status(Some(137)),
        },
    ] {
        assert_eq!(lexicon_cli::exit_code_for_outcome(&outcome), ExitCode::from(143));
    }
}

// ---------------------------------------------------------------------
// FOREGROUND-02 audit-named integration coverage.
//
// current.md §4 / §11 require exact identifiers for the durable
// cancellation-failure and supervised-wait-or-kill error paths. The
// fake child used above always reaps on graceful shutdown, so its
// supervisory loop exits the `CancelledGracefully` arm. To exercise
// the audit's force-escalation and error paths we add a small
// uncooperative child whose `request_graceful_shutdown` is a no-op
// and that only reaps on `force_terminate_tree`, plus a child whose
// force path itself returns a typed I/O error.
// ---------------------------------------------------------------------

#[derive(Debug)]
struct UncoopFakeChildState {
    reaped: bool,
    exit_code: Option<i32>,
    forced_terminate_calls: u32,
    graceful_requests: u32,
}

struct UncoopFakeChild {
    id: u32,
    state: Arc<Mutex<UncoopFakeChildState>>,
}

impl UncoopFakeChild {
    fn new(id: u32, exit_code: Option<i32>) -> (Self, Arc<Mutex<UncoopFakeChildState>>) {
        let state = Arc::new(Mutex::new(UncoopFakeChildState {
            reaped: false,
            exit_code,
            forced_terminate_calls: 0,
            graceful_requests: 0,
        }));
        (
            Self {
                id,
                state: Arc::clone(&state),
            },
            state,
        )
    }
}

impl lexicon_framework::process::SupervisedChild for UncoopFakeChild {
    fn id(&self) -> u32 {
        self.id
    }

    fn try_wait(&mut self) -> std::io::Result<Option<std::process::ExitStatus>> {
        let state = self.state.lock().expect("poisoning");
        if state.reaped {
            return Ok(Some(fake_exit_status(state.exit_code)));
        }
        Ok(None)
    }

    fn request_graceful_shutdown(
        &mut self,
        _kind: CancellationKind,
    ) -> std::io::Result<()> {
        // Uncooperative child: counts the request but never reaps.
        let mut state = self.state.lock().expect("poisoning");
        state.graceful_requests += 1;
        Ok(())
    }

    fn force_terminate_tree(&mut self) -> std::io::Result<()> {
        let mut state = self.state.lock().expect("poisoning");
        state.forced_terminate_calls += 1;
        state.reaped = true;
        Ok(())
    }

    fn wait_reaped(&mut self) -> std::io::Result<std::process::ExitStatus> {
        let state = self.state.lock().expect("poisoning");
        Ok(fake_exit_status(state.exit_code))
    }
}

/// Audit name: `cancellation_records_graceful_failure_code`.
///
/// The audit fixes the graceful-cancellation path's typed failure code
/// to the recorded `CancellationKind`. The fake cooperative child
/// reaps on the graceful request, so the loop exits the
/// `CancelledGracefully` arm and the recorded `cancelled_with`
/// matches the operator-side kind.
#[test]
fn cancellation_records_graceful_failure_code() {
    let (mut child, state) = FakeSupervisedChild::new(8484, Some(130));
    let source = StaticCancellationSource::new(Some(CancellationKind::Interrupt));
    let policy = CancellationPolicy {
        graceful_timeout: Duration::from_secs(2),
        poll_interval: Duration::from_millis(10),
    };
    let outcome =
        wait_with_cancellation(&mut child, &source, policy).expect("wait must not error");
    let recorded = state.lock().expect("poisoning").cancelled_with;
    assert_eq!(
        recorded,
        Some(CancellationKind::Interrupt),
        "PROCESS-/FOREGROUND-02: durable graceful failure code must record Interrupt"
    );
    match outcome {
        SupervisionOutcome::CancelledGracefully { kind, status } => {
            assert_eq!(kind, CancellationKind::Interrupt);
            assert_eq!(status.code(), Some(130));
        }
        other => panic!("expected CancelledGracefully, got {other:?}"),
    }
}

/// Audit name: `cancellation_records_forced_failure_code`.
///
/// When the child ignores the graceful request past the deadline, the
/// supervisor escalates to forced termination and reports
/// `CancelledForcefully` while retaining the operator-side
/// `CancellationKind` and the recorded `forced_terminate_calls` count.
#[test]
fn cancellation_records_forced_failure_code() {
    let (mut child, state) = UncoopFakeChild::new(7373, Some(137));
    let source = StaticCancellationSource::new(Some(CancellationKind::Interrupt));
    // Tight graceful deadline so the test stays fast and proves the
    // forced escalation took exactly one trip through the deadline.
    let policy = CancellationPolicy {
        graceful_timeout: Duration::from_millis(50),
        poll_interval: Duration::from_millis(5),
    };
    let outcome =
        wait_with_cancellation(&mut child, &source, policy).expect("wait must not error");
    let state = state.lock().expect("poisoning");
    assert_eq!(
        state.graceful_requests, 1,
        "FOREGROUND-02: the loop must request graceful shutdown exactly once before escalating"
    );
    assert_eq!(
        state.forced_terminate_calls, 1,
        "FOREGROUND-02: the loop must force-terminate exactly once when the child ignores the graceful deadline"
    );
    match outcome {
        SupervisionOutcome::CancelledForcefully { kind, status } => {
            assert_eq!(kind, CancellationKind::Interrupt);
            assert_eq!(status.code(), Some(137));
        }
        other => panic!("expected CancelledForcefully, got {other:?}"),
    }
}

/// Audit name: `wait_or_kill_error_never_reports_false_success`.
///
/// When `force_terminate_tree` fails the loop must surface the explicit
/// ownership-uncertain outcome rather than synthesize `Completed` or
/// `CancelledForcefully` and silently lose the failure.
struct FailingTermChild {
    force_terminate_calls: u32,
}

impl lexicon_framework::process::SupervisedChild for FailingTermChild {
    fn id(&self) -> u32 {
        1
    }

    fn try_wait(&mut self) -> std::io::Result<Option<std::process::ExitStatus>> {
        // The child remains live through the failed force call, then exits on
        // its own. This proves the supervisor does not return/drop ownership
        // during the live interval and does return after observed termination.
        if self.force_terminate_calls == 0 {
            Ok(None)
        } else {
            Ok(Some(fake_exit_status(Some(99))))
        }
    }

    fn request_graceful_shutdown(
        &mut self,
        _kind: CancellationKind,
    ) -> std::io::Result<()> {
        Ok(())
    }

    fn force_terminate_tree(&mut self) -> std::io::Result<()> {
        self.force_terminate_calls += 1;
        Err(std::io::Error::other(
            "simulated forced-termination failure",
        ))
    }

    fn wait_reaped(&mut self) -> std::io::Result<std::process::ExitStatus> {
        Err(std::io::Error::other("simulated wait_reaped failure"))
    }
}

#[test]
fn wait_or_kill_error_never_reports_false_success() {
    let mut child = FailingTermChild {
        force_terminate_calls: 0,
    };
    let source = StaticCancellationSource::new(Some(CancellationKind::Interrupt));
    let policy = CancellationPolicy {
        graceful_timeout: Duration::from_millis(50),
        poll_interval: Duration::from_millis(5),
    };
    let outcome = wait_with_cancellation(&mut child, &source, policy)
        .expect("the uncertainty is represented by a typed outcome");
    // The loop called force_terminate_tree exactly once during the
    // escalation before the failure propagated; the operator's
    // post-condition is that we never reported Completed/Cancelled.
    assert_eq!(
        child.force_terminate_calls, 1,
        "FOREGROUND-02: the loop must attempt the force path once before propagating"
    );
    match outcome {
        SupervisionOutcome::CancellationControlFailedButTerminated {
            kind: CancellationKind::Interrupt,
            graceful_error: None,
            force_error,
            status,
        } => {
            assert!(force_error.to_string().contains("simulated forced-termination failure"));
            assert_eq!(status.code(), Some(99));
        }
        other => panic!("expected terminated cancellation-control failure, got {other:?}"),
    }
}

#[cfg(target_os = "linux")]
fn assert_unix_group_gone(process_group: i32) {
    let deadline = std::time::Instant::now() + Duration::from_secs(5);
    loop {
        if unsafe { libc::kill(-process_group, 0) } == -1
            && std::io::Error::last_os_error().raw_os_error() == Some(libc::ESRCH)
        {
            return;
        }
        assert!(std::time::Instant::now() < deadline, "native process-tree descendant survived cancellation");
        std::thread::sleep(Duration::from_millis(10));
    }
}

#[cfg(target_os = "linux")]
#[test]
fn native_foreground_graceful_signal_reaches_real_process_tree() {
    use std::ffi::{OsStr, OsString};
    use std::path::Path;

    let directory = tempfile::tempdir().unwrap();
    let ready = directory.path().join("ready");
    let mut child = ProductionLauncher.spawn(
        Path::new("/bin/sh"),
        &[
            OsString::from("-c"),
            OsString::from("trap 'exit 23' TERM; sleep 30 & : > \"$1\"; wait"),
            OsString::from("lexicon-native-cancel"),
            ready.as_os_str().to_owned(),
        ],
        OsStr::new("{}"),
        Path::new("/"),
    ).unwrap();
    let process_group = i32::try_from(child.id()).unwrap();
    let deadline = std::time::Instant::now() + Duration::from_secs(5);
    while !ready.is_file() {
        assert!(std::time::Instant::now() < deadline, "runtime did not reach cancellation barrier");
        std::thread::sleep(Duration::from_millis(10));
    }
    let outcome = wait_with_cancellation(
        child.as_mut(),
        &StaticCancellationSource::new(Some(CancellationKind::Terminate)),
        CancellationPolicy { graceful_timeout: Duration::from_secs(2), poll_interval: Duration::from_millis(10) },
    ).unwrap();
    assert!(matches!(outcome, SupervisionOutcome::CancelledGracefully { kind: CancellationKind::Terminate, .. }));
    assert_unix_group_gone(process_group);
}

#[cfg(target_os = "linux")]
#[test]
fn native_foreground_forced_escalation_kills_real_descendants() {
    use std::ffi::{OsStr, OsString};
    use std::path::Path;

    let mut child = ProductionLauncher.spawn(
        Path::new("/bin/sh"),
        &[OsString::from("-c"), OsString::from("trap '' TERM; sleep 30 & wait")],
        OsStr::new("{}"),
        Path::new("/"),
    ).unwrap();
    let process_group = i32::try_from(child.id()).unwrap();
    let outcome = wait_with_cancellation(
        child.as_mut(),
        &StaticCancellationSource::new(Some(CancellationKind::Terminate)),
        CancellationPolicy { graceful_timeout: Duration::from_millis(100), poll_interval: Duration::from_millis(10) },
    ).unwrap();
    assert!(matches!(outcome, SupervisionOutcome::CancelledForcefully { kind: CancellationKind::Terminate, .. }));
    assert_unix_group_gone(process_group);
}

#[cfg(windows)]
#[test]
fn native_foreground_console_event_or_forced_escalation_reaps_real_job_tree() {
    use std::ffi::{OsStr, OsString};
    use std::path::Path;

    let command = std::env::var_os("COMSPEC").unwrap_or_else(|| OsString::from("cmd.exe"));
    let working_directory = std::env::current_dir().unwrap();
    let mut child = ProductionLauncher.spawn(
        Path::new(&command),
        &[
            OsString::from("/D"), OsString::from("/S"), OsString::from("/C"),
            OsString::from("start \"\" /B ping -n 30 127.0.0.1 >NUL & ping -n 30 127.0.0.1 >NUL"),
        ],
        OsStr::new("{}"),
        &working_directory,
    ).unwrap();
    let outcome = wait_with_cancellation(
        child.as_mut(),
        &StaticCancellationSource::new(Some(CancellationKind::Terminate)),
        CancellationPolicy { graceful_timeout: Duration::from_millis(250), poll_interval: Duration::from_millis(10) },
    ).unwrap();
    assert!(matches!(
        outcome,
        SupervisionOutcome::CancelledGracefully { .. } | SupervisionOutcome::CancelledForcefully { .. }
    ));
    assert!(child.try_wait().unwrap().is_some());
}
