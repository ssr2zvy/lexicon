use lexicon_framework::build::{
    admit_managed_core_dependency, verify_lexicon_core_metadata_document,
};
use lexicon_framework::core_provenance::{
    CORE_PROVENANCE_FILE, EMBEDDED_CORE_PACKAGE, EMBEDDED_CORE_SHA256,
    EMBEDDED_CORE_VERSION, MANAGED_CORE_RELATIVE_PATH, validate_managed_core,
};
use std::fs;
use std::path::{Path, PathBuf};
use std::process::{Command, Output};

fn copied_installed_binary(root: &Path) -> PathBuf {
    let source = PathBuf::from(env!("CARGO_BIN_EXE_lexicon"));
    let name = if cfg!(windows) { "lexicon.exe" } else { "lexicon" };
    let destination = root.join("installed/bin").join(name);
    fs::create_dir_all(destination.parent().unwrap()).unwrap();
    fs::copy(&source, &destination).unwrap();
    destination
}

fn run_isolated(binary: &Path, cwd: &Path, args: &[&str], tool_directory: &Path, cargo_home: &Path) -> Output {
    Command::new(binary)
        .args(args)
        .current_dir(cwd)
        .env_clear()
        .env("PATH", tool_directory)
        .env("CARGO_HOME", cargo_home)
        .env("CARGO_NET_OFFLINE", "true")
        .env("HOME", cwd)
        .env("USERPROFILE", cwd)
        .output()
        .expect("launch copied installed Lexicon executable")
}

fn cargo_executable() -> PathBuf {
    let cargo = std::env::var_os("CARGO").map(PathBuf::from).unwrap_or_else(|| PathBuf::from("cargo"));
    if cargo.is_absolute() { return cargo; }
    let output = Command::new(&cargo).arg("--version").output().expect("Cargo is required for the separately provisioned build phase");
    assert!(output.status.success());
    let path = std::env::var_os("PATH").expect("test harness PATH");
    std::env::split_paths(&path).map(|directory| directory.join(if cfg!(windows) { "cargo.exe" } else { "cargo" }))
        .find(|candidate| candidate.is_file()).expect("resolve absolute Cargo executable")
}

fn assert_exact_workspace_manifest(path: &Path) {
    let text = fs::read_to_string(path).unwrap();
    let document: toml::Value = toml::from_str(&text).unwrap();
    let dependency = document.get("workspace").and_then(|value| value.get("dependencies"))
        .and_then(|value| value.get("lexicon_core")).and_then(toml::Value::as_table).unwrap();
    let mut keys = dependency.keys().map(String::as_str).collect::<Vec<_>>();
    keys.sort();
    assert_eq!(keys, ["package", "path", "version"]);
    assert_eq!(dependency.get("package").and_then(toml::Value::as_str), Some(EMBEDDED_CORE_PACKAGE));
    assert_eq!(dependency.get("path").and_then(toml::Value::as_str), Some(MANAGED_CORE_RELATIVE_PATH));
    assert_eq!(dependency.get("version").and_then(toml::Value::as_str), Some(format!("={EMBEDDED_CORE_VERSION}").as_str()));
}

fn assert_no_checkout_reference(root: &Path) {
    let checkout = env!("CARGO_MANIFEST_DIR");
    let mut pending = vec![root.to_path_buf()];
    while let Some(path) = pending.pop() {
        for entry in fs::read_dir(path).unwrap() {
            let entry = entry.unwrap();
            let path = entry.path();
            if entry.file_type().unwrap().is_dir() {
                pending.push(path);
            } else if let Ok(text) = fs::read_to_string(&path) {
                assert!(!text.contains(checkout), "{} retained build checkout path {checkout}", path.display());
            }
        }
    }
}

#[test]
fn copied_installed_cli_materializes_exact_core_and_both_workspaces_build_locked_offline() {
    let test_root = tempfile::tempdir().unwrap();
    let installed = copied_installed_binary(test_root.path());
    let work = test_root.path().join("work");
    let tools_without_git_or_cargo = test_root.path().join("empty-tools");
    let cargo_home = std::env::var_os("CARGO_HOME").map(PathBuf::from).unwrap_or_else(|| {
        PathBuf::from(std::env::var_os("HOME").expect("HOME or CARGO_HOME is required")).join(".cargo")
    });
    fs::create_dir_all(&work).unwrap();
    fs::create_dir_all(&tools_without_git_or_cargo).unwrap();
    assert!(cargo_home.is_dir(), "reuse the Cargo cache that built this test");
    assert!(!tools_without_git_or_cargo.join("git").exists());
    assert!(!tools_without_git_or_cargo.join("cargo").exists());

    let init = run_isolated(&installed, &work, &["init", ".", "identity-project"], &tools_without_git_or_cargo, &cargo_home);
    assert!(init.status.success(), "init failed: {}", String::from_utf8_lossy(&init.stderr));
    let project = work.join("identity-project");
    let create = run_isolated(&installed, &project, &["source", "create", "identity-source", "--protocol", "http"], &tools_without_git_or_cargo, &cargo_home);
    assert!(create.status.success(), "source create failed without Git/Cargo/network/checkout: {}", String::from_utf8_lossy(&create.stderr));

    let protocol = project.join("sources/identity-source/http");
    assert_no_checkout_reference(&protocol);
    let core_root = protocol.join("vendor/lexicon-core");
    validate_managed_core(&core_root).unwrap();
    let provenance: toml::Value = toml::from_str(&fs::read_to_string(protocol.join("vendor").join(CORE_PROVENANCE_FILE)).unwrap()).unwrap();
    assert_eq!(provenance.get("package").and_then(toml::Value::as_str), Some(EMBEDDED_CORE_PACKAGE));
    assert_eq!(provenance.get("version").and_then(toml::Value::as_str), Some(EMBEDDED_CORE_VERSION));
    assert_eq!(provenance.get("sha256").and_then(toml::Value::as_str), Some(EMBEDDED_CORE_SHA256));

    let workspaces = [protocol.join("get-raw-data"), protocol.join("process-data")];
    for workspace in &workspaces {
        assert_exact_workspace_manifest(&workspace.join("Cargo.toml"));
        admit_managed_core_dependency(workspace).unwrap();
    }

    let cargo = cargo_executable();
    for workspace in &workspaces {
        let admitted = admit_managed_core_dependency(workspace).unwrap();
        let manifest = workspace.join("Cargo.toml");
        let metadata = Command::new(&cargo).args(["metadata", "--locked", "--offline", "--format-version", "1", "--manifest-path"])
            .arg(&manifest).env("CARGO_HOME", &cargo_home).env("CARGO_NET_OFFLINE", "true").output().unwrap();
        assert!(metadata.status.success(), "offline metadata failed: {}", String::from_utf8_lossy(&metadata.stderr));
        assert!(!String::from_utf8_lossy(&metadata.stdout).contains(env!("CARGO_MANIFEST_DIR")));
        verify_lexicon_core_metadata_document(&metadata.stdout, &admitted).unwrap();
        let target = test_root.path().join("offline-target").join(workspace.file_name().unwrap());
        let build = Command::new(&cargo).args(["build", "--locked", "--offline", "--release", "--manifest-path"])
            .arg(&manifest).arg("--target-dir").arg(target).env("CARGO_HOME", &cargo_home).env("CARGO_NET_OFFLINE", "true").output().unwrap();
        assert!(build.status.success(), "offline build failed: {}", String::from_utf8_lossy(&build.stderr));
    }
}

#[test]
fn managed_core_mutation_fails_before_build() {
    let root = tempfile::tempdir().unwrap();
    let vendor = root.path().join("vendor");
    let core = lexicon_framework::core_provenance::materialize_embedded_core(&vendor).unwrap();
    fs::write(core.join("src/lib.rs"), "pub fn substituted() {}\n").unwrap();
    assert!(validate_managed_core(&core).is_err());
}
