use std::path::{Path, PathBuf};
use std::process::{Command, Output};

use lexicon_core::session::{generate_session_id, SessionIdentity};
use lexicon_core::runtime::{OwnedRuntimeIdentity, ProjectInvocationIdentity, RuntimeExecutionMode, RuntimeSupervisionMode};
use lexicon_core::session::{HandoffAuthorityStateV1, HandoffClaimProof, HandoffFenceOutcome,
    HandoffProtocolError, HandoffRevocationReasonV1, HandoffToken, NewSessionRecord,
    OperatorIdentityV1, SessionLeaseError, SessionOperation, SessionOperationRoot, SessionState,
    SessionStore};
use lexicon_framework::data::DataOperation;
use lexicon_framework::supervision::{
    OperatorHostInvocationDecodingError, OperatorHostInvocationV1,
    OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE,
};

fn lexicon() -> PathBuf { PathBuf::from(env!("CARGO_BIN_EXE_lexicon")) }
fn run(current: &Path, arguments: &[&str]) -> Output {
    Command::new(lexicon()).current_dir(current).args(arguments).output().expect("spawn lexicon")
}
fn assert_success(output: Output, stage: &str) {
    assert!(output.status.success(), "{stage}: stdout={} stderr={}",
        String::from_utf8_lossy(&output.stdout), String::from_utf8_lossy(&output.stderr));
}
fn session() -> SessionIdentity {
    SessionIdentity::new(generate_session_id().expect("OS-CSPRNG session identity"))
        .expect("generated session identity")
}

#[test]
fn reserved_invocation_round_trips_without_serializing_private_token() {
    let reference = OperatorHostInvocationV1::new_reserved(
        "example", "http", DataOperation::Acquisition, session(), 17,
        "operator-instance-17",
    ).unwrap();
    let encoded = reference.to_json().unwrap();
    let decoded = OperatorHostInvocationV1::from_json(&encoded).unwrap();
    assert_eq!(decoded.handoff_epoch(), 17);
    assert_eq!(decoded.operator_instance_nonce(), "operator-instance-17");
    assert!(!encoded.contains("handoff_token"));
    assert!(!encoded.contains(&"11".repeat(32)));
}

#[test]
fn decoder_rejects_unknown_operation() {
    let document = r#"{"schema_version":1,"source_name":"x","protocol":"http","operation":"fetch","session_id":"abcdabcd","handoff_epoch":1,"operator_instance_nonce":"n"}"#;
    assert!(matches!(OperatorHostInvocationV1::from_json(document), Err(OperatorHostInvocationDecodingError::UnknownOperation(_))));
}

#[test]
fn hidden_operator_host_requires_literal_boundary_and_valid_reference() {
    let temp = tempfile::tempdir().unwrap();
    assert!(!run(temp.path(), &["__operator-host", "{}"]).status.success());
    assert!(!run(temp.path(), &["__operator-host", "{}", "--"]).status.success());
}

#[test]
fn hidden_operator_host_rejects_missing_and_malformed_private_capability() {
    let temp = tempfile::tempdir().unwrap();
    let reference = OperatorHostInvocationV1::new_reserved(
        "example",
        "http",
        DataOperation::Acquisition,
        session(),
        1,
        "operator-instance-1",
    )
    .unwrap()
    .to_json()
    .unwrap();

    let missing = Command::new(lexicon())
        .current_dir(temp.path())
        .arg("__operator-host")
        .arg(&reference)
        .arg("--")
        .env_remove(OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE)
        .output()
        .expect("spawn operator without capability");
    assert_eq!(missing.status.code(), Some(1));
    assert!(missing.stdout.is_empty());
    let missing_stderr = String::from_utf8(missing.stderr).unwrap();
    assert_eq!(
        missing_stderr,
        "[lexicon] ERROR [operator/host_decoding_failed]: The private background operator-host envelope is invalid.\n"
    );
    assert!(!missing_stderr.contains(OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE));

    let malformed = Command::new(lexicon())
        .current_dir(temp.path())
        .arg("__operator-host")
        .arg(reference)
        .arg("--")
        .env(
            OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE,
            "not-a-capability",
        )
        .output()
        .expect("spawn operator with malformed capability");
    assert_eq!(malformed.status.code(), Some(1));
    assert!(malformed.stdout.is_empty());
    let malformed_stderr = String::from_utf8(malformed.stderr).unwrap();
    assert_eq!(
        malformed_stderr,
        "[lexicon] ERROR [operator/host_decoding_failed]: The private background operator-host envelope is invalid.\n"
    );
    assert!(!malformed_stderr.contains(OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE));
    assert!(!malformed_stderr.contains("not-a-capability"));
}

fn prepare_project() -> (tempfile::TempDir, PathBuf) {
    let temp = tempfile::tempdir().unwrap();
    assert_success(run(temp.path(), &["init", ".", "handoff-project"]), "init");
    let project = temp.path().join("handoff-project");
    assert_success(run(&project, &["source", "create", "example", "--protocol", "http"]), "source create");
    std::fs::write(
        project.join(
            "sources/example/http/get-raw-data/get-raw-data-impl/src/lib.rs",
        ),
        r#"use std::ffi::OsString;
use lexicon_core::http::{AcquisitionResult, HttpAcquisitionContext, HttpSourceContractV1};

pub const SOURCE: HttpSourceContractV1 = HttpSourceContractV1::new(acquire);

pub fn acquire(_: &mut HttpAcquisitionContext, _: &[OsString]) -> AcquisitionResult<()> {
    Ok(())
}
"#,
    )
    .unwrap();
    std::fs::write(
        project.join(
            "sources/example/http/process-data/process-data-impl/src/lib.rs",
        ),
        r#"use std::ffi::OsString;
use lexicon_core::processing::{
    ProcessingContext, ProcessingResult, ProcessingSourceContractV1,
};

pub const PROCESSOR: ProcessingSourceContractV1 =
    ProcessingSourceContractV1::new(process);

pub fn process(context: &mut ProcessingContext, _: &[OsString]) -> ProcessingResult<()> {
    let database = context.create_staged_database()?;
    context.publish_database(database)?;
    Ok(())
}
"#,
    )
    .unwrap();
    assert_success(run(&project, &["source", "build", "example", "--protocol", "http"]), "source build");
    (temp, project)
}

fn assert_owned_authority(sessions: PathBuf) {
    let authority_path = std::fs::read_dir(sessions).unwrap().map(|entry| entry.unwrap().path().join("handoff_authority.json"))
        .find(|path| path.is_file()).expect("handoff authority file");
    let authority = std::fs::read_to_string(authority_path).unwrap();
    assert!(authority.contains(r#""state":"owned""#), "missing Owned evidence: {authority}");
    assert!(!authority.contains("handoff_token"), "private token was persisted: {authority}");
}

fn assert_eventually_terminal_and_summary(operation_root: &Path, expected_state: &str) {
    let sessions = operation_root.join("sessions");
    let session_directory = std::fs::read_dir(&sessions).unwrap()
        .map(|entry| entry.unwrap().path())
        .find(|path| path.join("session.json").is_file())
        .expect("session directory");
    let session_id = session_directory.file_name().unwrap().to_string_lossy().into_owned();
    let record_path = session_directory.join("session.json");
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(15);
    let (record, state) = loop {
        let record = std::fs::read_to_string(&record_path).unwrap();
        let state = ["succeeded", "failed", "abandoned"]
            .into_iter()
            .find(|state| {
                record.contains(&format!("\"state\": \"{state}\""))
                    || record.contains(&format!("\"state\":\"{state}\""))
            });
        if let Some(state) = state {
            break (record, state);
        }
        assert!(std::time::Instant::now() < deadline, "operator host did not reconcile terminal session: {record}");
        std::thread::sleep(std::time::Duration::from_millis(20));
    };
    assert!(record.contains(&session_id));
    assert_eq!(state, expected_state, "unexpected terminal record: {record}");
    let summary_path = operation_root.join("session_status.json");
    loop {
        let summary = std::fs::read_to_string(&summary_path).unwrap();
        let session_matches = summary.contains(&session_id);
        let state_matches = summary.contains(&format!("\"current_state\": \"{state}\""))
            || summary.contains(&format!("\"current_state\":\"{state}\""));
        if session_matches && state_matches {
            break;
        }
        assert!(std::time::Instant::now() < deadline,
            "root summary disagrees with terminal session record: {summary}");
        std::thread::sleep(std::time::Duration::from_millis(20));
    }
}

fn prepared_store() -> (tempfile::TempDir, SessionStore, SessionIdentity, lexicon_core::session::SessionLease) {
    let temp = tempfile::tempdir().unwrap();
    let root = SessionOperationRoot::new(temp.path().join("operation")).unwrap();
    let store = SessionStore::open(root).unwrap();
    let prepared = store.create_prepared(NewSessionRecord {
        project: ProjectInvocationIdentity::new("handoff-project").unwrap(),
        runtime: OwnedRuntimeIdentity::http_acquisition(
            "example", lexicon_core::protocols::http::HttpSourceContractV1::CONTRACT_VERSION,
        ),
        operation: SessionOperation::Acquisition,
        execution_mode: RuntimeExecutionMode::Run,
        supervision_mode: RuntimeSupervisionMode::Background,
    }).unwrap();
    let session = prepared.record().session().clone();
    let (_, lease) = prepared.into_owned_parts();
    (temp, store, session, lease)
}

fn operator(nonce: &str, process_id: u32) -> OperatorIdentityV1 {
    OperatorIdentityV1 { instance_nonce: nonce.to_owned(), process_id }
}

fn future_deadline() -> u64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_nanos()
        .min(u64::MAX as u128) as u64
        + 30_000_000_000
}

#[test]
fn real_background_acquisition_reexecutes_operator_and_publishes_owned_evidence() {
    let (_temp, project) = prepare_project();
    assert_success(run(&project, &["data", "--get", "example", "--protocol", "http", "--bg", "--"]), "background acquisition");
    assert_owned_authority(project.join("sources/example/http/get-raw-data/sessions"));
    assert_eventually_terminal_and_summary(
        &project.join("sources/example/http/get-raw-data"),
        "succeeded",
    );
}

#[test]
fn real_background_processing_uses_the_same_owned_handoff_protocol() {
    let (_temp, project) = prepare_project();
    assert_success(run(&project, &["data", "--process", "example", "--protocol", "http", "--bg", "--"]), "background processing");
    assert_owned_authority(project.join("sources/example/http/process-data/sessions"));
    assert_eventually_terminal_and_summary(
        &project.join("sources/example/http/process-data"),
        "succeeded",
    );
}

#[test]
fn real_operator_host_remains_ready_until_the_initiator_releases_lease() {
    let (_temp, project) = prepare_project();
    let operation_root = project.join("sources/example/http/get-raw-data");
    let store = SessionStore::open(SessionOperationRoot::new(operation_root).unwrap()).unwrap();
    let prepared = store.create_prepared(NewSessionRecord {
        project: ProjectInvocationIdentity::new("handoff-project").unwrap(),
        runtime: OwnedRuntimeIdentity::http_acquisition(
            "example", lexicon_core::protocols::http::HttpSourceContractV1::CONTRACT_VERSION,
        ),
        operation: SessionOperation::Acquisition,
        execution_mode: RuntimeExecutionMode::Run,
        supervision_mode: RuntimeSupervisionMode::Background,
    }).unwrap();
    let session = prepared.record().session().clone();
    let (_, initiating_lease) = prepared.into_owned_parts();
    let token = HandoffToken::generate().unwrap();
    let nonce = lexicon_core::session::generate_instance_nonce().unwrap();
    let reservation = store.reserve_handoff(
        &session, &initiating_lease, token.digest(),
        OperatorIdentityV1 { instance_nonce: nonce.clone(), process_id: 0 }, future_deadline(),
    ).unwrap();
    let reference = OperatorHostInvocationV1::new_reserved(
        "example", "http", DataOperation::Acquisition, session.clone(),
        reservation.epoch, nonce,
    ).unwrap();
    let mut child = Command::new(lexicon()).current_dir(&project)
        .arg("__operator-host").arg(reference.to_json().unwrap()).arg("--")
        .env(
            OPERATOR_HOST_HANDOFF_TOKEN_ENVIRONMENT_VARIABLE,
            token.expose_hex_for_private_transport(),
        )
        .spawn().expect("spawn real operator host");

    let ready_deadline = std::time::Instant::now() + std::time::Duration::from_secs(10);
    let _ready = loop {
        let authority = store.load_handoff_authority(&session).unwrap().unwrap();
        if matches!(&authority.state, HandoffAuthorityStateV1::Ready { .. }) { break authority; }
        assert!(std::time::Instant::now() < ready_deadline, "operator did not publish Ready");
        std::thread::sleep(std::time::Duration::from_millis(10));
    };
    assert!(child.try_wait().unwrap().is_none(), "operator exited while initiator retained lease");
    std::thread::sleep(std::time::Duration::from_millis(100));
    assert!(matches!(store.load_handoff_authority(&session).unwrap().unwrap().state, HandoffAuthorityStateV1::Ready { .. }),
        "Ready must not be treated as Owned while initiator retains the lease");

    drop(initiating_lease);
    let owned_deadline = std::time::Instant::now() + std::time::Duration::from_secs(10);
    let owned = loop {
        let authority = store.load_handoff_authority(&session).unwrap().unwrap();
        if matches!(&authority.state, HandoffAuthorityStateV1::Owned { .. }) { break authority; }
        assert!(std::time::Instant::now() < owned_deadline, "operator did not publish Owned");
        std::thread::sleep(std::time::Duration::from_millis(10));
    };
    assert_eq!(owned.expected_operator.process_id, child.id());
    child.wait().unwrap();
}

#[test]
fn reserved_and_ready_are_deterministic_contention_barriers() {
    let (_temp, store, session, initiating_lease) = prepared_store();
    let token = HandoffToken::generate().unwrap();
    let nonce = "barrier-nonce";
    let reservation = store.reserve_handoff(
        &session,
        &initiating_lease,
        token.digest(),
        operator(nonce, 0),
        future_deadline(),
    ).unwrap();
    drop(initiating_lease);

    assert!(matches!(
        store.acquire_lease(&session),
        Err(SessionLeaseError::ReservedForSuccessor { epoch }) if epoch == reservation.epoch
    ));

    let proof = HandoffClaimProof {
        session_id: session.id().to_owned(),
        epoch: reservation.epoch,
        token,
        operator: operator(nonce, 47_001),
    };
    store.mark_handoff_ready(&proof).unwrap();
    assert!(matches!(
        store.acquire_lease(&session),
        Err(SessionLeaseError::ReservedForSuccessor { epoch }) if epoch == reservation.epoch
    ));
    assert!(store.reconcile_stale_current_session(&session).unwrap().is_none());
    assert_eq!(store.load(&session).unwrap().state(), SessionState::Prepared);
}

#[test]
fn authenticated_ready_fence_prevents_late_claim_and_replay() {
    let (_temp, store, session, initiating_lease) = prepared_store();
    let token = HandoffToken::generate().unwrap();
    let token_transport = token.expose_hex_for_private_transport();
    let expected = operator("fence-nonce", 47_002);
    let reservation = store.reserve_handoff(
        &session,
        &initiating_lease,
        token.digest(),
        operator("fence-nonce", 0),
        future_deadline(),
    ).unwrap();
    let proof = HandoffClaimProof {
        session_id: session.id().to_owned(),
        epoch: reservation.epoch,
        token,
        operator: expected.clone(),
    };
    store.mark_handoff_ready(&proof).unwrap();
    drop(initiating_lease);

    assert_eq!(
        store.fence_ready_handoff(
            &session,
            reservation.epoch,
            &HandoffToken::from_hex(&token_transport).unwrap(),
            &expected,
            HandoffRevocationReasonV1::Timeout,
        ).unwrap(),
        HandoffFenceOutcome::Revoked,
    );
    let replay = HandoffClaimProof {
        session_id: session.id().to_owned(),
        epoch: reservation.epoch,
        token: HandoffToken::from_hex(&token_transport).unwrap(),
        operator: expected,
    };
    assert!(matches!(
        store.acquire_reserved_handoff(&replay),
        Err(lexicon_core::session::SessionStoreError::Handoff(HandoffProtocolError::InvalidState))
    ));
}

#[test]
fn malformed_final_authority_document_fails_closed() {
    let (_temp, store, session, initiating_lease) = prepared_store();
    let token = HandoffToken::generate().unwrap();
    store.reserve_handoff(
        &session,
        &initiating_lease,
        token.digest(),
        operator("partial-document", 0),
        future_deadline(),
    ).unwrap();
    let authority = store.operation_root().handoff_authority_path(&session);
    std::fs::write(&authority, br#"{"schema_version":1,"session_id":"#).unwrap();
    assert!(matches!(
        store.load_handoff_authority(&session),
        Err(HandoffProtocolError::Decoding(_))
    ));
    drop(initiating_lease);
    assert!(matches!(
        store.acquire_lease(&session),
        Err(SessionLeaseError::Io(_))
    ));
}

#[test]
fn incomplete_unique_staged_sibling_is_ignored_until_final_publication() {
    let (_temp, store, session, initiating_lease) = prepared_store();
    let token = HandoffToken::generate().unwrap();
    let reservation = store.reserve_handoff(
        &session,
        &initiating_lease,
        token.digest(),
        operator("staged-sibling", 0),
        future_deadline(),
    ).unwrap();
    let final_path = store.operation_root().handoff_authority_path(&session);
    let staged_path = final_path.with_file_name(format!(
        ".handoff_authority.json.staged-test-{}",
        std::process::id(),
    ));
    std::fs::write(&staged_path, br#"{"schema_version":1"#).unwrap();
    let observed = store.load_handoff_authority(&session).unwrap().unwrap();
    assert_eq!(observed.epoch, reservation.epoch);
    assert!(matches!(observed.state, HandoffAuthorityStateV1::Reserved));
    assert!(staged_path.is_file(), "reader must not consume a staged sibling");
}

#[test]
fn expired_reservation_is_revoked_before_ordinary_acquisition() {
    let (_temp, store, session, initiating_lease) = prepared_store();
    let expires = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap()
        .as_nanos()
        .min(u64::MAX as u128) as u64
        + 100_000_000;
    let token = HandoffToken::generate().unwrap();
    store.reserve_handoff(
        &session,
        &initiating_lease,
        token.digest(),
        operator("expiry-nonce", 0),
        expires,
    ).unwrap();
    drop(initiating_lease);
    let wait_deadline = std::time::Instant::now() + std::time::Duration::from_secs(2);
    loop {
        let now = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
            .min(u64::MAX as u128) as u64;
        if now > expires {
            break;
        }
        assert!(std::time::Instant::now() < wait_deadline, "wall clock did not pass reservation expiry");
        std::thread::sleep(std::time::Duration::from_millis(1));
    }
    let lease = store.acquire_lease(&session).expect("expired reservation must not fence forever");
    drop(lease);
    assert!(matches!(
        store.load_handoff_authority(&session).unwrap().unwrap().state,
        HandoffAuthorityStateV1::Revoked {
            reason: HandoffRevocationReasonV1::Expired,
            ..
        }
    ));
}

fn prepare_slow_acquisition_project() -> (tempfile::TempDir, PathBuf) {
    let temp = tempfile::tempdir().unwrap();
    assert_success(run(temp.path(), &["init", ".", "handoff-project"]), "init");
    let project = temp.path().join("handoff-project");
    assert_success(run(&project, &["source", "create", "example", "--protocol", "http"]), "source create");
    let implementation = project.join(
        "sources/example/http/get-raw-data/get-raw-data-impl/src/lib.rs",
    );
    let source = std::fs::read_to_string(&implementation).unwrap();
    let source = source.replace(
        "    todo!(\"implement HTTP acquisition\")",
        "    std::thread::sleep(std::time::Duration::from_secs(5));\n    Ok(())",
    );
    assert!(source.contains("Duration::from_secs(5)"));
    std::fs::write(implementation, source).unwrap();
    assert_success(run(&project, &["source", "build", "example", "--protocol", "http"]), "source build");
    (temp, project)
}

#[cfg(target_os = "linux")]
fn prepare_descendant_acquisition_project() -> (tempfile::TempDir, PathBuf) {
    let temp = tempfile::tempdir().unwrap();
    assert_success(run(temp.path(), &["init", ".", "handoff-project"]), "init");
    let project = temp.path().join("handoff-project");
    assert_success(run(&project, &["source", "create", "example", "--protocol", "http"]), "source create");
    let implementation = project.join(
        "sources/example/http/get-raw-data/get-raw-data-impl/src/lib.rs",
    );
    let source = std::fs::read_to_string(&implementation).unwrap();
    let replacement = r#"    let pid_path = context.source_state_directory().join("descendant.pid");
    let mut descendant = std::process::Command::new("/bin/sh")
        .arg("-c")
        .arg("sleep 30 & echo $! > \"$1\"; wait")
        .arg("lexicon-descendant-test")
        .arg(&pid_path)
        .spawn()
        .expect("spawn descendant tree");
    let _ = descendant.wait();
    Ok(())"#;
    let source = source.replace(
        "    let _ = (context, arguments);\n    todo!(\"implement HTTP acquisition\")",
        &format!("    let _ = arguments;\n{replacement}"),
    );
    assert!(source.contains("descendant.pid"));
    std::fs::write(implementation, source).unwrap();
    assert_success(run(&project, &["source", "build", "example", "--protocol", "http"]), "source build");
    (temp, project)
}

#[test]
fn background_cli_returns_after_owned_without_waiting_for_runtime_completion() {
    let (_temp, project) = prepare_slow_acquisition_project();
    let started = std::time::Instant::now();
    assert_success(
        run(&project, &["data", "--get", "example", "--protocol", "http", "--bg", "--"]),
        "background acquisition",
    );
    assert!(
        started.elapsed() < std::time::Duration::from_secs(4),
        "the initiating CLI retained the detached operator host's lifetime or stdio",
    );
    assert_owned_authority(project.join("sources/example/http/get-raw-data/sessions"));
}

#[cfg(windows)]
#[test]
fn windows_operator_host_does_not_retain_initiator_output_pipes() {
    let (_temp, project) = prepare_slow_acquisition_project();
    let started = std::time::Instant::now();
    let output = run(
        &project,
        &["data", "--get", "example", "--protocol", "http", "--bg", "--"],
    );
    assert_success(output, "background acquisition");
    assert!(
        started.elapsed() < std::time::Duration::from_secs(4),
        "Command::output remained blocked by operator-host stdout/stderr handles",
    );
    assert_owned_authority(project.join("sources/example/http/get-raw-data/sessions"));
}

#[cfg(target_os = "linux")]
#[test]
fn detached_operator_host_owns_a_new_native_session_and_process_group() {
    let (_temp, project) = prepare_slow_acquisition_project();
    assert_success(
        run(&project, &["data", "--get", "example", "--protocol", "http", "--bg", "--"]),
        "background acquisition",
    );
    let sessions = project.join("sources/example/http/get-raw-data/sessions");
    let authority_path = std::fs::read_dir(sessions).unwrap()
        .map(|entry| entry.unwrap().path().join("handoff_authority.json"))
        .find(|path| path.is_file()).unwrap();
    let authority = std::fs::read_to_string(authority_path).unwrap();
    let marker = "\"process_id\":";
    let start = authority.find(marker).unwrap() + marker.len();
    let pid: u32 = authority[start..].split(|character: char| !character.is_ascii_digit())
        .next().unwrap().parse().unwrap();
    let stat = std::fs::read_to_string(format!("/proc/{pid}/stat")).unwrap();
    let after_name = &stat[stat.rfind(')').unwrap() + 1..];
    let fields: Vec<_> = after_name.split_whitespace().collect();
    let process_group: u32 = fields[2].parse().unwrap();
    let native_session: u32 = fields[3].parse().unwrap();
    assert_eq!(process_group, pid, "operator host did not create its own process group");
    assert_eq!(native_session, pid, "operator host did not detach into its own Unix session");
}

#[cfg(target_os = "linux")]
#[test]
fn killing_real_operator_host_does_not_orphan_source_descendants() {
    let (_temp, project) = prepare_descendant_acquisition_project();
    assert_success(
        run(&project, &["data", "--get", "example", "--protocol", "http", "--bg", "--"]),
        "background acquisition",
    );
    let operation_root = project.join("sources/example/http/get-raw-data");
    let sessions = operation_root.join("sessions");
    let session_directory = std::fs::read_dir(&sessions).unwrap()
        .map(|entry| entry.unwrap().path())
        .find(|path| path.join("handoff_authority.json").is_file())
        .unwrap();
    let authority = std::fs::read_to_string(session_directory.join("handoff_authority.json")).unwrap();
    let marker = "\"process_id\":";
    let start = authority.find(marker).unwrap() + marker.len();
    let operator_pid: i32 = authority[start..]
        .split(|character: char| !character.is_ascii_digit())
        .next().unwrap().parse().unwrap();
    let descendant_path = operation_root.join("state/descendant.pid");
    let ready_deadline = std::time::Instant::now() + std::time::Duration::from_secs(10);
    while !descendant_path.is_file() {
        assert!(std::time::Instant::now() < ready_deadline, "source descendant did not publish pid");
        std::thread::sleep(std::time::Duration::from_millis(10));
    }
    let descendant_pid: i32 = std::fs::read_to_string(&descendant_path).unwrap().trim().parse().unwrap();
    assert!(Command::new("/bin/kill")
        .arg("-KILL")
        .arg("--")
        .arg(format!("-{operator_pid}"))
        .status().unwrap().success());

    let death_deadline = std::time::Instant::now() + std::time::Duration::from_secs(10);
    loop {
        let state = std::fs::read_to_string(format!("/proc/{descendant_pid}/stat"));
        let terminated = match state {
            Err(error) if error.kind() == std::io::ErrorKind::NotFound => true,
            Ok(stat) => stat[stat.rfind(')').unwrap() + 1..]
                .split_whitespace().next().is_some_and(|state| state == "Z"),
            Err(error) => panic!("failed to inspect descendant: {error}"),
        };
        if terminated { break; }
        assert!(std::time::Instant::now() < death_deadline,
            "source descendant survived operator-host death");
        std::thread::sleep(std::time::Duration::from_millis(10));
    }

    let session = SessionIdentity::new(session_directory.file_name().unwrap().to_string_lossy().into_owned()).unwrap();
    let store = SessionStore::open(SessionOperationRoot::new(operation_root.clone()).unwrap()).unwrap();
    let reconciled = store.reconcile_stale_current_session(&session).unwrap().unwrap();
    assert_eq!(reconciled.state(), SessionState::Failed);
    let summary = std::fs::read_to_string(operation_root.join("session_status.json")).unwrap();
    assert!(summary.contains(session.id()));
    assert!(summary.contains("\"current_state\": \"failed\""));
}
