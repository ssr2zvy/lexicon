use std::process::Command;

fn lexicon() -> Command {
    Command::new(env!("CARGO_BIN_EXE_lexicon"))
}

#[test]
fn invalid_usage_has_one_coded_status_two_outcome() {
    let cases: &[&[&str]] = &[
        &["unknown-command"],
        &["source", "build", "example-source"],
        &[
            "data",
            "--get",
            "example-source",
            "--protocol",
            "http",
        ],
        &[
            "data",
            "--get",
            "example-source",
            "--process",
            "other-source",
            "--protocol",
            "http",
            "--",
        ],
    ];

    for arguments in cases {
        let output = lexicon().args(*arguments).output().unwrap();
        assert_eq!(output.status.code(), Some(2), "arguments: {arguments:?}");
        assert!(output.stdout.is_empty(), "arguments: {arguments:?}");
        assert_eq!(
            String::from_utf8(output.stderr).unwrap(),
            "[lexicon] ERROR [cli/invalid_arguments]: The command arguments are invalid; run `lexicon --help` for the supported grammar.\n",
            "arguments: {arguments:?}",
        );
    }
}

#[test]
fn project_initialization_failure_omits_rejected_raw_name() {
    let temp = tempfile::tempdir().unwrap();
    let output = lexicon()
        .current_dir(temp.path())
        .args(["init", ".", "secret/bad-name"])
        .output()
        .unwrap();

    assert_eq!(output.status.code(), Some(1));
    assert!(output.stdout.is_empty());
    let stderr = String::from_utf8(output.stderr).unwrap();
    assert_eq!(
        stderr,
        "[lexicon] ERROR [project/initialization_failed]: The Lexicon project could not be initialized atomically.\n"
    );
    assert!(!stderr.contains("secret/bad-name"));
}

#[test]
fn help_and_version_remain_successful_display_outcomes() {
    for argument in ["--help", "--version"] {
        let output = lexicon().arg(argument).output().unwrap();
        assert!(output.status.success(), "{argument} must succeed");
        assert!(output.stderr.is_empty(), "{argument} wrote an error");
        let stdout = String::from_utf8_lossy(&output.stdout);
        assert!(!stdout.is_empty(), "{argument} produced no display output");
        assert!(!stdout.contains("[lexicon] ERROR"));
    }
}

#[test]
fn successful_init_emits_one_project_milestone() {
    let temp = tempfile::tempdir().unwrap();
    let output = lexicon()
        .current_dir(temp.path())
        .args(["init", ".", "example-project"])
        .output()
        .unwrap();

    assert!(output.status.success());
    assert!(output.stderr.is_empty());
    let stdout = String::from_utf8(output.stdout).unwrap();
    assert_eq!(
        stdout,
        "[lexicon] MILESTONE [project/initialized]: project='example-project'\n"
    );
    assert_eq!(stdout.lines().count(), 1);
    assert!(!temp.path().join("lexicon.log").exists());
    assert!(!temp.path().join("example-project/lexicon.log").exists());
}

#[test]
fn commands_do_not_create_a_general_lexicon_log() {
    let temp = tempfile::tempdir().unwrap();
    let output = lexicon()
        .current_dir(temp.path())
        .args(["init", ".", "no-general-log-project"])
        .output()
        .unwrap();

    assert!(output.status.success());
    assert!(!temp.path().join("lexicon.log").exists());
    assert!(
        !temp
            .path()
            .join("no-general-log-project/lexicon.log")
            .exists()
    );
}

#[cfg(unix)]
#[test]
fn successful_milestone_cannot_be_extended_by_a_newline_in_the_parent_path() {
    let temp = tempfile::tempdir().unwrap();
    let parent = temp
        .path()
        .join("line-break\n[lexicon] ERROR [forged/code]: forged");
    std::fs::create_dir(&parent).unwrap();

    let output = lexicon()
        .current_dir(&parent)
        .args(["init", ".", "example-project"])
        .output()
        .unwrap();

    assert!(output.status.success());
    assert!(output.stderr.is_empty());
    assert_eq!(
        String::from_utf8(output.stdout).unwrap(),
        "[lexicon] MILESTONE [project/initialized]: project='example-project'\n"
    );
}
