# Verification Manifest Format

This document specifies the durable evidence record produced by
`.github/workflows/conformance.yml` through
`automation/verification/conformance.py`. The checked-in
`verification-manifest.json` remains an explicitly non-evidentiary schema
placeholder: only per-platform manifests uploaded by an actual workflow run
are evidence.

Every future green Lexicon build must emit a `verification-manifest.json`
whose structure matches this schema, and the final conformance job must treat
the matrix step as a hard prerequisite.

The schema complements the policy in
[`workspace/specs/release-policy.md`](../workspace/specs/release-policy.md).
A number in `current.md` (or its successor) without the attached verification
manifest and durable run link is **not** evidence.

## Schema (v1)

```json
{
  "schema_version": 1,
  "result": "passed | failed",
  "failure": "<empty on success; typed summary on failure>",
  "repository": "https://github.com/ssr2zvy/lexicon",
  "commit": "<40-character sha>",
  "dirty": false,
  "os": "linux-x86_64 | windows-x86_64",
  "architecture": "x86_64 | aarch64",
  "rustc": "rustc 1.98.0 (xxxx 2026-xx-xx)",
  "cargo": "cargo 1.98.0 (xxxx 2026-xx-xx)",
  "mza_commit": "<pinned MZA sha or empty if not yet signed>",
  "commands": [
    {
      "argv": ["cargo", "check", "--workspace", "--locked"],
      "exit_code": 0,
      "started_at": "RFC3339 timestamp",
      "finished_at": "RFC3339 timestamp",
      "stdout_sha256": "<sha256>",
      "stderr_sha256": "<sha256>",
      "stdout_path": "<artifact-relative log>",
      "stderr_path": "<artifact-relative log>"
    }
  ],
  "tests": {
    "passed": <int>,
    "failed": 0,
    "ignored": <int>,
    "ignored_required": 0,
    "outer_workflow_skipped": 0
  },
  "artifacts": [
    "verification-manifest.json",
    "01-rustc--V.stdout.log"
  ]
}
```

### Field semantics

- `schema_version` is `1` until a future intentional bump. Bumps are
  incompatible and require a synchronized `current.md` update.
- `result` is `passed` only when every command, toolchain, cleanliness, test,
  and ignored-required-test gate passes. A failed job may still upload a
  `result = failed` diagnostic manifest; it is never success evidence.
- `commit` is the exact 40-character commit SHA the workflow ran against.
  Branch protection requires this SHA to match the intended merge commit.
- `dirty` is `false` only when the tested checkout exactly matches `commit`
  both before and after command execution. Evidence and Cargo targets are
  written outside the checkout so generated evidence cannot hide a source
  mutation by a build script or test.
- `os` and `architecture` describe the native CI runner. Cross-compiled
  artifacts require a follow-up native run before promotion.
- `rustc` and `cargo` capture the runner's actual toolchain versions. The
  workflow must pin its toolchain source; these values are the verbatim
  `rustc -V` and `cargo -V` outputs.
- `mza_commit` is the pin from MZA's accepted installer API. Until that API is
  accepted, the field is empty and `current.md` §3 keeps the master milestone
  open.
- `commands[].argv` is the exact argument vector invoked; `started_at` and
  `finished_at` are RFC3339 timestamps recorded around the OS execution
  boundary.
- `commands[].stdout_sha256` and `commands[].stderr_sha256` hash the captured
  raw streams. The final job recomputes every hash, rejects path traversal,
  and requires the manifest artifact set to equal the downloaded file set.
- `tests.passed`, `failed`, and `ignored` are native test rollups. Some ignored
  libtest entries are subprocess helpers rather than required assertions.
  `ignored_required` is the intersection of the ignored-test list with the
  exact tests named by `workspace/specs/conformance.toml`; it must be zero.
  `outer_workflow_skipped` counts platform skips reported by the outer
  workflow; nonzero is a hard failure.
- `artifacts` lists manifest-adjacent files actually uploaded with the run.

### Retention

- Each native job uploads its manifest, test index, ignored-test index, and raw
  logs under a pinned workflow action. The final job merges Linux and Windows
  test indexes before running the conformance checker so cfg-gated tests are
  validated against the complete native evidence set.
- The final job binds both native manifests to `${{ github.sha }}`, the exact
  command sequence, repository identity, native platform/architecture, pinned
  Rust version, zero skipped/failed/required-ignored tests, and authenticated
  stream hashes before it creates the merged test index.
- A green run uploads the manifest and raw logs under a pinned workflow action
  and a documented retention period.
- Release promotion links the latest green manifest alongside the SBOM and
  audit ledger.
- A red run must not publish a success manifest; it records a typed failure in
  the workflow summary instead.

### Native Windows evidence

Cross-compilation is not native runtime evidence. The native Windows
requirement is implemented by the `native-windows-x86_64` job on the
`windows-2025` runner. It runs the full workspace checks and tests natively;
the merged final job rejects missing, mislabeled, malformed, cross-commit, or
hash-inconsistent Windows evidence.
